#!/bin/sh

set -eu

build_obs_area_creator() {
    docker build -t iris-obs-area-creator --ssh default -f ../docker/obs-area-creator.builder.Dockerfile $@ ../..
}

run_obs_area_creator() {
    export $(cat ./.env.obs_area_creator | xargs) && docker compose \
        -f docker-compose-obs-area-creator.yml \
        up \
        --abort-on-container-exit \
        --exit-code-from obs-area-creator $@ \
        -- obs-area-creator
}

$*
