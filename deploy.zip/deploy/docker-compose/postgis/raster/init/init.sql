CREATE DATABASE iris_raster WITH OWNER postgres;
\c iris_raster
CREATE EXTENSION IF NOT EXISTS postgis;
