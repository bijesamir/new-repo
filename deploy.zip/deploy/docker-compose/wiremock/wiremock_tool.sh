#!/bin/sh

set -eu

GRPC_VERSION=0.6.0
URL=https://repo1.maven.org/maven2/org/wiremock

BASEDIR=$(dirname $0)

download_extensions() {
  curl -o ${BASEDIR}/extensions/wiremock-grpc-extension-standalone-${GRPC_VERSION}.jar \
    ${URL}/wiremock-grpc-extension-standalone/${GRPC_VERSION}/wiremock-grpc-extension-standalone-${GRPC_VERSION}.jar
}

get_proto_files() {
  FILES=(
    'api/proto/contracts/metadata.proto'
    'api/proto/services/verification/verification.proto'
    'api/proto/models/user.proto'
    'api/proto/models/package.proto'
    'api/proto/models/contract.proto'
    'api/proto/models/operator.proto'
    'api/proto/models/token.proto'
    'api/proto/models/role.proto'
    'api/proto/models/enums.proto'
    'api/proto/events/enums.proto'
    'api/proto/events/tasks/formula.proto'
    'api/proto/events/tasks/notification.proto'
    'api/proto/events/tasks/notification.proto'
  )

  rm -rf "${BASEDIR}/.tmp/citadel"
  for FILE in ${FILES[@]}; do
    mkdir -p "${BASEDIR}/.tmp/citadel/$(dirname ${FILE})"
    PAGER=cat gh api -H 'Accept: application/vnd.github.v3.raw' "repos/synspective/syns-citadel-v2/contents/${FILE}" > ${BASEDIR}/.tmp/citadel/${FILE}
  done
}

generate_descriptors() {
  protoc -I ${BASEDIR}/.tmp/citadel --include_imports \
    ${BASEDIR}/.tmp/citadel/api/proto/*/*.proto \
    ${BASEDIR}/.tmp/citadel/api/proto/*/*/*.proto \
    --descriptor_set_out ${BASEDIR}/data/citadel/grpc/verification.dsc
}

$*
