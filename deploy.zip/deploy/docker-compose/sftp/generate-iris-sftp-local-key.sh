#!/bin/bash
set -e

DIRNAME=`dirname $0`

mkdir -p ${DIRNAME}/.keys
mkdir -p ${DIRNAME}/../../../backend/.sftp

if [ -f ${DIRNAME}/.keys/iris-sftp-local.key ]; then
  echo "Use what already exists. ${DIRNAME}"
else
  ssh-keygen -t ed25519 -C "iris-sftp-local" -f ${DIRNAME}/.keys/iris-sftp-local.key -N ""
fi
