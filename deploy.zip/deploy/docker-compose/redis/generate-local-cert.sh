#!/bin/bash

# Source: https://github.com/redis/redis/blob/unstable/utils/gen-test-certs.sh
# Generate some test certificates which are used by the regression test suite:
#
#   ${DIRNAME}/.redis-tls/ca.{crt,key}          Self signed CA certificate.
#   ${DIRNAME}/.redis-tls/redis.{crt,key}       A certificate with no key usage/policy restrictions.
#   ${DIRNAME}/.redis-tls/client.{crt,key}      A certificate restricted for SSL client usage.
#   ${DIRNAME}/.redis-tls/server.{crt,key}      A certificate restricted for SSL server usage.
#   ${DIRNAME}/.redis-tls/redis.dh              DH Params file.

DIRNAME=`dirname $0`



generate_cert() {
    local name=$1
    local cn="$2"
    local opts="$3"

    local keyfile=${DIRNAME}/.redis-tls/${name}.key
    local certfile=${DIRNAME}/.redis-tls/${name}.crt

    [ -f $keyfile ] || openssl genrsa -out $keyfile 2048
    openssl req \
        -new -sha256 \
        -subj "/O=Redis Test/CN=$cn" \
        -key $keyfile | \
        openssl x509 \
            -req -sha256 \
            -CA ${DIRNAME}/.redis-tls/ca.crt \
            -CAkey ${DIRNAME}/.redis-tls/ca.key \
            -CAserial ${DIRNAME}/.redis-tls/ca.txt \
            -CAcreateserial \
            -days 365 \
            $opts \
            -out $certfile
}

mkdir -p ${DIRNAME}/.redis-tls
[ -f ${DIRNAME}/.redis-tls/ca.key ] || openssl genrsa -out ${DIRNAME}/.redis-tls/ca.key 4096
openssl req \
    -x509 -new -nodes -sha256 \
    -key ${DIRNAME}/.redis-tls/ca.key \
    -days 3650 \
    -subj '/O=Redis Test/CN=Certificate Authority' \
    -out ${DIRNAME}/.redis-tls/ca.crt

cat > ${DIRNAME}/.redis-tls/openssl.cnf <<_END_
[ server_cert ]
keyUsage = digitalSignature, keyEncipherment
nsCertType = server
[ client_cert ]
keyUsage = digitalSignature, keyEncipherment
nsCertType = client
_END_

generate_cert server "Server-only" "-extfile ${DIRNAME}/.redis-tls/openssl.cnf -extensions server_cert"
generate_cert client "Client-only" "-extfile ${DIRNAME}/.redis-tls/openssl.cnf -extensions client_cert"
generate_cert redis "Generic-cert"

[ -f ${DIRNAME}/.redis-tls/redis.dh ] || openssl dhparam -out ${DIRNAME}/.redis-tls/redis.dh 2048

[ -f ${DIRNAME}/.redis-tls/connection.json ] || cat << END_JSON  >> ${DIRNAME}/.redis-tls/connection.json
{
  "connections": [
    {
      "label": "local",
      "host": "iris-redis-local",
      "port": 6379,
      "password": "redis",
      "dbIndex": 0,
      "tls": {
        "ca": "`cat ${DIRNAME}/.redis-tls/ca.crt | perl -pe 's/\\n/\\\\n/g'`",
        "key": "`cat ${DIRNAME}/.redis-tls/redis.key | perl -pe 's/\\n/\\\\n/g'`"
      }
    }
  ]
}
END_JSON
