#!/bin/bash
set -e

DIRNAME=`dirname $0`

DEST_BASE_PATH=${DIRNAME}/../../../backend/.fake-gcs/preload
DPS_BUCKET='syns-gro-dev_product-data-store'
DPS_PATH_LIST=(
  iris/202310-00040_20231027232510_SM_test/15-PR-13-dps-20240116051509-auto-000/CEOS
  iris/202310-00040_20231027232510_SM_test/15-PR-13-dps-20240116051509-auto-000/SICD
  iris/202310-00040_20231027232510_SM_test/15-PR-13-dps-20240116051509-auto-000/GRD
  iris/202310-00040_20231027232510_SM_test/15-PR-13-dps-20240116051509-auto-000/ORT
  iris/202312-00048_20231231231112_SM_test/14-PR-11-dps-20240103012300-correct1-001/SR-GRD
)
IRIS_BUCKET='syns-daas-dev_iris-product-data-store'
IRIS_PATH_LIST=(
  fixtures/CEOS
  fixtures/SICD
  fixtures/GRD
  fixtures/ORT
  fixtures/SR-GRD
)

download() {
  local argv=($@)
  local argn=${#argv[@]}

  local SOURCE_BUCKET=${argv[0]}
  local SOURCE_PATH_LIST=("${argv[@]:1:$argn-2}")
  local DEST_PATH=${argv[$argn-1]}

  for SPL in ${SOURCE_PATH_LIST[@]}; do
    local PRODUCT_TYPE=$(basename ${SPL})

    if [ -d "${DEST_PATH}/${PRODUCT_TYPE}" ]; then
      # skip if folder already downloaded
      continue
    fi

    mkdir -p ${DEST_PATH}/${PRODUCT_TYPE}
    gcloud storage cp "gs://${SOURCE_BUCKET}/${SPL}/*" "${DEST_PATH}/${PRODUCT_TYPE}"
  done  
}

download ${DPS_BUCKET}  ${DPS_PATH_LIST[@]}  ${DEST_BASE_PATH}/dps_bucket
download ${IRIS_BUCKET} ${IRIS_PATH_LIST[@]} ${DEST_BASE_PATH}/iris_bucket/fixtures

