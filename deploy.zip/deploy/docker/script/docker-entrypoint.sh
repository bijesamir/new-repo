#!/bin/sh
set -e

exec "$@"
