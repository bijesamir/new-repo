#!/bin/sh

set -e

PROJECT_ID=$1

gcloud secrets versions access 1 \
  --secret="github-syns-dat-sids-ssh-private-key" \
  --project=${PROJECT_ID} >/root/.ssh/id_ed25519
chmod 600 /root/.ssh/id_ed25519

cat <<EOF >/root/.ssh/config
Hostname github.com
  IdentityFile /root/.ssh/id_ed25519
  User git
EOF

ssh-keyscan -t rsa github.com >/root/.ssh/known_hosts

git config --global user.name "syns-dat-sids"
git config --global user.email "dat_sids@synspective.com"
git config --global url."git@github.com:".insteadOf "https://github.com/"
