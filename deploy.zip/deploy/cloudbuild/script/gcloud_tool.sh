#!/bin/sh

set -eu

tag_image() {
  ARTIFACT_REPO=$1
  DOCKER_IMAGE=${ARTIFACT_REPO}/$2
  DOCKER_TAG=${ARTIFACT_REPO}/$3
  PROJECT_ID=$4

  gcloud beta artifacts docker tags add \
    ${DOCKER_IMAGE} \
    ${DOCKER_TAG} \
    --project=${PROJECT_ID}
}

$*
