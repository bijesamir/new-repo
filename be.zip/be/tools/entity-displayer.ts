import yargs from 'yargs';
import { DataSource, DataSourceOptions } from 'typeorm';
import { generateDbConfig } from '@iris-lib/db';

const parseArgs = async () => {
  return await yargs
    .command(
      '* <entity>',
      `get entities from <entity> (ex: ProductData)`,
      (tmp) => {
        tmp.positional('entity', {
          type: 'string',
          example: 'ProductData',
        });
        tmp.option('stringify', {
          type: 'boolean',
          alias: 's',
          default: false,
          description: 'Stringify result',
        });
        tmp.option('relations', {
          type: 'string',
          alias: 'r',
          array: true,
          default: [],
          description: 'Array of relations to load (separated by space)',
          example: 'taskingInfo.satellite productDataVersions',
        });
      },
    )
    .demandCommand(1)
    .boolean('stringify')
    .array('relations')
    .help().argv;
};

const main = async () => {
  const args = await parseArgs();
  const dataSource = await new DataSource(
    generateDbConfig().db as DataSourceOptions,
  ).initialize();

  const result = await dataSource.manager
    .getRepository(args.entity as string)
    .find({ relations: args.relations as string[] });
  if (args.stringify) {
    console.log(JSON.stringify(result));
  } else {
    console.log(result);
  }

  await dataSource.destroy();
};

(async () => {
  await main();
})();
