import { PubSub } from '@google-cloud/pubsub';
import * as yargs from 'yargs';

const getStdIn = async () => {
  const tmp = await new Promise<Buffer[]>((res, rej) => {
    try {
      const rtn = new Array<Buffer>();
      process.stdin.on('data', function (chunk) {
        rtn.push(chunk);
      });
      process.stdin.on('end', function () {
        res(rtn);
      });
    } catch (e) {
      rej(e);
    }
  });
  return Buffer.concat(tmp);
};

const parseArgs = async () => {
  return await yargs
    .command(
      '* <topic> [pattern]',
      `send event with optional [pattern] as pubsub attribute to <topic>
      (ex: iris-storage-notification import-observable-area)`,
      (tmp) => {
        tmp.positional('topic', { type: 'string' });
        tmp.positional('pattern', { type: 'string' });
      },
    )
    .demandCommand(1)
    .help().argv;
};

const main = async () => {
  const c = new PubSub({
    apiEndpoint: process.env.PUBSUB_EMULATOR_HOST,
  });

  const parsedArgs = await parseArgs();
  const eventData = await getStdIn();
  console.log('args:', parsedArgs);
  console.log('input data:', eventData.toString());

  const message = { data: eventData };
  if (parsedArgs.pattern) {
    message['attributes'] = {
      pattern: parsedArgs.pattern as string,
    };
  }

  const result = await c
    .topic(parsedArgs.topic as string)
    .publishMessage(message);

  console.log('messageId:', result);
};

(async () => {
  await main();
})();
