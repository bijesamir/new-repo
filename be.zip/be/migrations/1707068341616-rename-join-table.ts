import { MigrationInterface, QueryRunner } from "typeorm";

export class RenameJoinTable1707068341616 implements MigrationInterface {
    name = 'RenameJoinTable1707068341616'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE archive_purchase_requests_reprocessing_requests
            RENAME TO join_archive_purchase_request_on_reprocessing_request
        `);
        await queryRunner.query(`
            ALTER TABLE "join_archive_purchase_request_on_reprocessing_request" DROP CONSTRAINT "FK_1aaedba621ec56a904dd99f3b3e"
        `);
        await queryRunner.query(`
            ALTER TABLE "join_archive_purchase_request_on_reprocessing_request" DROP CONSTRAINT "FK_70ba91b9c3b8788df2d24293adc"
        `);
        await queryRunner.query(`
            DROP INDEX "public"."IDX_1aaedba621ec56a904dd99f3b3"
        `);
        await queryRunner.query(`
            DROP INDEX "public"."IDX_70ba91b9c3b8788df2d24293ad"
        `);
        await queryRunner.query(`
            CREATE INDEX "IDX_a1ad5d9b0ff3ec14e91337eaeb" ON "join_archive_purchase_request_on_reprocessing_request" ("archive_purchase_request_id")
        `);
        await queryRunner.query(`
            CREATE INDEX "IDX_d33a9bcc79da706e90e0d19a63" ON "join_archive_purchase_request_on_reprocessing_request" ("reprocessing_request_id")
        `);
        await queryRunner.query(`
            ALTER TABLE "join_archive_purchase_request_on_reprocessing_request"
            ADD CONSTRAINT "FK_a1ad5d9b0ff3ec14e91337eaeb4" FOREIGN KEY ("archive_purchase_request_id") REFERENCES "archive_purchase_requests"("id") ON DELETE CASCADE ON UPDATE CASCADE
        `);
        await queryRunner.query(`
            ALTER TABLE "join_archive_purchase_request_on_reprocessing_request"
            ADD CONSTRAINT "FK_d33a9bcc79da706e90e0d19a63d" FOREIGN KEY ("reprocessing_request_id") REFERENCES "reprocessing_requests"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "join_archive_purchase_request_on_reprocessing_request" DROP CONSTRAINT "FK_d33a9bcc79da706e90e0d19a63d"
        `);
        await queryRunner.query(`
            ALTER TABLE "join_archive_purchase_request_on_reprocessing_request" DROP CONSTRAINT "FK_a1ad5d9b0ff3ec14e91337eaeb4"
        `);
        await queryRunner.query(`
            DROP INDEX "public"."IDX_d33a9bcc79da706e90e0d19a63"
        `);
        await queryRunner.query(`
            DROP INDEX "public"."IDX_a1ad5d9b0ff3ec14e91337eaeb"
        `);
        await queryRunner.query(`
            CREATE INDEX "IDX_70ba91b9c3b8788df2d24293ad" ON "join_archive_purchase_request_on_reprocessing_request" ("archive_purchase_request_id")
        `);
        await queryRunner.query(`
            CREATE INDEX "IDX_1aaedba621ec56a904dd99f3b3" ON "join_archive_purchase_request_on_reprocessing_request" ("reprocessing_request_id")
        `);
        await queryRunner.query(`
            ALTER TABLE "join_archive_purchase_request_on_reprocessing_request"
            ADD CONSTRAINT "FK_70ba91b9c3b8788df2d24293adc" FOREIGN KEY ("archive_purchase_request_id") REFERENCES "archive_purchase_requests"("id") ON DELETE CASCADE ON UPDATE CASCADE
        `);
        await queryRunner.query(`
            ALTER TABLE "join_archive_purchase_request_on_reprocessing_request"
            ADD CONSTRAINT "FK_1aaedba621ec56a904dd99f3b3e" FOREIGN KEY ("reprocessing_request_id") REFERENCES "reprocessing_requests"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE join_archive_purchase_request_on_reprocessing_request
            RENAME TO archive_purchase_requests_reprocessing_requests
        `);
    }

}
