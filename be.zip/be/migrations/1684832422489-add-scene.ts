import { MigrationInterface, QueryRunner } from "typeorm";

export class addScene1684832422489 implements MigrationInterface {
    name = 'addScene1684832422489'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD "scenes" integer NOT NULL DEFAULT '1'
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."scenes" IS 'number of scene'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_requests"
            ADD "scenes" integer NOT NULL DEFAULT '1'
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_requests"."scenes" IS 'number of scene'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_requests"."scenes" IS 'number of scene'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_requests" DROP COLUMN "scenes"
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."scenes" IS 'number of scene'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP COLUMN "scenes"
        `);
    }

}
