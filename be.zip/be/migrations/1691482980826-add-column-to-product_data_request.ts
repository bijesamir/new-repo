import { MigrationInterface, QueryRunner } from "typeorm";

export class AddColumnToProductDataRequest1691482980826 implements MigrationInterface {
    name = 'AddColumnToProductDataRequest1691482980826'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "product_data_requests"
            ADD "resolution_mode" integer NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "product_data_requests"."resolution_mode" IS 'resolution mode'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "product_data_requests"."resolution_mode" IS 'resolution mode'
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data_requests" DROP COLUMN "resolution_mode"
        `);
    }

}
