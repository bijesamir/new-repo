import { MigrationInterface, QueryRunner } from "typeorm";

export class indexTaskingInfoColumn1678932283138 implements MigrationInterface {
    name = 'indexTaskingInfoColumn1678932283138'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            CREATE INDEX "IDX_74df01b801ccde6b3b001cdae1" ON "tasking_infos" ("scs_order_id")
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            DROP INDEX "public"."IDX_74df01b801ccde6b3b001cdae1"
        `);
    }

}
