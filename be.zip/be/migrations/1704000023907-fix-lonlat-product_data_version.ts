import { MigrationInterface, QueryRunner } from 'typeorm';

export class FixLonlatProductDataVersion1704000023907
  implements MigrationInterface
{
  name = 'FixLonlatProductDataVersion1704000023907';

  public async up(queryRunner: QueryRunner): Promise<void> {
    // product-metadata uses [lat, lng], postgis uses [lng, lat] order
    await queryRunner.query(`
            UPDATE product_data_versions AS pdv
            SET center = (
              SELECT array_agg(ST_MakePoint(b, a) ORDER BY o)
              FROM (
                SELECT elem::double precision AS a, lead(elem::double precision) OVER (ORDER BY o) AS b, o
                FROM UNNEST(string_to_array(metadata::jsonb -> 'geometry' ->> 'sceneCenterLocation', ' ')) WITH ORDINALITY els(elem, o)
              ) AS pairs
              WHERE o % 2 = 1
            )[1]
        `);
    await queryRunner.query(`
            UPDATE product_data_versions
            SET area = ST_MakePolygon(
              ST_MakeLine(
                (
                  SELECT array_agg(ST_MakePoint(b, a) ORDER BY o)
                  FROM (
                    SELECT elem::double precision AS a, lead(elem::double precision) OVER (ORDER BY o) AS b, o
                    FROM UNNEST(string_to_array(metadata::jsonb -> 'geometry' ->> 'sceneCornerLocations', ' ')) WITH ORDINALITY els(elem, o)
                  ) AS pairs
                  WHERE o % 2 = 1
                )
              )
            )
        `);
    await queryRunner.query(`
        UPDATE "product_data_versions" SET "bbox" = ST_Envelope("area")
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            UPDATE product_data_versions AS pdv
            SET center = (
              SELECT array_agg(ST_MakePoint(a, b) ORDER BY o)
              FROM (
                SELECT elem::double precision AS a, lead(elem::double precision) OVER (ORDER BY o) AS b, o
                FROM UNNEST(string_to_array(metadata::jsonb -> 'geometry' ->> 'sceneCenterLocation', ' ')) WITH ORDINALITY els(elem, o)
              ) AS pairs
              WHERE o % 2 = 1
            )[1]
        `);
    await queryRunner.query(`
            UPDATE product_data_versions
            SET area = ST_MakePolygon(
              ST_MakeLine(
                (
                  SELECT array_agg(ST_MakePoint(a, b) ORDER BY o)
                  FROM (
                    SELECT elem::double precision AS a, lead(elem::double precision) OVER (ORDER BY o) AS b, o
                    FROM UNNEST(string_to_array(metadata::jsonb -> 'geometry' ->> 'sceneCornerLocations', ' ')) WITH ORDINALITY els(elem, o)
                  ) AS pairs
                  WHERE o % 2 = 1
                )
              )
            )
        `);
    await queryRunner.query(`
        UPDATE "product_data_versions" SET "bbox" = ST_Envelope("area")
    `);
  }
}
