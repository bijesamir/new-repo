import { MigrationInterface, QueryRunner } from "typeorm";

export class indexTaskingInfoColumn1686717709861 implements MigrationInterface {
    name = 'indexTaskingInfoColumn1686717709861'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            CREATE INDEX "IDX_577546a2b31a72483adfc5b6fe" ON "tasking_infos" ("scs_order_code")
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            DROP INDEX "public"."IDX_577546a2b31a72483adfc5b6fe"
        `);
    }

}
