import { MigrationInterface, QueryRunner } from "typeorm";

export class ChangeArchiveRequest1688978637050 implements MigrationInterface {
    name = 'ChangeArchiveRequest1688978637050'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "archive_requests"
            ADD "contract_id" integer NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "archive_requests"."contract_id" IS 'Contract ID associated with this record'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "archive_requests"."contract_id" IS 'Contract ID associated with this record'
        `);
        await queryRunner.query(`
            ALTER TABLE "archive_requests" DROP COLUMN "contract_id"
        `);
    }

}
