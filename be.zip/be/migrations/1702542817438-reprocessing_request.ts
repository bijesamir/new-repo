import { MigrationInterface, QueryRunner } from "typeorm";

export class ReprocessingRequest1702542817438 implements MigrationInterface {
    name = 'ReprocessingRequest1702542817438'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            CREATE TABLE "reprocessing_requests" (
                "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
                "no" integer GENERATED ALWAYS AS IDENTITY NOT NULL,
                "status" character varying NOT NULL,
                "created_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "updated_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "deleted_at" TIMESTAMP(6) WITH TIME ZONE,
                "product_datum_id" uuid,
                CONSTRAINT "PK_5f2a2e320741fe81ad3250c39b4" PRIMARY KEY ("id")
            );
            COMMENT ON COLUMN "reprocessing_requests"."id" IS 'reprocessing request id';
            COMMENT ON COLUMN "reprocessing_requests"."no" IS 'serial number';
            COMMENT ON COLUMN "reprocessing_requests"."status" IS 'status';
            COMMENT ON COLUMN "reprocessing_requests"."product_datum_id" IS 'product_data id'
        `);
        await queryRunner.query(`
            CREATE TABLE "archive_purchase_requests_reprocessing_requests" (
                "archive_purchase_request_id" uuid NOT NULL,
                "reprocessing_request_id" uuid NOT NULL,
                CONSTRAINT "PK_1a8e2c7c84dc340132287ad9054" PRIMARY KEY (
                    "archive_purchase_request_id",
                    "reprocessing_request_id"
                )
            )
        `);
        await queryRunner.query(`
            CREATE INDEX "IDX_70ba91b9c3b8788df2d24293ad" ON "archive_purchase_requests_reprocessing_requests" ("archive_purchase_request_id")
        `);
        await queryRunner.query(`
            CREATE INDEX "IDX_1aaedba621ec56a904dd99f3b3" ON "archive_purchase_requests_reprocessing_requests" ("reprocessing_request_id")
        `);
        await queryRunner.query(`
            ALTER TABLE "reprocessing_requests"
            ADD CONSTRAINT "FK_53b0c51c159c8442313c6681a1b" FOREIGN KEY ("product_datum_id") REFERENCES "product_data"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE "archive_purchase_requests_reprocessing_requests"
            ADD CONSTRAINT "FK_70ba91b9c3b8788df2d24293adc" FOREIGN KEY ("archive_purchase_request_id") REFERENCES "archive_purchase_requests"("id") ON DELETE CASCADE ON UPDATE CASCADE
        `);
        await queryRunner.query(`
            ALTER TABLE "archive_purchase_requests_reprocessing_requests"
            ADD CONSTRAINT "FK_1aaedba621ec56a904dd99f3b3e" FOREIGN KEY ("reprocessing_request_id") REFERENCES "reprocessing_requests"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "archive_purchase_requests_reprocessing_requests" DROP CONSTRAINT "FK_1aaedba621ec56a904dd99f3b3e"
        `);
        await queryRunner.query(`
            ALTER TABLE "archive_purchase_requests_reprocessing_requests" DROP CONSTRAINT "FK_70ba91b9c3b8788df2d24293adc"
        `);
        await queryRunner.query(`
            ALTER TABLE "reprocessing_requests" DROP CONSTRAINT "FK_53b0c51c159c8442313c6681a1b"
        `);
        await queryRunner.query(`
            DROP INDEX "public"."IDX_1aaedba621ec56a904dd99f3b3"
        `);
        await queryRunner.query(`
            DROP INDEX "public"."IDX_70ba91b9c3b8788df2d24293ad"
        `);
        await queryRunner.query(`
            DROP TABLE "archive_purchase_requests_reprocessing_requests"
        `);
        await queryRunner.query(`
            DROP TABLE "reprocessing_requests"
        `);
    }

}
