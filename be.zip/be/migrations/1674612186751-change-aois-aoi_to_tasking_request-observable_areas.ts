import { MigrationInterface, QueryRunner } from 'typeorm';

export class changeAoisAoiToTaskingRequestObservableAreas1674612186751
  implements MigrationInterface
{
  name = 'changeAoisAoiToTaskingRequestObservableAreas1674612186751';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "aoi_to_tasking_request" DROP CONSTRAINT "FK_97e317f9c69add3451f043e030c"
        `);
    await queryRunner.query(`
            ALTER TABLE "aoi_to_tasking_request" DROP CONSTRAINT "FK_37a500421a38daaee35ba9e707d"
        `);
    await queryRunner.query(`
            DROP INDEX "public"."IDX_c307285f7fdfdb69bc15006ea4"
        `);
    await queryRunner.query(`
            ALTER TABLE "aois" DROP COLUMN "elevation"
        `);
    await queryRunner.query(`
            ALTER TABLE "aois" DROP COLUMN "geometry"
        `);
    await queryRunner.query(`
            ALTER TABLE "aois"
            ADD "center" geometry(Point, 4326) NOT NULL
        `);
    await queryRunner.query(`
            COMMENT ON COLUMN "aois"."center" IS 'center of area of interest'
        `);
    await queryRunner.query(`
            ALTER TABLE "aois"
            ADD "altitude" numeric(8, 3) NOT NULL
        `);
    await queryRunner.query(`
            COMMENT ON COLUMN "aois"."altitude" IS 'altitude'
        `);
    await queryRunner.query(`
            ALTER TABLE "aois"
            ADD "area" geometry(POLYGON, 4326)
        `);
    await queryRunner.query(`
            COMMENT ON COLUMN "aois"."area" IS 'Area of interest'
        `);
    await queryRunner.query(`
            ALTER TABLE "aois"
            ADD "latest_editor_id" uuid NOT NULL
        `);
    await queryRunner.query(`
            COMMENT ON COLUMN "aois"."latest_editor_id" IS 'userId who last edited the record'
        `);
    await queryRunner.query(`
            ALTER TABLE "aois"
            ADD "organization_id" uuid NOT NULL
        `);
    await queryRunner.query(`
            COMMENT ON COLUMN "aois"."organization_id" IS 'ID of the organization to which this record belongs'
        `);
    await queryRunner.query(`
            ALTER TABLE "observable_areas"
            ALTER COLUMN "polygon" TYPE geometry
        `);
    await queryRunner.query(`
            CREATE INDEX "IDX_6b21742b1eef4ed87f4cd66972" ON "aois" USING GiST ("center")
        `);
    await queryRunner.query(`
            ALTER TABLE "aoi_to_tasking_request"
            ADD CONSTRAINT "FK_37a500421a38daaee35ba9e707d" FOREIGN KEY ("aoi_id") REFERENCES "aois"("id") ON DELETE
            SET NULL ON UPDATE NO ACTION
        `);
    await queryRunner.query(`
            ALTER TABLE "aoi_to_tasking_request"
            ADD CONSTRAINT "FK_97e317f9c69add3451f043e030c" FOREIGN KEY ("tasking_request_id") REFERENCES "tasking_requests"("id") ON DELETE
            SET NULL ON UPDATE NO ACTION
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "aoi_to_tasking_request" DROP CONSTRAINT "FK_97e317f9c69add3451f043e030c"
        `);
    await queryRunner.query(`
            ALTER TABLE "aoi_to_tasking_request" DROP CONSTRAINT "FK_37a500421a38daaee35ba9e707d"
        `);
    await queryRunner.query(`
            DROP INDEX "public"."IDX_6b21742b1eef4ed87f4cd66972"
        `);
    // await queryRunner.query(`
    //     ALTER TABLE "observable_areas"
    //     ALTER COLUMN "polygon" TYPE geometry(POLYGON, 4326)
    // `);
    await queryRunner.query(`
            COMMENT ON COLUMN "aois"."organization_id" IS 'ID of the organization to which this record belongs'
        `);
    await queryRunner.query(`
            ALTER TABLE "aois" DROP COLUMN "organization_id"
        `);
    await queryRunner.query(`
            COMMENT ON COLUMN "aois"."latest_editor_id" IS 'userId who last edited the record'
        `);
    await queryRunner.query(`
            ALTER TABLE "aois" DROP COLUMN "latest_editor_id"
        `);
    await queryRunner.query(`
            COMMENT ON COLUMN "aois"."area" IS 'Area of interest'
        `);
    await queryRunner.query(`
            ALTER TABLE "aois" DROP COLUMN "area"
        `);
    await queryRunner.query(`
            COMMENT ON COLUMN "aois"."altitude" IS 'altitude'
        `);
    await queryRunner.query(`
            ALTER TABLE "aois" DROP COLUMN "altitude"
        `);
    await queryRunner.query(`
            COMMENT ON COLUMN "aois"."center" IS 'center of area of interest'
        `);
    await queryRunner.query(`
            ALTER TABLE "aois" DROP COLUMN "center"
        `);
    await queryRunner.query(`
            ALTER TABLE "aois"
            ADD "geometry" geometry(POINT, 4326) NOT NULL
        `);
    await queryRunner.query(`
            ALTER TABLE "aois"
            ADD "elevation" integer NOT NULL
        `);
    await queryRunner.query(`
            CREATE INDEX "IDX_c307285f7fdfdb69bc15006ea4" ON "aois" USING GiST ("geometry")
        `);
    await queryRunner.query(`
            ALTER TABLE "aoi_to_tasking_request"
            ADD CONSTRAINT "FK_37a500421a38daaee35ba9e707d" FOREIGN KEY ("aoi_id") REFERENCES "aois"("id") ON DELETE CASCADE ON UPDATE NO ACTION
        `);
    await queryRunner.query(`
            ALTER TABLE "aoi_to_tasking_request"
            ADD CONSTRAINT "FK_97e317f9c69add3451f043e030c" FOREIGN KEY ("tasking_request_id") REFERENCES "tasking_requests"("id") ON DELETE CASCADE ON UPDATE NO ACTION
        `);
  }
}
