import { MigrationInterface, QueryRunner } from "typeorm";

export class AddColumnsProductDataView1708508080508 implements MigrationInterface {
    name = 'AddColumnsProductDataView1708508080508'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            DELETE FROM "typeorm_metadata"
            WHERE "type" = $1
                AND "name" = $2
                AND "schema" = $3
        `, ["VIEW","product_data_views","public"]);
        await queryRunner.query(`
            DROP VIEW "product_data_views"
        `);
        await queryRunner.query(`
            CREATE VIEW "product_data_views" AS
            SELECT *
            FROM (
                    (
                        SELECT 1 AS desc_no_idx,
                            ti.download_expired AS download_expired,
                            null AS archive_purchase_request_id,
                            null AS archive_purchase_request_no,
                            pd.id AS id,
                            pd.no AS no,
                            pd.created_at AS created_at,
                            pd.updated_at AS updated_at,
                            pd.deleted_at AS deleted_at,
                            pd.organization_id AS organization_id,
                            pd.contract_id AS contract_id,
                            pd.tasking_info_id AS tasking_info_id,
                            pd.aoi_id AS aoi_id,
                            pd.product_format AS product_format,
                            pd.resolution_mode AS resolution_mode,
                            pd.scene_id AS scene_id,
                            pd.scene_no AS scene_no,
                            pdv.id AS product_data_version_id,
                            pdv.no AS product_data_version_no,
                            pdv.created_at AS product_data_version_created_at,
                            pdv.updated_at AS product_data_version_updated_at,
                            pdv.deleted_at AS product_data_version_deleted_at,
                            pdv.version AS version,
                            pdv.source_expired AS source_expired,
                            pdv.is_source_deleted AS is_source_deleted,
                            pdv.bucket AS bucket,
                            pdv.location AS location,
                            pdv.quicklook_bucket AS quicklook_bucket,
                            pdv.quicklook_location AS quicklook_location,
                            pdv.quicklook_content_type AS quicklook_content_type,
                            pdv.metadata AS metadata
                        FROM product_data pd
                            LEFT JOIN product_data_versions pdv ON pdv.product_datum_id = pd.id
                            AND pdv.organization_id != -1
                            AND pdv.contract_id != -1
                            LEFT JOIN tasking_infos ti ON ti.id = pd.tasking_info_id
                            AND ti.organization_id != -1
                            AND ti.contract_id != -1
                        WHERE pd.organization_id != -1
                            AND pd.contract_id != -1
                    )
                    UNION ALL
                    (
                        SELECT ROW_NUMBER() OVER (
                                PARTITION BY appd.archive_purchase_request_id,
                                appd.product_datum_id
                                ORDER BY appd.no DESC
                            ) AS desc_no_idx,
                            apr.download_expired AS download_expired,
                            apr.id AS archive_purchase_request_id,
                            apr.no AS archive_purchase_request_no,
                            pd.id AS id,
                            pd.no AS no,
                            pd.created_at AS created_at,
                            pd.updated_at AS updated_at,
                            pd.deleted_at AS deleted_at,
                            -1 AS organization_id,
                            -1 AS contract_id,
                            pd.tasking_info_id AS tasking_info_id,
                            pd.aoi_id AS aoi_id,
                            pd.product_format AS product_format,
                            pd.resolution_mode AS resolution_mode,
                            pd.scene_id AS scene_id,
                            pd.scene_no AS scene_no,
                            pdv.id AS product_data_version_id,
                            pdv.no AS product_data_version_no,
                            pdv.created_at AS product_data_version_created_at,
                            pdv.updated_at AS product_data_version_updated_at,
                            pdv.deleted_at AS product_data_version_deleted_at,
                            pdv.version AS version,
                            pdv.source_expired AS source_expired,
                            pdv.is_source_deleted AS is_source_deleted,
                            pdv.bucket AS bucket,
                            pdv.location AS location,
                            pdv.quicklook_bucket AS quicklook_bucket,
                            pdv.quicklook_location AS quicklook_location,
                            pdv.quicklook_content_type AS quicklook_content_type,
                            pdv.metadata AS metadata
                        FROM archive_purchased_product_data appd
                            INNER JOIN archive_purchase_requests apr ON apr.id = appd.archive_purchase_request_id
                            INNER JOIN product_data pd ON pd.id = appd.product_datum_id
                            LEFT JOIN product_data_versions pdv ON pdv.id = appd.product_data_version_id
                    )
                ) AS pds
            WHERE desc_no_idx = 1
        `);
        await queryRunner.query(`
            INSERT INTO "typeorm_metadata"(
                    "database",
                    "schema",
                    "table",
                    "type",
                    "name",
                    "value"
                )
            VALUES (DEFAULT, $1, DEFAULT, $2, $3, $4)
        `, ["public","VIEW","product_data_views","SELECT * FROM (\n      (\n        SELECT\n          1 AS desc_no_idx,\n          ti.download_expired AS download_expired,\n          null AS archive_purchase_request_id,\n          null AS archive_purchase_request_no,\n\n          pd.id AS id,\n          pd.no AS no,\n          pd.created_at AS created_at,\n          pd.updated_at AS updated_at,\n          pd.deleted_at AS deleted_at,\n          pd.organization_id AS organization_id,\n          pd.contract_id AS contract_id,\n          pd.tasking_info_id AS tasking_info_id,\n          pd.aoi_id AS aoi_id,\n          pd.product_format AS product_format,\n          pd.resolution_mode AS resolution_mode,\n          pd.scene_id AS scene_id,\n          pd.scene_no AS scene_no,\n\n          pdv.id AS product_data_version_id,\n          pdv.no AS product_data_version_no,\n          pdv.created_at AS product_data_version_created_at,\n          pdv.updated_at AS product_data_version_updated_at,\n          pdv.deleted_at AS product_data_version_deleted_at,\n          pdv.version AS version,\n          pdv.source_expired AS source_expired,\n          pdv.is_source_deleted AS is_source_deleted,\n          pdv.bucket AS bucket,\n          pdv.location AS location,\n          pdv.quicklook_bucket AS quicklook_bucket,\n          pdv.quicklook_location AS quicklook_location,\n          pdv.quicklook_content_type AS quicklook_content_type,\n          pdv.metadata AS metadata\n        FROM product_data pd\n        LEFT JOIN product_data_versions pdv\n          ON pdv.product_datum_id = pd.id\n          AND pdv.organization_id != -1\n          AND pdv.contract_id != -1\n        LEFT JOIN tasking_infos ti\n          ON ti.id = pd.tasking_info_id\n          AND ti.organization_id != -1\n          AND ti.contract_id != -1\n        WHERE pd.organization_id != -1\n        AND pd.contract_id != -1\n      )\n      UNION ALL\n      (\n        SELECT\n          ROW_NUMBER() OVER (\n            PARTITION BY appd.archive_purchase_request_id, appd.product_datum_id\n            ORDER BY appd.no DESC\n          ) AS desc_no_idx,\n          apr.download_expired AS download_expired,\n          apr.id AS archive_purchase_request_id,\n          apr.no AS archive_purchase_request_no,\n\n          pd.id AS id,\n          pd.no AS no,\n          pd.created_at AS created_at,\n          pd.updated_at AS updated_at,\n          pd.deleted_at AS deleted_at,\n          -1 AS organization_id,\n          -1 AS contract_id,\n          pd.tasking_info_id AS tasking_info_id,\n          pd.aoi_id AS aoi_id,\n          pd.product_format AS product_format,\n          pd.resolution_mode AS resolution_mode,\n          pd.scene_id AS scene_id,\n          pd.scene_no AS scene_no,\n          \n          pdv.id AS product_data_version_id,\n          pdv.no AS product_data_version_no,\n          pdv.created_at AS product_data_version_created_at,\n          pdv.updated_at AS product_data_version_updated_at,\n          pdv.deleted_at AS product_data_version_deleted_at,\n          pdv.version AS version,\n          pdv.source_expired AS source_expired,\n          pdv.is_source_deleted AS is_source_deleted,\n          pdv.bucket AS bucket,\n          pdv.location AS location,\n          pdv.quicklook_bucket AS quicklook_bucket,\n          pdv.quicklook_location AS quicklook_location,\n          pdv.quicklook_content_type AS quicklook_content_type,\n          pdv.metadata AS metadata\n        FROM archive_purchased_product_data appd\n        INNER JOIN archive_purchase_requests apr\n          ON apr.id = appd.archive_purchase_request_id\n        INNER JOIN product_data pd\n          ON pd.id = appd.product_datum_id\n        LEFT JOIN product_data_versions pdv\n          ON pdv.id = appd.product_data_version_id\n      )\n    ) AS pds\n    WHERE desc_no_idx=1"]);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            DELETE FROM "typeorm_metadata"
            WHERE "type" = $1
                AND "name" = $2
                AND "schema" = $3
        `, ["VIEW","product_data_views","public"]);
        await queryRunner.query(`
            DROP VIEW "product_data_views"
        `);
        await queryRunner.query(`
            CREATE VIEW "product_data_views" AS
            SELECT *
            FROM (
                    (
                        SELECT 1 AS desc_no_idx,
                            null AS archive_purchase_request_id,
                            null AS archive_purchase_request_no,
                            pd.id AS id,
                            pd.no AS no,
                            pd.created_at AS created_at,
                            pd.updated_at AS updated_at,
                            pd.deleted_at AS deleted_at,
                            pd.organization_id AS organization_id,
                            pd.contract_id AS contract_id,
                            pd.tasking_info_id AS tasking_info_id,
                            pd.aoi_id AS aoi_id,
                            pd.product_format AS product_format,
                            pd.resolution_mode AS resolution_mode,
                            pd.scene_id AS scene_id,
                            pd.scene_no AS scene_no,
                            pdv.id AS product_data_version_id,
                            pdv.no AS product_data_version_no,
                            pdv.created_at AS product_data_version_created_at,
                            pdv.updated_at AS product_data_version_updated_at,
                            pdv.deleted_at AS product_data_version_deleted_at,
                            pdv.version AS version,
                            pdv.bucket AS bucket,
                            pdv.location AS location,
                            pdv.quicklook_bucket AS quicklook_bucket,
                            pdv.quicklook_location AS quicklook_location,
                            pdv.quicklook_content_type AS quicklook_content_type,
                            pdv.metadata AS metadata
                        FROM product_data pd
                            LEFT JOIN product_data_versions pdv ON pdv.product_datum_id = pd.id
                            AND pdv.organization_id != -1
                            AND pdv.contract_id != -1
                        WHERE pd.organization_id != -1
                            AND pd.contract_id != -1
                    )
                    UNION ALL
                    (
                        SELECT ROW_NUMBER() OVER (
                                PARTITION BY appd.archive_purchase_request_id,
                                appd.product_datum_id
                                ORDER BY appd.no DESC
                            ) AS desc_no_idx,
                            apr.id AS archive_purchase_request_id,
                            apr.no AS archive_purchase_request_no,
                            pd.id AS id,
                            pd.no AS no,
                            pd.created_at AS created_at,
                            pd.updated_at AS updated_at,
                            pd.deleted_at AS deleted_at,
                            -1 AS organization_id,
                            -1 AS contract_id,
                            pd.tasking_info_id AS tasking_info_id,
                            pd.aoi_id AS aoi_id,
                            pd.product_format AS product_format,
                            pd.resolution_mode AS resolution_mode,
                            pd.scene_id AS scene_id,
                            pd.scene_no AS scene_no,
                            pdv.id AS product_data_version_id,
                            pdv.no AS product_data_version_no,
                            pdv.created_at AS product_data_version_created_at,
                            pdv.updated_at AS product_data_version_updated_at,
                            pdv.deleted_at AS product_data_version_deleted_at,
                            pdv.version AS version,
                            pdv.bucket AS bucket,
                            pdv.location AS location,
                            pdv.quicklook_bucket AS quicklook_bucket,
                            pdv.quicklook_location AS quicklook_location,
                            pdv.quicklook_content_type AS quicklook_content_type,
                            pdv.metadata AS metadata
                        FROM archive_purchased_product_data appd
                            INNER JOIN archive_purchase_requests apr ON apr.id = appd.archive_purchase_request_id
                            INNER JOIN product_data pd ON pd.id = appd.product_datum_id
                            LEFT JOIN product_data_versions pdv ON pdv.id = appd.product_data_version_id
                    )
                ) AS pds
            WHERE desc_no_idx = 1
        `);
        await queryRunner.query(`
            INSERT INTO "typeorm_metadata"(
                    "database",
                    "schema",
                    "table",
                    "type",
                    "name",
                    "value"
                )
            VALUES (DEFAULT, $1, DEFAULT, $2, $3, $4)
        `, ["public","VIEW","product_data_views","SELECT * FROM (\n      (\n        SELECT\n          1 AS desc_no_idx,\n          null AS archive_purchase_request_id,\n          null AS archive_purchase_request_no,\n\n          pd.id AS id,\n          pd.no AS no,\n          pd.created_at AS created_at,\n          pd.updated_at AS updated_at,\n          pd.deleted_at AS deleted_at,\n          pd.organization_id AS organization_id,\n          pd.contract_id AS contract_id,\n          pd.tasking_info_id AS tasking_info_id,\n          pd.aoi_id AS aoi_id,\n          pd.product_format AS product_format,\n          pd.resolution_mode AS resolution_mode,\n          pd.scene_id AS scene_id,\n          pd.scene_no AS scene_no,\n\n          pdv.id AS product_data_version_id,\n          pdv.no AS product_data_version_no,\n          pdv.created_at AS product_data_version_created_at,\n          pdv.updated_at AS product_data_version_updated_at,\n          pdv.deleted_at AS product_data_version_deleted_at,\n          pdv.version AS version,\n          pdv.bucket AS bucket,\n          pdv.location AS location,\n          pdv.quicklook_bucket AS quicklook_bucket,\n          pdv.quicklook_location AS quicklook_location,\n          pdv.quicklook_content_type AS quicklook_content_type,\n          pdv.metadata AS metadata\n        FROM product_data pd\n        LEFT JOIN product_data_versions pdv\n          ON pdv.product_datum_id = pd.id\n          AND pdv.organization_id != -1\n          AND pdv.contract_id != -1\n        WHERE pd.organization_id != -1\n        AND pd.contract_id != -1\n      )\n      UNION ALL\n      (\n        SELECT\n          ROW_NUMBER() OVER (\n            PARTITION BY appd.archive_purchase_request_id, appd.product_datum_id\n            ORDER BY appd.no DESC\n          ) AS desc_no_idx,\n          apr.id AS archive_purchase_request_id,\n          apr.no AS archive_purchase_request_no,\n\n          pd.id AS id,\n          pd.no AS no,\n          pd.created_at AS created_at,\n          pd.updated_at AS updated_at,\n          pd.deleted_at AS deleted_at,\n          -1 AS organization_id,\n          -1 AS contract_id,\n          pd.tasking_info_id AS tasking_info_id,\n          pd.aoi_id AS aoi_id,\n          pd.product_format AS product_format,\n          pd.resolution_mode AS resolution_mode,\n          pd.scene_id AS scene_id,\n          pd.scene_no AS scene_no,\n          \n          pdv.id AS product_data_version_id,\n          pdv.no AS product_data_version_no,\n          pdv.created_at AS product_data_version_created_at,\n          pdv.updated_at AS product_data_version_updated_at,\n          pdv.deleted_at AS product_data_version_deleted_at,\n          pdv.version AS version,\n          pdv.bucket AS bucket,\n          pdv.location AS location,\n          pdv.quicklook_bucket AS quicklook_bucket,\n          pdv.quicklook_location AS quicklook_location,\n          pdv.quicklook_content_type AS quicklook_content_type,\n          pdv.metadata AS metadata\n        FROM archive_purchased_product_data appd\n        INNER JOIN archive_purchase_requests apr\n          ON apr.id = appd.archive_purchase_request_id\n        INNER JOIN product_data pd\n          ON pd.id = appd.product_datum_id\n        LEFT JOIN product_data_versions pdv\n          ON pdv.id = appd.product_data_version_id\n      )\n    ) AS pds\n    WHERE desc_no_idx=1"]);
    }

}
