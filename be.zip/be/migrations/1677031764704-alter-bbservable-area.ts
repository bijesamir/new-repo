import { MigrationInterface, QueryRunner } from "typeorm";

export class alterBbservableArea1677031764704 implements MigrationInterface {
    name = 'alterBbservableArea1677031764704'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "observable_areas"
            ALTER COLUMN "polygon" TYPE geometry(POLYGONZ, 4326)
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "observable_areas"
            ALTER COLUMN "polygon" TYPE geometry(GEOMETRY, 0)
        `);
    }

}
