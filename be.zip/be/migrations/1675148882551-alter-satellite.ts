import { MigrationInterface, QueryRunner } from "typeorm";

export class alterSatellite1675148882551 implements MigrationInterface {
    name = 'alterSatellite1675148882551'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "satellites" DROP CONSTRAINT "UQ_a12e6ffd1faf91f258773ffa962"
        `);
        await queryRunner.query(`
            ALTER TABLE "satellites" DROP COLUMN "satellite_id"
        `);
        await queryRunner.query(`
            ALTER TABLE "satellites" DROP CONSTRAINT "UQ_07cf92b5c2f2ba5028cfb3846da"
        `);
        await queryRunner.query(`
            ALTER TABLE "satellites" DROP COLUMN "satellite_code"
        `);
        await queryRunner.query(`
            ALTER TABLE "satellites"
            ADD "sat_id" character varying NOT NULL
        `);
        await queryRunner.query(`
            ALTER TABLE "satellites"
            ADD CONSTRAINT "UQ_35124aa634967869f63a1e15c4f" UNIQUE ("sat_id")
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "satellites"."sat_id" IS 'determine satellites in daas'
        `);
        await queryRunner.query(`
            ALTER TABLE "satellites"
            ADD "satellite_development_code" character varying NOT NULL
        `);
        await queryRunner.query(`
            ALTER TABLE "satellites"
            ADD CONSTRAINT "UQ_179f0fea12bbe9b77c3b1e0a2f7" UNIQUE ("satellite_development_code")
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "satellites"."satellite_development_code" IS 'determine satellites in scs'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "satellites"."satellite_development_code" IS 'determine satellites in scs'
        `);
        await queryRunner.query(`
            ALTER TABLE "satellites" DROP CONSTRAINT "UQ_179f0fea12bbe9b77c3b1e0a2f7"
        `);
        await queryRunner.query(`
            ALTER TABLE "satellites" DROP COLUMN "satellite_development_code"
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "satellites"."sat_id" IS 'determine satellites in daas'
        `);
        await queryRunner.query(`
            ALTER TABLE "satellites" DROP CONSTRAINT "UQ_35124aa634967869f63a1e15c4f"
        `);
        await queryRunner.query(`
            ALTER TABLE "satellites" DROP COLUMN "sat_id"
        `);
        await queryRunner.query(`
            ALTER TABLE "satellites"
            ADD "satellite_code" character varying NOT NULL
        `);
        await queryRunner.query(`
            ALTER TABLE "satellites"
            ADD CONSTRAINT "UQ_07cf92b5c2f2ba5028cfb3846da" UNIQUE ("satellite_code")
        `);
        await queryRunner.query(`
            ALTER TABLE "satellites"
            ADD "satellite_id" character varying NOT NULL
        `);
        await queryRunner.query(`
            ALTER TABLE "satellites"
            ADD CONSTRAINT "UQ_a12e6ffd1faf91f258773ffa962" UNIQUE ("satellite_id")
        `);
    }

}
