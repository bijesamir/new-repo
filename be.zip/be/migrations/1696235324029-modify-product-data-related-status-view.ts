import { MigrationInterface, QueryRunner } from "typeorm";

export class ModifyProductDataRelatedStatusView1696235324029 implements MigrationInterface {
    name = 'ModifyProductDataRelatedStatusView1696235324029'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            DELETE FROM "typeorm_metadata"
            WHERE "type" = $1
                AND "name" = $2
                AND "schema" = $3
        `, ["VIEW","product_data_related_statuses","public"]);
        await queryRunner.query(`
            DROP VIEW "product_data_related_statuses"
        `);
        await queryRunner.query(`
            CREATE VIEW "product_data_related_statuses" AS WITH prepare_lpdr AS(
                SELECT ROW_NUMBER() OVER(
                        PARTITION BY tasking_info_id,
                        scene_no,
                        product_format,
                        resolution_mode
                        ORDER BY created_at DESC
                    ) AS desc_order_idx,
                    id,
                    tasking_info_id,
                    scene_no,
                    product_format,
                    resolution_mode,
                    status,
                    updated_at
                FROM product_data_requests
            ),
            lpdr AS(
                SELECT tasking_info_id as pdr_ti_id,
                    id AS product_data_request_id,
                    scene_no,
                    product_format,
                    resolution_mode,
                    status AS product_data_request_status,
                    updated_at AS product_data_request_updated_at
                FROM prepare_lpdr
                WHERE desc_order_idx = 1
            ),
            joined_ti_lpdr AS(
                SELECT ti.id AS tasking_info_id,
                    ti.scs_order_id AS order_id,
                    ti.scs_order_code AS order_code,
                    ti.status AS tasking_info_status,
                    lpdr.product_data_request_id,
                    lpdr.scene_no,
                    lpdr.product_format,
                    lpdr.resolution_mode,
                    lpdr.product_data_request_status,
                    lpdr.product_data_request_updated_at
                FROM tasking_infos AS ti
                    LEFT JOIN lpdr ON ti.id = lpdr.pdr_ti_id
            ),
            joined_ti_lpdr_pd AS(
                SELECT ti_lpdr.*,
                    pd.id AS product_datum_id,
                    pd.scene_id AS scene_id,
                    aoi.id AS aoi_id,
                    aoi.name AS aoi_name
                FROM joined_ti_lpdr AS ti_lpdr
                    LEFT JOIN product_data AS pd ON ti_lpdr.product_data_request_id = pd.product_data_request_id
                    LEFT JOIN aois AS aoi ON aoi.id = pd.aoi_id
            ),
            prepare_lpdv AS(
                SELECT ROW_NUMBER() OVER(
                        PARTITION BY product_datum_id
                        ORDER BY created_at DESC
                    ) AS desc_order_idx,
                    id,
                    product_datum_id
                FROM product_data_versions
                WHERE deleted_at IS NULL
            ),
            lpdv AS(
                SELECT product_datum_id AS pd_id,
                    id AS product_data_version_id
                FROM prepare_lpdv
                WHERE desc_order_idx = 1
            ),
            prepare_lar AS(
                SELECT ROW_NUMBER() OVER(
                        PARTITION BY product_data_version_id
                        ORDER BY created_at DESC
                    ) AS desc_order_idx,
                    id,
                    product_data_version_id,
                    status,
                    updated_at
                FROM archive_requests
            ),
            lar AS(
                SELECT product_data_version_id AS pdv_id,
                    id AS archive_request_id,
                    status AS archive_request_status,
                    updated_at AS archive_request_updated_at
                FROM prepare_lar
                WHERE desc_order_idx = 1
            )
            SELECT joined_ti_lpdr_pd.*,
                lpdv.product_data_version_id,
                lar.archive_request_id,
                lar.archive_request_status,
                lar.archive_request_updated_at
            FROM joined_ti_lpdr_pd
                LEFT JOIN lpdv ON joined_ti_lpdr_pd.product_datum_id = lpdv.pd_id
                LEFT JOIN lar ON lpdv.product_data_version_id = lar.pdv_id;
        `);
        await queryRunner.query(`
            INSERT INTO "typeorm_metadata"(
                    "database",
                    "schema",
                    "table",
                    "type",
                    "name",
                    "value"
                )
            VALUES (DEFAULT, $1, DEFAULT, $2, $3, $4)
        `, ["public","VIEW","product_data_related_statuses","WITH prepare_lpdr AS(\n    SELECT\n        ROW_NUMBER() OVER(\n            PARTITION BY tasking_info_id,\n            scene_no,\n            product_format,\n            resolution_mode\n            ORDER BY\n                created_at DESC\n        ) AS desc_order_idx,\n        id,\n        tasking_info_id,\n        scene_no,\n        product_format,\n        resolution_mode,\n        status,\n        updated_at\n    FROM\n        product_data_requests\n),\nlpdr AS(\n    SELECT\n        tasking_info_id as pdr_ti_id,\n        id AS product_data_request_id,\n        scene_no,\n        product_format,\n        resolution_mode,\n        status AS product_data_request_status,\n        updated_at AS product_data_request_updated_at\n    FROM\n        prepare_lpdr\n    WHERE\n        desc_order_idx = 1\n),\njoined_ti_lpdr AS(\n    SELECT\n        ti.id AS tasking_info_id,\n        ti.scs_order_id AS order_id,\n        ti.scs_order_code AS order_code,\n        ti.status AS tasking_info_status,\n        lpdr.product_data_request_id,\n        lpdr.scene_no,\n        lpdr.product_format,\n        lpdr.resolution_mode,\n        lpdr.product_data_request_status,\n        lpdr.product_data_request_updated_at\n    FROM\n        tasking_infos AS ti\n        LEFT JOIN lpdr ON ti.id = lpdr.pdr_ti_id\n),\njoined_ti_lpdr_pd AS(\n    SELECT\n        ti_lpdr.*,\n        pd.id AS product_datum_id,\n        pd.scene_id AS scene_id,\n        aoi.id AS aoi_id,\n        aoi.name AS aoi_name\n    FROM\n        joined_ti_lpdr AS ti_lpdr\n        LEFT JOIN product_data AS pd ON ti_lpdr.product_data_request_id = pd.product_data_request_id\n        LEFT JOIN aois AS aoi ON aoi.id = pd.aoi_id\n),\nprepare_lpdv AS(\n    SELECT\n        ROW_NUMBER() OVER(\n            PARTITION BY product_datum_id\n            ORDER BY\n                created_at DESC\n        ) AS desc_order_idx,\n        id,\n        product_datum_id\n    FROM\n        product_data_versions\n    WHERE deleted_at IS NULL\n),\nlpdv AS(\n    SELECT\n        product_datum_id AS pd_id,\n        id AS product_data_version_id\n    FROM\n        prepare_lpdv\n    WHERE\n        desc_order_idx = 1\n),\nprepare_lar AS(\n    SELECT\n        ROW_NUMBER() OVER(\n            PARTITION BY product_data_version_id\n            ORDER BY\n                created_at DESC\n        ) AS desc_order_idx,\n        id,\n        product_data_version_id,\n        status,\n        updated_at\n    FROM\n        archive_requests\n),\nlar AS(\n    SELECT\n        product_data_version_id AS pdv_id,\n        id AS archive_request_id,\n        status AS archive_request_status,\n        updated_at AS archive_request_updated_at\n    FROM\n        prepare_lar\n    WHERE\n        desc_order_idx = 1\n)\nSELECT\n    joined_ti_lpdr_pd.*,\n    lpdv.product_data_version_id,\n    lar.archive_request_id,\n    lar.archive_request_status,\n    lar.archive_request_updated_at\nFROM\n    joined_ti_lpdr_pd\n    LEFT JOIN lpdv ON joined_ti_lpdr_pd.product_datum_id = lpdv.pd_id\n    LEFT JOIN lar ON lpdv.product_data_version_id = lar.pdv_id;"]);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            DELETE FROM "typeorm_metadata"
            WHERE "type" = $1
                AND "name" = $2
                AND "schema" = $3
        `, ["VIEW","product_data_related_statuses","public"]);
        await queryRunner.query(`
            DROP VIEW "product_data_related_statuses"
        `);
        await queryRunner.query(`
            CREATE VIEW "product_data_related_statuses" AS WITH prepare_lpdr AS(
                SELECT ROW_NUMBER() OVER(
                        PARTITION BY tasking_info_id,
                        scene_no,
                        product_format,
                        resolution_mode
                        ORDER BY created_at DESC
                    ) AS desc_order_idx,
                    id,
                    tasking_info_id,
                    scene_no,
                    product_format,
                    resolution_mode,
                    status,
                    updated_at
                FROM product_data_requests
            ),
            lpdr AS(
                SELECT tasking_info_id as pdr_ti_id,
                    id AS product_data_request_id,
                    scene_no,
                    product_format,
                    resolution_mode,
                    status AS product_data_request_status,
                    updated_at AS product_data_request_updated_at
                FROM prepare_lpdr
                WHERE desc_order_idx = 1
            ),
            joined_ti_lpdr AS(
                SELECT ti.id AS tasking_info_id,
                    ti.scs_order_id AS order_id,
                    ti.scs_order_code AS order_code,
                    ti.status AS tasking_info_status,
                    lpdr.product_data_request_id,
                    lpdr.scene_no,
                    lpdr.product_format,
                    lpdr.resolution_mode,
                    lpdr.product_data_request_status,
                    lpdr.product_data_request_updated_at
                FROM tasking_infos AS ti
                    LEFT JOIN lpdr ON ti.id = lpdr.pdr_ti_id
            ),
            joined_ti_lpdr_pd AS(
                SELECT ti_lpdr.*,
                    pd.id AS product_datum_id,
                    pd.scene_id AS scene_id,
                    aoi.id AS aoi_id,
                    aoi.name AS aoi_name
                FROM joined_ti_lpdr AS ti_lpdr
                    LEFT JOIN product_data AS pd ON ti_lpdr.product_data_request_id = pd.product_data_request_id
                    LEFT JOIN aois AS aoi ON pd.aoi_id = aoi.id
            ),
            prepare_lpdv AS(
                SELECT ROW_NUMBER() OVER(
                        PARTITION BY product_datum_id
                        ORDER BY created_at DESC
                    ) AS desc_order_idx,
                    id,
                    product_datum_id
                FROM product_data_versions
            ),
            lpdv AS(
                SELECT product_datum_id AS pd_id,
                    id AS product_data_version_id
                FROM prepare_lpdv
                WHERE desc_order_idx = 1
            ),
            prepare_lar AS(
                SELECT ROW_NUMBER() OVER(
                        PARTITION BY product_data_version_id
                        ORDER BY created_at DESC
                    ) AS desc_order_idx,
                    id,
                    product_data_version_id,
                    status,
                    updated_at
                FROM archive_requests
            ),
            lar AS(
                SELECT product_data_version_id AS pdv_id,
                    id AS archive_request_id,
                    status AS archive_request_status,
                    updated_at AS archive_request_updated_at
                FROM prepare_lar
                WHERE desc_order_idx = 1
            )
            SELECT joined_ti_lpdr_pd.*,
                lpdv.product_data_version_id,
                lar.archive_request_id,
                lar.archive_request_status,
                lar.archive_request_updated_at
            FROM joined_ti_lpdr_pd
                LEFT JOIN lpdv ON joined_ti_lpdr_pd.product_datum_id = lpdv.pd_id
                LEFT JOIN lar ON lpdv.product_data_version_id = lar.pdv_id;
        `);
        await queryRunner.query(`
            INSERT INTO "typeorm_metadata"(
                    "database",
                    "schema",
                    "table",
                    "type",
                    "name",
                    "value"
                )
            VALUES (DEFAULT, $1, DEFAULT, $2, $3, $4)
        `, ["public","VIEW","product_data_related_statuses","WITH prepare_lpdr AS(\n    SELECT\n        ROW_NUMBER() OVER(\n            PARTITION BY tasking_info_id,\n            scene_no,\n            product_format,\n            resolution_mode\n            ORDER BY\n                created_at DESC\n        ) AS desc_order_idx,\n        id,\n        tasking_info_id,\n        scene_no,\n        product_format,\n        resolution_mode,\n        status,\n        updated_at\n    FROM\n        product_data_requests\n),\nlpdr AS(\n    SELECT\n        tasking_info_id as pdr_ti_id,\n        id AS product_data_request_id,\n        scene_no,\n        product_format,\n        resolution_mode,\n        status AS product_data_request_status,\n        updated_at AS product_data_request_updated_at\n    FROM\n        prepare_lpdr\n    WHERE\n        desc_order_idx = 1\n),\njoined_ti_lpdr AS(\n    SELECT\n        ti.id AS tasking_info_id,\n        ti.scs_order_id AS order_id,\n        ti.scs_order_code AS order_code,\n        ti.status AS tasking_info_status,\n        lpdr.product_data_request_id,\n        lpdr.scene_no,\n        lpdr.product_format,\n        lpdr.resolution_mode,\n        lpdr.product_data_request_status,\n        lpdr.product_data_request_updated_at\n    FROM\n        tasking_infos AS ti\n        LEFT JOIN lpdr ON ti.id = lpdr.pdr_ti_id\n),\njoined_ti_lpdr_pd AS(\n    SELECT\n        ti_lpdr.*,\n        pd.id AS product_datum_id,\n        pd.scene_id AS scene_id,\n        aoi.id AS aoi_id,\n        aoi.name AS aoi_name\n    FROM\n        joined_ti_lpdr AS ti_lpdr\n        LEFT JOIN product_data AS pd ON ti_lpdr.product_data_request_id = pd.product_data_request_id\n        LEFT JOIN aois AS aoi ON pd.aoi_id = aoi.id\n),\nprepare_lpdv AS(\n    SELECT\n        ROW_NUMBER() OVER(\n            PARTITION BY product_datum_id\n            ORDER BY\n                created_at DESC\n        ) AS desc_order_idx,\n        id,\n        product_datum_id\n    FROM\n        product_data_versions\n),\nlpdv AS(\n    SELECT\n        product_datum_id AS pd_id,\n        id AS product_data_version_id\n    FROM\n        prepare_lpdv\n    WHERE\n        desc_order_idx = 1\n),\nprepare_lar AS(\n    SELECT\n        ROW_NUMBER() OVER(\n            PARTITION BY product_data_version_id\n            ORDER BY\n                created_at DESC\n        ) AS desc_order_idx,\n        id,\n        product_data_version_id,\n        status,\n        updated_at\n    FROM\n        archive_requests\n),\nlar AS(\n    SELECT\n        product_data_version_id AS pdv_id,\n        id AS archive_request_id,\n        status AS archive_request_status,\n        updated_at AS archive_request_updated_at\n    FROM\n        prepare_lar\n    WHERE\n        desc_order_idx = 1\n)\nSELECT\n    joined_ti_lpdr_pd.*,\n    lpdv.product_data_version_id,\n    lar.archive_request_id,\n    lar.archive_request_status,\n    lar.archive_request_updated_at\nFROM\n    joined_ti_lpdr_pd\n    LEFT JOIN lpdv ON joined_ti_lpdr_pd.product_datum_id = lpdv.pd_id\n    LEFT JOIN lar ON lpdv.product_data_version_id = lar.pdv_id;"]);
    }

}
