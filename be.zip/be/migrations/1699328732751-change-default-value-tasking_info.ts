import { MigrationInterface, QueryRunner } from "typeorm";

export class ChangeDefaultValueTaskingInfo1699328732751 implements MigrationInterface {
    name = 'ChangeDefaultValueTaskingInfo1699328732751'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ALTER COLUMN "catalog_delay_kind"
            SET DEFAULT '-1'
        `);
        await queryRunner.query(`
            UPDATE "tasking_infos" SET "catalog_delay_kind" = -1
            WHERE "catalog_delay_kind" = 2
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ALTER COLUMN "catalog_delay_kind"
            SET DEFAULT '2'
        `);
    }

}
