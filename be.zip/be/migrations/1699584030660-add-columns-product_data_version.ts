import { MigrationInterface, QueryRunner } from "typeorm";

export class AddColumnsProductDataVersion1699584030660 implements MigrationInterface {
    name = 'AddColumnsProductDataVersion1699584030660'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "product_data_versions"
            ADD "bbox" box
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "product_data_versions"."bbox" IS 'bbox of area'
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data_versions"
            ADD "datetime" TIMESTAMP(6) WITH TIME ZONE DEFAULT NULL
        `);
        await queryRunner.query(`
            UPDATE "product_data_versions" SET "bbox" = ST_Envelope("area")
        `);
        await queryRunner.query(`
            UPDATE "product_data_versions" SET "datetime" = to_timestamp(metadata ::jsonb -> 'observation' ->> 'sceneCenterDateTime', 'YYYY-MM-DD"T"HH24:MI:SS.US"Z"')
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "product_data_versions" DROP COLUMN "datetime"
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "product_data_versions"."bbox" IS 'bbox of area'
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data_versions" DROP COLUMN "bbox"
        `);
    }

}
