import { MigrationInterface, QueryRunner } from "typeorm";

export class addColumnDeliveryConfig1681458626602 implements MigrationInterface {
    name = 'addColumnDeliveryConfig1681458626602'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "delivery_configs"
            ADD "concurrency" integer NOT NULL DEFAULT '1'
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "delivery_configs"."concurrency" IS 'concurrency'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "delivery_configs"."concurrency" IS 'concurrency'
        `);
        await queryRunner.query(`
            ALTER TABLE "delivery_configs" DROP COLUMN "concurrency"
        `);
    }

}
