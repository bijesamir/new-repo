import { MigrationInterface, QueryRunner } from "typeorm";

export class AddColumnToDeliveryConfigs1693225261821 implements MigrationInterface {
    name = 'AddColumnToDeliveryConfigs1693225261821'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "delivery_configs"
            ADD "product_details" jsonb NOT NULL DEFAULT '[]'
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "delivery_configs"."product_details" IS 'product details to deliver'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "delivery_configs"."product_details" IS 'product details to deliver'
        `);
        await queryRunner.query(`
            ALTER TABLE "delivery_configs" DROP COLUMN "product_details"
        `);
    }

}
