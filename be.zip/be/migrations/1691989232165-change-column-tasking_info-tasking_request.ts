import { MigrationInterface, QueryRunner } from "typeorm";

export class ChangeColumnTaskingInfoTaskingRequest1691989232165 implements MigrationInterface {
    name = 'ChangeColumnTaskingInfoTaskingRequest1691989232165'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
                RENAME COLUMN "product_formats" TO "product_details"
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_requests"
                RENAME COLUMN "product_formats" TO "product_details"
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."product_details" IS 'product details'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ALTER COLUMN "product_details" DROP DEFAULT
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_requests"."product_details" IS 'product details'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_requests"
            ALTER COLUMN "product_details" DROP DEFAULT
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "tasking_requests"
            ALTER COLUMN "product_details"
            SET DEFAULT '[]'
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_requests"."product_details" IS 'product format list'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ALTER COLUMN "product_details"
            SET DEFAULT '[]'
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."product_details" IS 'product format list'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_requests"
                RENAME COLUMN "product_details" TO "product_formats"
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
                RENAME COLUMN "product_details" TO "product_formats"
        `);
    }

}
