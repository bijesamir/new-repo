import { MigrationInterface, QueryRunner } from "typeorm";

export class ArchiveExpired1703050592679 implements MigrationInterface {
    name = 'ArchiveExpired1703050592679'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "archive_purchase_requests"
            ADD "download_expired" TIMESTAMP(6) WITH TIME ZONE
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "archive_purchase_requests"."download_expired" IS 'archive data download expired date'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "archive_purchase_requests"."download_expired" IS 'archive data download expired date'
        `);
        await queryRunner.query(`
            ALTER TABLE "archive_purchase_requests" DROP COLUMN "download_expired"
        `);
    }

}
