import { MigrationInterface, QueryRunner } from "typeorm";

export class AddDataTypeToApItem1708654081943 implements MigrationInterface {
    name = 'AddDataTypeToApItem1708654081943'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "archive_purchased_items"
            ADD "data_source_type" integer  DEFAULT 1;
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "archive_purchased_items"."data_source_type" IS 'fresh archive or not'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "archive_purchased_items"."data_source_type" IS 'fresh archive or not'
        `);
        await queryRunner.query(`
            ALTER TABLE "archive_purchased_items" DROP COLUMN "data_source_type"
        `);
    }

}
