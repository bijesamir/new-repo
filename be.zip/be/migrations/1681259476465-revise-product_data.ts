import { MigrationInterface, QueryRunner } from "typeorm";

export class reviseProductData1681259476465 implements MigrationInterface {
    name = 'reviseProductData1681259476465'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "product_data" DROP COLUMN "processing_request_id"`);
        await queryRunner.query(`ALTER TABLE "product_data" ADD "latest_editor_id" character varying(128) NOT NULL`);
        await queryRunner.query(`COMMENT ON COLUMN "product_data"."latest_editor_id" IS 'User ID who last edited this record'`);
        await queryRunner.query(`ALTER TABLE "product_data" ADD "organization_id" integer NOT NULL`);
        await queryRunner.query(`COMMENT ON COLUMN "product_data"."organization_id" IS 'Organization ID associated with this record'`);
        await queryRunner.query(`ALTER TABLE "product_data" ADD "contract_id" integer NOT NULL`);
        await queryRunner.query(`COMMENT ON COLUMN "product_data"."contract_id" IS 'Contract ID associated with this record'`);
        await queryRunner.query(`ALTER TABLE "product_data" ADD "tasking_info_id" uuid NOT NULL`);
        await queryRunner.query(`COMMENT ON COLUMN "product_data"."tasking_info_id" IS 'tasking_info id'`);
        await queryRunner.query(`ALTER TABLE "product_data_versions" ADD "latest_editor_id" character varying(128) NOT NULL`);
        await queryRunner.query(`COMMENT ON COLUMN "product_data_versions"."latest_editor_id" IS 'User ID who last edited this record'`);
        await queryRunner.query(`ALTER TABLE "product_data_versions" ADD "organization_id" integer NOT NULL`);
        await queryRunner.query(`COMMENT ON COLUMN "product_data_versions"."organization_id" IS 'Organization ID associated with this record'`);
        await queryRunner.query(`ALTER TABLE "product_data_versions" ADD "contract_id" integer NOT NULL`);
        await queryRunner.query(`COMMENT ON COLUMN "product_data_versions"."contract_id" IS 'Contract ID associated with this record'`);
        await queryRunner.query(`ALTER TABLE "product_data" ADD CONSTRAINT "FK_fab703fa04ae87adbf84d1d0b52" FOREIGN KEY ("tasking_info_id") REFERENCES "tasking_infos"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "product_data" DROP CONSTRAINT "FK_fab703fa04ae87adbf84d1d0b52"`);
        await queryRunner.query(`COMMENT ON COLUMN "product_data_versions"."contract_id" IS 'Contract ID associated with this record'`);
        await queryRunner.query(`ALTER TABLE "product_data_versions" DROP COLUMN "contract_id"`);
        await queryRunner.query(`COMMENT ON COLUMN "product_data_versions"."organization_id" IS 'Organization ID associated with this record'`);
        await queryRunner.query(`ALTER TABLE "product_data_versions" DROP COLUMN "organization_id"`);
        await queryRunner.query(`COMMENT ON COLUMN "product_data_versions"."latest_editor_id" IS 'User ID who last edited this record'`);
        await queryRunner.query(`ALTER TABLE "product_data_versions" DROP COLUMN "latest_editor_id"`);
        await queryRunner.query(`COMMENT ON COLUMN "product_data"."tasking_info_id" IS 'tasking_info id'`);
        await queryRunner.query(`ALTER TABLE "product_data" DROP COLUMN "tasking_info_id"`);
        await queryRunner.query(`COMMENT ON COLUMN "product_data"."contract_id" IS 'Contract ID associated with this record'`);
        await queryRunner.query(`ALTER TABLE "product_data" DROP COLUMN "contract_id"`);
        await queryRunner.query(`COMMENT ON COLUMN "product_data"."organization_id" IS 'Organization ID associated with this record'`);
        await queryRunner.query(`ALTER TABLE "product_data" DROP COLUMN "organization_id"`);
        await queryRunner.query(`COMMENT ON COLUMN "product_data"."latest_editor_id" IS 'User ID who last edited this record'`);
        await queryRunner.query(`ALTER TABLE "product_data" DROP COLUMN "latest_editor_id"`);
        await queryRunner.query(`ALTER TABLE "product_data" ADD "processing_request_id" uuid NOT NULL`);
    }

}
