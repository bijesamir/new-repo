import { MigrationInterface, QueryRunner } from "typeorm";

export class AddTaskingSummaryView1697782842695 implements MigrationInterface {
    name = 'AddTaskingSummaryView1697782842695'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            DELETE FROM "typeorm_metadata"
            WHERE "type" = $1
                AND "name" = $2
                AND "schema" = $3
        `, ["VIEW","product_data_related_statuses","public"]);
        await queryRunner.query(`
            DROP VIEW "product_data_related_statuses"
        `);
        await queryRunner.query(`
            CREATE VIEW "product_data_related_statuses" AS WITH prepare_lpdr AS(
                SELECT ROW_NUMBER() OVER(
                        PARTITION BY tasking_info_id,
                        scene_no,
                        product_format,
                        resolution_mode
                        ORDER BY created_at DESC
                    ) AS desc_order_idx,
                    id,
                    tasking_info_id,
                    scene_no,
                    product_format,
                    resolution_mode,
                    status,
                    updated_at
                FROM product_data_requests
            ),
            lpdr AS(
                SELECT tasking_info_id as pdr_ti_id,
                    id AS product_data_request_id,
                    scene_no,
                    product_format,
                    resolution_mode,
                    status AS product_data_request_status,
                    updated_at AS product_data_request_updated_at
                FROM prepare_lpdr
                WHERE desc_order_idx = 1
            ),
            joined_ti_lpdr AS(
                SELECT ti.id AS tasking_info_id,
                    ti.scs_order_id AS order_id,
                    ti.scs_order_code AS order_code,
                    ti.status AS tasking_info_status,
                    ti.updated_at AS tasking_info_updated_at,
                    lpdr.product_data_request_id,
                    lpdr.scene_no,
                    lpdr.product_format,
                    lpdr.resolution_mode,
                    lpdr.product_data_request_status,
                    lpdr.product_data_request_updated_at
                FROM tasking_infos AS ti
                    LEFT JOIN lpdr ON ti.id = lpdr.pdr_ti_id
            ),
            joined_ti_lpdr_pd AS(
                SELECT ti_lpdr.*,
                    pd.id AS product_datum_id,
                    pd.scene_id AS scene_id,
                    aoi.id AS aoi_id,
                    aoi.name AS aoi_name
                FROM joined_ti_lpdr AS ti_lpdr
                    LEFT JOIN product_data AS pd ON ti_lpdr.product_data_request_id = pd.product_data_request_id
                    LEFT JOIN aois AS aoi ON aoi.id = pd.aoi_id
            ),
            prepare_lpdv AS(
                SELECT ROW_NUMBER() OVER(
                        PARTITION BY product_datum_id
                        ORDER BY created_at DESC
                    ) AS desc_order_idx,
                    id,
                    product_datum_id
                FROM product_data_versions
                WHERE deleted_at IS NULL
            ),
            lpdv AS(
                SELECT product_datum_id AS pd_id,
                    id AS product_data_version_id
                FROM prepare_lpdv
                WHERE desc_order_idx = 1
            ),
            prepare_lar AS(
                SELECT ROW_NUMBER() OVER(
                        PARTITION BY product_data_version_id
                        ORDER BY created_at DESC
                    ) AS desc_order_idx,
                    id,
                    product_data_version_id,
                    status,
                    updated_at
                FROM archive_requests
            ),
            lar AS(
                SELECT product_data_version_id AS pdv_id,
                    id AS archive_request_id,
                    status AS archive_request_status,
                    updated_at AS archive_request_updated_at
                FROM prepare_lar
                WHERE desc_order_idx = 1
            )
            SELECT joined_ti_lpdr_pd.*,
                lpdv.product_data_version_id,
                lar.archive_request_id,
                lar.archive_request_status,
                lar.archive_request_updated_at
            FROM joined_ti_lpdr_pd
                LEFT JOIN lpdv ON joined_ti_lpdr_pd.product_datum_id = lpdv.pd_id
                LEFT JOIN lar ON lpdv.product_data_version_id = lar.pdv_id;
        `);
        await queryRunner.query(`
            INSERT INTO "typeorm_metadata"(
                    "database",
                    "schema",
                    "table",
                    "type",
                    "name",
                    "value"
                )
            VALUES (DEFAULT, $1, DEFAULT, $2, $3, $4)
        `, ["public","VIEW","product_data_related_statuses","WITH prepare_lpdr AS(\n    SELECT\n        ROW_NUMBER() OVER(\n            PARTITION BY tasking_info_id,\n            scene_no,\n            product_format,\n            resolution_mode\n            ORDER BY\n                created_at DESC\n        ) AS desc_order_idx,\n        id,\n        tasking_info_id,\n        scene_no,\n        product_format,\n        resolution_mode,\n        status,\n        updated_at\n    FROM\n        product_data_requests\n),\nlpdr AS(\n    SELECT\n        tasking_info_id as pdr_ti_id,\n        id AS product_data_request_id,\n        scene_no,\n        product_format,\n        resolution_mode,\n        status AS product_data_request_status,\n        updated_at AS product_data_request_updated_at\n    FROM\n        prepare_lpdr\n    WHERE\n        desc_order_idx = 1\n),\njoined_ti_lpdr AS(\n    SELECT\n        ti.id AS tasking_info_id,\n        ti.scs_order_id AS order_id,\n        ti.scs_order_code AS order_code,\n        ti.status AS tasking_info_status,\n        ti.updated_at AS tasking_info_updated_at,\n        lpdr.product_data_request_id,\n        lpdr.scene_no,\n        lpdr.product_format,\n        lpdr.resolution_mode,\n        lpdr.product_data_request_status,\n        lpdr.product_data_request_updated_at\n    FROM\n        tasking_infos AS ti\n        LEFT JOIN lpdr ON ti.id = lpdr.pdr_ti_id\n),\njoined_ti_lpdr_pd AS(\n    SELECT\n        ti_lpdr.*,\n        pd.id AS product_datum_id,\n        pd.scene_id AS scene_id,\n        aoi.id AS aoi_id,\n        aoi.name AS aoi_name\n    FROM\n        joined_ti_lpdr AS ti_lpdr\n        LEFT JOIN product_data AS pd ON ti_lpdr.product_data_request_id = pd.product_data_request_id\n        LEFT JOIN aois AS aoi ON aoi.id = pd.aoi_id\n),\nprepare_lpdv AS(\n    SELECT\n        ROW_NUMBER() OVER(\n            PARTITION BY product_datum_id\n            ORDER BY\n                created_at DESC\n        ) AS desc_order_idx,\n        id,\n        product_datum_id\n    FROM\n        product_data_versions\n    WHERE deleted_at IS NULL\n),\nlpdv AS(\n    SELECT\n        product_datum_id AS pd_id,\n        id AS product_data_version_id\n    FROM\n        prepare_lpdv\n    WHERE\n        desc_order_idx = 1\n),\nprepare_lar AS(\n    SELECT\n        ROW_NUMBER() OVER(\n            PARTITION BY product_data_version_id\n            ORDER BY\n                created_at DESC\n        ) AS desc_order_idx,\n        id,\n        product_data_version_id,\n        status,\n        updated_at\n    FROM\n        archive_requests\n),\nlar AS(\n    SELECT\n        product_data_version_id AS pdv_id,\n        id AS archive_request_id,\n        status AS archive_request_status,\n        updated_at AS archive_request_updated_at\n    FROM\n        prepare_lar\n    WHERE\n        desc_order_idx = 1\n)\nSELECT\n    joined_ti_lpdr_pd.*,\n    lpdv.product_data_version_id,\n    lar.archive_request_id,\n    lar.archive_request_status,\n    lar.archive_request_updated_at\nFROM\n    joined_ti_lpdr_pd\n    LEFT JOIN lpdv ON joined_ti_lpdr_pd.product_datum_id = lpdv.pd_id\n    LEFT JOIN lar ON lpdv.product_data_version_id = lar.pdv_id;"]);
        await queryRunner.query(`
            CREATE VIEW "tasking_summaries" AS
            SELECT tasking_info_id,
                GREATEST(
                    tasking_info_updated_at,
                    MAX(product_data_request_updated_at),
                    MAX(archive_request_updated_at)
                ) AS summary_updated_at,
                CASE
                    WHEN tasking_info_status = 'pre-credit-check' THEN 'pre-credit-check'
                    WHEN tasking_info_status = 'pre-order' THEN 'pre-order'
                    WHEN tasking_info_status = 'ordered' THEN 'ordered'
                    WHEN tasking_info_status = 'order-fixed' THEN 'acquiring'
                    WHEN tasking_info_status = 'observation-completed' THEN (
                        CASE
                            WHEN SUM(
                                CASE
                                    WHEN product_data_request_status = 'failed' THEN 1
                                    ELSE 0
                                END
                            ) = COUNT(tasking_info_id) THEN 'product-failed'
                            WHEN SUM(
                                CASE
                                    WHEN archive_request_status = 'failed' THEN 1
                                    ELSE 0
                                END
                            ) = COUNT(tasking_info_id) THEN 'delivery-failed'
                            WHEN SUM(
                                CASE
                                    WHEN archive_request_status = 'completed' THEN 1
                                    ELSE 0
                                END
                            ) = COUNT(tasking_info_id) THEN 'delivered'
                            WHEN SUM(
                                CASE
                                    WHEN product_data_request_status = 'completed' THEN 1
                                    ELSE 0
                                END
                            ) = COUNT(tasking_info_id) THEN 'product-created'
                            ELSE 'processing'
                        END
                    )
                    WHEN tasking_info_status = 'observation-failed' THEN 'acquisition-failed'
                    WHEN tasking_info_status = 'canceled' THEN 'canceled'
                    WHEN tasking_info_status = 'rejected' THEN 'rejected'
                    ELSE 'N/A'
                END AS summary_status
            FROM product_data_related_statuses
            GROUP BY tasking_info_id,
                tasking_info_status,
                tasking_info_updated_at;
        `);
        await queryRunner.query(`
            INSERT INTO "typeorm_metadata"(
                    "database",
                    "schema",
                    "table",
                    "type",
                    "name",
                    "value"
                )
            VALUES (DEFAULT, $1, DEFAULT, $2, $3, $4)
        `, ["public","VIEW","tasking_summaries","SELECT\n    tasking_info_id,\n    GREATEST(tasking_info_updated_at, MAX(product_data_request_updated_at), MAX(archive_request_updated_at)) AS summary_updated_at,\n    CASE\n        WHEN tasking_info_status = 'pre-credit-check' THEN 'pre-credit-check'\n        WHEN tasking_info_status = 'pre-order' THEN 'pre-order'\n        WHEN tasking_info_status = 'ordered' THEN 'ordered'\n        WHEN tasking_info_status = 'order-fixed' THEN 'acquiring'\n        WHEN tasking_info_status = 'observation-completed' THEN (CASE\n            WHEN SUM(CASE WHEN product_data_request_status = 'failed' THEN 1 ELSE 0 END) = COUNT(tasking_info_id) THEN 'product-failed'\n            WHEN SUM(CASE WHEN archive_request_status = 'failed' THEN 1 ELSE 0 END) = COUNT(tasking_info_id) THEN 'delivery-failed'\n            WHEN SUM(CASE WHEN archive_request_status = 'completed' THEN 1 ELSE 0 END) = COUNT(tasking_info_id) THEN 'delivered'\n            WHEN SUM(CASE WHEN product_data_request_status = 'completed' THEN 1 ELSE 0 END) = COUNT(tasking_info_id) THEN 'product-created'\n            ELSE 'processing'\n        END)\n        WHEN tasking_info_status = 'observation-failed' THEN 'acquisition-failed'\n        WHEN tasking_info_status = 'canceled' THEN 'canceled'\n        WHEN tasking_info_status = 'rejected' THEN 'rejected'\n        ELSE 'N/A'\n    END AS summary_status\nFROM product_data_related_statuses\nGROUP BY tasking_info_id, tasking_info_status, tasking_info_updated_at;"]);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            DELETE FROM "typeorm_metadata"
            WHERE "type" = $1
                AND "name" = $2
                AND "schema" = $3
        `, ["VIEW","tasking_summaries","public"]);
        await queryRunner.query(`
            DROP VIEW "tasking_summaries"
        `);
        await queryRunner.query(`
            DELETE FROM "typeorm_metadata"
            WHERE "type" = $1
                AND "name" = $2
                AND "schema" = $3
        `, ["VIEW","product_data_related_statuses","public"]);
        await queryRunner.query(`
            DROP VIEW "product_data_related_statuses"
        `);
        await queryRunner.query(`
            CREATE VIEW "product_data_related_statuses" AS WITH prepare_lpdr AS(
                SELECT ROW_NUMBER() OVER(
                        PARTITION BY tasking_info_id,
                        scene_no,
                        product_format,
                        resolution_mode
                        ORDER BY created_at DESC
                    ) AS desc_order_idx,
                    id,
                    tasking_info_id,
                    scene_no,
                    product_format,
                    resolution_mode,
                    status,
                    updated_at
                FROM product_data_requests
            ),
            lpdr AS(
                SELECT tasking_info_id as pdr_ti_id,
                    id AS product_data_request_id,
                    scene_no,
                    product_format,
                    resolution_mode,
                    status AS product_data_request_status,
                    updated_at AS product_data_request_updated_at
                FROM prepare_lpdr
                WHERE desc_order_idx = 1
            ),
            joined_ti_lpdr AS(
                SELECT ti.id AS tasking_info_id,
                    ti.scs_order_id AS order_id,
                    ti.scs_order_code AS order_code,
                    ti.status AS tasking_info_status,
                    lpdr.product_data_request_id,
                    lpdr.scene_no,
                    lpdr.product_format,
                    lpdr.resolution_mode,
                    lpdr.product_data_request_status,
                    lpdr.product_data_request_updated_at
                FROM tasking_infos AS ti
                    LEFT JOIN lpdr ON ti.id = lpdr.pdr_ti_id
            ),
            joined_ti_lpdr_pd AS(
                SELECT ti_lpdr.*,
                    pd.id AS product_datum_id,
                    pd.scene_id AS scene_id,
                    aoi.id AS aoi_id,
                    aoi.name AS aoi_name
                FROM joined_ti_lpdr AS ti_lpdr
                    LEFT JOIN product_data AS pd ON ti_lpdr.product_data_request_id = pd.product_data_request_id
                    LEFT JOIN aois AS aoi ON aoi.id = pd.aoi_id
            ),
            prepare_lpdv AS(
                SELECT ROW_NUMBER() OVER(
                        PARTITION BY product_datum_id
                        ORDER BY created_at DESC
                    ) AS desc_order_idx,
                    id,
                    product_datum_id
                FROM product_data_versions
                WHERE deleted_at IS NULL
            ),
            lpdv AS(
                SELECT product_datum_id AS pd_id,
                    id AS product_data_version_id
                FROM prepare_lpdv
                WHERE desc_order_idx = 1
            ),
            prepare_lar AS(
                SELECT ROW_NUMBER() OVER(
                        PARTITION BY product_data_version_id
                        ORDER BY created_at DESC
                    ) AS desc_order_idx,
                    id,
                    product_data_version_id,
                    status,
                    updated_at
                FROM archive_requests
            ),
            lar AS(
                SELECT product_data_version_id AS pdv_id,
                    id AS archive_request_id,
                    status AS archive_request_status,
                    updated_at AS archive_request_updated_at
                FROM prepare_lar
                WHERE desc_order_idx = 1
            )
            SELECT joined_ti_lpdr_pd.*,
                lpdv.product_data_version_id,
                lar.archive_request_id,
                lar.archive_request_status,
                lar.archive_request_updated_at
            FROM joined_ti_lpdr_pd
                LEFT JOIN lpdv ON joined_ti_lpdr_pd.product_datum_id = lpdv.pd_id
                LEFT JOIN lar ON lpdv.product_data_version_id = lar.pdv_id;
        `);
        await queryRunner.query(`
            INSERT INTO "typeorm_metadata"(
                    "database",
                    "schema",
                    "table",
                    "type",
                    "name",
                    "value"
                )
            VALUES (DEFAULT, $1, DEFAULT, $2, $3, $4)
        `, ["public","VIEW","product_data_related_statuses","WITH prepare_lpdr AS(\n    SELECT\n        ROW_NUMBER() OVER(\n            PARTITION BY tasking_info_id,\n            scene_no,\n            product_format,\n            resolution_mode\n            ORDER BY\n                created_at DESC\n        ) AS desc_order_idx,\n        id,\n        tasking_info_id,\n        scene_no,\n        product_format,\n        resolution_mode,\n        status,\n        updated_at\n    FROM\n        product_data_requests\n),\nlpdr AS(\n    SELECT\n        tasking_info_id as pdr_ti_id,\n        id AS product_data_request_id,\n        scene_no,\n        product_format,\n        resolution_mode,\n        status AS product_data_request_status,\n        updated_at AS product_data_request_updated_at\n    FROM\n        prepare_lpdr\n    WHERE\n        desc_order_idx = 1\n),\njoined_ti_lpdr AS(\n    SELECT\n        ti.id AS tasking_info_id,\n        ti.scs_order_id AS order_id,\n        ti.scs_order_code AS order_code,\n        ti.status AS tasking_info_status,\n        lpdr.product_data_request_id,\n        lpdr.scene_no,\n        lpdr.product_format,\n        lpdr.resolution_mode,\n        lpdr.product_data_request_status,\n        lpdr.product_data_request_updated_at\n    FROM\n        tasking_infos AS ti\n        LEFT JOIN lpdr ON ti.id = lpdr.pdr_ti_id\n),\njoined_ti_lpdr_pd AS(\n    SELECT\n        ti_lpdr.*,\n        pd.id AS product_datum_id,\n        pd.scene_id AS scene_id,\n        aoi.id AS aoi_id,\n        aoi.name AS aoi_name\n    FROM\n        joined_ti_lpdr AS ti_lpdr\n        LEFT JOIN product_data AS pd ON ti_lpdr.product_data_request_id = pd.product_data_request_id\n        LEFT JOIN aois AS aoi ON aoi.id = pd.aoi_id\n),\nprepare_lpdv AS(\n    SELECT\n        ROW_NUMBER() OVER(\n            PARTITION BY product_datum_id\n            ORDER BY\n                created_at DESC\n        ) AS desc_order_idx,\n        id,\n        product_datum_id\n    FROM\n        product_data_versions\n    WHERE deleted_at IS NULL\n),\nlpdv AS(\n    SELECT\n        product_datum_id AS pd_id,\n        id AS product_data_version_id\n    FROM\n        prepare_lpdv\n    WHERE\n        desc_order_idx = 1\n),\nprepare_lar AS(\n    SELECT\n        ROW_NUMBER() OVER(\n            PARTITION BY product_data_version_id\n            ORDER BY\n                created_at DESC\n        ) AS desc_order_idx,\n        id,\n        product_data_version_id,\n        status,\n        updated_at\n    FROM\n        archive_requests\n),\nlar AS(\n    SELECT\n        product_data_version_id AS pdv_id,\n        id AS archive_request_id,\n        status AS archive_request_status,\n        updated_at AS archive_request_updated_at\n    FROM\n        prepare_lar\n    WHERE\n        desc_order_idx = 1\n)\nSELECT\n    joined_ti_lpdr_pd.*,\n    lpdv.product_data_version_id,\n    lar.archive_request_id,\n    lar.archive_request_status,\n    lar.archive_request_updated_at\nFROM\n    joined_ti_lpdr_pd\n    LEFT JOIN lpdv ON joined_ti_lpdr_pd.product_datum_id = lpdv.pd_id\n    LEFT JOIN lar ON lpdv.product_data_version_id = lar.pdv_id;"]);
    }

}
