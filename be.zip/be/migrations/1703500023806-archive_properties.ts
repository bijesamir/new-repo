import { MigrationInterface, QueryRunner } from "typeorm";

export class ArchiveProperties1703500023806 implements MigrationInterface {
    name = 'ArchiveProperties1703500023806'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "archive_purchase_requests"
            ADD "ordered_user_id" character varying(128)
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "archive_purchase_requests"."ordered_user_id" IS 'User ID who ordered this record'
        `);
        await queryRunner.query(
          `UPDATE "archive_purchase_requests" SET "ordered_user_id" = "latest_editor_id"`,
        );
        await queryRunner.query(
          `ALTER TABLE "archive_purchase_requests" ALTER COLUMN "ordered_user_id" SET NOT NULL`,
        );
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(
          `ALTER TABLE "archive_purchase_requests" ALTER COLUMN "ordered_user_id" DROP NOT NULL`,
        );
        await queryRunner.query(`
            COMMENT ON COLUMN "archive_purchase_requests"."ordered_user_id" IS 'User ID who ordered this record'
        `);
        await queryRunner.query(`
            ALTER TABLE "archive_purchase_requests" DROP COLUMN "ordered_user_id"
        `);
    }

}
