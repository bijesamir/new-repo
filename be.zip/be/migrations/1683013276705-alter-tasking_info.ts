import { MigrationInterface, QueryRunner } from "typeorm";

export class alterTaskingInfo1683013276705 implements MigrationInterface {
    name = 'alterTaskingInfo1683013276705'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            DROP INDEX "public"."IDX_74df01b801ccde6b3b001cdae1"
        `);
        await queryRunner.query(`
            CREATE UNIQUE INDEX "IDX_577546a2b31a72483adfc5b6fe" ON "tasking_infos" ("scs_order_code")
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            DROP INDEX "public"."IDX_577546a2b31a72483adfc5b6fe"
        `);
        await queryRunner.query(`
            CREATE INDEX "IDX_74df01b801ccde6b3b001cdae1" ON "tasking_infos" ("scs_order_id")
        `);
    }

}
