import { MigrationInterface, QueryRunner } from 'typeorm';

export class dropTableProcessingResults1681203259570
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
        DROP TABLE processing_results
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            CREATE TABLE "processing_results" (
                "latest_editor_id" character varying(128) NOT NULL,
                "organization_id" integer NOT NULL,
                "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
                "no" integer GENERATED ALWAYS AS IDENTITY NOT NULL,
                "created_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "updated_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "deleted_at" TIMESTAMP(6) WITH TIME ZONE,
                "scs_order_id" uuid NOT NULL,
                "product_format" integer NOT NULL,
                "path" character varying NOT NULL,
                "note" text,
                CONSTRAINT "PK_8feacafee4607a786d4fec8646b" PRIMARY KEY ("id")
            );
            COMMENT ON COLUMN "processing_results"."latest_editor_id" IS 'User ID who last edited this record';
            COMMENT ON COLUMN "processing_results"."organization_id" IS 'Organization ID associated with this record';
            COMMENT ON COLUMN "processing_results"."id" IS 'processing_result id';
            COMMENT ON COLUMN "processing_results"."no" IS 'serial number of ProcessingResult';
            COMMENT ON COLUMN "processing_results"."scs_order_id" IS 'ID assigned to the order by SCS';
            COMMENT ON COLUMN "processing_results"."product_format" IS 'product format';
            COMMENT ON COLUMN "processing_results"."path" IS 'the path of the target object';
            COMMENT ON COLUMN "processing_results"."note" IS 'Matters that are not used in processing but that you want to keep as a memo'
        `);
    await queryRunner.query(`
            CREATE INDEX "IDX_79dd737bde85046835f8107649" ON "processing_results" ("scs_order_id")
        `);
  }
}
