import { MigrationInterface, QueryRunner } from "typeorm";

export class addColumnToProductDataVersion1681870503201 implements MigrationInterface {
    name = 'addColumnToProductDataVersion1681870503201'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "product_data_versions"
            ADD "bucket" character varying NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "product_data_versions"."bucket" IS 'storage bucket of product data'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "product_data_versions"."bucket" IS 'storage bucket of product data'
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data_versions" DROP COLUMN "bucket"
        `);
    }

}
