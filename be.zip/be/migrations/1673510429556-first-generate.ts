import { MigrationInterface, QueryRunner } from "typeorm";

export class firstGenerate1673510429556 implements MigrationInterface {
    name = 'firstGenerate1673510429556'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            CREATE TABLE "aois" (
                "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
                "no" integer GENERATED ALWAYS AS IDENTITY NOT NULL,
                "created_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "updated_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "deleted_at" TIMESTAMP(6) WITH TIME ZONE,
                "name" character varying(255) NOT NULL,
                "geometry" geometry(Point, 4326) NOT NULL,
                "elevation" integer NOT NULL,
                CONSTRAINT "PK_eaea476f9ddf1208f808598649e" PRIMARY KEY ("id")
            );
            COMMENT ON COLUMN "aois"."id" IS 'aoi id';
            COMMENT ON COLUMN "aois"."no" IS 'serial number of Aoi';
            COMMENT ON COLUMN "aois"."name" IS 'aoi name';
            COMMENT ON COLUMN "aois"."geometry" IS 'Area of interest';
            COMMENT ON COLUMN "aois"."elevation" IS 'elevation'
        `);
        await queryRunner.query(`
            CREATE INDEX "IDX_c307285f7fdfdb69bc15006ea4" ON "aois" USING GiST ("geometry")
        `);
        await queryRunner.query(`
            CREATE TABLE "tasking_infos" (
                "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
                "no" integer GENERATED ALWAYS AS IDENTITY NOT NULL,
                "created_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "updated_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "deleted_at" TIMESTAMP(6) WITH TIME ZONE,
                "scs_order_id" uuid NOT NULL,
                "scs_order_code" character varying(12) NOT NULL,
                "tasking_type" character varying NOT NULL,
                "tasking_request_id" uuid NOT NULL,
                "status" character varying NOT NULL,
                "center_position" geometry(Point, 4326) NOT NULL,
                "observation_area" geometry(Polygon, 4326) NOT NULL,
                "priority" integer NOT NULL,
                "imaging_mode" integer NOT NULL,
                "looking_direction" integer NOT NULL,
                "flight_direction" integer NOT NULL,
                "offnadir_angle" numeric(5, 2) NOT NULL,
                "observation_start" TIMESTAMP(6) WITH TIME ZONE NOT NULL,
                "observation_end" TIMESTAMP(6) WITH TIME ZONE NOT NULL,
                "satellite" character varying NOT NULL,
                CONSTRAINT "PK_314c0c24565096b55dfb4045a0e" PRIMARY KEY ("id")
            );
            COMMENT ON COLUMN "tasking_infos"."id" IS 'tasking_info id';
            COMMENT ON COLUMN "tasking_infos"."no" IS 'serial number of TaskingInfo';
            COMMENT ON COLUMN "tasking_infos"."scs_order_id" IS 'ID assigned to the order by SCS';
            COMMENT ON COLUMN "tasking_infos"."scs_order_code" IS 'serial value assigned to the order by SCS';
            COMMENT ON COLUMN "tasking_infos"."tasking_type" IS 'tasking type';
            COMMENT ON COLUMN "tasking_infos"."tasking_request_id" IS 'tasking_request id';
            COMMENT ON COLUMN "tasking_infos"."status" IS 'status';
            COMMENT ON COLUMN "tasking_infos"."center_position" IS 'center position';
            COMMENT ON COLUMN "tasking_infos"."observation_area" IS 'observation area';
            COMMENT ON COLUMN "tasking_infos"."priority" IS 'priority';
            COMMENT ON COLUMN "tasking_infos"."imaging_mode" IS 'imaging mode code';
            COMMENT ON COLUMN "tasking_infos"."looking_direction" IS 'looking direction code';
            COMMENT ON COLUMN "tasking_infos"."flight_direction" IS 'flight direction code';
            COMMENT ON COLUMN "tasking_infos"."offnadir_angle" IS 'offnadir angle';
            COMMENT ON COLUMN "tasking_infos"."observation_start" IS 'observation start';
            COMMENT ON COLUMN "tasking_infos"."observation_end" IS 'observation end';
            COMMENT ON COLUMN "tasking_infos"."satellite" IS 'satelite name'
        `);
        await queryRunner.query(`
            CREATE TABLE "tasking_requests" (
                "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
                "no" integer GENERATED ALWAYS AS IDENTITY NOT NULL,
                "created_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "updated_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "deleted_at" TIMESTAMP(6) WITH TIME ZONE,
                "priority" integer NOT NULL,
                "imaging_mode" integer NOT NULL,
                "looking_direction" integer NOT NULL,
                "flight_direction" integer NOT NULL,
                "offnadir_angle_min" numeric(5, 2) NOT NULL,
                "offnadir_angle_max" numeric(5, 2) NOT NULL,
                "product_formats" jsonb NOT NULL DEFAULT '[]',
                CONSTRAINT "PK_7ba9f6b74018bb5dca1c216360c" PRIMARY KEY ("id")
            );
            COMMENT ON COLUMN "tasking_requests"."id" IS 'tasking_request id';
            COMMENT ON COLUMN "tasking_requests"."no" IS 'serial number of TaskingRequest';
            COMMENT ON COLUMN "tasking_requests"."priority" IS 'priority';
            COMMENT ON COLUMN "tasking_requests"."imaging_mode" IS 'imaging mode code';
            COMMENT ON COLUMN "tasking_requests"."looking_direction" IS 'looking direction code';
            COMMENT ON COLUMN "tasking_requests"."flight_direction" IS 'flight direction code';
            COMMENT ON COLUMN "tasking_requests"."offnadir_angle_min" IS 'offnadir angle min';
            COMMENT ON COLUMN "tasking_requests"."offnadir_angle_max" IS 'offnadir angle max';
            COMMENT ON COLUMN "tasking_requests"."product_formats" IS 'product format list'
        `);
        await queryRunner.query(`
            CREATE TABLE "aoi_to_tasking_request" (
                "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
                "no" integer GENERATED ALWAYS AS IDENTITY NOT NULL,
                "created_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "updated_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "deleted_at" TIMESTAMP(6) WITH TIME ZONE,
                "aoi_id" uuid NOT NULL,
                "tasking_request_id" uuid NOT NULL,
                CONSTRAINT "PK_d0bae9de94e5e2b788c92d86eef" PRIMARY KEY ("id")
            );
            COMMENT ON COLUMN "aoi_to_tasking_request"."id" IS 'aoi_to_tasking_request id';
            COMMENT ON COLUMN "aoi_to_tasking_request"."no" IS 'serial number of AoiToTaskingrequest';
            COMMENT ON COLUMN "aoi_to_tasking_request"."aoi_id" IS 'aoi id';
            COMMENT ON COLUMN "aoi_to_tasking_request"."tasking_request_id" IS 'tasking_request id'
        `);
        await queryRunner.query(`
            CREATE TABLE "product_data_versions" (
                "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
                "no" integer GENERATED ALWAYS AS IDENTITY NOT NULL,
                "created_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "updated_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "deleted_at" TIMESTAMP(6) WITH TIME ZONE,
                "processing_request_id" uuid NOT NULL,
                "version" character varying NOT NULL,
                "location" character varying NOT NULL,
                "product_datum_id" uuid,
                CONSTRAINT "REL_e7aef93cc631fd6f544aeac0fe" UNIQUE ("processing_request_id"),
                CONSTRAINT "PK_e347518ce0ee400daee335ff789" PRIMARY KEY ("id")
            );
            COMMENT ON COLUMN "product_data_versions"."id" IS 'product_data_version id';
            COMMENT ON COLUMN "product_data_versions"."no" IS 'serial number of ProductDataVersion';
            COMMENT ON COLUMN "product_data_versions"."processing_request_id" IS 'processing_request id';
            COMMENT ON COLUMN "product_data_versions"."version" IS 'version identifier for product data';
            COMMENT ON COLUMN "product_data_versions"."location" IS 'storage location of product data';
            COMMENT ON COLUMN "product_data_versions"."product_datum_id" IS 'product_data id'
        `);
        await queryRunner.query(`
            CREATE TABLE "processing_requests" (
                "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
                "no" integer GENERATED ALWAYS AS IDENTITY NOT NULL,
                "created_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "updated_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "deleted_at" TIMESTAMP(6) WITH TIME ZONE,
                "tasking_info_id" uuid NOT NULL,
                "status" character varying NOT NULL,
                "format" character varying NOT NULL,
                CONSTRAINT "PK_46414274080ed50db44039331a4" PRIMARY KEY ("id")
            );
            COMMENT ON COLUMN "processing_requests"."id" IS 'processing_request id';
            COMMENT ON COLUMN "processing_requests"."no" IS 'serial number of ProcessingRequest';
            COMMENT ON COLUMN "processing_requests"."tasking_info_id" IS 'tasking_info id';
            COMMENT ON COLUMN "processing_requests"."status" IS 'status';
            COMMENT ON COLUMN "processing_requests"."format" IS 'product format'
        `);
        await queryRunner.query(`
            CREATE TABLE "product_data" (
                "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
                "no" integer GENERATED ALWAYS AS IDENTITY NOT NULL,
                "created_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "updated_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "deleted_at" TIMESTAMP(6) WITH TIME ZONE,
                "processing_request_id" uuid NOT NULL,
                CONSTRAINT "REL_ce102084c6b69980bdee6bb29e" UNIQUE ("processing_request_id"),
                CONSTRAINT "PK_c1489ff567e5e5edec170df6e43" PRIMARY KEY ("id")
            );
            COMMENT ON COLUMN "product_data"."id" IS 'product_data id';
            COMMENT ON COLUMN "product_data"."no" IS 'serial number of ProductData';
            COMMENT ON COLUMN "product_data"."processing_request_id" IS 'processing_request id'
        `);
        await queryRunner.query(`
            CREATE TABLE "observable_areas" (
                "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
                "no" integer GENERATED ALWAYS AS IDENTITY NOT NULL,
                "date" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT DATE_TRUNC('DAY', NOW()),
                "satellite_id" character varying NOT NULL,
                "polygon" geometry(PolygonZ, 4326) NOT NULL,
                CONSTRAINT "PK_b8bf44fd2b673434e43ab0d4eeb" PRIMARY KEY ("id")
            );
            COMMENT ON COLUMN "observable_areas"."id" IS 'observable_area id';
            COMMENT ON COLUMN "observable_areas"."no" IS 'serial number of ObservableArea';
            COMMENT ON COLUMN "observable_areas"."date" IS 'date';
            COMMENT ON COLUMN "observable_areas"."satellite_id" IS 'satellite id';
            COMMENT ON COLUMN "observable_areas"."polygon" IS 'polygons composing the observation area'
        `);
        await queryRunner.query(`
            CREATE INDEX "IDX_c5452559742aaa8b8f40dc2741" ON "observable_areas" USING GiST ("polygon")
        `);
        await queryRunner.query(`
            CREATE TABLE "satellites" (
                "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
                "created_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "updated_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "deleted_at" TIMESTAMP(6) WITH TIME ZONE,
                "name" character varying NOT NULL,
                "satellite_id" character varying NOT NULL,
                "satellite_code" character varying NOT NULL,
                CONSTRAINT "UQ_a12e6ffd1faf91f258773ffa962" UNIQUE ("satellite_id"),
                CONSTRAINT "UQ_07cf92b5c2f2ba5028cfb3846da" UNIQUE ("satellite_code"),
                CONSTRAINT "PK_e2bf9f8a415cbd78e889efd40b0" PRIMARY KEY ("id")
            );
            COMMENT ON COLUMN "satellites"."id" IS 'satellite id';
            COMMENT ON COLUMN "satellites"."name" IS 'satellite name';
            COMMENT ON COLUMN "satellites"."satellite_id" IS 'determine satellites in daas';
            COMMENT ON COLUMN "satellites"."satellite_code" IS 'determine satellites in scs'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD CONSTRAINT "FK_a2889da6ac59c7175014a1d3e1b" FOREIGN KEY ("tasking_request_id") REFERENCES "tasking_requests"("id") ON DELETE CASCADE ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE "aoi_to_tasking_request"
            ADD CONSTRAINT "FK_37a500421a38daaee35ba9e707d" FOREIGN KEY ("aoi_id") REFERENCES "aois"("id") ON DELETE CASCADE ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE "aoi_to_tasking_request"
            ADD CONSTRAINT "FK_97e317f9c69add3451f043e030c" FOREIGN KEY ("tasking_request_id") REFERENCES "tasking_requests"("id") ON DELETE CASCADE ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data_versions"
            ADD CONSTRAINT "FK_2b4877b421278d2587ed390a676" FOREIGN KEY ("product_datum_id") REFERENCES "product_data"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data_versions"
            ADD CONSTRAINT "FK_e7aef93cc631fd6f544aeac0fe3" FOREIGN KEY ("processing_request_id") REFERENCES "processing_requests"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE "processing_requests"
            ADD CONSTRAINT "FK_ba37f4dbbd98fd4a992bcfecc9a" FOREIGN KEY ("tasking_info_id") REFERENCES "tasking_infos"("id") ON DELETE CASCADE ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data"
            ADD CONSTRAINT "FK_ce102084c6b69980bdee6bb29e6" FOREIGN KEY ("processing_request_id") REFERENCES "processing_requests"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "product_data" DROP CONSTRAINT "FK_ce102084c6b69980bdee6bb29e6"
        `);
        await queryRunner.query(`
            ALTER TABLE "processing_requests" DROP CONSTRAINT "FK_ba37f4dbbd98fd4a992bcfecc9a"
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data_versions" DROP CONSTRAINT "FK_e7aef93cc631fd6f544aeac0fe3"
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data_versions" DROP CONSTRAINT "FK_2b4877b421278d2587ed390a676"
        `);
        await queryRunner.query(`
            ALTER TABLE "aoi_to_tasking_request" DROP CONSTRAINT "FK_97e317f9c69add3451f043e030c"
        `);
        await queryRunner.query(`
            ALTER TABLE "aoi_to_tasking_request" DROP CONSTRAINT "FK_37a500421a38daaee35ba9e707d"
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP CONSTRAINT "FK_a2889da6ac59c7175014a1d3e1b"
        `);
        await queryRunner.query(`
            DROP TABLE "satellites"
        `);
        await queryRunner.query(`
            DROP INDEX "public"."IDX_c5452559742aaa8b8f40dc2741"
        `);
        await queryRunner.query(`
            DROP TABLE "observable_areas"
        `);
        await queryRunner.query(`
            DROP TABLE "product_data"
        `);
        await queryRunner.query(`
            DROP TABLE "processing_requests"
        `);
        await queryRunner.query(`
            DROP TABLE "product_data_versions"
        `);
        await queryRunner.query(`
            DROP TABLE "aoi_to_tasking_request"
        `);
        await queryRunner.query(`
            DROP TABLE "tasking_requests"
        `);
        await queryRunner.query(`
            DROP TABLE "tasking_infos"
        `);
        await queryRunner.query(`
            DROP INDEX "public"."IDX_c307285f7fdfdb69bc15006ea4"
        `);
        await queryRunner.query(`
            DROP TABLE "aois"
        `);
    }

}
