import { MigrationInterface, QueryRunner } from "typeorm";

export class alterAoiToTaskingRequest1675927365527 implements MigrationInterface {
    name = 'alterAoiToTaskingRequest1675927365527'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "aoi_to_tasking_request" DROP CONSTRAINT "FK_37a500421a38daaee35ba9e707d"
        `);
        await queryRunner.query(`
            ALTER TABLE "aoi_to_tasking_request" DROP CONSTRAINT "FK_97e317f9c69add3451f043e030c"
        `);
        await queryRunner.query(`
            ALTER TABLE "aoi_to_tasking_request"
            ALTER COLUMN "aoi_id" DROP NOT NULL
        `);
        await queryRunner.query(`
            ALTER TABLE "aoi_to_tasking_request"
            ALTER COLUMN "tasking_request_id" DROP NOT NULL
        `);
        await queryRunner.query(`
            ALTER TABLE "aoi_to_tasking_request"
            ADD CONSTRAINT "FK_37a500421a38daaee35ba9e707d" FOREIGN KEY ("aoi_id") REFERENCES "aois"("id") ON DELETE
            SET NULL ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE "aoi_to_tasking_request"
            ADD CONSTRAINT "FK_97e317f9c69add3451f043e030c" FOREIGN KEY ("tasking_request_id") REFERENCES "tasking_requests"("id") ON DELETE
            SET NULL ON UPDATE NO ACTION
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "aoi_to_tasking_request" DROP CONSTRAINT "FK_97e317f9c69add3451f043e030c"
        `);
        await queryRunner.query(`
            ALTER TABLE "aoi_to_tasking_request" DROP CONSTRAINT "FK_37a500421a38daaee35ba9e707d"
        `);
        await queryRunner.query(`
            ALTER TABLE "aoi_to_tasking_request"
            ALTER COLUMN "tasking_request_id"
            SET NOT NULL
        `);
        await queryRunner.query(`
            ALTER TABLE "aoi_to_tasking_request"
            ALTER COLUMN "aoi_id"
            SET NOT NULL
        `);
        await queryRunner.query(`
            ALTER TABLE "aoi_to_tasking_request"
            ADD CONSTRAINT "FK_97e317f9c69add3451f043e030c" FOREIGN KEY ("tasking_request_id") REFERENCES "tasking_requests"("id") ON DELETE
            SET NULL ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE "aoi_to_tasking_request"
            ADD CONSTRAINT "FK_37a500421a38daaee35ba9e707d" FOREIGN KEY ("aoi_id") REFERENCES "aois"("id") ON DELETE
            SET NULL ON UPDATE NO ACTION
        `);
    }

}
