import { MigrationInterface, QueryRunner } from "typeorm";

export class AddColumnsProductDataVersion1708497963578 implements MigrationInterface {
    name = 'AddColumnsProductDataVersion1708497963578'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "product_data_versions"
            ADD "source_expired" TIMESTAMP(6) WITH TIME ZONE
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "product_data_versions"."source_expired" IS 'archive source expired date'
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data_versions"
            ADD "is_source_deleted" boolean NOT NULL DEFAULT false
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "product_data_versions"."is_source_deleted" IS 'is archive source deleted'
        `);
        await queryRunner.query(`
            CREATE INDEX "IDX_37edfea1c19b606ceda6fff3ae" ON "product_data_versions" ("is_source_deleted")
        `);
        await queryRunner.query(`
            UPDATE "product_data_versions"
            SET "source_expired" = NOW() + INTERVAL '385 DAYS'
        `)
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            DROP INDEX "public"."IDX_37edfea1c19b606ceda6fff3ae"
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "product_data_versions"."is_source_deleted" IS 'is archive source deleted'
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data_versions" DROP COLUMN "is_source_deleted"
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "product_data_versions"."source_expired" IS 'archive source expired date'
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data_versions" DROP COLUMN "source_expired"
        `);
    }

}
