import { MigrationInterface, QueryRunner } from "typeorm";

export class AddColumnTaskingInfo1708390033543 implements MigrationInterface {
    name = 'AddColumnTaskingInfo1708390033543'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD "download_expired" TIMESTAMP(6) WITH TIME ZONE
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."download_expired" IS 'product data download expired date'
        `);
        await queryRunner.query(`
            UPDATE "tasking_infos"
            SET "download_expired" = NOW() + INTERVAL '365 DAYS'
            WHERE "status" IN ('observation-completed')
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."download_expired" IS 'product data download expired date'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP COLUMN "download_expired"
        `);
    }

}
