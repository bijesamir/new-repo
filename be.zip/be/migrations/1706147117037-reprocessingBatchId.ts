import { MigrationInterface, QueryRunner } from "typeorm";

export class ReprocessingBatchId1706147117037 implements MigrationInterface {
    name = 'ReprocessingBatchId1706147117037'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "reprocessing_requests"
            ADD "dps_batch_id" character varying
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "reprocessing_requests"."dps_batch_id" IS 'id assigned to the batch by DPS'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "reprocessing_requests"."dps_batch_id" IS 'id assigned to the batch by DPS'
        `);
        await queryRunner.query(`
            ALTER TABLE "reprocessing_requests" DROP COLUMN "dps_batch_id"
        `);
    }

}
