import { MigrationInterface, QueryRunner } from "typeorm";

export class AddRelationArchivePurchasedRequestProductData1707081158199 implements MigrationInterface {
    name = 'AddRelationArchivePurchasedRequestProductData1707081158199'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "archive_purchased_product_data"
            ADD "product_data_version_id" uuid
        `);
        await queryRunner.query(`
            CREATE INDEX "IDX_4b5d66d7bbbe88d5a7aad76c13" ON "archive_purchased_product_data" ("product_data_version_id")
        `);
        await queryRunner.query(`
            ALTER TABLE "archive_purchased_product_data"
            ADD CONSTRAINT "FK_4b5d66d7bbbe88d5a7aad76c13c" FOREIGN KEY ("product_data_version_id") REFERENCES "product_data_versions"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE "archive_purchased_product_data"
            ADD "no" integer GENERATED ALWAYS AS IDENTITY NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "archive_purchased_product_data"."no" IS 'serial number'
        `);
        await queryRunner.query(`
            UPDATE archive_purchased_product_data 
            SET product_data_version_id=prepare_apr_appd_pdv.pdv_id
            FROM (
                SELECT
                    apr.id AS apr_id,
                    apr.status AS apr_status,
                    appd.product_datum_id AS appd_pd_id,
                    pdv.id AS pdv_id
                FROM archive_purchase_requests apr
                JOIN archive_purchased_product_data appd
                    ON appd.archive_purchase_request_id=apr.id
                JOIN product_data_versions pdv
                    ON pdv.product_datum_id=appd.product_datum_id
                    AND pdv.no = (
                        SELECT max(no)
                        FROM product_data_versions
                        WHERE product_datum_id=appd.product_datum_id
                            AND deleted_at IS NULL
                        )
                WHERE apr.status='completed'
            ) AS prepare_apr_appd_pdv
            WHERE archive_purchase_request_id=prepare_apr_appd_pdv.apr_id
            AND product_datum_id=prepare_apr_appd_pdv.appd_pd_id
        `);
        await queryRunner.query(`
            UPDATE archive_purchased_product_data 
            SET product_data_version_id=prepare_apr_rr_pdv.pdv_id
            FROM (
                SELECT
                    apr.id AS apr_id,
                    apr.status AS apr_status,
                    rr.id AS rr_id,
                    rr.status AS rr_status,
                    rr.product_datum_id AS rr_pd_id,
                    pdv.id AS pdv_id
                FROM archive_purchase_requests apr
                JOIN join_archive_purchase_request_on_reprocessing_request apr_rr
                    ON apr_rr.archive_purchase_request_id=apr.id
                JOIN reprocessing_requests rr
                    ON rr.id=apr_rr.reprocessing_request_id
                JOIN product_data_versions pdv
                    ON pdv.product_datum_id=rr.product_datum_id
                    AND pdv.no = (
                        SELECT max(no)
                        FROM product_data_versions
                        WHERE product_datum_id=rr.product_datum_id
                            AND deleted_at IS NULL
                        )
                WHERE apr.status='new'
                AND rr.status='completed'
            ) AS prepare_apr_rr_pdv
            WHERE archive_purchase_request_id=prepare_apr_rr_pdv.apr_id
            AND product_datum_id=prepare_apr_rr_pdv.rr_pd_id
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "archive_purchased_product_data"."no" IS 'serial number'
        `);
        await queryRunner.query(`
            ALTER TABLE "archive_purchased_product_data" DROP COLUMN "no"
        `);
        await queryRunner.query(`
            ALTER TABLE "archive_purchased_product_data" DROP CONSTRAINT "FK_4b5d66d7bbbe88d5a7aad76c13c"
        `);
        await queryRunner.query(`
            DROP INDEX "public"."IDX_4b5d66d7bbbe88d5a7aad76c13"
        `);
        await queryRunner.query(`
            ALTER TABLE "archive_purchased_product_data" DROP COLUMN "product_data_version_id"
        `);
    }

}
