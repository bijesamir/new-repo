import { MigrationInterface, QueryRunner } from "typeorm";

export class alterTaskingInfos1677027633772 implements MigrationInterface {
    name = 'alterTaskingInfos1677027633772'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ALTER COLUMN "observation_area" TYPE geometry(PolygonZ, 4326)
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ALTER COLUMN "observation_area" TYPE geometry(GEOMETRY, 0)
        `);
    }

}
