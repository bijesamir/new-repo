import { MigrationInterface, QueryRunner } from "typeorm";

export class AddColumnToProductData1691482933949 implements MigrationInterface {
    name = 'AddColumnToProductData1691482933949'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "product_data"
            ADD "resolution_mode" integer NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "product_data"."resolution_mode" IS 'resolution mode'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "product_data"."resolution_mode" IS 'resolution mode'
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data" DROP COLUMN "resolution_mode"
        `);
    }

}
