import { MigrationInterface, QueryRunner } from "typeorm";

export class addColumnToProcessingResult1681090127086 implements MigrationInterface {
    name = 'addColumnToProcessingResult1681090127086'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "processing_results"
            ADD "latest_editor_id" character varying(128) NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "processing_results"."latest_editor_id" IS 'User ID who last edited this record'
        `);
        await queryRunner.query(`
            ALTER TABLE "processing_results"
            ADD "organization_id" integer NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "processing_results"."organization_id" IS 'Organization ID associated with this record'
        `);
        await queryRunner.query(`
            ALTER TABLE "processing_results"
            ADD "note" text
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "processing_results"."note" IS 'Matters that are not used in processing but that you want to keep as a memo'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "processing_results"."note" IS 'Matters that are not used in processing but that you want to keep as a memo'
        `);
        await queryRunner.query(`
            ALTER TABLE "processing_results" DROP COLUMN "note"
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "processing_results"."organization_id" IS 'Organization ID associated with this record'
        `);
        await queryRunner.query(`
            ALTER TABLE "processing_results" DROP COLUMN "organization_id"
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "processing_results"."latest_editor_id" IS 'User ID who last edited this record'
        `);
        await queryRunner.query(`
            ALTER TABLE "processing_results" DROP COLUMN "latest_editor_id"
        `);
    }

}
