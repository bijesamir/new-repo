import { MigrationInterface, QueryRunner } from "typeorm";

export class AddColumnSceneInfo1705032867270 implements MigrationInterface {
    name = 'AddColumnSceneInfo1705032867270'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "scene_infos"
            ADD "no" integer GENERATED ALWAYS AS IDENTITY NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "scene_infos"."no" IS 'serial number of SceneInfo'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "scene_infos"."no" IS 'serial number of SceneInfo'
        `);
        await queryRunner.query(`
            ALTER TABLE "scene_infos" DROP COLUMN "no"
        `);
    }

}
