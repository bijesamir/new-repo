import { MigrationInterface, QueryRunner } from "typeorm";

export class changeTypeTaskingType1687333820774 implements MigrationInterface {
    name = 'changeTypeTaskingType1687333820774'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP COLUMN "tasking_type"
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD "tasking_type" integer NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."tasking_type" IS 'tasking type'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."tasking_type" IS 'tasking type'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP COLUMN "tasking_type"
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD "tasking_type" character varying NOT NULL
        `);
    }

}
