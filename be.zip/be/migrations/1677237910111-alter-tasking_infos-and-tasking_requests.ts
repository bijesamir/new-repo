import { MigrationInterface, QueryRunner } from "typeorm";

export class alterTaskingInfosAndTaskingRequests1677237910111 implements MigrationInterface {
    name = 'alterTaskingInfosAndTaskingRequests1677237910111'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "tasking_requests"
            ADD "polarization" integer NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_requests"."polarization" IS 'polarization type'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD "polarization" integer NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."polarization" IS 'polarization type'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."polarization" IS 'polarization type'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP COLUMN "polarization"
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_requests"."polarization" IS 'polarization type'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_requests" DROP COLUMN "polarization"
        `);
    }

}
