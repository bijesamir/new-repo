import { MigrationInterface, QueryRunner } from 'typeorm';

export class dropAoiToTaskingRequest1676358293290
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            DROP TABLE "aoi_to_tasking_request" CASCADE
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {}
}
