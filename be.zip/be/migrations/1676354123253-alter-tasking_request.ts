import { MigrationInterface, QueryRunner } from "typeorm";

export class alterTaskingRequest1676354123253 implements MigrationInterface {
    name = 'alterTaskingRequest1676354123253'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "tasking_requests"
            ADD "name" character varying(255)
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_requests"."name" IS 'tasking request name (option)'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_requests"."name" IS 'tasking request name (option)'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_requests" DROP COLUMN "name"
        `);
    }

}
