import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddColumnReprocessingRequests1707013792173
  implements MigrationInterface
{
  name = 'AddColumnReprocessingRequests1707013792173';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "reprocessing_requests"
            ADD "due_date" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT NOW() + '7 day'
        `);
    await queryRunner.query(`
            UPDATE "reprocessing_requests"
            SET "due_date" = "created_at" + INTERVAL '7 DAYS'
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "reprocessing_requests" DROP COLUMN "due_date"
        `);
  }
}
