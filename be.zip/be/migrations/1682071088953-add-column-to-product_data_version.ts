import { MigrationInterface, QueryRunner } from "typeorm";

export class addColumnToProductDataVersion1682071088953 implements MigrationInterface {
    name = 'addColumnToProductDataVersion1682071088953'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "product_data_versions"
            ADD "metadata" jsonb NOT NULL DEFAULT '{}'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "product_data_versions" DROP COLUMN "metadata"
        `);
    }

}
