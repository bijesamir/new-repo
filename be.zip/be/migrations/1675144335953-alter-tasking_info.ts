import { MigrationInterface, QueryRunner } from "typeorm";

export class alterTaskingInfo1675144335953 implements MigrationInterface {
    name = 'alterTaskingInfo1675144335953'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP COLUMN "center_position"
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP COLUMN "satellite"
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD "center" geometry(Point, 4326) NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."center" IS 'center of tasking'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD "altitude" numeric(8, 3) NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."altitude" IS 'altitude of tasking'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD "satellite_id" uuid NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."satellite_id" IS 'satellite id'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD "aoi_id" uuid NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."aoi_id" IS 'aoi id'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD "latest_editor_id" uuid NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."latest_editor_id" IS 'userId who last edited the record'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD "organization_id" uuid NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."organization_id" IS 'ID of the organization to which this record belongs'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD "contract_id" uuid NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."contract_id" IS 'Contract ID associated with the tasking request'
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."observation_area" IS 'observation area of tasking'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ALTER COLUMN "observation_area" TYPE geometry(GEOMETRY, 0)
        `);
        await queryRunner.query(`
            CREATE INDEX "IDX_c03a5b44ddd44c39a0a4fad586" ON "tasking_infos" USING GiST ("center")
        `);
        await queryRunner.query(`
            CREATE INDEX "IDX_6d7806e4b5e184ddfb2000bffc" ON "tasking_infos" USING GiST ("observation_area")
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD CONSTRAINT "FK_a7cee045eaf9ad367a86a4fd898" FOREIGN KEY ("satellite_id") REFERENCES "satellites"("id") ON DELETE CASCADE ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD CONSTRAINT "FK_0d45b0fa3461ca042e986ab0d18" FOREIGN KEY ("aoi_id") REFERENCES "aois"("id") ON DELETE CASCADE ON UPDATE NO ACTION
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP CONSTRAINT "FK_0d45b0fa3461ca042e986ab0d18"
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP CONSTRAINT "FK_a7cee045eaf9ad367a86a4fd898"
        `);
        await queryRunner.query(`
            DROP INDEX "public"."IDX_6d7806e4b5e184ddfb2000bffc"
        `);
        await queryRunner.query(`
            DROP INDEX "public"."IDX_c03a5b44ddd44c39a0a4fad586"
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ALTER COLUMN "observation_area" TYPE geometry(POLYGON, 4326)
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."observation_area" IS 'observation area'
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."contract_id" IS 'Contract ID associated with the tasking request'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP COLUMN "contract_id"
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."organization_id" IS 'ID of the organization to which this record belongs'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP COLUMN "organization_id"
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."latest_editor_id" IS 'userId who last edited the record'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP COLUMN "latest_editor_id"
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."aoi_id" IS 'aoi id'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP COLUMN "aoi_id"
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."satellite_id" IS 'satellite id'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP COLUMN "satellite_id"
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."altitude" IS 'altitude of tasking'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP COLUMN "altitude"
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."center" IS 'center of tasking'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP COLUMN "center"
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD "satellite" character varying NOT NULL
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD "center_position" geometry(POINT, 4326) NOT NULL
        `);
    }

}
