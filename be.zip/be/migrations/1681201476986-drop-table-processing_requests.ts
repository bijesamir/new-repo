import { MigrationInterface, QueryRunner } from "typeorm";

export class dropTableProcessingRequests1681201476986 implements MigrationInterface {
    name = 'dropTableProcessingRequests1681201476986'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "product_data" DROP CONSTRAINT "FK_ce102084c6b69980bdee6bb29e6"
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data_versions" DROP CONSTRAINT "FK_e7aef93cc631fd6f544aeac0fe3"
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data_versions" DROP CONSTRAINT "REL_e7aef93cc631fd6f544aeac0fe"
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data_versions" DROP COLUMN "processing_request_id"
        `);
        await queryRunner.query(`
            ALTER TABLE "archive_requests" DROP COLUMN "contract_id"
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data" DROP CONSTRAINT "REL_ce102084c6b69980bdee6bb29e"
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "product_data"
            ADD CONSTRAINT "REL_ce102084c6b69980bdee6bb29e" UNIQUE ("processing_request_id")
        `);
        await queryRunner.query(`
            ALTER TABLE "archive_requests"
            ADD "contract_id" integer NOT NULL
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data_versions"
            ADD "processing_request_id" uuid NOT NULL
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data_versions"
            ADD CONSTRAINT "REL_e7aef93cc631fd6f544aeac0fe" UNIQUE ("processing_request_id")
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data_versions"
            ADD CONSTRAINT "FK_e7aef93cc631fd6f544aeac0fe3" FOREIGN KEY ("processing_request_id") REFERENCES "processing_requests"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data"
            ADD CONSTRAINT "FK_ce102084c6b69980bdee6bb29e6" FOREIGN KEY ("processing_request_id") REFERENCES "processing_requests"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
    }

}
