import { MigrationInterface, QueryRunner } from 'typeorm';

export class changeTypeOfLastEditorId1680071855245
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "tasking_infos"
              ALTER COLUMN "latest_editor_id" TYPE VARCHAR(128) -- There is no rationale for string length
        `);
    await queryRunner.query(`
            ALTER TABLE "aois"
              ALTER COLUMN "latest_editor_id" TYPE VARCHAR(128) -- There is no rationale for string length
        `);
    await queryRunner.query(`
            ALTER TABLE "tasking_requests"
              ALTER COLUMN "latest_editor_id" TYPE VARCHAR(128) -- There is no rationale for string length
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "tasking_infos"
              ALTER COLUMN "latest_editor_id" TYPE integer USING latest_editor_id::integer
        `);
    await queryRunner.query(`
            ALTER TABLE "aois"
              ALTER COLUMN "latest_editor_id" TYPE integer USING latest_editor_id::integer
        `);
    await queryRunner.query(`
            ALTER TABLE "tasking_requests"
              ALTER COLUMN "latest_editor_id" TYPE integer USING latest_editor_id::integer
        `);
  }
}
