import { MigrationInterface, QueryRunner } from "typeorm";

export class alterSatellite1675402597914 implements MigrationInterface {
    name = 'alterSatellite1675402597914'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "satellites"
            ADD "is_available" boolean NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "satellites"."is_available" IS 'available or not'
        `);
        await queryRunner.query(`
            ALTER TABLE "satellites"
            ADD "parameters" jsonb NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "satellites"."parameters" IS 'satellite parameters'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "satellites"."parameters" IS 'satellite parameters'
        `);
        await queryRunner.query(`
            ALTER TABLE "satellites" DROP COLUMN "parameters"
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "satellites"."is_available" IS 'available or not'
        `);
        await queryRunner.query(`
            ALTER TABLE "satellites" DROP COLUMN "is_available"
        `);
    }

}
