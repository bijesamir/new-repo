import { MigrationInterface, QueryRunner } from "typeorm";

export class SceneInfoArchivePurchaseRequest1702351794937 implements MigrationInterface {
    name = 'SceneInfoArchivePurchaseRequest1702351794937'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            CREATE TABLE "scene_infos" (
                "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
                "scene_no" integer NOT NULL,
                "scene_info_id" character varying NOT NULL,
                "created_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "updated_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "deleted_at" TIMESTAMP(6) WITH TIME ZONE,
                "tasking_info_id" uuid,
                CONSTRAINT "UQ_2ad7a44f24e44949b73ea869232" UNIQUE ("scene_info_id"),
                CONSTRAINT "UQ_e682dac9db03b9eb53d6192eafc" UNIQUE ("tasking_info_id", "scene_no"),
                CONSTRAINT "PK_193cef2119f09ecd52ffbdae960" PRIMARY KEY ("id")
            );
            COMMENT ON COLUMN "scene_infos"."id" IS 'id to be used system internal only';
            COMMENT ON COLUMN "scene_infos"."scene_no" IS 'scene number';
            COMMENT ON COLUMN "scene_infos"."scene_info_id" IS 'sceneInfo unique ID';
            COMMENT ON COLUMN "scene_infos"."tasking_info_id" IS 'tasking_info id'
        `);
        await queryRunner.query(`
            CREATE TABLE "archive_purchase_requests" (
                "latest_editor_id" character varying(128) NOT NULL,
                "organization_id" integer NOT NULL,
                "contract_id" integer NOT NULL,
                "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
                "request_id" character varying NOT NULL,
                "no" integer GENERATED ALWAYS AS IDENTITY NOT NULL,
                "created_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "updated_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "deleted_at" TIMESTAMP(6) WITH TIME ZONE,
                "status" character varying NOT NULL,
                CONSTRAINT "UQ_55a4f794008052265d188574dac" UNIQUE ("request_id"),
                CONSTRAINT "PK_34918398a54fa04cd58e3f8ac7f" PRIMARY KEY ("id")
            );
            COMMENT ON COLUMN "archive_purchase_requests"."latest_editor_id" IS 'User ID who last edited this record';
            COMMENT ON COLUMN "archive_purchase_requests"."organization_id" IS 'Organization ID associated with this record';
            COMMENT ON COLUMN "archive_purchase_requests"."contract_id" IS 'Contract ID associated with this record';
            COMMENT ON COLUMN "archive_purchase_requests"."id" IS 'archive_purchase id';
            COMMENT ON COLUMN "archive_purchase_requests"."request_id" IS 'archive purchase request external ID';
            COMMENT ON COLUMN "archive_purchase_requests"."no" IS 'serial number of ArchivePurchaseRequest';
            COMMENT ON COLUMN "archive_purchase_requests"."status" IS 'status'
        `);
        await queryRunner.query(`
            CREATE TABLE "archive_purchase_requests_product_data" (
                "archive_purchase_request_id" uuid NOT NULL,
                "product_datum_id" uuid NOT NULL,
                CONSTRAINT "PK_df723e72d33c2e6b43ae61a5681" PRIMARY KEY (
                    "archive_purchase_request_id",
                    "product_datum_id"
                )
            )
        `);
        await queryRunner.query(`
            CREATE INDEX "IDX_87311bb5eac8f41d13ee45b895" ON "archive_purchase_requests_product_data" ("archive_purchase_request_id")
        `);
        await queryRunner.query(`
            CREATE INDEX "IDX_53da14928e390ffe807b2db568" ON "archive_purchase_requests_product_data" ("product_datum_id")
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data"
            ADD "scene_info_id" uuid
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "product_data"."scene_info_id" IS 'id to be used system internal only'
        `);
        await queryRunner.query(`
            ALTER TABLE "scene_infos"
            ADD CONSTRAINT "FK_e506fdc30e787073e98637efdaf" FOREIGN KEY ("tasking_info_id") REFERENCES "tasking_infos"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data"
            ADD CONSTRAINT "FK_88ef03409348aef512dd2308dd1" FOREIGN KEY ("scene_info_id") REFERENCES "scene_infos"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE "archive_purchase_requests_product_data"
            ADD CONSTRAINT "FK_87311bb5eac8f41d13ee45b895c" FOREIGN KEY ("archive_purchase_request_id") REFERENCES "archive_purchase_requests"("id") ON DELETE CASCADE ON UPDATE CASCADE
        `);
        await queryRunner.query(`
            ALTER TABLE "archive_purchase_requests_product_data"
            ADD CONSTRAINT "FK_53da14928e390ffe807b2db568e" FOREIGN KEY ("product_datum_id") REFERENCES "product_data"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "archive_purchase_requests_product_data" DROP CONSTRAINT "FK_53da14928e390ffe807b2db568e"
        `);
        await queryRunner.query(`
            ALTER TABLE "archive_purchase_requests_product_data" DROP CONSTRAINT "FK_87311bb5eac8f41d13ee45b895c"
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data" DROP CONSTRAINT "FK_88ef03409348aef512dd2308dd1"
        `);
        await queryRunner.query(`
            ALTER TABLE "scene_infos" DROP CONSTRAINT "FK_e506fdc30e787073e98637efdaf"
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "product_data"."scene_info_id" IS 'id to be used system internal only'
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data" DROP COLUMN "scene_info_id"
        `);
        await queryRunner.query(`
            DROP INDEX "public"."IDX_53da14928e390ffe807b2db568"
        `);
        await queryRunner.query(`
            DROP INDEX "public"."IDX_87311bb5eac8f41d13ee45b895"
        `);
        await queryRunner.query(`
            DROP TABLE "archive_purchase_requests_product_data"
        `);
        await queryRunner.query(`
            DROP TABLE "archive_purchase_requests"
        `);
        await queryRunner.query(`
            DROP TABLE "scene_infos"
        `);
    }

}
