import { MigrationInterface, QueryRunner } from 'typeorm';

export class dropTableProcessingRequests1681201546059
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
        DROP TABLE processing_requests
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            CREATE TABLE "processing_requests" (
                "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
                "no" integer GENERATED ALWAYS AS IDENTITY NOT NULL,
                "created_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "updated_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "deleted_at" TIMESTAMP(6) WITH TIME ZONE,
                "tasking_info_id" uuid NOT NULL,
                "status" character varying NOT NULL,
                "format" character varying NOT NULL,
                CONSTRAINT "PK_46414274080ed50db44039331a4" PRIMARY KEY ("id")
            );
            COMMENT ON COLUMN "processing_requests"."id" IS 'processing_request id';
            COMMENT ON COLUMN "processing_requests"."no" IS 'serial number of ProcessingRequest';
            COMMENT ON COLUMN "processing_requests"."tasking_info_id" IS 'tasking_info id';
            COMMENT ON COLUMN "processing_requests"."status" IS 'status';
            COMMENT ON COLUMN "processing_requests"."format" IS 'product format'
        `);
    await queryRunner.query(`
            ALTER TABLE "processing_requests"
            ADD CONSTRAINT "FK_ba37f4dbbd98fd4a992bcfecc9a" FOREIGN KEY ("tasking_info_id") REFERENCES "tasking_infos"("id") ON DELETE CASCADE ON UPDATE NO ACTION
        `);
  }
}
