import { MigrationInterface, QueryRunner } from "typeorm";

export class SceneInfoIdChange1702623588564 implements MigrationInterface {
    name = 'SceneInfoIdChange1702623588564'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "scene_infos"
                RENAME COLUMN "scene_info_id" TO "item_id"
        `);
        await queryRunner.query(`
            ALTER TABLE "scene_infos"
                RENAME CONSTRAINT "UQ_2ad7a44f24e44949b73ea869232" TO "UQ_3a0e4c63ebe0cd73de8bcddf5c2"
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "scene_infos"
                RENAME CONSTRAINT "UQ_3a0e4c63ebe0cd73de8bcddf5c2" TO "UQ_2ad7a44f24e44949b73ea869232"
        `);
        await queryRunner.query(`
            ALTER TABLE "scene_infos"
                RENAME COLUMN "item_id" TO "scene_info_id"
        `);
    }

}
