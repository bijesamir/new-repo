import { MigrationInterface, QueryRunner } from "typeorm";

export class addColumnToProductData1688088867725 implements MigrationInterface {
    name = 'addColumnToProductData1688088867725'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "product_data"
            ADD "scene_no" integer NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "product_data"."scene_no" IS 'scene number'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "product_data"."scene_no" IS 'scene number'
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data" DROP COLUMN "scene_no"
        `);
    }

}
