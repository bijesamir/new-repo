import { MigrationInterface, QueryRunner } from "typeorm";

export class addArchiveRequest1681111214703 implements MigrationInterface {
    name = 'addArchiveRequest1681111214703'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            CREATE TABLE "archive_requests" (
                "latest_editor_id" character varying(128) NOT NULL,
                "organization_id" integer NOT NULL,
                "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
                "no" integer GENERATED ALWAYS AS IDENTITY NOT NULL,
                "product_data_version_id" uuid NOT NULL,
                "status" character varying NOT NULL,
                "status_detail" integer NOT NULL DEFAULT '0',
                CONSTRAINT "PK_1e846a0a6a139cc898bf83d9b0e" PRIMARY KEY ("id")
            );
            COMMENT ON COLUMN "archive_requests"."latest_editor_id" IS 'User ID who last edited this record';
            COMMENT ON COLUMN "archive_requests"."organization_id" IS 'Organization ID associated with this record';
            COMMENT ON COLUMN "archive_requests"."id" IS 'archive_request id';
            COMMENT ON COLUMN "archive_requests"."no" IS 'serial number of ArchiveRequest';
            COMMENT ON COLUMN "archive_requests"."product_data_version_id" IS 'product data version id';
            COMMENT ON COLUMN "archive_requests"."status" IS 'status';
            COMMENT ON COLUMN "archive_requests"."status_detail" IS 'Status detail'
        `);
        await queryRunner.query(`
            ALTER TABLE "archive_requests"
            ADD CONSTRAINT "FK_e43bb9016756007184ea34efb56" FOREIGN KEY ("product_data_version_id") REFERENCES "product_data_versions"("id") ON DELETE CASCADE ON UPDATE NO ACTION
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "archive_requests" DROP CONSTRAINT "FK_e43bb9016756007184ea34efb56"
        `);
        await queryRunner.query(`
            DROP TABLE "archive_requests"
        `);
    }

}
