import { MigrationInterface, QueryRunner } from "typeorm";

export class changeTypeForRelatedCitadelData1677748584524 implements MigrationInterface {
    name = 'changeTypeForRelatedCitadelData1677748584524'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP COLUMN "latest_editor_id"
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD "latest_editor_id" integer NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."latest_editor_id" IS 'User ID who last edited this record'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP COLUMN "organization_id"
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD "organization_id" integer NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."organization_id" IS 'Organization ID associated with this record'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP COLUMN "contract_id"
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD "contract_id" integer NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."contract_id" IS 'Contract ID associated with this record'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_requests" DROP COLUMN "latest_editor_id"
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_requests"
            ADD "latest_editor_id" integer NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_requests"."latest_editor_id" IS 'User ID who last edited this record'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_requests" DROP COLUMN "organization_id"
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_requests"
            ADD "organization_id" integer NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_requests"."organization_id" IS 'Organization ID associated with this record'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_requests" DROP COLUMN "contract_id"
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_requests"
            ADD "contract_id" integer NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_requests"."contract_id" IS 'Contract ID associated with this record'
        `);
        await queryRunner.query(`
            ALTER TABLE "aois" DROP COLUMN "latest_editor_id"
        `);
        await queryRunner.query(`
            ALTER TABLE "aois"
            ADD "latest_editor_id" integer NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "aois"."latest_editor_id" IS 'User ID who last edited this record'
        `);
        await queryRunner.query(`
            ALTER TABLE "aois" DROP COLUMN "organization_id"
        `);
        await queryRunner.query(`
            ALTER TABLE "aois"
            ADD "organization_id" integer NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "aois"."organization_id" IS 'Organization ID associated with this record'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "aois"."organization_id" IS 'Organization ID associated with this record'
        `);
        await queryRunner.query(`
            ALTER TABLE "aois" DROP COLUMN "organization_id"
        `);
        await queryRunner.query(`
            ALTER TABLE "aois"
            ADD "organization_id" uuid NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "aois"."latest_editor_id" IS 'User ID who last edited this record'
        `);
        await queryRunner.query(`
            ALTER TABLE "aois" DROP COLUMN "latest_editor_id"
        `);
        await queryRunner.query(`
            ALTER TABLE "aois"
            ADD "latest_editor_id" uuid NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_requests"."contract_id" IS 'Contract ID associated with this record'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_requests" DROP COLUMN "contract_id"
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_requests"
            ADD "contract_id" uuid NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_requests"."organization_id" IS 'Organization ID associated with this record'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_requests" DROP COLUMN "organization_id"
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_requests"
            ADD "organization_id" uuid NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_requests"."latest_editor_id" IS 'User ID who last edited this record'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_requests" DROP COLUMN "latest_editor_id"
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_requests"
            ADD "latest_editor_id" uuid NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."contract_id" IS 'Contract ID associated with this record'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP COLUMN "contract_id"
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD "contract_id" uuid NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."organization_id" IS 'Organization ID associated with this record'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP COLUMN "organization_id"
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD "organization_id" uuid NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."latest_editor_id" IS 'User ID who last edited this record'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP COLUMN "latest_editor_id"
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD "latest_editor_id" uuid NOT NULL
        `);
    }

}
