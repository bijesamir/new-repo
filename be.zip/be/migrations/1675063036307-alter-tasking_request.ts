import { MigrationInterface, QueryRunner } from "typeorm";

export class alterTaskingRequest1675063036307 implements MigrationInterface {
    name = 'alterTaskingRequest1675063036307'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "tasking_requests"
            ADD "latest_editor_id" uuid NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_requests"."latest_editor_id" IS 'userId who last edited the record'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_requests"
            ADD "organization_id" uuid NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_requests"."organization_id" IS 'ID of the organization to which this record belongs'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_requests"
            ADD "contract_id" uuid NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_requests"."contract_id" IS 'Contract ID associated with the tasking request'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_requests"."contract_id" IS 'Contract ID associated with the tasking request'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_requests" DROP COLUMN "contract_id"
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_requests"."organization_id" IS 'ID of the organization to which this record belongs'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_requests" DROP COLUMN "organization_id"
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_requests"."latest_editor_id" IS 'userId who last edited the record'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_requests" DROP COLUMN "latest_editor_id"
        `);
    }

}
