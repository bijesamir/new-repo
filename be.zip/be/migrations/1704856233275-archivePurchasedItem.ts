import { MigrationInterface, QueryRunner } from 'typeorm';

export class ArchivePurchasedItem1704856233275 implements MigrationInterface {
  name = 'ArchivePurchasedItem1704856233275';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            CREATE TABLE "archive_purchased_items" (
                "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
                "registration_id" integer,
                "consumption_credit" integer,
                "archive_purchase_request_id" uuid,
                "scene_info_id" uuid,
                CONSTRAINT "UQ_856f5419963c128aa210b91d3dd" UNIQUE ("archive_purchase_request_id", "scene_info_id"),
                CONSTRAINT "PK_81692f940392ab91619baa58239" PRIMARY KEY ("id")
            );
            COMMENT ON COLUMN "archive_purchased_items"."registration_id" IS 'payment registration Id';
            COMMENT ON COLUMN "archive_purchased_items"."consumption_credit" IS 'payment consumption credit';
            COMMENT ON COLUMN "archive_purchased_items"."archive_purchase_request_id" IS 'archive_purchase id';
            COMMENT ON COLUMN "archive_purchased_items"."scene_info_id" IS 'id to be used system internal only'
        `);
    await queryRunner.query(`
            ALTER TABLE "archive_purchased_items"
            ADD CONSTRAINT "FK_48a43dd1e97261bf10155d455d0" FOREIGN KEY ("archive_purchase_request_id") REFERENCES "archive_purchase_requests"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
    await queryRunner.query(`
            ALTER TABLE "archive_purchased_items"
            ADD CONSTRAINT "FK_b7fa2f1095ee71151d3ff94fb4c" FOREIGN KEY ("scene_info_id") REFERENCES "scene_infos"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
    await queryRunner.query(`
        INSERT INTO archive_purchased_items (archive_purchase_request_id, scene_info_id)
        SELECT DISTINCT apr.id, si.id
        FROM archive_purchase_requests apr
        JOIN archive_purchase_requests_product_data a2p ON apr.id = a2p.archive_purchase_request_id
        JOIN product_data pd ON pd.id = a2p.product_datum_id
        JOIN scene_infos si ON si.id = pd.scene_info_id
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "archive_purchased_items" DROP CONSTRAINT "FK_b7fa2f1095ee71151d3ff94fb4c"
        `);
    await queryRunner.query(`
            ALTER TABLE "archive_purchased_items" DROP CONSTRAINT "FK_48a43dd1e97261bf10155d455d0"
        `);
    await queryRunner.query(`
            DROP TABLE "archive_purchased_items"
        `);
  }
}
