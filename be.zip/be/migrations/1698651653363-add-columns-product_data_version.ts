import { ProductDataVersion } from '@iris-lib/db/entities';
import { toPoint, toPolygon } from '@iris-lib/utils';
import { Point, Polygon } from 'geojson';
import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddColumnsProductDataVersion1698651653363
  implements MigrationInterface
{
  name = 'AddColumnsProductDataVersion1698651653363';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            ALTER TABLE "product_data_versions"
            ADD "center" geometry(POINT, 4326)
        `);
    await queryRunner.query(`
            COMMENT ON COLUMN "product_data_versions"."center" IS 'scene center'
        `);
    await queryRunner.query(`
            ALTER TABLE "product_data_versions"
            ADD "area" geometry(POLYGON, 4326)
        `);
    await queryRunner.query(`
            COMMENT ON COLUMN "product_data_versions"."area" IS 'area defined by scene corners'
        `);
    await queryRunner.query(`
            CREATE INDEX "IDX_fe8ae5b3e4544418b11a5d65ed" ON "product_data_versions" USING GiST ("center")
        `);
    await queryRunner.query(`
            CREATE INDEX "IDX_1936e58ff3153e54107fca474f" ON "product_data_versions" USING GiST ("area")
        `);
    await queryRunner.query(`
            UPDATE product_data_versions AS pdv
            SET center = (
              SELECT array_agg(ST_MakePoint(a, b) ORDER BY o)
              FROM (
                SELECT elem::double precision AS a, lead(elem::double precision) OVER (ORDER BY o) AS b, o
                FROM UNNEST(string_to_array(metadata::jsonb -> 'geometry' ->> 'sceneCenterLocation', ' ')) WITH ORDINALITY els(elem, o)
              ) AS pairs
              WHERE o % 2 = 1
            )[1]
        `);
    await queryRunner.query(`
            UPDATE product_data_versions
            SET area = ST_MakePolygon(
              ST_MakeLine(
                (
                  SELECT array_agg(ST_MakePoint(a, b) ORDER BY o)
                  FROM (
                    SELECT elem::double precision AS a, lead(elem::double precision) OVER (ORDER BY o) AS b, o
                    FROM UNNEST(string_to_array(metadata::jsonb -> 'geometry' ->> 'sceneCornerLocations', ' ')) WITH ORDINALITY els(elem, o)
                  ) AS pairs
                  WHERE o % 2 = 1
                )
              )
            )
        `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            DROP INDEX "public"."IDX_1936e58ff3153e54107fca474f"
        `);
    await queryRunner.query(`
            DROP INDEX "public"."IDX_fe8ae5b3e4544418b11a5d65ed"
        `);
    await queryRunner.query(`
            COMMENT ON COLUMN "product_data_versions"."area" IS 'area defined by scene corners'
        `);
    await queryRunner.query(`
            ALTER TABLE "product_data_versions" DROP COLUMN "area"
        `);
    await queryRunner.query(`
            COMMENT ON COLUMN "product_data_versions"."center" IS 'scene center'
        `);
    await queryRunner.query(`
            ALTER TABLE "product_data_versions" DROP COLUMN "center"
        `);
  }
}
