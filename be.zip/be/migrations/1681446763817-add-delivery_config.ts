import { MigrationInterface, QueryRunner } from "typeorm";

export class addDeliveryConfig1681446763817 implements MigrationInterface {
    name = 'addDeliveryConfig1681446763817'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            CREATE TABLE "delivery_configs" (
                "latest_editor_id" character varying(128) NOT NULL,
                "organization_id" integer NOT NULL,
                "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
                "no" integer GENERATED ALWAYS AS IDENTITY NOT NULL,
                "created_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "updated_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "deleted_at" TIMESTAMP(6) WITH TIME ZONE,
                "method" integer NOT NULL,
                "config" text NOT NULL,
                "job_name" character varying(32) NOT NULL,
                CONSTRAINT "PK_77a39b50899362bc5a0867c6b94" PRIMARY KEY ("id")
            );
            COMMENT ON COLUMN "delivery_configs"."latest_editor_id" IS 'User ID who last edited this record';
            COMMENT ON COLUMN "delivery_configs"."organization_id" IS 'Organization ID associated with this record';
            COMMENT ON COLUMN "delivery_configs"."id" IS 'delivery_config id';
            COMMENT ON COLUMN "delivery_configs"."no" IS 'serial number of DeliveryConfig';
            COMMENT ON COLUMN "delivery_configs"."method" IS 'delivery method';
            COMMENT ON COLUMN "delivery_configs"."config" IS 'configuration information about delivery';
            COMMENT ON COLUMN "delivery_configs"."job_name" IS 'job name'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            DROP TABLE "delivery_configs"
        `);
    }

}
