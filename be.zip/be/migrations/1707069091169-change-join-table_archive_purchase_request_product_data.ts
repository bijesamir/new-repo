import { MigrationInterface, QueryRunner } from 'typeorm';

export class ChangeJoinTableArchivePurchaseRequestProductData1707069091169
  implements MigrationInterface
{
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
        ALTER TABLE archive_purchase_requests_product_data
        RENAME TO archive_purchased_product_data
    `);
    await queryRunner.query(`
        ALTER TABLE "archive_purchased_product_data"
        ADD "id" uuid NOT NULL DEFAULT uuid_generate_v4()
    `);
    await queryRunner.query(`
        ALTER TABLE "archive_purchased_product_data" DROP CONSTRAINT "FK_53da14928e390ffe807b2db568e"
    `);
    await queryRunner.query(`
        ALTER TABLE "archive_purchased_product_data" DROP CONSTRAINT "FK_87311bb5eac8f41d13ee45b895c"
    `);
    await queryRunner.query(`
        ALTER TABLE "archive_purchased_product_data" DROP CONSTRAINT "PK_df723e72d33c2e6b43ae61a5681"
    `);
    await queryRunner.query(`
        ALTER TABLE "archive_purchased_product_data"
        ADD CONSTRAINT "PK_273a8562657456f16bcd1e45e1e" PRIMARY KEY ("id")
    `);
    await queryRunner.query(`
        DROP INDEX "public"."IDX_87311bb5eac8f41d13ee45b895"
    `);
    await queryRunner.query(`
        DROP INDEX "public"."IDX_53da14928e390ffe807b2db568"
    `);
    await queryRunner.query(`
        CREATE INDEX "IDX_596492ce64e569db2ec9c60497" ON "archive_purchased_product_data" ("archive_purchase_request_id")
    `);
    await queryRunner.query(`
        CREATE INDEX "IDX_e7768386bc4f6d9a547c77130b" ON "archive_purchased_product_data" ("product_datum_id")
    `);
    await queryRunner.query(`
        ALTER TABLE "archive_purchased_product_data"
        ADD CONSTRAINT "FK_596492ce64e569db2ec9c604972" FOREIGN KEY ("archive_purchase_request_id") REFERENCES "archive_purchase_requests"("id") ON DELETE CASCADE ON UPDATE CASCADE
    `);
    await queryRunner.query(`
        ALTER TABLE "archive_purchased_product_data"
        ADD CONSTRAINT "FK_e7768386bc4f6d9a547c77130be" FOREIGN KEY ("product_datum_id") REFERENCES "product_data"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
        ALTER TABLE "archive_purchased_product_data" DROP CONSTRAINT "FK_e7768386bc4f6d9a547c77130be"
    `);
    await queryRunner.query(`
        ALTER TABLE "archive_purchased_product_data" DROP CONSTRAINT "FK_596492ce64e569db2ec9c604972"
    `);
    await queryRunner.query(`
        ALTER TABLE "archive_purchased_product_data" DROP CONSTRAINT "PK_273a8562657456f16bcd1e45e1e"
    `);
    await queryRunner.query(`
        ALTER TABLE "archive_purchased_product_data"
        ADD CONSTRAINT "PK_df723e72d33c2e6b43ae61a5681" PRIMARY KEY (
                "archive_purchase_request_id",
                "product_datum_id"
            )
    `);
    await queryRunner.query(`
        DROP INDEX "public"."IDX_e7768386bc4f6d9a547c77130b"
    `);
    await queryRunner.query(`
        DROP INDEX "public"."IDX_596492ce64e569db2ec9c60497"
    `);
    await queryRunner.query(`
        CREATE INDEX "IDX_53da14928e390ffe807b2db568" ON "archive_purchased_product_data" ("product_datum_id")
    `);
    await queryRunner.query(`
        CREATE INDEX "IDX_87311bb5eac8f41d13ee45b895" ON "archive_purchased_product_data" ("archive_purchase_request_id")
    `);
    await queryRunner.query(`
        ALTER TABLE "archive_purchased_product_data"
        ADD CONSTRAINT "FK_87311bb5eac8f41d13ee45b895c" FOREIGN KEY ("archive_purchase_request_id") REFERENCES "archive_purchase_requests"("id") ON DELETE CASCADE ON UPDATE CASCADE
    `);
    await queryRunner.query(`
        ALTER TABLE "archive_purchased_product_data"
        ADD CONSTRAINT "FK_53da14928e390ffe807b2db568e" FOREIGN KEY ("product_datum_id") REFERENCES "product_data"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
    `);
    await queryRunner.query(`
        ALTER TABLE "archive_purchased_product_data" DROP COLUMN "id"
    `);
    await queryRunner.query(`
        ALTER TABLE archive_purchased_product_data
        RENAME TO archive_purchase_requests_product_data
    `);
  }
}
