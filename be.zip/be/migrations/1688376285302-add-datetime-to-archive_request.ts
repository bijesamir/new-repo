import { MigrationInterface, QueryRunner } from "typeorm";

export class addDatetimeToArchiveRequest1688376285302 implements MigrationInterface {
    name = 'addDatetimeToArchiveRequest1688376285302'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "archive_requests"
            ADD "created_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now()
        `);
        await queryRunner.query(`
            ALTER TABLE "archive_requests"
            ADD "updated_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now()
        `);
        await queryRunner.query(`
            ALTER TABLE "archive_requests"
            ADD "deleted_at" TIMESTAMP(6) WITH TIME ZONE
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "archive_requests" DROP COLUMN "deleted_at"
        `);
        await queryRunner.query(`
            ALTER TABLE "archive_requests" DROP COLUMN "updated_at"
        `);
        await queryRunner.query(`
            ALTER TABLE "archive_requests" DROP COLUMN "created_at"
        `);
    }

}
