import { MigrationInterface, QueryRunner } from "typeorm";

export class addColumnToProductDataVersion1685935977614 implements MigrationInterface {
    name = 'addColumnToProductDataVersion1685935977614'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "product_data_versions"
            ADD "quicklook_bucket" character varying NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "product_data_versions"."quicklook_bucket" IS 'storage bucket of quicklook image'
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data_versions"
            ADD "quicklook_location" character varying NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "product_data_versions"."quicklook_location" IS 'storage location of quicklook image'
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data_versions"
            ADD "quicklook_content_type" character varying NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "product_data_versions"."quicklook_content_type" IS 'content-type of quicklook image'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "product_data_versions"."quicklook_content_type" IS 'content-type of quicklook image'
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data_versions" DROP COLUMN "quicklook_content_type"
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "product_data_versions"."quicklook_location" IS 'storage location of quicklook image'
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data_versions" DROP COLUMN "quicklook_location"
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "product_data_versions"."quicklook_bucket" IS 'storage bucket of quicklook image'
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data_versions" DROP COLUMN "quicklook_bucket"
        `);
    }

}
