import { MigrationInterface, QueryRunner } from "typeorm";

export class AddColumnSatellite1697013304362 implements MigrationInterface {
    name = 'AddColumnSatellite1697013304362'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "satellites"
            ADD "visible_to" jsonb NOT NULL DEFAULT '[]'
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "satellites"."visible_to" IS 'user roles that are granted visibility to the satellite'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "satellites"."visible_to" IS 'user roles that are granted visibility to the satellite'
        `);
        await queryRunner.query(`
            ALTER TABLE "satellites" DROP COLUMN "visible_to"
        `);
    }

}
