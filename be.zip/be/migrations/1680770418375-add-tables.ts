import { MigrationInterface, QueryRunner } from "typeorm";

export class addTables1680770418375 implements MigrationInterface {
    name = 'addTables1680770418375'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            CREATE TABLE "registration_requests" (
                "latest_editor_id" character varying(128) NOT NULL,
                "organization_id" integer NOT NULL,
                "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
                "no" integer GENERATED ALWAYS AS IDENTITY NOT NULL,
                "created_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "updated_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "deleted_at" TIMESTAMP(6) WITH TIME ZONE,
                "meta_information" text NOT NULL,
                "note" text,
                "processing_result_id" uuid NOT NULL,
                CONSTRAINT "REL_559e241086b0cd833a9dbc3d3a" UNIQUE ("processing_result_id"),
                CONSTRAINT "PK_75e49f863f30250e82ab8638eaa" PRIMARY KEY ("id")
            );
            COMMENT ON COLUMN "registration_requests"."latest_editor_id" IS 'User ID who last edited this record';
            COMMENT ON COLUMN "registration_requests"."organization_id" IS 'Organization ID associated with this record';
            COMMENT ON COLUMN "registration_requests"."id" IS 'registration_request id';
            COMMENT ON COLUMN "registration_requests"."no" IS 'serial number of RegistrationRequest';
            COMMENT ON COLUMN "registration_requests"."meta_information" IS 'Contents of the metadata yaml file';
            COMMENT ON COLUMN "registration_requests"."note" IS 'Matters that are not used in processing but that you want to keep as a memo';
            COMMENT ON COLUMN "registration_requests"."processing_result_id" IS 'tasking_request id'
        `);
        await queryRunner.query(`
            CREATE TABLE "processing_results" (
                "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
                "no" integer GENERATED ALWAYS AS IDENTITY NOT NULL,
                "created_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "updated_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "deleted_at" TIMESTAMP(6) WITH TIME ZONE,
                "scs_order_id" uuid NOT NULL,
                "product_format" integer NOT NULL,
                CONSTRAINT "PK_8feacafee4607a786d4fec8646b" PRIMARY KEY ("id")
            );
            COMMENT ON COLUMN "processing_results"."id" IS 'processing_result id';
            COMMENT ON COLUMN "processing_results"."no" IS 'serial number of ProcessingResult';
            COMMENT ON COLUMN "processing_results"."scs_order_id" IS 'ID assigned to the order by SCS';
            COMMENT ON COLUMN "processing_results"."product_format" IS 'product format'
        `);
        await queryRunner.query(`
            CREATE INDEX "IDX_79dd737bde85046835f8107649" ON "processing_results" ("scs_order_id")
        `);
        await queryRunner.query(`
            ALTER TABLE "registration_requests"
            ADD CONSTRAINT "FK_559e241086b0cd833a9dbc3d3ac" FOREIGN KEY ("processing_result_id") REFERENCES "processing_results"("id") ON DELETE CASCADE ON UPDATE NO ACTION
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "registration_requests" DROP CONSTRAINT "FK_559e241086b0cd833a9dbc3d3ac"
        `);
        await queryRunner.query(`
            DROP INDEX "public"."IDX_79dd737bde85046835f8107649"
        `);
        await queryRunner.query(`
            DROP TABLE "processing_results"
        `);
        await queryRunner.query(`
            DROP TABLE "registration_requests"
        `);
    }

}
