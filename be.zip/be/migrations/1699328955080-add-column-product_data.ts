import { MigrationInterface, QueryRunner } from "typeorm";

export class AddColumnProductData1699328955080 implements MigrationInterface {
    name = 'AddColumnProductData1699328955080'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "product_data"
            ADD "collection" character varying(50) NOT NULL DEFAULT 'StriX'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "product_data" DROP COLUMN "collection"
        `);
    }

}
