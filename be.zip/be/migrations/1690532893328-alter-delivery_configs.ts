import { MigrationInterface, QueryRunner } from "typeorm";

export class AlterDeliveryConfigs1690532893328 implements MigrationInterface {
    name = 'AlterDeliveryConfigs1690532893328'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "delivery_configs"
            ADD CONSTRAINT "UQ_2f2818e44c9540e62507c1066f1" UNIQUE ("job_name")
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "delivery_configs" DROP CONSTRAINT "UQ_2f2818e44c9540e62507c1066f1"
        `);
    }

}
