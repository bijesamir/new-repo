import { MigrationInterface, QueryRunner } from "typeorm";

export class addColumnToProductDataVersion1686717087507 implements MigrationInterface {
    name = 'addColumnToProductDataVersion1686717087507'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "product_data_versions" DROP CONSTRAINT "FK_2b4877b421278d2587ed390a676"
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data_versions"
            ALTER COLUMN "product_datum_id"
            SET NOT NULL
        `);
        await queryRunner.query(`
            CREATE INDEX "IDX_2b4877b421278d2587ed390a67" ON "product_data_versions" ("product_datum_id")
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data_versions"
            ADD CONSTRAINT "FK_2b4877b421278d2587ed390a676" FOREIGN KEY ("product_datum_id") REFERENCES "product_data"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "product_data_versions" DROP CONSTRAINT "FK_2b4877b421278d2587ed390a676"
        `);
        await queryRunner.query(`
            DROP INDEX "public"."IDX_2b4877b421278d2587ed390a67"
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data_versions"
            ALTER COLUMN "product_datum_id" DROP NOT NULL
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data_versions"
            ADD CONSTRAINT "FK_2b4877b421278d2587ed390a676" FOREIGN KEY ("product_datum_id") REFERENCES "product_data"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
    }

}
