import { MigrationInterface, QueryRunner } from "typeorm";

export class alterTaskingInfos1677567304967 implements MigrationInterface {
    name = 'alterTaskingInfos1677567304967'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP CONSTRAINT "FK_a7cee045eaf9ad367a86a4fd898"
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
                RENAME COLUMN "satellite_id" TO "sat_id"
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP COLUMN "sat_id"
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD "sat_id" character varying NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."sat_id" IS 'satId'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD CONSTRAINT "FK_dafff81d786aa90037711e250ed" FOREIGN KEY ("sat_id") REFERENCES "satellites"("sat_id") ON DELETE CASCADE ON UPDATE NO ACTION
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP CONSTRAINT "FK_dafff81d786aa90037711e250ed"
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."sat_id" IS 'satId'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP COLUMN "sat_id"
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD "sat_id" uuid NOT NULL
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
                RENAME COLUMN "sat_id" TO "satellite_id"
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD CONSTRAINT "FK_a7cee045eaf9ad367a86a4fd898" FOREIGN KEY ("satellite_id") REFERENCES "satellites"("id") ON DELETE CASCADE ON UPDATE NO ACTION
        `);
    }

}
