import { MigrationInterface, QueryRunner } from "typeorm";

export class AddColumnProductData1698802169280 implements MigrationInterface {
    name = 'AddColumnProductData1698802169280'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "product_data"
            ADD "publication_start" TIMESTAMP(6) WITH TIME ZONE
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "product_data"."publication_start" IS 'publication start'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "product_data"."publication_start" IS 'publication start'
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data" DROP COLUMN "publication_start"
        `);
    }

}
