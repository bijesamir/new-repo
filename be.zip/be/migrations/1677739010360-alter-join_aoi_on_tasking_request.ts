import { MigrationInterface, QueryRunner } from "typeorm";

export class alterJoinAoiOnTaskingRequest1677739010360 implements MigrationInterface {
    name = 'alterJoinAoiOnTaskingRequest1677739010360'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request" DROP CONSTRAINT "FK_93e977310c1e801eb268d217177"
        `);
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request" DROP CONSTRAINT "FK_2c06de6ebc17254e008774b9f7f"
        `);
        await queryRunner.query(`
            DROP INDEX "public"."IDX_93e977310c1e801eb268d21717"
        `);
        await queryRunner.query(`
            DROP INDEX "public"."IDX_2c06de6ebc17254e008774b9f7"
        `);
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request" DROP CONSTRAINT "PK_109529473bb43e5f1af64fd4e72"
        `);
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request"
            ADD CONSTRAINT "PK_2c06de6ebc17254e008774b9f7f" PRIMARY KEY ("taskingRequestId")
        `);
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request" DROP COLUMN "aoiId"
        `);
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request" DROP CONSTRAINT "PK_2c06de6ebc17254e008774b9f7f"
        `);
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request" DROP COLUMN "taskingRequestId"
        `);
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request"
            ADD "aoi_id" uuid NOT NULL
        `);
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request"
            ADD CONSTRAINT "PK_906570f49259d68b1ba13f011ba" PRIMARY KEY ("aoi_id")
        `);
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request"
            ADD "tasking_request_id" uuid NOT NULL
        `);
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request" DROP CONSTRAINT "PK_906570f49259d68b1ba13f011ba"
        `);
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request"
            ADD CONSTRAINT "PK_349f2f3ed66e6ab077061d3d9a6" PRIMARY KEY ("aoi_id", "tasking_request_id")
        `);
        await queryRunner.query(`
            CREATE INDEX "IDX_906570f49259d68b1ba13f011b" ON "join_aoi_on_tasking_request" ("aoi_id")
        `);
        await queryRunner.query(`
            CREATE INDEX "IDX_416966d2ec6d209c3516ae1155" ON "join_aoi_on_tasking_request" ("tasking_request_id")
        `);
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request"
            ADD CONSTRAINT "FK_906570f49259d68b1ba13f011ba" FOREIGN KEY ("aoi_id") REFERENCES "aois"("id") ON DELETE CASCADE ON UPDATE CASCADE
        `);
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request"
            ADD CONSTRAINT "FK_416966d2ec6d209c3516ae11559" FOREIGN KEY ("tasking_request_id") REFERENCES "tasking_requests"("id") ON DELETE CASCADE ON UPDATE NO ACTION
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request" DROP CONSTRAINT "FK_416966d2ec6d209c3516ae11559"
        `);
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request" DROP CONSTRAINT "FK_906570f49259d68b1ba13f011ba"
        `);
        await queryRunner.query(`
            DROP INDEX "public"."IDX_416966d2ec6d209c3516ae1155"
        `);
        await queryRunner.query(`
            DROP INDEX "public"."IDX_906570f49259d68b1ba13f011b"
        `);
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request" DROP CONSTRAINT "PK_349f2f3ed66e6ab077061d3d9a6"
        `);
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request"
            ADD CONSTRAINT "PK_906570f49259d68b1ba13f011ba" PRIMARY KEY ("aoi_id")
        `);
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request" DROP COLUMN "tasking_request_id"
        `);
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request" DROP CONSTRAINT "PK_906570f49259d68b1ba13f011ba"
        `);
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request" DROP COLUMN "aoi_id"
        `);
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request"
            ADD "taskingRequestId" uuid NOT NULL
        `);
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request"
            ADD CONSTRAINT "PK_2c06de6ebc17254e008774b9f7f" PRIMARY KEY ("taskingRequestId")
        `);
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request"
            ADD "aoiId" uuid NOT NULL
        `);
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request" DROP CONSTRAINT "PK_2c06de6ebc17254e008774b9f7f"
        `);
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request"
            ADD CONSTRAINT "PK_109529473bb43e5f1af64fd4e72" PRIMARY KEY ("aoiId", "taskingRequestId")
        `);
        await queryRunner.query(`
            CREATE INDEX "IDX_2c06de6ebc17254e008774b9f7" ON "join_aoi_on_tasking_request" ("taskingRequestId")
        `);
        await queryRunner.query(`
            CREATE INDEX "IDX_93e977310c1e801eb268d21717" ON "join_aoi_on_tasking_request" ("aoiId")
        `);
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request"
            ADD CONSTRAINT "FK_2c06de6ebc17254e008774b9f7f" FOREIGN KEY ("taskingRequestId") REFERENCES "tasking_requests"("id") ON DELETE CASCADE ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request"
            ADD CONSTRAINT "FK_93e977310c1e801eb268d217177" FOREIGN KEY ("aoiId") REFERENCES "aois"("id") ON DELETE CASCADE ON UPDATE CASCADE
        `);
    }

}
