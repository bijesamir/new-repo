import { MigrationInterface, QueryRunner } from "typeorm";

export class addPaymentId1687242030560 implements MigrationInterface {
    name = 'addPaymentId1687242030560'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "archive_requests"
            ADD "payment_id" integer
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "archive_requests"."payment_id" IS 'registrationId issued by citadel'
        `);
        await queryRunner.query(`
            ALTER TABLE "archive_requests"
            ADD "source" integer NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "archive_requests"."source" IS 'source'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD "payment_id" integer
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."payment_id" IS 'registrationId issued by citadel'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."payment_id" IS 'registrationId issued by citadel'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP COLUMN "payment_id"
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "archive_requests"."source" IS 'source'
        `);
        await queryRunner.query(`
            ALTER TABLE "archive_requests" DROP COLUMN "source"
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "archive_requests"."payment_id" IS 'registrationId issued by citadel'
        `);
        await queryRunner.query(`
            ALTER TABLE "archive_requests" DROP COLUMN "payment_id"
        `);
    }

}
