import { MigrationInterface, QueryRunner } from "typeorm";

export class AddColumnToProductDataView1691483133812 implements MigrationInterface {
    name = 'AddColumnToProductDataView1691483133812'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            DELETE FROM "typeorm_metadata"
            WHERE "type" = $1
                AND "name" = $2
                AND "schema" = $3
        `, ["VIEW","product_data_views","public"]);
        await queryRunner.query(`
            DROP VIEW "product_data_views"
        `);
        await queryRunner.query(`
            CREATE VIEW "product_data_views" AS
            SELECT pd.id AS id,
                pd.no AS no,
                pd.created_at AS created_at,
                pd.updated_at AS updated_at,
                pd.deleted_at AS deleted_at,
                pd.organization_id AS organization_id,
                pd.contract_id AS contract_id,
                pd.tasking_info_id AS tasking_info_id,
                pd.aoi_id AS aoi_id,
                pd.product_format AS product_format,
                pd.resolution_mode AS resolution_mode,
                pd.scene_id AS scene_id,
                pd.scene_no AS scene_no,
                pdv.id AS product_data_version_id,
                pdv.no AS product_data_version_no,
                pdv.created_at AS product_data_version_created_at,
                pdv.updated_at AS product_data_version_updated_at,
                pdv.deleted_at AS product_data_version_deleted_at,
                pdv.version AS version,
                pdv.bucket AS bucket,
                pdv.location AS location,
                pdv.quicklook_bucket AS quicklook_bucket,
                pdv.quicklook_location AS quicklook_location,
                pdv.quicklook_content_type AS quicklook_content_type,
                -- product
                (
                    pdv.metadata::jsonb->'product'->>'productSoftwareVersion'
                )::varchar AS metadata_product_software_version,
                (
                    pdv.metadata::jsonb->'product'->>'productFormat'
                )::int AS metadata_product_format,
                (
                    pdv.metadata::jsonb->'product'->>'dataProcessingSoftwareVersion'
                )::varchar AS metadata_data_processing_software_version,
                (
                    pdv.metadata::jsonb->'product'->>'orbitType'
                )::int AS metadata_orbit_type,
                (
                    pdv.metadata::jsonb->'product'->>'focusSoftwareType'
                )::varchar AS metadata_focus_software_type,
                (
                    pdv.metadata::jsonb->'product'->>'focusSoftwareVersion'
                )::varchar AS metadata_focus_software_version,
                (
                    pdv.metadata::jsonb->'product'->>'resolutionMode'
                )::int AS metadata_resolution_mode,
                -- geometry
                pdv.metadata::jsonb->'geometry'->'sceneCenterLocation' AS metadata_scene_center_location,
                pdv.metadata::jsonb->'geometry'->'sceneCornerLocations' AS metadata_scene_corner_locations,
                -- observation
                (
                    pdv.metadata::jsonb->'observation'->>'sceneId'
                )::varchar(50) AS metadata_scene_id,
                (
                    pdv.metadata::jsonb->'observation'->>'sceneNo'
                )::int AS metadata_scene_no,
                (
                    pdv.metadata::jsonb->'observation'->>'orderCode'
                )::varchar(12) AS metadata_order_code,
                (
                    pdv.metadata::jsonb->'observation'->>'imagingMode'
                )::int AS metadata_imaging_mode,
                (
                    pdv.metadata::jsonb->'observation'->>'satelliteId'
                )::varchar AS metadata_sat_id,
                (
                    pdv.metadata::jsonb->'observation'->>'polarization'
                )::int AS metadata_polarization,
                (
                    pdv.metadata::jsonb->'observation'->>'offnadirAngle'
                )::decimal(5, 2) AS metadata_offnadir_angle,
                (
                    pdv.metadata::jsonb->'observation'->>'flightDirection'
                )::int AS metadata_flight_direction,
                (
                    pdv.metadata::jsonb->'observation'->>'lookingDirection'
                )::int AS metadata_looking_direction,
                (
                    pdv.metadata::jsonb->'observation'->>'sceneEndDateTime'
                )::timestamptz(6) AS metadata_scene_end_date_time,
                (
                    pdv.metadata::jsonb->'observation'->>'sceneStartDateTime'
                )::timestamptz(6) AS metadata_scene_start_date_time,
                (
                    pdv.metadata::jsonb->'observation'->>'sceneCenterDateTime'
                )::timestamptz(6) AS metadata_scene_center_date_time
            FROM product_data pd
                LEFT JOIN product_data_versions pdv ON pdv.product_datum_id = pd.id
                AND pdv.no =(
                    SELECT MAX(no)
                    from product_data_versions
                    WHERE product_datum_id = pd.id
                );
        `);
        await queryRunner.query(`
            INSERT INTO "typeorm_metadata"(
                    "database",
                    "schema",
                    "table",
                    "type",
                    "name",
                    "value"
                )
            VALUES (DEFAULT, $1, DEFAULT, $2, $3, $4)
        `, ["public","VIEW","product_data_views","SELECT pd.id AS id,\n      pd.no AS no,\n      pd.created_at AS created_at,\n      pd.updated_at AS updated_at,\n      pd.deleted_at AS deleted_at,\n      pd.organization_id AS organization_id,\n      pd.contract_id AS contract_id,\n      pd.tasking_info_id AS tasking_info_id,\n      pd.aoi_id AS aoi_id,\n      pd.product_format AS product_format,\n      pd.resolution_mode AS resolution_mode,\n      pd.scene_id AS scene_id,\n      pd.scene_no AS scene_no,\n\n      pdv.id AS product_data_version_id,\n      pdv.no AS product_data_version_no,\n      pdv.created_at AS product_data_version_created_at,\n      pdv.updated_at AS product_data_version_updated_at,\n      pdv.deleted_at AS product_data_version_deleted_at,\n      pdv.version AS version,\n      pdv.bucket AS bucket,\n      pdv.location AS location,\n      pdv.quicklook_bucket AS quicklook_bucket,\n      pdv.quicklook_location AS quicklook_location,\n      pdv.quicklook_content_type AS quicklook_content_type,\n      \n      -- product\n      (pdv.metadata ::jsonb -> 'product' ->> 'productSoftwareVersion')\n        ::varchar AS metadata_product_software_version,\n      (pdv.metadata ::jsonb -> 'product' ->> 'productFormat')\n        ::int AS metadata_product_format,\n      (pdv.metadata ::jsonb -> 'product' ->> 'dataProcessingSoftwareVersion')\n        ::varchar AS metadata_data_processing_software_version,\n      (pdv.metadata ::jsonb -> 'product' ->> 'orbitType')\n        ::int AS metadata_orbit_type,\n      (pdv.metadata ::jsonb -> 'product' ->> 'focusSoftwareType')\n        ::varchar AS metadata_focus_software_type,\n      (pdv.metadata ::jsonb -> 'product' ->> 'focusSoftwareVersion')\n        ::varchar AS metadata_focus_software_version,\n      (pdv.metadata ::jsonb -> 'product' ->> 'resolutionMode')\n        ::int AS metadata_resolution_mode,\n\n      -- geometry\n      pdv.metadata ::jsonb -> 'geometry' -> 'sceneCenterLocation'\n        AS metadata_scene_center_location,\n      pdv.metadata ::jsonb -> 'geometry' -> 'sceneCornerLocations'\n        AS metadata_scene_corner_locations,\n\n      -- observation\n      (pdv.metadata ::jsonb -> 'observation' ->> 'sceneId')\n        ::varchar(50) AS metadata_scene_id,\n      (pdv.metadata ::jsonb -> 'observation' ->> 'sceneNo')\n        ::int AS metadata_scene_no,\n      (pdv.metadata ::jsonb -> 'observation' ->> 'orderCode')\n        ::varchar(12) AS metadata_order_code,\n      (pdv.metadata ::jsonb -> 'observation' ->> 'imagingMode')\n        ::int AS metadata_imaging_mode,\n      (pdv.metadata ::jsonb -> 'observation' ->> 'satelliteId')\n        ::varchar AS metadata_sat_id,\n      (pdv.metadata ::jsonb -> 'observation' ->> 'polarization')\n        ::int AS metadata_polarization,\n      (pdv.metadata ::jsonb -> 'observation' ->> 'offnadirAngle')\n        ::decimal(5,2) AS metadata_offnadir_angle,\n      (pdv.metadata ::jsonb -> 'observation' ->> 'flightDirection')\n        ::int AS metadata_flight_direction,\n      (pdv.metadata ::jsonb -> 'observation' ->> 'lookingDirection')\n        ::int AS metadata_looking_direction,\n      (pdv.metadata ::jsonb -> 'observation' ->> 'sceneEndDateTime')\n        ::timestamptz(6) AS metadata_scene_end_date_time,\n      (pdv.metadata ::jsonb -> 'observation' ->> 'sceneStartDateTime')\n        ::timestamptz(6) AS metadata_scene_start_date_time,\n      (pdv.metadata ::jsonb -> 'observation' ->> 'sceneCenterDateTime')\n        ::timestamptz(6) AS metadata_scene_center_date_time\n\n    FROM product_data pd\n    LEFT JOIN product_data_versions pdv\n    ON pdv.product_datum_id=pd.id AND\n      pdv.no=(SELECT MAX(no) from product_data_versions WHERE product_datum_id=pd.id);"]);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            DELETE FROM "typeorm_metadata"
            WHERE "type" = $1
                AND "name" = $2
                AND "schema" = $3
        `, ["VIEW","product_data_views","public"]);
        await queryRunner.query(`
            DROP VIEW "product_data_views"
        `);
        await queryRunner.query(`
            CREATE VIEW "product_data_views" AS
            SELECT pd.id AS id,
                pd.no AS no,
                pd.created_at AS created_at,
                pd.updated_at AS updated_at,
                pd.deleted_at AS deleted_at,
                pd.organization_id AS organization_id,
                pd.contract_id AS contract_id,
                pd.tasking_info_id AS tasking_info_id,
                pd.aoi_id AS aoi_id,
                pd.product_format AS product_format,
                pd.scene_id AS scene_id,
                pd.scene_no AS scene_no,
                pdv.id AS product_data_version_id,
                pdv.no AS product_data_version_no,
                pdv.created_at AS product_data_version_created_at,
                pdv.updated_at AS product_data_version_updated_at,
                pdv.deleted_at AS product_data_version_deleted_at,
                pdv.version AS version,
                pdv.bucket AS bucket,
                pdv.location AS location,
                pdv.quicklook_bucket AS quicklook_bucket,
                pdv.quicklook_location AS quicklook_location,
                pdv.quicklook_content_type AS quicklook_content_type,
                -- product
                (
                    pdv.metadata::jsonb->'product'->>'productSoftwareVersion'
                )::varchar AS metadata_product_software_version,
                (
                    pdv.metadata::jsonb->'product'->>'productFormat'
                )::int AS metadata_product_format,
                (
                    pdv.metadata::jsonb->'product'->>'dataProcessingSoftwareVersion'
                )::varchar AS metadata_data_processing_software_version,
                (
                    pdv.metadata::jsonb->'product'->>'orbitType'
                )::int AS metadata_orbit_type,
                (
                    pdv.metadata::jsonb->'product'->>'focusSoftwareType'
                )::varchar AS metadata_focus_software_type,
                (
                    pdv.metadata::jsonb->'product'->>'focusSoftwareVersion'
                )::varchar AS metadata_focus_software_version,
                (
                    pdv.metadata::jsonb->'product'->>'resolutionMode'
                )::int AS metadata_resolution_mode,
                -- geometry
                pdv.metadata::jsonb->'geometry'->'sceneCenterLocation' AS metadata_scene_center_location,
                pdv.metadata::jsonb->'geometry'->'sceneCornerLocations' AS metadata_scene_corner_locations,
                -- observation
                (
                    pdv.metadata::jsonb->'observation'->>'sceneId'
                )::varchar(50) AS metadata_scene_id,
                (
                    pdv.metadata::jsonb->'observation'->>'sceneNo'
                )::int AS metadata_scene_no,
                (
                    pdv.metadata::jsonb->'observation'->>'orderCode'
                )::varchar(12) AS metadata_order_code,
                (
                    pdv.metadata::jsonb->'observation'->>'imagingMode'
                )::int AS metadata_imaging_mode,
                (
                    pdv.metadata::jsonb->'observation'->>'satelliteId'
                )::varchar AS metadata_sat_id,
                (
                    pdv.metadata::jsonb->'observation'->>'polarization'
                )::int AS metadata_polarization,
                (
                    pdv.metadata::jsonb->'observation'->>'offnadirAngle'
                )::decimal(5, 2) AS metadata_offnadir_angle,
                (
                    pdv.metadata::jsonb->'observation'->>'flightDirection'
                )::int AS metadata_flight_direction,
                (
                    pdv.metadata::jsonb->'observation'->>'lookingDirection'
                )::int AS metadata_looking_direction,
                (
                    pdv.metadata::jsonb->'observation'->>'sceneEndDateTime'
                )::timestamptz(6) AS metadata_scene_end_date_time,
                (
                    pdv.metadata::jsonb->'observation'->>'sceneStartDateTime'
                )::timestamptz(6) AS metadata_scene_start_date_time,
                (
                    pdv.metadata::jsonb->'observation'->>'sceneCenterDateTime'
                )::timestamptz(6) AS metadata_scene_center_date_time
            FROM product_data pd
                LEFT JOIN product_data_versions pdv ON pdv.product_datum_id = pd.id
                AND pdv.no =(
                    SELECT MAX(no)
                    from product_data_versions
                    WHERE product_datum_id = pd.id
                );
        `);
        await queryRunner.query(`
            INSERT INTO "typeorm_metadata"(
                    "database",
                    "schema",
                    "table",
                    "type",
                    "name",
                    "value"
                )
            VALUES (DEFAULT, $1, DEFAULT, $2, $3, $4)
        `, ["public","VIEW","product_data_views","SELECT pd.id AS id,\n      pd.no AS no,\n      pd.created_at AS created_at,\n      pd.updated_at AS updated_at,\n      pd.deleted_at AS deleted_at,\n      pd.organization_id AS organization_id,\n      pd.contract_id AS contract_id,\n      pd.tasking_info_id AS tasking_info_id,\n      pd.aoi_id AS aoi_id,\n      pd.product_format AS product_format,\n      pd.scene_id AS scene_id,\n      pd.scene_no AS scene_no,\n\n      pdv.id AS product_data_version_id,\n      pdv.no AS product_data_version_no,\n      pdv.created_at AS product_data_version_created_at,\n      pdv.updated_at AS product_data_version_updated_at,\n      pdv.deleted_at AS product_data_version_deleted_at,\n      pdv.version AS version,\n      pdv.bucket AS bucket,\n      pdv.location AS location,\n      pdv.quicklook_bucket AS quicklook_bucket,\n      pdv.quicklook_location AS quicklook_location,\n      pdv.quicklook_content_type AS quicklook_content_type,\n      \n      -- product\n      (pdv.metadata ::jsonb -> 'product' ->> 'productSoftwareVersion')\n        ::varchar AS metadata_product_software_version,\n      (pdv.metadata ::jsonb -> 'product' ->> 'productFormat')\n        ::int AS metadata_product_format,\n      (pdv.metadata ::jsonb -> 'product' ->> 'dataProcessingSoftwareVersion')\n        ::varchar AS metadata_data_processing_software_version,\n      (pdv.metadata ::jsonb -> 'product' ->> 'orbitType')\n        ::int AS metadata_orbit_type,\n      (pdv.metadata ::jsonb -> 'product' ->> 'focusSoftwareType')\n        ::varchar AS metadata_focus_software_type,\n      (pdv.metadata ::jsonb -> 'product' ->> 'focusSoftwareVersion')\n        ::varchar AS metadata_focus_software_version,\n      (pdv.metadata ::jsonb -> 'product' ->> 'resolutionMode')\n        ::int AS metadata_resolution_mode,\n\n      -- geometry\n      pdv.metadata ::jsonb -> 'geometry' -> 'sceneCenterLocation'\n        AS metadata_scene_center_location,\n      pdv.metadata ::jsonb -> 'geometry' -> 'sceneCornerLocations'\n        AS metadata_scene_corner_locations,\n\n      -- observation\n      (pdv.metadata ::jsonb -> 'observation' ->> 'sceneId')\n        ::varchar(50) AS metadata_scene_id,\n      (pdv.metadata ::jsonb -> 'observation' ->> 'sceneNo')\n        ::int AS metadata_scene_no,\n      (pdv.metadata ::jsonb -> 'observation' ->> 'orderCode')\n        ::varchar(12) AS metadata_order_code,\n      (pdv.metadata ::jsonb -> 'observation' ->> 'imagingMode')\n        ::int AS metadata_imaging_mode,\n      (pdv.metadata ::jsonb -> 'observation' ->> 'satelliteId')\n        ::varchar AS metadata_sat_id,\n      (pdv.metadata ::jsonb -> 'observation' ->> 'polarization')\n        ::int AS metadata_polarization,\n      (pdv.metadata ::jsonb -> 'observation' ->> 'offnadirAngle')\n        ::decimal(5,2) AS metadata_offnadir_angle,\n      (pdv.metadata ::jsonb -> 'observation' ->> 'flightDirection')\n        ::int AS metadata_flight_direction,\n      (pdv.metadata ::jsonb -> 'observation' ->> 'lookingDirection')\n        ::int AS metadata_looking_direction,\n      (pdv.metadata ::jsonb -> 'observation' ->> 'sceneEndDateTime')\n        ::timestamptz(6) AS metadata_scene_end_date_time,\n      (pdv.metadata ::jsonb -> 'observation' ->> 'sceneStartDateTime')\n        ::timestamptz(6) AS metadata_scene_start_date_time,\n      (pdv.metadata ::jsonb -> 'observation' ->> 'sceneCenterDateTime')\n        ::timestamptz(6) AS metadata_scene_center_date_time\n\n    FROM product_data pd\n    LEFT JOIN product_data_versions pdv\n    ON pdv.product_datum_id=pd.id AND\n      pdv.no=(SELECT MAX(no) from product_data_versions WHERE product_datum_id=pd.id);"]);
    }

}
