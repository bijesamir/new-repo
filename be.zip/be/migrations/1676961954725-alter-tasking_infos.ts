import { MigrationInterface, QueryRunner } from "typeorm";

export class alterTaskingInfos1676961954725 implements MigrationInterface {
    name = 'alterTaskingInfos1676961954725'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ALTER COLUMN "scs_order_id" DROP NOT NULL
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ALTER COLUMN "scs_order_code" DROP NOT NULL
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ALTER COLUMN "status_detail"
            SET DEFAULT '0'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ALTER COLUMN "status_detail" DROP DEFAULT
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ALTER COLUMN "scs_order_code"
            SET NOT NULL
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ALTER COLUMN "scs_order_id"
            SET NOT NULL
        `);
    }

}
