import { MigrationInterface, QueryRunner } from "typeorm";

export class AddColumnTaskingInfo1698801895506 implements MigrationInterface {
    name = 'AddColumnTaskingInfo1698801895506'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD "catalog_delay_kind" integer NOT NULL DEFAULT '2'
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."catalog_delay_kind" IS 'catalog delay kind'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."catalog_delay_kind" IS 'catalog delay kind'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP COLUMN "catalog_delay_kind"
        `);
    }

}
