import { MigrationInterface, QueryRunner } from 'typeorm';

export class SceneInfoCreate1707003792172 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`        
        -- Step 1: Filter and convert scene_center in product_data_versions
        WITH product_data_versions_first AS (
          SELECT
            product_datum_id,
            (metadata ::jsonb -> 'observation' ->> 'sceneCenterDateTime')::timestamptz AS scene_center,
            updated_at,
            ROW_NUMBER() OVER (PARTITION BY product_datum_id ORDER BY updated_at ASC, no ASC) as rn
          FROM product_data_versions
        ), 
        
        -- Step 2: Join tables and filter latest GRD existing records, convert imaging_mode
        latest_records AS (
          SELECT
            si.item_id as item_id,
            pd.product_format,
            pd.tasking_info_id,
            pd.scene_no,
            pd.resolution_mode,
            pd.scene_info_id,
            pdv.scene_center,
            sat.name as sat_name,
            CASE ti.imaging_mode
              WHEN 1 THEN 'SM'
              WHEN 2 THEN 'SL'
              ELSE 'UNKNOWN' 
            END as imaging_mode_str,
            ROW_NUMBER() OVER (PARTITION BY sat.name, pdv.scene_center ORDER BY pdv.updated_at ASC) as seq
          FROM
            product_data pd
          INNER JOIN 
            product_data_versions_first pdv ON pd.id = pdv.product_datum_id AND pdv.rn = 1
          LEFT JOIN scene_infos si ON si.id = pd.scene_info_id
          INNER JOIN tasking_infos ti ON ti.id = pd.tasking_info_id
          INNER JOIN satellites sat ON sat.sat_id = ti.sat_id
          WHERE pd.product_format = 1 and pd.resolution_mode = 1
        ),
        
        -- Step 3: Add row numbers for time records
        time_records AS (
         SELECT
            item_id, 
            scene_info_id,
            tasking_info_id,
            scene_no,
            sat_name,
            imaging_mode_str,
            scene_center,
            ROW_NUMBER() OVER (PARTITION BY sat_name, scene_center ORDER BY scene_center DESC, seq) as num
          FROM
            latest_records  
        )
        
        -- Step 4: Create and insert the item_id
        INSERT INTO scene_infos (tasking_info_id, scene_no,item_id)
          SELECT 
            tasking_info_id, 
            scene_no,
            sat_name || '_' || 
            TO_CHAR(t.scene_center, 'YYYYMMDD_HH24MISS') ||
            CASE 
              WHEN t.num > 1 THEN 
                '-' || LPAD(t.num::text,2,'0') || '_' || t.imaging_mode_str
              ELSE '_' || t.imaging_mode_str 
            END as new_item_id
          FROM time_records t
          WHERE t.scene_info_id is NULL   
        `);
    await queryRunner.query(`
          WITH new_records AS (
            SELECT 
              si.tasking_info_id, 
              si.scene_no,
              si.id as scene_info_id,
              pd.id as pd_id,
              pd.scene_info_id as pd_scene_info_id
            FROM
              scene_infos si
            LEFT JOIN
              product_data pd ON si.tasking_info_id = pd.tasking_info_id AND si.scene_no = pd.scene_no
            WHERE
              pd.scene_info_id IS NULL
           )
          UPDATE 
              product_data pd
          SET
              scene_info_id = n.scene_info_id
          FROM
              new_records n
          WHERE
              pd.id = n.pd_id and n.pd_scene_info_id is NULL                    
          `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {}
}
