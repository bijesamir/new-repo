import { MigrationInterface, QueryRunner } from "typeorm";

export class addJoinAoiOnTaskingRequest1676358796579 implements MigrationInterface {
    name = 'addJoinAoiOnTaskingRequest1676358796579'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            CREATE TABLE "join_aoi_on_tasking_request" (
                "aoiId" uuid NOT NULL,
                "taskingRequestId" uuid NOT NULL,
                CONSTRAINT "PK_109529473bb43e5f1af64fd4e72" PRIMARY KEY ("aoiId", "taskingRequestId")
            )
        `);
        await queryRunner.query(`
            CREATE INDEX "IDX_93e977310c1e801eb268d21717" ON "join_aoi_on_tasking_request" ("aoiId")
        `);
        await queryRunner.query(`
            CREATE INDEX "IDX_2c06de6ebc17254e008774b9f7" ON "join_aoi_on_tasking_request" ("taskingRequestId")
        `);
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request"
            ADD CONSTRAINT "FK_93e977310c1e801eb268d217177" FOREIGN KEY ("aoiId") REFERENCES "aois"("id") ON DELETE CASCADE ON UPDATE CASCADE
        `);
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request"
            ADD CONSTRAINT "FK_2c06de6ebc17254e008774b9f7f" FOREIGN KEY ("taskingRequestId") REFERENCES "tasking_requests"("id") ON DELETE CASCADE ON UPDATE NO ACTION
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request" DROP CONSTRAINT "FK_2c06de6ebc17254e008774b9f7f"
        `);
        await queryRunner.query(`
            ALTER TABLE "join_aoi_on_tasking_request" DROP CONSTRAINT "FK_93e977310c1e801eb268d217177"
        `);
        await queryRunner.query(`
            DROP INDEX "public"."IDX_2c06de6ebc17254e008774b9f7"
        `);
        await queryRunner.query(`
            DROP INDEX "public"."IDX_93e977310c1e801eb268d21717"
        `);
        await queryRunner.query(`
            DROP TABLE "join_aoi_on_tasking_request"
        `);
    }

}
