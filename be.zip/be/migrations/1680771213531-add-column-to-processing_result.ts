import { MigrationInterface, QueryRunner } from "typeorm";

export class addColumnToProcessingResult1680771213531 implements MigrationInterface {
    name = 'addColumnToProcessingResult1680771213531'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "processing_results"
            ADD "path" character varying NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "processing_results"."path" IS 'the path of the target object'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "processing_results"."path" IS 'the path of the target object'
        `);
        await queryRunner.query(`
            ALTER TABLE "processing_results" DROP COLUMN "path"
        `);
    }

}
