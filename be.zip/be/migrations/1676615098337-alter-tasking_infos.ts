import { MigrationInterface, QueryRunner } from "typeorm";

export class alterTaskingInfos1676615098337 implements MigrationInterface {
    name = 'alterTaskingInfos1676615098337'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP CONSTRAINT "FK_0d45b0fa3461ca042e986ab0d18"
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP COLUMN "aoi_id"
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD "status_detail" integer NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."status_detail" IS 'Status details'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD "product_formats" jsonb NOT NULL DEFAULT '[]'
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."product_formats" IS 'product format list'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD "name" character varying(255) NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."name" IS 'tasking name'
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."contract_id" IS 'Contract ID associated with the tasking info'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."contract_id" IS 'Contract ID associated with the tasking request'
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."name" IS 'tasking name'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP COLUMN "name"
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."product_formats" IS 'product format list'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP COLUMN "product_formats"
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "tasking_infos"."status_detail" IS 'Status details'
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos" DROP COLUMN "status_detail"
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD "aoi_id" uuid NOT NULL
        `);
        await queryRunner.query(`
            ALTER TABLE "tasking_infos"
            ADD CONSTRAINT "FK_0d45b0fa3461ca042e986ab0d18" FOREIGN KEY ("aoi_id") REFERENCES "aois"("id") ON DELETE CASCADE ON UPDATE NO ACTION
        `);
    }

}
