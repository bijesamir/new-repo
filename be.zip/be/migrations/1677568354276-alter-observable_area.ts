import { MigrationInterface, QueryRunner } from "typeorm";

export class alterObservableArea1677568354276 implements MigrationInterface {
    name = 'alterObservableArea1677568354276'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "observable_areas"
                RENAME COLUMN "satellite_id" TO "sat_id"
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "observable_areas"."sat_id" IS 'public satellite identifier'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "observable_areas"."sat_id" IS 'satellite id'
        `);
        await queryRunner.query(`
            ALTER TABLE "observable_areas"
                RENAME COLUMN "sat_id" TO "satellite_id"
        `);
    }

}
