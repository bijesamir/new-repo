import { MigrationInterface, QueryRunner } from "typeorm";

export class AddProductDataRequestsTable1689756510774 implements MigrationInterface {
    name = 'AddProductDataRequestsTable1689756510774'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            CREATE TABLE "product_data_requests" (
                "latest_editor_id" character varying(128) NOT NULL,
                "organization_id" integer NOT NULL,
                "contract_id" integer NOT NULL,
                "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
                "no" integer GENERATED ALWAYS AS IDENTITY NOT NULL,
                "created_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "updated_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "deleted_at" TIMESTAMP(6) WITH TIME ZONE,
                "tasking_info_id" uuid NOT NULL,
                "scs_order_id" uuid NOT NULL,
                "scene_no" integer NOT NULL,
                "flight_direction" integer NOT NULL,
                "dps_batch_id" character varying,
                "product_format" integer NOT NULL,
                "status" character varying NOT NULL,
                CONSTRAINT "PK_f06f9ad0dd8d0880a53b56e78ba" PRIMARY KEY ("id")
            );
            COMMENT ON COLUMN "product_data_requests"."latest_editor_id" IS 'User ID who last edited this record';
            COMMENT ON COLUMN "product_data_requests"."organization_id" IS 'Organization ID associated with this record';
            COMMENT ON COLUMN "product_data_requests"."contract_id" IS 'Contract ID associated with this record';
            COMMENT ON COLUMN "product_data_requests"."id" IS 'product_data id';
            COMMENT ON COLUMN "product_data_requests"."no" IS 'serial number of ProductData';
            COMMENT ON COLUMN "product_data_requests"."tasking_info_id" IS 'tasking_info id';
            COMMENT ON COLUMN "product_data_requests"."scs_order_id" IS 'ID assigned to the order by SCS';
            COMMENT ON COLUMN "product_data_requests"."scene_no" IS 'scene number';
            COMMENT ON COLUMN "product_data_requests"."flight_direction" IS 'flight direction';
            COMMENT ON COLUMN "product_data_requests"."dps_batch_id" IS 'id assigned to the batch by DPS';
            COMMENT ON COLUMN "product_data_requests"."product_format" IS 'product format';
            COMMENT ON COLUMN "product_data_requests"."status" IS 'status'
        `);
        await queryRunner.query(`
            CREATE INDEX "IDX_a60e1df4b524e77b3e6bd5f6db" ON "product_data_requests" ("scs_order_id")
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data"
            ADD "product_data_request_id" uuid
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data"
            ADD CONSTRAINT "UQ_56e919e330d04201721aab8925e" UNIQUE ("product_data_request_id")
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "product_data"."product_data_request_id" IS 'product_data_request id'
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data_requests"
            ADD CONSTRAINT "FK_a60e1df4b524e77b3e6bd5f6db5" FOREIGN KEY ("scs_order_id") REFERENCES "tasking_infos"("scs_order_id") ON DELETE CASCADE ON UPDATE NO ACTION
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data"
            ADD CONSTRAINT "FK_56e919e330d04201721aab8925e" FOREIGN KEY ("product_data_request_id") REFERENCES "product_data_requests"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "product_data" DROP CONSTRAINT "FK_56e919e330d04201721aab8925e"
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data_requests" DROP CONSTRAINT "FK_a60e1df4b524e77b3e6bd5f6db5"
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "product_data"."product_data_request_id" IS 'product_data_request id'
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data" DROP CONSTRAINT "UQ_56e919e330d04201721aab8925e"
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data" DROP COLUMN "product_data_request_id"
        `);
        await queryRunner.query(`
            DROP INDEX "public"."IDX_a60e1df4b524e77b3e6bd5f6db"
        `);
        await queryRunner.query(`
            DROP TABLE "product_data_requests"
        `);
    }

}
