import { MigrationInterface, QueryRunner } from "typeorm";

export class addColumnToProductData1681696167160 implements MigrationInterface {
    name = 'addColumnToProductData1681696167160'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "product_data"
            ADD "product_format" integer NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "product_data"."product_format" IS 'product format'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "product_data"."product_format" IS 'product format'
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data" DROP COLUMN "product_format"
        `);
    }

}
