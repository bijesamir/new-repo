import { MigrationInterface, QueryRunner } from "typeorm";

export class addColumnToProductData1682062018637 implements MigrationInterface {
    name = 'addColumnToProductData1682062018637'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "product_data"
            ADD "scene_id" character varying(50) NOT NULL
        `);
        await queryRunner.query(`
            COMMENT ON COLUMN "product_data"."scene_id" IS 'id of scene from DPS'
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            COMMENT ON COLUMN "product_data"."scene_id" IS 'id of scene from DPS'
        `);
        await queryRunner.query(`
            ALTER TABLE "product_data" DROP COLUMN "scene_id"
        `);
    }

}
