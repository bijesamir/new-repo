import { MigrationInterface, QueryRunner } from 'typeorm';

export class AddTableDownloadHistories1712026443366
  implements MigrationInterface
{
  name = 'AddTableDownloadHistories1712026443366';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            CREATE TABLE "download_histories" (
                "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
                "user_id" character varying(128) NOT NULL,
                "product_datum_id" uuid NOT NULL,
                "product_data_version_id" uuid NOT NULL,
                "tasking_info_id" uuid NOT NULL,
                "scene_no" integer NOT NULL,
                "product_format" integer NOT NULL,
                "resolution_mode" integer NOT NULL,
                "contract_type" character varying NOT NULL,
                "organization_id" integer NOT NULL,
                "contract_id" integer NOT NULL,
                "scs_order_code" character varying(12),
                "archive_purchase_request_request_id" character varying,
                "download_datetime" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "user_agent" character varying,
                "request_source_ip" character varying,
                "created_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "updated_at" TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT now(),
                "deleted_at" TIMESTAMP(6) WITH TIME ZONE,
                CONSTRAINT "PK_a43fa8be38d09d1ca746647ca1d" PRIMARY KEY ("id")
            );
            COMMENT ON COLUMN "download_histories"."id" IS 'id to be used system internal only';
            COMMENT ON COLUMN "download_histories"."user_id" IS 'User ID who download';
            COMMENT ON COLUMN "download_histories"."product_datum_id" IS 'product_data id';
            COMMENT ON COLUMN "download_histories"."product_data_version_id" IS 'product data version id';
            COMMENT ON COLUMN "download_histories"."tasking_info_id" IS 'tasking_info id';
            COMMENT ON COLUMN "download_histories"."scene_no" IS 'scene number';
            COMMENT ON COLUMN "download_histories"."product_format" IS 'product format';
            COMMENT ON COLUMN "download_histories"."resolution_mode" IS 'resolution mode';
            COMMENT ON COLUMN "download_histories"."contract_type" IS 'contract type';
            COMMENT ON COLUMN "download_histories"."organization_id" IS 'organization id';
            COMMENT ON COLUMN "download_histories"."contract_id" IS 'Contract ID associated with this record';
            COMMENT ON COLUMN "download_histories"."scs_order_code" IS 'serial value assigned to the order by SCS';
            COMMENT ON COLUMN "download_histories"."archive_purchase_request_request_id" IS 'archive purchase request external ID';
            COMMENT ON COLUMN "download_histories"."user_agent" IS 'user agent';
            COMMENT ON COLUMN "download_histories"."request_source_ip" IS 'request source ip'
        `);
    await queryRunner.query(`
        ALTER TABLE "download_histories"
        ADD CONSTRAINT "FK_843ea5495a13708b0a7cae39229" FOREIGN KEY ("product_datum_id") REFERENCES "product_data"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
    `);
    await queryRunner.query(`
        ALTER TABLE "download_histories"
        ADD CONSTRAINT "FK_868d6ef8f3f3a725dcafc8c3b66" FOREIGN KEY ("product_data_version_id") REFERENCES "product_data_versions"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
    `);
    await queryRunner.query(`
        ALTER TABLE "download_histories"
        ADD CONSTRAINT "FK_fc79f3a7d4d46ee06200564c1e1" FOREIGN KEY ("tasking_info_id") REFERENCES "tasking_infos"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
    `);
    await queryRunner.query(`
        ALTER TABLE "download_histories"
        ADD CONSTRAINT "FK_1beb7d0c55258c966c1e0d9180c" FOREIGN KEY ("archive_purchase_request_request_id") REFERENCES "archive_purchase_requests"("request_id") ON DELETE NO ACTION ON UPDATE NO ACTION
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
            DROP TABLE "download_histories"
        `);
  }
}
