import { ContractType } from '@iris-lib/constants';
import { IrisRequestContext } from '@iris-lib/middlewares';
import { IrisContractPackage } from '@iris-lib/models/payment';
import {
  ValidationArguments,
  ValidatorConstraint,
  ValidatorConstraintInterface,
} from 'class-validator';
import { isWithinInterval } from 'date-fns';

@ValidatorConstraint({ name: 'isValidContract', async: false })
export class IsValidContract implements ValidatorConstraintInterface {
  validate(contractType: ContractType, args: ValidationArguments) {
    const reqCtx = IrisRequestContext.get().req;

    const contractId = args.object.hasOwnProperty('contractId')
      ? args.object['contractId']
      : null;

    if (contractId && reqCtx.currentContracts) {
      const found = this.find(
        reqCtx.currentContracts,
        contractId,
        contractType,
      );
      return found ? true : false;
    }
    return false;
  }

  find(
    list: IrisContractPackage[],
    contractId: number,
    contractType: ContractType,
    current: Date = new Date(),
  ) {
    const found = list.find((x) => {
      return (
        x.contractId == contractId &&
        isWithinInterval(current, { start: x.startAt, end: x.endAt }) &&
        ((contractType === ContractType.Tasking && x.availableTasking) ||
          (contractType === ContractType.Archive && x.availableArchivePurchase))
      );
    });
    return found ? true : false;
  }

  defaultMessage() {
    return `It's a contract that can't be operated.`;
  }
}
