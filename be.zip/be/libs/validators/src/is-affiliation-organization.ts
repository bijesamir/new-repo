import {
  ValidationArguments,
  ValidatorConstraint,
  ValidatorConstraintInterface,
} from 'class-validator';
import { IrisRequestContext } from '@iris-lib/middlewares';

@ValidatorConstraint({ name: 'isAffiliationOrganization', async: false })
export class IsAffiliationOrganization implements ValidatorConstraintInterface {
  validate(data: any) {
    const reqCtx = IrisRequestContext.get().req;
    let result: boolean;
    if (data) {
      result = reqCtx.currentUser.organizationIds.includes(data);
    }
    return result;
  }
  defaultMessage(args: ValidationArguments) {
    return `${args.property} has an unrelated organization`;
  }
}
