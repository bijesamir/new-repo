import {
  ValidationArguments,
  ValidatorConstraint,
  ValidatorConstraintInterface,
} from 'class-validator';
import {
  TaskingStatusDetail,
  TaskingStatusDetailAllValues,
} from '@iris-lib/constants';
import { TaskingStatus } from '@iris-lib/constants';

@ValidatorConstraint({ name: 'isCorrectTaskingStatusDetail', async: false })
export class IsCorrectTaskingStatusDetail
  implements ValidatorConstraintInterface
{
  validate(a: number, args: ValidationArguments) {
    if (!TaskingStatusDetailAllValues.includes(a)) {
      return false;
    }
    const status: TaskingStatus = args.object['status'];
    if (a != TaskingStatusDetail.None) {
      return status == TaskingStatus.Canceled;
    } else {
      return status != TaskingStatus.Canceled;
    }
  }

  defaultMessage(args: ValidationArguments) {
    return `${args.property} has a problem in combination with status`;
  }
}
