import {
  ValidatorConstraint,
  ValidatorConstraintInterface,
  ValidationArguments,
} from 'class-validator';

@ValidatorConstraint({ name: 'isSingleProp', async: false })
export class IsSingleProp implements ValidatorConstraintInterface {
  validate(_, args: ValidationArguments) {
    const arr = [args.property, ...args.constraints];
    const count = arr.reduce((p, c) => {
      if (args.object.hasOwnProperty(c)) {
        return p + 1;
      }
      return p;
    }, 0);
    if (count > 1) {
      return false;
    }
    return true;
  }
  defaultMessage(args: ValidationArguments) {
    return `Expected ${[args.property, ...args.constraints].join(
      ' OR ',
    )}, but more than one provided`;
  }
}
