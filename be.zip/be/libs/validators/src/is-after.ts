import {
  ValidatorConstraint,
  ValidatorConstraintInterface,
  ValidationArguments,
  isNotEmpty,
} from 'class-validator';

@ValidatorConstraint({ name: 'isAfter', async: false })
export class IsAfter implements ValidatorConstraintInterface {
  validate(a: any, args: ValidationArguments) {
    if (typeof a == 'object' && (a as object) instanceof Date) {
      const b: Date = args.object[args.constraints[0]];
      if (a && b) {
        return a > b;
      } else {
        return true;
      }
    } else if (typeof a == 'number') {
      const b: number = args.object[args.constraints[0]];
      if (isNotEmpty(a) && isNotEmpty(b)) {
        return a > b;
      } else {
        return true;
      }
    } else {
      return false;
    }
  }
  defaultMessage(args: ValidationArguments) {
    return `${args.property} is not after ${args.constraints[0]}`;
  }
}
