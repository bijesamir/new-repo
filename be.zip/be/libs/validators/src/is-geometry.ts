import { LoggerWrapper } from '@iris-lib/logger';
import {
  ValidatorConstraint,
  ValidatorConstraintInterface,
  ValidationArguments,
} from 'class-validator';
import { valid } from 'geojson-validation';

// keep this in case we need to confirm to WGS84
// define('Position', (position) => {
//   const errors = [];
//   if (Math.abs(position[0]) > 180) {
//     errors.push('longitude must be between -180 and 180');
//   }
//   if (Math.abs(position[1]) > 90) {
//     errors.push('latitude must be between -90 and 90');
//   }
//   return errors;
// });

@ValidatorConstraint({ name: 'isGeometry', async: false })
export class IsGeometry implements ValidatorConstraintInterface {
  private logger = new LoggerWrapper(IsGeometry.name);

  validate(data: any, args: ValidationArguments) {
    if (args.constraints.length === 0) {
      args.constraints.push(valid);
    }

    const result = args.constraints.some((geojsonCheckFunc) => {
      const errors = geojsonCheckFunc(data, true);
      if (errors.length > 0) {
        this.logger.debug('geojson validation error', errors);
      }
      return errors.length === 0;
    });
    return result;
  }
  defaultMessage(args: ValidationArguments) {
    return `${args.property} is not valid GeoJSON`;
  }
}
