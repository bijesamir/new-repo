import { ContractType } from '@iris-lib/constants';
import { IrisRequestContext } from '@iris-lib/middlewares';
import { IrisContractPackage } from '@iris-lib/models/payment';
import {
  ValidationArguments,
  ValidatorConstraint,
  ValidatorConstraintInterface,
} from 'class-validator';
import { isWithinInterval } from 'date-fns';

@ValidatorConstraint({ name: 'isValidContractWithOrganization', async: false })
export class IsValidContractWithOrganization
  implements ValidatorConstraintInterface
{
  validate(contractType: ContractType, args: ValidationArguments) {
    const reqCtx = IrisRequestContext.get().req;

    const contractId = args.object.hasOwnProperty('contractId')
      ? args.object['contractId']
      : null;
    const organizationId = args.object.hasOwnProperty('organizationId')
      ? args.object['organizationId']
      : null;

    if (contractId && organizationId && reqCtx.currentContracts) {
      const found = this.find(
        reqCtx.currentContracts,
        contractId,
        organizationId,
        contractType,
      );
      return found ? true : false;
    }
    return false;
  }

  find(
    list: IrisContractPackage[],
    contractId: number,
    organizationId: number,
    contractType: ContractType,
    current: Date = new Date(),
  ) {
    const found = list.find((x) => {
      return (
        x.contractId == contractId &&
        x.organizationId == organizationId &&
        isWithinInterval(current, { start: x.startAt, end: x.endAt }) &&
        ((contractType === ContractType.Tasking && x.availableTasking) ||
          (contractType === ContractType.Archive && x.availableArchivePurchase))
      );
    });
    return found ? true : false;
  }

  defaultMessage() {
    return `It's a contract that can't be operated.`;
  }
}
