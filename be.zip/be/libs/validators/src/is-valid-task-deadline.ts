import { TaskDeadline } from '@iris-lib/constants';
import { IrisRequestContext } from '@iris-lib/middlewares';
import {
  ValidationArguments,
  ValidatorConstraint,
  ValidatorConstraintInterface,
} from 'class-validator';

@ValidatorConstraint({ name: 'isValidTaskDeadline', async: false })
export class IsValidTaskDeadline implements ValidatorConstraintInterface {
  validate(taskDeadline: TaskDeadline, args: ValidationArguments) {
    const reqCtx = IrisRequestContext.get().req;
    const contract = reqCtx.currentContracts.find(
      (c) => c.contractId === args.object['contractId'],
    );
    if (!contract) return false;
    return contract.taskDeadline === taskDeadline;
  }

  defaultMessage() {
    return `Invalid task deadline contract.`;
  }
}
