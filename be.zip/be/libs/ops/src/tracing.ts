import {
  SpanExporter,
  NodeTracerProvider,
  // ConsoleSpanExporter,
  BatchSpanProcessor,
  SimpleSpanProcessor,
  SpanProcessor,
} from '@opentelemetry/sdk-trace-node';
import {
  registerInstrumentations,
  InstrumentationOption,
} from '@opentelemetry/instrumentation';
import { detectResourcesSync } from '@opentelemetry/resources';
import { SemanticResourceAttributes } from '@opentelemetry/semantic-conventions';
import { TraceExporter } from '@google-cloud/opentelemetry-cloud-trace-exporter';
import { envStringValue } from '@iris-lib/utils';
import { OTLPTraceExporter } from '@opentelemetry/exporter-trace-otlp-http';
import { getResourceDetectors } from '@opentelemetry/auto-instrumentations-node';

// for debugging
// import { diag, DiagConsoleLogger, DiagLogLevel } from '@opentelemetry/api';
// diag.setLogger(new DiagConsoleLogger(), DiagLogLevel.DEBUG);

export const initTracing = (
  serviceName: string,
  instrumentations: InstrumentationOption[],
) => {
  let exporter: SpanExporter;
  let spanProcessor: SpanProcessor;

  switch (envStringValue('TRACING_BACKEND')) {
    case 'local':
      // exporter = new ConsoleSpanExporter();
      exporter = new OTLPTraceExporter();
      spanProcessor = new SimpleSpanProcessor(exporter);
      break;
    case 'google':
      exporter = new TraceExporter({
        // optional
        projectId: process.env.TRACING_PROJECT_ID,
        resourceFilter: /^(service|env|host|os|container|cloud|k8s)\./,
      });
      spanProcessor = new BatchSpanProcessor(exporter);
      break;
    default:
      throw new Error('Invalid TRACING_BACKEND');
  }

  const resource = detectResourcesSync({
    detectors: getResourceDetectors(),
  });
  resource.attributes[SemanticResourceAttributes.SERVICE_NAME] = serviceName;

  const provider = new NodeTracerProvider({ resource });
  provider.addSpanProcessor(spanProcessor);
  provider.register();

  registerInstrumentations({ instrumentations });
  console.log(
    `tracing initialized (service name: ${serviceName}, backend: ${envStringValue(
      'TRACING_BACKEND',
    )})`,
  );

  // gracefully shut down
  function signalHandler(signal) {
    console.log(`${signal} received. Shutting down...`);
    provider
      ?.shutdown()
      .then(
        () => console.log('tracing shut down successfully'),
        (err) => console.log('error shutting down tracing', err),
      )
      .finally(() => process.exit(0));
  }
  process.on('SIGINT', signalHandler);
  process.on('SIGTERM', signalHandler);
  process.on('SIGQUIT', signalHandler);
};
