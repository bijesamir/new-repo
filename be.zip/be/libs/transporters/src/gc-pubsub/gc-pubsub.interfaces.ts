import { ClientConfig } from '@google-cloud/pubsub';
import { Deserializer, Serializer } from '@nestjs/microservices';

export interface GcPubsubOptions {
  client?: ClientConfig;
  topic?: string;
  responseTopic?: string;
  subscription?: string;
  responseSubscription?: string;
  serializer?: Serializer;
  deserializer?: Deserializer;
}
