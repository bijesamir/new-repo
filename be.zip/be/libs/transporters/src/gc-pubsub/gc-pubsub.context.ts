import { Message } from '@google-cloud/pubsub';
import { BaseRpcContext } from '@nestjs/microservices/ctx-host/base-rpc.context';

type GcPubsubContextArgs = [Message, string];

export class GcPubsubContext extends BaseRpcContext<GcPubsubContextArgs> {
  constructor(args: GcPubsubContextArgs) {
    super(args);
  }

  getMessage() {
    return this.args[0];
  }

  getPattern() {
    return this.args[1];
  }
}
