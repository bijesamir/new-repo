import { Message, PubSub, Subscription, Topic } from '@google-cloud/pubsub';
import { LoggerWrapper } from '@iris-lib/logger';
import {
  ClientProxy,
  IncomingResponse,
  PacketId,
  ReadPacket,
  WritePacket,
} from '@nestjs/microservices';
import { ERROR_EVENT, MESSAGE_EVENT } from '@nestjs/microservices/constants';
import { GcPubsubOptions } from './gc-pubsub.interfaces';

export class GcPubsubClient extends ClientProxy {
  protected logger = new LoggerWrapper(GcPubsubClient.name);

  client: PubSub | null = null;
  topic: Topic | null = null;
  responseSubscription: Subscription | null = null;

  constructor(private readonly options: GcPubsubOptions) {
    super();

    this.initializeSerializer(options);
    this.initializeDeserializer(options);
  }

  async connect(): Promise<any> {
    if (this.client) {
      return this.client;
    }

    this.client = new PubSub(this.options.client);
    this.topic = this.client.topic(this.options.topic);

    const [exists] = await this.topic.exists();
    if (!exists) {
      throw new Error(`topic ${this.topic.name} does not exist`);
    }

    if (this.options.responseSubscription) {
      this.responseSubscription = this.client.subscription(
        this.options.responseSubscription,
      );

      const [exists] = await this.responseSubscription.exists();
      if (!exists) {
        throw new Error(
          `response subscription ${this.responseSubscription.name} does not exist`,
        );
      }

      this.responseSubscription
        .on(MESSAGE_EVENT, async (message: Message) => {
          await this.handleResponse(message);
          message.ack();
        })
        .on(ERROR_EVENT, (error: any) => {
          this.logger.error('response subscription error', null, { error });
        });
    }

    return this.client;
  }

  async close() {
    this.topic && (await this.topic.flush());
    this.responseSubscription && (await this.responseSubscription.close());
    this.client && (await this.client.close());
    this.topic = null;
    this.responseSubscription = null;
    this.client = null;
  }

  async dispatchEvent(packet: ReadPacket<any>): Promise<any> {
    const serializedPacket = this.serializer.serialize({
      data: packet.data,
      pattern: this.normalizePattern(packet.pattern),
    });

    if (this.topic) {
      await this.topic.publishMessage({ json: serializedPacket });
    }
  }

  publish(
    partialPacket: ReadPacket<any>,
    callback: (packet: WritePacket<any>) => void,
  ) {
    try {
      const packet = this.assignPacketId(partialPacket);
      const serializedPacket = this.serializer.serialize(packet);
      this.routingMap.set(packet.id, callback);

      if (this.topic) {
        this.topic
          .publishMessage({ json: serializedPacket })
          .catch((err) => callback({ err }));
      } else {
        callback({ err: new Error(`topic ${this.topic.name} does not exist`) });
      }

      return () => this.routingMap.delete(packet.id);
    } catch (err) {
      callback({ err });
    }
  }

  private async handleResponse(pubSubMessage: Message) {
    const { data, attributes } = pubSubMessage;

    const parsedData = this.parseData(data.toString());
    const packet = this.deserializer.deserialize(
      parsedData,
      attributes,
    ) as IncomingResponse;

    if (packet.id && packet.id !== (parsedData as ReadPacket & PacketId).id) {
      return undefined;
    }

    const { err, response, isDisposed, id } = packet;
    const callback = this.routingMap.get(id);
    if (!callback) {
      return undefined;
    }

    if (isDisposed || err) {
      return callback({
        err,
        response,
        isDisposed: true,
      });
    }

    callback({ err, response });
  }

  private parseData(content) {
    try {
      return JSON.parse(content);
    } catch (error) {
      return content;
    }
  }
}
