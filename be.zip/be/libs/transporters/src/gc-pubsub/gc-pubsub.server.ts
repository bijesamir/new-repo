import { Message, PubSub, Subscription, Topic } from '@google-cloud/pubsub';
import { LoggerWrapper } from '@iris-lib/logger';
import {
  CustomTransportStrategy,
  IncomingRequest,
  Server,
} from '@nestjs/microservices';
import {
  ERROR_EVENT,
  MESSAGE_EVENT,
  NO_MESSAGE_HANDLER,
} from '@nestjs/microservices/constants';
import { isString } from 'class-validator';
import { Observable } from 'rxjs';
import { GcPubsubContext } from './gc-pubsub.context';
import { GcPubsubOptions } from './gc-pubsub.interfaces';

export class GcPubsubServer extends Server implements CustomTransportStrategy {
  protected logger = new LoggerWrapper(GcPubsubServer.name);

  client: PubSub | null = null;
  subscription: Subscription | null = null;
  responseTopic: Topic | null = null;

  constructor(private readonly options: GcPubsubOptions) {
    super();

    this.initializeSerializer(options);
    this.initializeDeserializer(options);
  }

  async listen(callback: () => void) {
    // list all message handlers (logging of ES6 Map not supported)
    this.logger.info('initialized message handlers', {
      handlers: Array.from(this.messageHandlers.keys()),
    });

    this.client = new PubSub(this.options.client);
    this.subscription = this.client.subscription(this.options.subscription);

    const [exists] = await this.subscription.exists();
    if (!exists) {
      throw new Error(`subscription ${this.subscription.name} does not exist`);
    }

    if (this.options.responseTopic) {
      this.responseTopic = this.client.topic(this.options.responseTopic);

      const [exists] = await this.responseTopic.exists();
      if (!exists) {
        throw new Error(
          `response topic ${this.responseTopic.name} does not exist`,
        );
      }
    }

    this.subscription
      .on(MESSAGE_EVENT, async (message: Message) => {
        await this.handleMessage(message);
        message.ack();
      })
      .on(ERROR_EVENT, (error: any) => {
        this.logger.error('subscription error', null, { error });
      });

    callback();
  }

  async close() {
    this.responseTopic && (await this.responseTopic.flush());
    this.subscription && (await this.subscription.close());
    this.client && (await this.client.close());
    this.responseTopic = null;
    this.subscription = null;
    this.client = null;
  }

  private async handleMessage(message: Message) {
    const { data, attributes } = message;

    const parsedData = this.parseData(data.toString());
    const packet = this.deserializer.deserialize(
      parsedData,
      attributes,
    ) as IncomingRequest;

    const pattern = isString(packet.pattern)
      ? packet.pattern
      : JSON.stringify(packet.pattern);

    const context = new GcPubsubContext([message, pattern]);
    const correlationId = packet.id;

    if (!correlationId) {
      return this.handleEvent(pattern, packet, context);
    }

    const handler = this.getHandlerByPattern(pattern);
    if (!handler) {
      const noHandlerPacket = {
        status: 'error',
        err: NO_MESSAGE_HANDLER,
      };
      return this.sendMessage(noHandlerPacket, correlationId);
    }

    const response$ = this.transformToObservable(
      await handler(packet.data, context),
    ) as Observable<any>;
    const publish = (response) => this.sendMessage(response, correlationId);

    response$ && this.send(response$, publish);
  }

  private parseData(content) {
    try {
      return JSON.parse(content);
    } catch (error) {
      return content;
    }
  }

  private async sendMessage(response: any, id: string): Promise<string> {
    Object.assign(response, { id });
    const outgoingResponse = this.serializer.serialize(response);
    return await this.responseTopic.publishMessage({ json: outgoingResponse });
  }
}
