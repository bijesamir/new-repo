import { GcPubsubServer } from '@iris-lib/transporters';
import { INestApplication } from '@nestjs/common';
import { Test, TestingModule } from '@nestjs/testing';
import * as request from 'supertest';
import { GcPubsubTestController } from './gc-pubsub-test.controller';
import { ExpressAdapter } from '@nestjs/platform-express';

describe('GcPubsub transporter', () => {
  let httpServer: ExpressAdapter;
  let app: INestApplication;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [GcPubsubTestController],
    }).compile();

    app = module.createNestApplication();
    httpServer = app.getHttpServer();

    app.connectMicroservice(
      {
        strategy: new GcPubsubServer({
          subscription: 'test-sub',
          responseTopic: 'response-pub',
          client: {
            apiEndpoint: process.env.PUBSUB_EMULATOR_HOST,
            projectId: 'gc-pubsub-transporter-test',
          },
        }),
      },
      { inheritAppConfig: true },
    );
    await app.startAllMicroservices();
    await app.init();
  });

  afterEach(async () => {
    await app.close();
  });

  it(`request`, async () => {
    await request
      .default(httpServer)
      .post('/request')
      .send([1, 2, 3, 4])
      .expect(200, '10');
  });

  it(`promise`, async () => {
    await request
      .default(httpServer)
      .post('/promise')
      .send([1, 2, 3, 4])
      .expect(200, '10');
  });

  it(`observable`, async () => {
    await request
      .default(httpServer)
      .post('/observable')
      .send([1, 2, 3, 4])
      .expect(200, '10');
  });

  it(`stream`, async () => {
    await request
      .default(httpServer)
      .post('/stream')
      .send([1, 2, 3, 4])
      .expect(200, '10');
  });

  it(`event`, async () => {
    await request.default(httpServer).post('/event');
    // wait for pubsub handler to complete
    await new Promise((r) => setTimeout(r, 500));
    expect(GcPubsubTestController.IS_NOTIFIED).toBeTruthy();
  });

  // TODO: test for race condition: https://github.com/johnbiundo/nestjs-faye-transporter-sample/blob/990719c76673bc0d242419b214260a55dd966e16/nestHttpApp/src/app.controller.ts#L249-L266

  // TODO: test for multiple client & server setup in k8s
});
