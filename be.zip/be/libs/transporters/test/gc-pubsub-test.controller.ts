import { GcPubsubClient } from '@iris-lib/transporters';
import {
  Body,
  Controller,
  HttpCode,
  OnApplicationShutdown,
  Post,
} from '@nestjs/common';
import {
  ClientProxy,
  EventPattern,
  MessagePattern,
} from '@nestjs/microservices';
import { from, Observable, of, scan } from 'rxjs';

@Controller()
export class GcPubsubTestController implements OnApplicationShutdown {
  static IS_NOTIFIED = false;

  client: ClientProxy;

  constructor() {
    this.client = new GcPubsubClient({
      topic: 'test-pub',
      responseSubscription: 'response-sub',
      client: {
        apiEndpoint: process.env.PUBSUB_EMULATOR_HOST,
        projectId: 'gc-pubsub-transporter-test',
      },
    });
  }

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  onApplicationShutdown(signal?: string) {
    return this.client.close();
  }

  @Post('/request')
  @HttpCode(200)
  request(@Body() data: number[]) {
    return this.client.send({ cmd: 'request-sum' }, data);
  }

  @MessagePattern({ cmd: 'request-sum' })
  requestHandler(data: number[]) {
    return (data || []).reduce((a, b) => a + b);
  }

  @Post('/promise')
  @HttpCode(200)
  promise(@Body() data: number[]) {
    return this.client.send({ cmd: 'promise-sum' }, data);
  }

  @MessagePattern({ cmd: 'promise-sum' })
  async promiseHandler(data: number[]): Promise<number> {
    return (data || []).reduce((a, b) => a + b);
  }

  @Post('/observable')
  @HttpCode(200)
  observable(@Body() data: number[]) {
    return this.client.send({ cmd: 'observable-sum' }, data);
  }

  @MessagePattern({ cmd: 'observable-sum' })
  observableHandler(data: number[]): Observable<number> {
    return of((data || []).reduce((a, b) => a + b));
  }

  @Post('/stream')
  @HttpCode(200)
  stream(@Body() data: number[]): Observable<number> {
    return this.client
      .send<number>({ cmd: 'stream' }, data)
      .pipe(scan((a, b) => a + b));
  }

  @MessagePattern({ cmd: 'stream' })
  streamHandler(data: number[]): Observable<number> {
    return from(data);
  }

  @Post('/event')
  async event(): Promise<any> {
    return this.client.emit<number>('notification', true);
  }

  @EventPattern('notification')
  eventHandler(data: boolean) {
    GcPubsubTestController.IS_NOTIFIED = data;
  }
}
