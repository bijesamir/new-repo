import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { ProductDataVersion } from './product-data-version.entity';
import { IsIn, IsInt, IsUUID } from 'class-validator';
import {
  DeliveryRequestStatus,
  DeliveryRequestStatusAllValues,
} from '@iris-lib/constants/delivery-request-status';
import { Type } from 'class-transformer';
import {
  DeliveryRequestStatusDetail,
  DeliveryRequestStatusDetailAllValues,
} from '@iris-lib/constants/delivery-request-status-detail';
import {
  DeliveryRequestSource,
  DeliveryRequestSourceAllValues,
} from '@iris-lib/constants';
import { ContractRequiredEntity } from './contract-required.entity';

/**
 * Delivery Request Entity <br/>
 *   The content of product data that customers want and the data necessary to provide it.
 */
@Entity()
export class DeliveryRequest extends ContractRequiredEntity {
  @PrimaryGeneratedColumn('uuid', { comment: 'delivery_request id' })
  id: string;

  @Column({
    generated: 'identity',
    generatedIdentity: 'ALWAYS',
    comment: 'serial number of DeliveryRequest',
  })
  readonly no: number;

  @IsUUID(4)
  // TODO add validator
  @Column({ type: 'uuid', comment: 'product data version id' })
  productDataVersionId: string;

  @ManyToOne(() => ProductDataVersion, {
    orphanedRowAction: 'soft-delete',
    onDelete: 'CASCADE',
  })
  @JoinColumn()
  productDataVersion: ProductDataVersion;

  @IsIn(DeliveryRequestStatusAllValues)
  @Column({
    type: 'varchar',
    comment: 'status',
  })
  @Type(() => String)
  status: DeliveryRequestStatus;

  @IsIn(DeliveryRequestStatusDetailAllValues)
  @Type(() => Number)
  @Column({
    comment: 'Status detail',
    default: DeliveryRequestStatusDetail.None,
  })
  statusDetail: DeliveryRequestStatusDetail;

  @IsInt()
  @Column({
    type: 'int',
    comment: 'registrationId issued by citadel',
    nullable: true,
  })
  paymentId: number;

  @IsIn(DeliveryRequestSourceAllValues)
  @Type(() => Number)
  @Column({
    comment: 'source',
  })
  source: DeliveryRequestSource;

  @CreateDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  createdAt: Date;

  @UpdateDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  updatedAt: Date;

  @DeleteDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  deletedAt: Date;
}
