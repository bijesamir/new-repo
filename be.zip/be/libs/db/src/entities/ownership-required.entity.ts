import {
  IsNotEmpty,
  IsNumber,
  IsPositive,
  IsString,
  Validate,
} from 'class-validator';
import { IsAffiliationOrganization } from '@iris-lib/validators/is-affiliation-organization';
import { Column } from 'typeorm';
import { Type } from 'class-transformer';

/**
 * Ownership Required Entity <br/>
 * Base class of Entity that requires owning organization and latest editor.
 */
export class OwnershipRequiredEntity {
  @IsString()
  @IsNotEmpty()
  @Column({
    comment: 'User ID who last edited this record',
    length: 128,
  })
  latestEditorId: string;

  @Type(() => Number)
  @IsNumber()
  @IsPositive()
  @Validate(IsAffiliationOrganization)
  @Column({
    type: 'int',
    comment: 'Organization ID associated with this record',
  })
  organizationId: number;
}
