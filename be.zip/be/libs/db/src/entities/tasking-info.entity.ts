import { Point, Polygon } from 'geojson';
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  OneToMany,
  OneToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { TaskingRequest } from './tasking-request.entity';
import { Satellite } from './satellite.entity';
import {
  IsArray,
  IsDate,
  IsIn,
  IsInt,
  IsNotEmptyObject,
  IsNumber,
  IsOptional,
  IsPositive,
  IsString,
  IsUUID,
  Max,
  MaxLength,
  Min,
  MinLength,
  Validate,
  ValidateNested,
} from 'class-validator';
import {
  CatalogDelayKind,
  CatalogDelayKindAllValues,
  FlightDirection,
  FlightDirectionValues,
  ImagingMode,
  ImagingModeAllValues,
  LookingDirection,
  LookingDirectionValues,
  PolarizationType,
  PolarizationTypeValues,
  TaskingStatus,
  TaskingStatusAllValues,
  TaskingStatusDetail,
  TaskingStatusDetailAllValues,
  TaskingTypeAllValues,
} from '@iris-lib/constants';
import { IsBefore, IsGeometry } from '@iris-lib/validators';
import { Type } from 'class-transformer';
import { ContractRequiredEntity } from './contract-required.entity';
import { IsExistingTaskingRequest } from '../validators';
import { ProductData } from './product-data.entity';
import { ProductDataRequest } from './product-data-request.entity';
import { ProductDetailsDto } from '@iris-lib/models';
import { ApiProperty } from '@nestjs/swagger';
import { TaskingSummary } from './tasking-summary-view.entity';
import { SceneInfo } from './scene-info.entity';
import { isPoint, isPolygon } from 'geojson-validation';

/**
 * Tasking Info Entity <br/>
 * Imaging request information that is one-to-one with SCS OrderInfo.
 */
@Entity()
export class TaskingInfo extends ContractRequiredEntity {
  @PrimaryGeneratedColumn('uuid', { comment: 'tasking_info id' })
  id: string;

  @Column({
    generated: 'identity',
    generatedIdentity: 'ALWAYS',
    comment: 'serial number of TaskingInfo',
  })
  readonly no: number;

  @Type(() => Date)
  @CreateDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  createdAt: Date;

  @Type(() => Date)
  @UpdateDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  updatedAt: Date;

  @IsOptional()
  @Type(() => Date)
  @DeleteDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  deletedAt?: Date;

  @Index({ unique: true })
  @Column({
    type: 'uuid',
    comment: 'ID assigned to the order by SCS',
    nullable: true,
  })
  scsOrderId: string;

  @Index()
  @Column({
    type: 'varchar',
    length: '12',
    comment: 'serial value assigned to the order by SCS',
    nullable: true,
  })
  scsOrderCode: string;

  @IsNumber()
  @IsIn(TaskingTypeAllValues)
  @Type(() => Number)
  @Column({
    type: 'int',
    comment: 'tasking type',
  })
  taskingType: number;

  @IsUUID(4)
  //  TODO Custom validator with datasource ignored when using PickType.
  @Validate(IsExistingTaskingRequest)
  @Column({ type: 'uuid', comment: 'tasking_request id' })
  taskingRequestId: string;

  @ManyToOne(() => TaskingRequest, {
    orphanedRowAction: 'soft-delete',
    onDelete: 'CASCADE',
  })
  @JoinColumn()
  taskingRequest: TaskingRequest;

  @IsString()
  @IsIn(TaskingStatusAllValues)
  @Column({
    type: 'varchar',
    comment: 'status',
  })
  @Type(() => String)
  status: TaskingStatus;

  @ApiProperty({
    properties: {
      type: {
        type: 'string',
        default: 'Point',
        example: 'Point',
      },
      coordinates: {
        type: 'array',
        maxItems: 2,
        minItems: 2,
        items: {
          type: 'number',
        },
        example: [138.7309, 35.3628],
      },
    },
  })
  @IsNotEmptyObject()
  @Validate(IsGeometry, [isPoint], {
    message: 'center is not a valid point',
  })
  @Index({ spatial: true })
  @Column({
    type: 'geometry',
    srid: 4326,
    spatialFeatureType: 'Point',
    comment: 'center of tasking',
  })
  center: Point;

  @Type(() => Number)
  @Max(99999.999)
  @Min(0)
  @IsNumber()
  @Column({
    type: 'decimal',
    precision: 8,
    scale: 3,
    comment: 'altitude of tasking',
  })
  altitude: number;

  @ApiProperty({
    properties: {
      type: {
        type: 'string',
        default: 'Polygon',
        example: 'Polygon',
      },
      coordinates: {
        type: 'array',
        items: {
          type: 'array',
          items: {
            type: 'array',
            maxItems: 3,
            minItems: 2,
            items: {
              type: 'number',
            },
          },
        },
        example: [
          [
            [-100.250215, -66.611957, 0],
            [-121.401844, -64.557515, 0],
            [-119.190092, -62.959596, 0],
            [-110.432081, -64.884794, 0],
            [-100.250215, -66.611957, 0],
          ],
        ],
      },
    },
  })
  @IsNotEmptyObject()
  @Validate(IsGeometry, [isPolygon], {
    message: 'observationArea is not a valid polygon',
  })
  @Index({ spatial: true })
  @Column({
    type: 'geometry',
    srid: 4326, // Even if not specified, it should be 4326, but just in case, set
    // https://github.com/typeorm/typeorm/issues/4534
    // https://postgis.net/docs/using_postgis_dbmanagement.html#Create_Geography_Tables
    // `The modifier supports coordinate dimensionality restrictions by adding suffixes: Z, M and ZM.`
    // However, the type of geometry_columns table is suffixed. The suffix seems to be represented by the ndims column.
    // Therefore, PostgresQueryRunner recognizes that there is a difference.
    // After generating the migration file, you can avoid it for the time being by setting it to POLYGON.
    spatialFeatureType: 'POLYGON',
    //spatialFeatureType: 'POLYGONZ',
    comment: 'observation area of tasking',
  })
  observationArea: Polygon;

  @IsPositive()
  @IsNumber()
  @Min(100000)
  @Max(999999)
  @Type(() => Number)
  @Column({ type: 'int', comment: 'priority' })
  priority: number;

  @IsNumber()
  @IsIn(ImagingModeAllValues)
  @Type(() => Number)
  @Column({ type: 'int', comment: 'imaging mode code' })
  imagingMode: ImagingMode;

  @IsNumber()
  @IsIn(LookingDirectionValues)
  @Type(() => Number)
  @Column({ type: 'int', comment: 'looking direction code' })
  lookingDirection: LookingDirection;

  @IsNumber()
  @IsIn(FlightDirectionValues)
  @Type(() => Number)
  @Column({ type: 'int', comment: 'flight direction code' })
  flightDirection: FlightDirection;

  @IsNumber()
  @IsIn(CatalogDelayKindAllValues)
  @Type(() => Number)
  @Column({
    type: 'int',
    default: CatalogDelayKind.PERMANENT,
    comment: 'catalog delay kind',
  })
  catalogDelayKind: CatalogDelayKind;

  @IsNumber()
  @Type(() => Number)
  @Column({
    type: 'decimal',
    precision: 5,
    scale: 2,
    comment: 'offnadir angle',
  })
  offnadirAngle: number;

  @IsDate()
  @Validate(IsBefore, ['observationEnd'])
  @Type(() => Date)
  @Column({
    type: 'timestamp with time zone',
    precision: 6,
    comment: 'observation start',
  })
  observationStart: Date;

  @IsDate()
  @Type(() => Date)
  @Column({
    type: 'timestamp with time zone',
    precision: 6,
    comment: 'observation end',
  })
  observationEnd: Date;

  @Column({ type: 'uuid', comment: 'satId' })
  satId: string;

  @ManyToOne(() => Satellite, {
    orphanedRowAction: 'soft-delete',
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'sat_id', referencedColumnName: 'satId' })
  satellite: Satellite;

  @IsIn(TaskingStatusDetailAllValues)
  @Type(() => Number)
  @Column({
    comment: 'Status details',
    default: TaskingStatusDetail.None,
  })
  statusDetail: TaskingStatusDetail;

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => ProductDetailsDto)
  @Column({
    type: 'jsonb',
    comment: 'product details',
  })
  productDetails: ProductDetailsDto[];

  @IsString()
  @MaxLength(255)
  @MinLength(1)
  @Column({
    type: 'varchar',
    length: 255,
    comment: 'tasking name',
    nullable: false,
  })
  name: string;

  @IsNumber()
  @IsIn(PolarizationTypeValues)
  @Column({ type: 'int', comment: 'polarization type' })
  polarization: PolarizationType;

  @IsDate()
  @Column({
    type: 'timestamp with time zone',
    precision: 6,
    nullable: true,
    comment: 'product data download expired date',
  })
  @Type(() => Date)
  downloadExpired: Date;

  @OneToMany(() => ProductData, (productData) => productData.taskingInfo)
  productData: ProductData[];

  @OneToMany(() => SceneInfo, (scene) => scene.taskingInfo)
  sceneInfos: SceneInfo[];

  @Max(7)
  @Min(1)
  @IsInt()
  @Column({ type: 'int', comment: 'number of scene', default: 1 })
  scenes: number;

  @IsInt()
  @Column({
    type: 'int',
    comment: 'registrationId issued by citadel',
    nullable: true,
  })
  paymentId: number;

  @OneToMany(
    () => ProductDataRequest,
    (productDataRequest) => productDataRequest.taskingInfo,
  )
  productDataRequests: ProductDataRequest[];

  @OneToOne(
    () => TaskingSummary,
    (taskingSummary) => taskingSummary.taskingInfo,
  )
  taskingSummary: TaskingSummary;
}
