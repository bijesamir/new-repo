import { Type } from 'class-transformer';
import {
  IsArray,
  IsBoolean,
  IsIn,
  IsString,
  Matches,
  ValidateNested,
} from 'class-validator';

import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { SatelliteParameterDto } from '@iris-lib/models';
import { IrisUserRole, IrisUserRoleAllValues } from '@iris-lib/constants';
import { ApiProperty } from '@nestjs/swagger';

/**
 * Satellite Entity <br/>
 * Satellite information.
 */
@Entity()
export class Satellite {
  @PrimaryGeneratedColumn('uuid', { comment: 'satellite id' })
  id: string;

  @CreateDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  @Type(() => Date)
  createdAt: Date;

  @UpdateDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  @Type(() => Date)
  updatedAt: Date;

  @DeleteDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  @Type(() => Date)
  deletedAt: Date;

  @IsString()
  @Matches(/^Stri[xX]{1}\-[a-zA-Z0-9]{1,10}$/)
  @Column({ type: 'varchar', comment: 'satellite name' })
  name: string;

  @IsString()
  @Matches(/ST\d{4}$/)
  @Column({
    type: 'varchar',
    comment: 'determine satellites in daas',
    unique: true,
  })
  satId: string;

  @IsString()
  @Matches(/dsx\d{4}$/)
  @Column({
    type: 'varchar',
    comment: 'determine satellites in scs',
    unique: true,
  })
  satelliteDevelopmentCode: string;

  @IsBoolean()
  @Column({
    comment: 'available or not',
  })
  isAvailable: boolean;

  @ApiProperty({
    isArray: true,
    enum: IrisUserRoleAllValues,
    example: IrisUserRoleAllValues,
  })
  @IsArray()
  @IsIn(IrisUserRoleAllValues, { each: true })
  @Type(() => Number)
  @Column({
    type: 'jsonb',
    comment: 'user roles that are granted visibility to the satellite',
    default: [],
  })
  visibleTo: IrisUserRole[];

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => SatelliteParameterDto)
  @Column({
    type: 'jsonb',
    comment: 'satellite parameters',
  })
  parameters: SatelliteParameterDto[];
}
