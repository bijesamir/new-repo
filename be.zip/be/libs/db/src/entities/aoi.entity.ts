import { Point, Polygon } from 'geojson';
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  Index,
  JoinTable,
  ManyToMany,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import {
  IsNotEmpty,
  IsNotEmptyObject,
  IsNumber,
  IsOptional,
  MaxLength,
  Validate,
  ValidateIf,
} from 'class-validator';
import { IsGeometry } from '@iris-lib/validators';
import { Transform, Type } from 'class-transformer';
import { TaskingRequest } from './tasking-request.entity';
import { OwnershipRequiredEntity } from './ownership-required.entity';
import { ProductData } from './product-data.entity';
import { ApiProperty } from '@nestjs/swagger';
import { isPoint, isPolygon } from 'geojson-validation';

/**
 * Area of interest Entity <br/>
 * Data indicating the point or area requested by the customer, which is necessary for observation and processing.
 */
@Entity()
export class Aoi extends OwnershipRequiredEntity {
  @PrimaryGeneratedColumn('uuid', { comment: 'aoi id' })
  id: string;

  @Column({
    generated: 'identity',
    generatedIdentity: 'ALWAYS',
    comment: 'serial number of Aoi',
  })
  readonly no: number;

  @CreateDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  createdAt: Date;

  @UpdateDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  updatedAt: Date;

  @DeleteDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  deletedAt: Date;

  @ValidateIf((o) => o.otherProperty == null)
  @IsNotEmpty()
  @MaxLength(255)
  @Column({ type: 'varchar', length: 255, comment: 'aoi name' })
  @Transform(({ value }) => value || '', {
    toClassOnly: true,
  })
  name: string;

  @ApiProperty({
    properties: {
      type: {
        type: 'string',
        default: 'Point',
        example: 'Point',
      },
      coordinates: {
        type: 'array',
        maxItems: 2,
        minItems: 2,
        items: {
          type: 'number',
        },
        example: [138.7309, 35.3628],
      },
    },
  })
  @IsNotEmptyObject()
  @Validate(IsGeometry, [isPoint], {
    message: 'center is not a valid point',
  })
  @Index({ spatial: true })
  @Column({
    type: 'geometry',
    srid: 4326,
    spatialFeatureType: 'Point',
    comment: 'center of area of interest',
    //precision: 15, // https://github.com/typeorm/typeorm/issues/9077
  })
  center: Point;

  @Type(() => Number)
  @IsNumber()
  @Column({
    type: 'decimal',
    precision: 8,
    scale: 3,
    comment: 'altitude',
  })
  altitude: number;

  @ApiProperty({
    properties: {
      type: {
        type: 'string',
        default: 'Polygon',
        example: 'Polygon',
      },
      coordinates: {
        type: 'array',
        items: {
          type: 'array',
          items: {
            type: 'array',
            maxItems: 2,
            minItems: 2,
            items: {
              type: 'number',
            },
          },
        },
        example: [
          [
            [-100.250215, -66.611957],
            [-121.401844, -64.557515],
            [-119.190092, -62.959596],
            [-110.432081, -64.884794],
            [-100.250215, -66.611957],
          ],
        ],
      },
    },
  })
  @IsOptional()
  @Validate(IsGeometry, [isPolygon], {
    message: 'area is not a valid polygon',
  })
  @Column({
    type: 'geometry',
    srid: 4326,
    comment: 'Area of interest',
    spatialFeatureType: 'POLYGON',
    nullable: true,
    // precision: 15, // https://github.com/typeorm/typeorm/issues/9077 && https://postgis.net/docs/ST_AsGeoJSON.html
  })
  area?: Polygon;

  @ManyToMany(() => TaskingRequest, (taskingRequest) => taskingRequest.aois, {
    cascade: true,
    orphanedRowAction: 'delete',
    onDelete: 'CASCADE',
  })
  @JoinTable({
    name: 'join_aoi_on_tasking_request',
    joinColumn: {
      name: 'aoi_id',
      referencedColumnName: 'id',
    },
    inverseJoinColumn: {
      name: 'tasking_request_id',
      referencedColumnName: 'id',
    },
  })
  taskingRequests: TaskingRequest[];

  @OneToMany(() => ProductData, (productData) => productData.aoi)
  productData: ProductData[];
}
