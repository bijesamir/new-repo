import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  OneToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { ProductDataVersion } from './product-data-version.entity';
import { ContractRequiredEntity } from './contract-required.entity';
import {
  IsDate,
  IsIn,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsUUID,
} from 'class-validator';
import { TaskingInfo } from './tasking-info.entity';
import {
  ProductFormat,
  ProductFormatValues,
  ResolutionMode,
  ResolutionModeAllValues,
  StacCollection,
} from '@iris-lib/constants';
import { Type } from 'class-transformer';
import { Aoi } from './aoi.entity';
import { ProductDataRequest } from './product-data-request.entity';
import { SceneInfo } from './scene-info.entity';
import { ReprocessingRequest } from './reprocessing-request.entity';
import { ArchivePurchasedProductData } from './archive-purchased-product-data.entity';

/**
 * Product Data Entity <br/>
 * Multiple product_data_versions with the same tasking_info_id, scene_no, and product_format are linked.
 */
@Entity()
export class ProductData extends ContractRequiredEntity {
  @PrimaryGeneratedColumn('uuid', { comment: 'product_data id' })
  id: string;

  @Column({
    generated: 'identity',
    generatedIdentity: 'ALWAYS',
    comment: 'serial number of ProductData',
  })
  readonly no: number;

  @CreateDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  @Type(() => Date)
  createdAt: Date;

  @UpdateDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  @Type(() => Date)
  updatedAt: Date;

  @DeleteDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  @Type(() => Date)
  deletedAt: Date;

  @IsNumber()
  @IsIn(ProductFormatValues)
  @Column({ type: 'int', comment: 'product format' })
  productFormat: ProductFormat;

  @IsNumber()
  @IsIn(ResolutionModeAllValues)
  @Column({ type: 'int', comment: 'resolution mode' })
  resolutionMode: ResolutionMode;

  @Column({
    type: 'varchar',
    length: 50,
    comment: 'id of scene from DPS',
    nullable: false,
  })
  sceneId: string;

  @IsInt()
  @Column({ type: 'int', comment: 'scene number', nullable: false })
  sceneNo: number;

  @OneToMany(
    () => ProductDataVersion,
    (productDataVersion) => productDataVersion.productData,
  )
  productDataVersions: ProductDataVersion[];

  @IsUUID(4)
  //  TODO Existence check validator
  @IsNotEmpty()
  @Column({ type: 'uuid', comment: 'tasking_info id' })
  taskingInfoId: string;

  @ManyToOne(() => TaskingInfo, (taskingInfo) => taskingInfo.productData, {
    orphanedRowAction: 'soft-delete',
    onDelete: 'CASCADE',
  })
  @JoinColumn()
  taskingInfo: TaskingInfo;

  @ManyToOne(() => SceneInfo, (scene) => scene.productData, { nullable: true })
  @JoinColumn()
  sceneInfo: SceneInfo;

  @IsUUID(4)
  //  TODO Existence check validator
  @IsNotEmpty()
  @Column({ type: 'uuid', comment: 'aoi id', nullable: true })
  aoiId: string;

  @ManyToOne(() => Aoi, (aoi) => aoi.productData, {
    orphanedRowAction: 'soft-delete',
    onDelete: 'CASCADE',
    nullable: true,
  })
  @JoinColumn()
  aoi: Aoi;

  @IsUUID(4)
  @IsNotEmpty()
  @Column({ type: 'uuid', comment: 'product_data_request id', nullable: true })
  productDataRequestId: string;

  @OneToOne(
    () => ProductDataRequest,
    (productDataRequest) => productDataRequest.productData,
    { nullable: true },
  )
  @JoinColumn()
  productDataRequest: ProductDataRequest;

  @IsDate()
  @Type(() => Date)
  @Column({
    type: 'timestamp with time zone',
    precision: 6,
    nullable: true,
    comment: 'publication start',
  })
  publicationStart: Date;

  @Column({
    type: 'varchar',
    length: 50,
    default: StacCollection.STRIX,
  })
  collection: StacCollection;

  @OneToMany(() => ArchivePurchasedProductData, (appd) => appd.productData)
  archivePurchasedProductData?: ArchivePurchasedProductData[];

  @OneToMany(
    () => ReprocessingRequest,
    (reprocessingRequest) => reprocessingRequest.productData,
  )
  reprocessingRequests?: ReprocessingRequest[];
}
