import { ProductFormat, ResolutionMode } from '@iris-lib/constants';
import { ProductMetadataDto } from '@iris-lib/models';
import { Column, ViewColumn, ViewEntity } from 'typeorm';

@ViewEntity({
  expression: `
    SELECT * FROM (
      (
        SELECT
          1 AS desc_no_idx,
          ti.download_expired AS download_expired,
          null AS archive_purchase_request_id,
          null AS archive_purchase_request_no,
          null AS archive_purchase_request_request_id,

          pd.id AS id,
          pd.no AS no,
          pd.created_at AS created_at,
          pd.updated_at AS updated_at,
          pd.deleted_at AS deleted_at,
          pd.organization_id AS organization_id,
          pd.contract_id AS contract_id,
          -1 AS archive_purchase_request_organization_id,
          -1 AS archive_purchase_request_contract_id,
          pd.tasking_info_id AS tasking_info_id,
          ti.scs_order_code AS scs_order_code,
          pd.aoi_id AS aoi_id,
          pd.product_format AS product_format,
          pd.resolution_mode AS resolution_mode,
          pd.scene_id AS scene_id,
          pd.scene_no AS scene_no,

          pdv.id AS product_data_version_id,
          pdv.no AS product_data_version_no,
          pdv.created_at AS product_data_version_created_at,
          pdv.updated_at AS product_data_version_updated_at,
          pdv.deleted_at AS product_data_version_deleted_at,
          pdv.version AS version,
          pdv.source_expired AS source_expired,
          pdv.is_source_deleted AS is_source_deleted,
          pdv.bucket AS bucket,
          pdv.location AS location,
          pdv.quicklook_bucket AS quicklook_bucket,
          pdv.quicklook_location AS quicklook_location,
          pdv.quicklook_content_type AS quicklook_content_type,
          pdv.metadata AS metadata
        FROM product_data pd
        LEFT JOIN product_data_versions pdv
          ON pdv.product_datum_id = pd.id
          AND pdv.organization_id != -1
          AND pdv.contract_id != -1
        LEFT JOIN tasking_infos ti
          ON ti.id = pd.tasking_info_id
          AND ti.organization_id != -1
          AND ti.contract_id != -1
        WHERE pd.organization_id != -1
        AND pd.contract_id != -1
      )
      UNION ALL
      (
        SELECT
          ROW_NUMBER() OVER (
            PARTITION BY appd.archive_purchase_request_id, appd.product_datum_id
            ORDER BY appd.no DESC
          ) AS desc_no_idx,
          apr.download_expired AS download_expired,
          apr.id AS archive_purchase_request_id,
          apr.no AS archive_purchase_request_no,
          apr.request_id AS archive_purchase_request_request_id,

          pd.id AS id,
          pd.no AS no,
          pd.created_at AS created_at,
          pd.updated_at AS updated_at,
          pd.deleted_at AS deleted_at,
          -1 AS organization_id,
          -1 AS contract_id,
          apr.organization_id AS archive_purchase_request_organization_id,
          apr.contract_id AS archive_purchase_request_contract_id,
          pd.tasking_info_id AS tasking_info_id,
          ti.scs_order_code AS scs_order_code,
          pd.aoi_id AS aoi_id,
          pd.product_format AS product_format,
          pd.resolution_mode AS resolution_mode,
          pd.scene_id AS scene_id,
          pd.scene_no AS scene_no,

          pdv.id AS product_data_version_id,
          pdv.no AS product_data_version_no,
          pdv.created_at AS product_data_version_created_at,
          pdv.updated_at AS product_data_version_updated_at,
          pdv.deleted_at AS product_data_version_deleted_at,
          pdv.version AS version,
          pdv.source_expired AS source_expired,
          pdv.is_source_deleted AS is_source_deleted,
          pdv.bucket AS bucket,
          pdv.location AS location,
          pdv.quicklook_bucket AS quicklook_bucket,
          pdv.quicklook_location AS quicklook_location,
          pdv.quicklook_content_type AS quicklook_content_type,
          pdv.metadata AS metadata
        FROM archive_purchased_product_data appd
        INNER JOIN archive_purchase_requests apr
          ON apr.id = appd.archive_purchase_request_id
        INNER JOIN product_data pd
          ON pd.id = appd.product_datum_id
        LEFT JOIN product_data_versions pdv
          ON pdv.id = appd.product_data_version_id
        LEFT JOIN tasking_infos ti
          ON ti.id = pd.tasking_info_id
          AND ti.organization_id != -1
          AND ti.contract_id != -1
      )
    ) AS pds
    WHERE desc_no_idx=1
  `,
})
export class ProductDataView {
  @ViewColumn()
  archivePurchaseRequestId: string;

  @ViewColumn()
  archivePurchaseRequestNo: string;

  @ViewColumn()
  archivePurchaseRequestRequestId: string;

  @ViewColumn()
  downloadExpired: Date;

  @ViewColumn()
  id: string;

  @ViewColumn()
  no: number;

  @ViewColumn()
  createdAt: Date;

  @ViewColumn()
  updatedAt: Date;

  @ViewColumn()
  deletedAt: Date;

  @ViewColumn()
  organizationId: number;

  @ViewColumn()
  contractId: number;

  @ViewColumn()
  archivePurchaseRequestOrganizationId: number;

  @ViewColumn()
  archivePurchaseRequestContractId: number;

  @ViewColumn()
  taskingInfoId: string;

  @ViewColumn()
  scsOrderCode: string;

  @ViewColumn()
  aoiId: string;

  @ViewColumn()
  productFormat: ProductFormat;

  @ViewColumn()
  resolutionMode: ResolutionMode;

  @ViewColumn()
  sceneId: string;

  @ViewColumn()
  sceneNo: number;

  @ViewColumn()
  productDataVersionId: string;

  @ViewColumn()
  productDataVersionNo: number;

  @ViewColumn()
  productDataVersionCreatedAt: Date;

  @ViewColumn()
  productDataVersionUpdatedAt: Date;

  @ViewColumn()
  productDataVersionDeletedAt: Date;

  @ViewColumn()
  version: string;

  @ViewColumn()
  sourceExpired: Date;

  @ViewColumn()
  isSourceDeleted: boolean;

  @ViewColumn()
  bucket: string;

  @ViewColumn()
  location: string;

  @ViewColumn()
  quicklookBucket: string;

  @ViewColumn()
  quicklookLocation: string;

  @ViewColumn()
  quicklookContentType: string;

  @Column({ type: 'jsonb', nullable: false })
  metadata: ProductMetadataDto;
}
