import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToMany,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Type } from 'class-transformer';
import { IsIn } from 'class-validator';
import {
  ProcessingStatus,
  ProcessingStatusAllValues,
} from '@iris-lib/constants';
import { ProductData } from './product-data.entity';
import { ArchivePurchaseRequest } from './archive-purchase-request.entity';

/**
 * Reprocessing Request Entity <br/>
 * Information on reprocessing requests and their status.
 */
@Entity()
export class ReprocessingRequest {
  @PrimaryGeneratedColumn('uuid', { comment: 'reprocessing request id' })
  id: string;

  @Column({
    generated: 'identity',
    generatedIdentity: 'ALWAYS',
    comment: 'serial number',
  })
  readonly no: number;

  @IsIn(ProcessingStatusAllValues)
  @Column({
    type: 'varchar',
    comment: 'status',
  })
  @Type(() => String)
  status: ProcessingStatus;

  @CreateDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
    default: () => "NOW() + '7 day'",
  })
  @Type(() => Date)
  dueDate: Date;

  @Column({
    comment: 'id assigned to the batch by DPS',
    nullable: true,
  })
  dpsBatchId: string;

  @CreateDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  @Type(() => Date)
  createdAt: Date;

  @UpdateDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  @Type(() => Date)
  updatedAt: Date;

  @DeleteDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  @Type(() => Date)
  deletedAt: Date;

  @ManyToOne(
    () => ProductData,
    (productData) => productData.reprocessingRequests,
    { orphanedRowAction: 'soft-delete' },
  )
  @JoinColumn()
  productData: ProductData;

  @ManyToMany(
    () => ArchivePurchaseRequest,
    (archivePurchaseRequest) => archivePurchaseRequest.reprocessingRequests,
    { orphanedRowAction: 'soft-delete' },
  )
  archivePurchaseRequests?: ArchivePurchaseRequest[];
}
