import {
  JoinColumn,
  OneToOne,
  PrimaryColumn,
  ViewColumn,
  ViewEntity,
} from 'typeorm';
import { TaskingInfo } from './tasking-info.entity';
import { SystemOrganization, TaskingSummaryStatus } from '@iris-lib/constants';

// productDeliveries is not used in the backend.
// But, it will be useful to evaluate tasking progress for operators.
// Thus, I added it to this view.
@ViewEntity({
  dependsOn: ['product_data_related_statuses'],
  expression: `
SELECT
    tasking_info_id,
    GREATEST(tasking_info_updated_at, MAX(product_data_request_updated_at), MAX(delivery_request_updated_at)) AS summary_updated_at,
    CASE
        WHEN tasking_info_status = 'pre-credit-check' THEN 'pre-credit-check'
        WHEN tasking_info_status = 'pre-order' THEN 'pre-order'
        WHEN tasking_info_status = 'ordered' THEN 'ordered'
        WHEN tasking_info_status = 'order-fixed' THEN 'acquiring'
        WHEN tasking_info_status = 'observation-completed' THEN (CASE
            WHEN SUM(CASE WHEN product_data_request_status = 'failed' THEN 1 ELSE 0 END) = COUNT(tasking_info_id) THEN 'product-failed'
            WHEN SUM(CASE WHEN delivery_request_status = 'failed' THEN 1 ELSE 0 END) = COUNT(tasking_info_id) THEN 'delivery-failed'
            WHEN SUM(CASE WHEN delivery_request_status = 'completed' THEN 1 ELSE 0 END) = COUNT(tasking_info_id) THEN 'delivered'
            WHEN SUM(CASE WHEN product_data_request_status = 'completed' THEN 1 ELSE 0 END) = COUNT(tasking_info_id) THEN 'product-created'
            ELSE 'processing'
        END)
        WHEN tasking_info_status = 'observation-failed' THEN 'acquisition-failed'
        WHEN tasking_info_status = 'canceled' THEN 'canceled'
        WHEN tasking_info_status = 'rejected' THEN 'rejected'
        ELSE 'N/A'
    END AS summary_status
FROM product_data_related_statuses
WHERE
  (product_data_request_organization_id != ${SystemOrganization.NO_ORGANIZATION} OR
    product_data_request_organization_id IS NULL) AND
  (product_datum_organization_id != ${SystemOrganization.NO_ORGANIZATION} OR
    product_datum_organization_id IS NULL) AND
  (product_data_version_organization_id != ${SystemOrganization.NO_ORGANIZATION} OR
    product_data_version_organization_id IS NULL)
GROUP BY tasking_info_id, tasking_info_status, tasking_info_updated_at;
`,
})
export class TaskingSummary {
  @PrimaryColumn()
  @ViewColumn()
  taskingInfoId: string;

  @ViewColumn()
  summaryUpdatedAt: Date;

  @ViewColumn()
  summaryStatus: TaskingSummaryStatus;

  @OneToOne(() => TaskingInfo, (taskingInfo) => taskingInfo.taskingSummary)
  @JoinColumn([{ name: 'tasking_info_id', referencedColumnName: 'id' }])
  taskingInfo: TaskingInfo;
}
