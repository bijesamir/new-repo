import {
  Column,
  Entity,
  Index,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { ArchivePurchaseRequest } from './archive-purchase-request.entity';
import { ProductData } from './product-data.entity';
import { ProductDataVersion } from './product-data-version.entity';

@Entity()
export class ArchivePurchasedProductData {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({
    generated: 'identity',
    generatedIdentity: 'ALWAYS',
    comment: 'serial number',
  })
  readonly no: number;

  @Column()
  @Index()
  archivePurchaseRequestId: string;

  @ManyToOne(
    () => ArchivePurchaseRequest,
    (apr) => apr.archivePurchasedProductData,
    { onUpdate: 'CASCADE', onDelete: 'CASCADE' },
  )
  archivePurchaseRequest: ArchivePurchaseRequest;

  @Column()
  @Index()
  productDatumId: string;

  @ManyToOne(() => ProductData, (pd) => pd.archivePurchasedProductData)
  productData: ProductData;

  @Column({
    nullable: true,
  })
  @Index()
  productDataVersionId: string;

  @ManyToOne(() => ProductDataVersion)
  productDataVersion: ProductDataVersion;
}
