import {
  DeliveryRequestStatus,
  ProcessingStatus,
  ProductFormat,
  ResolutionMode,
  TaskingStatus,
} from '@iris-lib/constants';
import { ViewColumn, ViewEntity } from 'typeorm';

@ViewEntity({
  expression: `
WITH prepare_lpdr AS(
    SELECT
        ROW_NUMBER() OVER(
            PARTITION BY tasking_info_id,
            scene_no,
            product_format,
            resolution_mode
            ORDER BY
                created_at DESC
        ) AS desc_order_idx,
        id,
        tasking_info_id,
        scene_no,
        product_format,
        resolution_mode,
        organization_id,
        contract_id,
        status,
        updated_at
    FROM
        product_data_requests
),
lpdr AS(
    SELECT
        tasking_info_id as pdr_ti_id,
        id AS product_data_request_id,
        scene_no,
        product_format,
        resolution_mode,
        organization_id AS product_data_request_organization_id,
        contract_id AS product_data_request_contract_id,
        status AS product_data_request_status,
        updated_at AS product_data_request_updated_at
    FROM
        prepare_lpdr
    WHERE
        desc_order_idx = 1
),
joined_ti_lpdr AS(
    SELECT
        ti.id AS tasking_info_id,
        ti.scs_order_id AS order_id,
        ti.scs_order_code AS order_code,
        ti.status AS tasking_info_status,
        ti.organization_id AS tasking_info_organization_id,
        ti.contract_id AS tasking_info_contract_id,
        ti.updated_at AS tasking_info_updated_at,
        lpdr.product_data_request_id,
        lpdr.scene_no,
        lpdr.product_format,
        lpdr.resolution_mode,
        lpdr.product_data_request_organization_id,
        lpdr.product_data_request_contract_id,
        lpdr.product_data_request_status,
        lpdr.product_data_request_updated_at
    FROM
        tasking_infos AS ti
        LEFT JOIN lpdr ON ti.id = lpdr.pdr_ti_id
),
joined_ti_lpdr_pd AS(
    SELECT
        ti_lpdr.*,
        pd.id AS product_datum_id,
        pd.organization_id AS product_datum_organization_id,
        pd.contract_id AS product_datum_contract_id,
        pd.scene_id AS scene_id,
        aoi.id AS aoi_id,
        aoi.name AS aoi_name
    FROM
        joined_ti_lpdr AS ti_lpdr
        LEFT JOIN product_data AS pd ON ti_lpdr.product_data_request_id = pd.product_data_request_id
        LEFT JOIN aois AS aoi ON aoi.id = pd.aoi_id
),
prepare_lpdv AS(
    SELECT
        ROW_NUMBER() OVER(
            PARTITION BY product_datum_id
            ORDER BY
                created_at DESC
        ) AS desc_order_idx,
        id,
        product_datum_id,
        organization_id,
        contract_id
    FROM
        product_data_versions
    WHERE deleted_at IS NULL AND organization_id != -1
),
lpdv AS(
    SELECT
        product_datum_id AS pd_id,
        id AS product_data_version_id,
        organization_id AS product_data_version_organization_id,
        contract_id AS product_data_version_contract_id
    FROM
        prepare_lpdv
    WHERE
        desc_order_idx = 1
),
prepare_ldr AS(
    SELECT
        ROW_NUMBER() OVER(
            PARTITION BY product_data_version_id
            ORDER BY
                created_at DESC
        ) AS desc_order_idx,
        id,
        product_data_version_id,
        organization_id,
        contract_id,
        status,
        updated_at
    FROM
        delivery_requests
),
ldr AS(
    SELECT
        product_data_version_id AS pdv_id,
        id AS delivery_request_id,
        organization_id AS delivery_request_organization_id,
        contract_id AS delivery_request_contract_id,
        status AS delivery_request_status,
        updated_at AS delivery_request_updated_at
    FROM
        prepare_ldr
    WHERE
        desc_order_idx = 1
)
SELECT
    joined_ti_lpdr_pd.*,
    lpdv.product_data_version_id,
    lpdv.product_data_version_organization_id,
    lpdv.product_data_version_contract_id,
    ldr.delivery_request_id,
    ldr.delivery_request_organization_id,
    ldr.delivery_request_contract_id,
    ldr.delivery_request_status,
    ldr.delivery_request_updated_at
FROM
    joined_ti_lpdr_pd
    LEFT JOIN lpdv ON joined_ti_lpdr_pd.product_datum_id = lpdv.pd_id
    LEFT JOIN ldr ON lpdv.product_data_version_id = ldr.pdv_id;
  `,
})
export class ProductDataRelatedStatus {
  @ViewColumn()
  taskingInfoId: string;

  @ViewColumn()
  orderId: string;

  @ViewColumn()
  orderCode: string;

  @ViewColumn()
  taskingInfoStatus: TaskingStatus;

  @ViewColumn()
  taskingInfoOrganizationId: number;

  @ViewColumn()
  taskingInfoContractId: number;

  @ViewColumn()
  productDataRequestId: string;

  @ViewColumn()
  sceneNo: number;

  @ViewColumn()
  productFormat: ProductFormat;

  @ViewColumn()
  resolutionMode: ResolutionMode;

  @ViewColumn()
  productDataRequestOrganizationId: number;

  @ViewColumn()
  productDataRequestContractId: number;

  @ViewColumn()
  productDataRequestStatus: ProcessingStatus;

  @ViewColumn()
  productDataRequestUpdatedAt: Date;

  @ViewColumn()
  productDatumId: string;

  @ViewColumn()
  productDatumOrganizationId: number;

  @ViewColumn()
  productDatumContractId: number;

  @ViewColumn()
  sceneId: string;

  @ViewColumn()
  aoiId: string;

  @ViewColumn()
  aoiName: string;

  @ViewColumn()
  productDataVersionId: string;

  @ViewColumn()
  productDataVersionOrganizationId: number;

  @ViewColumn()
  productDataVersionContractId: number;

  @ViewColumn()
  deliveryRequestId: string;

  @ViewColumn()
  deliveryRequestOrganizationId: number;

  @ViewColumn()
  deliveryRequestContractId: number;

  @ViewColumn()
  deliveryRequestStatus: DeliveryRequestStatus;

  @ViewColumn()
  deliveryRequestUpdatedAt: Date;
}
