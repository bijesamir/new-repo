import { Type } from 'class-transformer';

import {
  IsIn,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsPositive,
  IsString,
  IsUUID,
} from 'class-validator';

import {
  ContractTypeAllValues,
  ResolutionMode,
  ResolutionModeAllValues,
} from '@iris-lib/constants';
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import {
  ProductFormat,
  ProductFormatValues,
} from '../../../constants/src/product-format';
import { ArchivePurchaseRequest } from './archive-purchase-request.entity';
import { ProductDataVersion } from './product-data-version.entity';
import { ProductData } from './product-data.entity';
import { TaskingInfo } from './tasking-info.entity';

/**
 * Download history Entity <br/>
 * Stores download history when users get product data files.
 */
@Entity()
export class DownloadHistory {
  @PrimaryGeneratedColumn('uuid', {
    comment: 'id to be used system internal only',
  })
  id: string;

  @IsString()
  @IsNotEmpty()
  @Column({
    comment: 'User ID who download',
    length: 128,
  })
  userId: string;

  @IsUUID(4)
  @IsNotEmpty()
  @Column({ type: 'uuid', comment: 'product_data id' })
  productDatumId: string;

  @IsUUID(4)
  @IsNotEmpty()
  @Column({ type: 'uuid', comment: 'product data version id' })
  productDataVersionId: string;

  @IsUUID(4)
  @IsNotEmpty()
  @Column({ type: 'uuid', comment: 'tasking_info id' })
  taskingInfoId: string;

  @IsInt()
  @IsNotEmpty()
  @Column({
    type: 'int',
    comment: 'scene number',
  })
  sceneNo: number;

  @IsNumber()
  @IsNotEmpty()
  @IsIn(ProductFormatValues)
  @Type(() => Number)
  @Column({ type: 'int', comment: 'product format' })
  productFormat: ProductFormat;

  @IsNumber()
  @IsNotEmpty()
  @IsIn(ResolutionModeAllValues)
  @Type(() => Number)
  @Column({ type: 'int', comment: 'resolution mode' })
  resolutionMode: ResolutionMode;

  @IsString()
  @IsNotEmpty()
  @IsIn(ContractTypeAllValues)
  @Column({ type: 'varchar', comment: 'contract type' })
  contractType: string;

  @IsNumber()
  @IsPositive()
  @IsNotEmpty()
  @Type(() => Number)
  @Column({ type: 'int', comment: 'organization id' })
  organizationId: number;

  @IsNumber()
  @IsPositive()
  @IsNotEmpty()
  @Type(() => Number)
  @Column({
    type: 'int',
    comment: 'Contract ID associated with this record',
  })
  contractId: number;

  @IsString()
  @Column({
    type: 'varchar',
    length: '12',
    comment: 'serial value assigned to the order by SCS',
    nullable: true,
  })
  scsOrderCode: string;

  @IsOptional()
  @IsString()
  @Column({
    type: 'varchar',
    comment: 'archive purchase request external ID',
    nullable: true,
  })
  archivePurchaseRequestRequestId?: string;

  @CreateDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  @Type(() => Date)
  downloadDatetime: Date;

  @IsOptional()
  @IsString()
  @Column({ type: 'varchar', comment: 'user agent', nullable: true })
  userAgent?: string;

  @IsOptional()
  @IsString()
  @Column({ type: 'varchar', comment: 'request source ip', nullable: true })
  requestSourceIp?: string;

  @CreateDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  @Type(() => Date)
  createdAt: Date;

  @UpdateDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  @Type(() => Date)
  updatedAt: Date;

  @DeleteDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  @Type(() => Date)
  deletedAt: Date;

  @ManyToOne(() => ProductData, () => {})
  productData: ProductData;

  @ManyToOne(() => ProductDataVersion, () => {})
  productDataVersion: ProductDataVersion;

  @ManyToOne(() => TaskingInfo, () => {})
  taskingInfo: TaskingInfo;

  @ManyToOne(() => ArchivePurchaseRequest, () => {})
  @JoinColumn({
    name: 'archive_purchase_request_request_id',
    referencedColumnName: 'requestId',
  })
  archivePurchaseRequest: ArchivePurchaseRequest;
}
