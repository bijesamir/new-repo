import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { OwnershipRequiredEntity } from './ownership-required.entity';
import {
  DeliveryMethod,
  DeliveryMethodAllValues,
} from '@iris-lib/constants/delivery-method';
import { Type } from 'class-transformer';
import {
  IsArray,
  IsIn,
  IsInt,
  IsNotEmpty,
  IsPositive,
  IsString,
  Matches,
  MaxLength,
  Validate,
  ValidateNested,
} from 'class-validator';
import { SshConfigValidator } from '../validators';
import { ProductDetailsDto } from '@iris-lib/models';

/**
 * Delivery Config Entity <br/>
 * Information for automatic delivery of product data. <br/>
 * <br/>
 * A record must be created for each organization requiring automated delivery.
 */
@Entity()
export class DeliveryConfig extends OwnershipRequiredEntity {
  @PrimaryGeneratedColumn('uuid', { comment: 'delivery_config id' })
  id: string;

  @Column({
    generated: 'identity',
    generatedIdentity: 'ALWAYS',
    comment: 'serial number of DeliveryConfig',
  })
  readonly no: number;

  @CreateDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  createdAt: Date;

  @UpdateDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  updatedAt: Date;

  @DeleteDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  deletedAt: Date;

  @IsIn(DeliveryMethodAllValues)
  @IsInt()
  @Type(() => Number)
  @Column({ type: 'int', comment: 'delivery method' })
  method: DeliveryMethod;

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => ProductDetailsDto)
  @Column({
    type: 'jsonb',
    comment: 'product details to deliver',
    default: [],
  })
  productDetails: ProductDetailsDto[];

  /**
   * Information required for automatic delivery. <br/>
   * <br/>
   * The format is described in README.adoc of delivery-center. <br/>
   * Or see ssh-config-validator.ts
   */
  @Validate(SshConfigValidator)
  @IsString()
  @Column({ type: 'text', comment: 'configuration information about delivery' })
  config: string;

  /**
   * Name of the queue for automatic delivery processing.
   */
  @Matches(/^[a-z][a-z_\-0-9]*$/)
  @MaxLength(32)
  @IsString()
  @IsNotEmpty()
  @Column({ type: 'varchar', length: 32, comment: 'job name', unique: true })
  jobName: string;

  /**
   * Organization ID issued by citadel.
   */
  @IsPositive()
  @IsInt()
  @IsNotEmpty()
  @Type(() => Number)
  @Column({ type: 'int', comment: 'organization id' })
  organizationId: number;

  /**
   * Number of concurrent parallel executions.
   */
  @IsPositive()
  @IsInt()
  @IsNotEmpty()
  @Type(() => Number)
  @Column({ type: 'int', comment: 'concurrency', default: 1 })
  concurrency: number;
}
