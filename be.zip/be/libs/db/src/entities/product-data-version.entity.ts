import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { ProductData } from './product-data.entity';
import { ContractRequiredEntity } from './contract-required.entity';
import { ProductMetadataDto } from '@iris-lib/models';
import { Exclude, Type } from 'class-transformer';
import {
  IsBoolean,
  IsDate,
  IsNotEmpty,
  IsUUID,
  Validate,
} from 'class-validator';
import { ApiHideProperty, ApiProperty } from '@nestjs/swagger';
import { IsGeometry } from '@iris-lib/validators';
import { BBox, Point, Polygon } from 'geojson';
import { isPoint, isPolygon } from 'geojson-validation';
import { ArchivePurchasedProductData } from './archive-purchased-product-data.entity';

/**
 * Product Data Version Entity <br/>
 * Substantial information of product data.
 */
@Entity()
export class ProductDataVersion extends ContractRequiredEntity {
  @PrimaryGeneratedColumn('uuid', { comment: 'product_data_version id' })
  id: string;

  @Column({
    generated: 'identity',
    generatedIdentity: 'ALWAYS',
    comment: 'serial number of ProductDataVersion',
  })
  readonly no: number;

  @CreateDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  @Type(() => Date)
  createdAt: Date;

  @UpdateDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  @Type(() => Date)
  updatedAt: Date;

  @DeleteDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  @Type(() => Date)
  deletedAt: Date;

  @Column('jsonb', { nullable: false, default: {} })
  metadata: ProductMetadataDto;

  @IsUUID(4)
  //  TODO Existence check validator
  @IsNotEmpty()
  @Index()
  @Column({ type: 'uuid', comment: 'product_data id' })
  productDatumId: string;

  @ManyToOne(
    () => ProductData,
    (productData) => productData.productDataVersions,
    { orphanedRowAction: 'soft-delete' },
  )
  @JoinColumn()
  productData: ProductData;

  @OneToMany(
    () => ArchivePurchasedProductData,
    (appd) => appd.productDataVersion,
  )
  archivePurchasedProductData?: ArchivePurchasedProductData[];

  @ApiProperty({
    properties: {
      type: {
        type: 'string',
        default: 'Point',
        example: 'Point',
      },
      coordinates: {
        type: 'array',
        maxItems: 2,
        minItems: 2,
        items: {
          type: 'number',
        },
        example: [138.7309, 35.3628],
      },
    },
  })
  @Validate(IsGeometry, [isPoint], {
    message: 'center is not a valid point',
  })
  @Index({ spatial: true })
  @Column({
    type: 'geometry',
    srid: 4326,
    spatialFeatureType: 'POINT',
    comment: 'scene center',
    nullable: true,
    // precision: 15, // https://github.com/typeorm/typeorm/issues/9077
  })
  center?: Point;

  @ApiProperty({
    properties: {
      type: {
        type: 'string',
        default: 'Polygon',
        example: 'Polygon',
      },
      coordinates: {
        type: 'array',
        items: {
          type: 'array',
          items: {
            type: 'array',
            maxItems: 2,
            minItems: 2,
            items: {
              type: 'number',
            },
          },
        },
        example: [
          [
            [-100.250215, -66.611957],
            [-121.401844, -64.557515],
            [-119.190092, -62.959596],
            [-110.432081, -64.884794],
            [-100.250215, -66.611957],
          ],
        ],
      },
    },
  })
  @Validate(IsGeometry, [isPolygon], {
    message: 'area is not a valid polygon',
  })
  @Index({ spatial: true })
  @Column({
    type: 'geometry',
    srid: 4326,
    spatialFeatureType: 'POLYGON',
    comment: 'area defined by scene corners',
    nullable: true,
    // precision: 15, // https://github.com/typeorm/typeorm/issues/9077 && https://postgis.net/docs/ST_AsGeoJSON.html
  })
  area?: Polygon;

  @ApiProperty({
    type: Number,
    isArray: true,
    minItems: 4,
    maxItems: 4,
    example: [15.2677, 44.5574, 15.4412, 44.7921],
  })
  @Column({
    type: 'box',
    comment: 'bbox of area',
    nullable: true,
    transformer: {
      to: (value: BBox) => {
        if (!value) {
          return null;
        }
        return `(${value[0]},${value[1]}),(${value[2]},${value[3]})`;
      },
      from: (value: string) => {
        if (!value) {
          return null;
        }
        value = value.replace(/[\(\)]/g, '');
        const values = value.split(',').map((v) => +v);
        // https://www.postgresql.org/docs/current/datatype-geometric.html#DATATYPE-GEOMETRIC-BOXES
        // upper right and lower left corners, in that order
        // eg. (44.79, 15.44),(44.55, 15.26)
        return [values[2], values[3], values[0], values[1]] as BBox;
      },
    },
  })
  bbox?: BBox;

  @CreateDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
    nullable: true,
    default: () => 'NULL',
  })
  datetime?: Date;

  @Column({
    type: 'varchar',
    comment: 'version identifier for product data',
  })
  version: string;

  @IsDate()
  @Column({
    type: 'timestamp with time zone',
    precision: 6,
    nullable: true,
    comment: 'archive source expired date',
  })
  @Type(() => Date)
  sourceExpired: Date;

  @IsBoolean()
  @Column({
    type: 'boolean',
    default: false,
    nullable: false,
    comment: 'is archive source deleted',
  })
  @Index()
  isSourceDeleted: boolean;

  @ApiHideProperty()
  @Exclude({ toPlainOnly: true })
  @Column({
    type: 'varchar',
    comment: 'storage bucket of product data',
  })
  bucket: string;

  @ApiHideProperty()
  @Exclude({ toPlainOnly: true })
  @Column({
    type: 'varchar',
    comment: 'storage location of product data',
  })
  location: string;

  @ApiHideProperty()
  @Exclude({ toPlainOnly: true })
  @Column({
    type: 'varchar',
    comment: 'storage bucket of quicklook image',
  })
  quicklookBucket: string;

  @ApiHideProperty()
  @Exclude({ toPlainOnly: true })
  @Column({
    type: 'varchar',
    comment: 'storage location of quicklook image',
  })
  quicklookLocation: string;

  @ApiHideProperty()
  @Exclude({ toPlainOnly: true })
  @Column({
    type: 'varchar',
    comment: 'content-type of quicklook image',
  })
  quicklookContentType: string;
}
