import { ApiProperty } from '@nestjs/swagger';
import { Polygon } from 'geojson';
import { PrimaryGeneratedColumn, Column, Index, Entity } from 'typeorm';

/**
 * Observable Area Entity <br/>
 * Stores expected observation area data created in batches. <br/>
 * The raw data is in the syns-daas-(dev|stg|prd)_observable-area-storage bucket. <br/>
 * Register from bucket with pubsub-center's importObservableArea.
 */
@Entity()
export class ObservableArea {
  @PrimaryGeneratedColumn('uuid', { comment: 'observable_area id' })
  id: string;

  @Column({
    generated: 'identity',
    generatedIdentity: 'ALWAYS',
    comment: 'serial number of ObservableArea',
  })
  readonly no: number;

  @Column({
    type: 'timestamp with time zone',
    precision: 6,
    comment: 'date',
    default: () => "DATE_TRUNC('DAY', NOW())",
  })
  date: Date;

  @Column({ type: 'varchar', comment: 'public satellite identifier' })
  satId: string;

  @ApiProperty({
    properties: {
      type: {
        type: 'string',
        default: 'Polygon',
        example: 'Polygon',
      },
      coordinates: {
        type: 'array',
        items: {
          type: 'array',
          items: {
            type: 'array',
            maxItems: 3,
            minItems: 2,
            items: {
              type: 'number',
            },
          },
        },
        example: [
          [
            [-100.250215, -66.611957, 0],
            [-121.401844, -64.557515, 0],
            [-119.190092, -62.959596, 0],
            [-110.432081, -64.884794, 0],
            [-100.250215, -66.611957, 0],
          ],
        ],
      },
    },
  })
  @Index({ spatial: true })
  @Column({
    type: 'geometry',
    srid: 4326, // Even if not specified, it should be 4326, but just in case, set
    // https://github.com/typeorm/typeorm/issues/4534
    // https://postgis.net/docs/using_postgis_dbmanagement.html#Create_Geography_Tables
    // `The modifier supports coordinate dimensionality restrictions by adding suffixes: Z, M and ZM.`
    // However, the type of geometry_columns table is suffixed. The suffix seems to be represented by the ndims column.
    // Therefore, PostgresQueryRunner recognizes that there is a difference.
    // After generating the migration file, you can avoid it for the time being by setting it to POLYGON.
    spatialFeatureType: 'POLYGON',
    //spatialFeatureType: 'POLYGONZ',
    comment: 'polygons composing the observation area',
  })
  polygon: Polygon;
}
