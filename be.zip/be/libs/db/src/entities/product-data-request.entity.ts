import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  OneToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { ContractRequiredEntity } from './contract-required.entity';
import { Type } from 'class-transformer';
import { IsIn, IsInt, IsNotEmpty, IsNumber, IsUUID } from 'class-validator';
import {
  FlightDirection,
  FlightDirectionValues,
  ProcessingStatus,
  ProcessingStatusAllValues,
  ProductFormat,
  ProductFormatValues,
  ResolutionMode,
  ResolutionModeAllValues,
} from '@iris-lib/constants';
import { TaskingInfo } from './tasking-info.entity';
import { ProductData } from './product-data.entity';

/**
 * Product Data Request Entity <br/>
 * Information on product data creation requests and their status.
 */
@Entity()
export class ProductDataRequest extends ContractRequiredEntity {
  @PrimaryGeneratedColumn('uuid', { comment: 'product_data id' })
  id: string;

  @Column({
    generated: 'identity',
    generatedIdentity: 'ALWAYS',
    comment: 'serial number of ProductData',
  })
  readonly no: number;

  @CreateDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  @Type(() => Date)
  createdAt: Date;

  @UpdateDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  @Type(() => Date)
  updatedAt: Date;

  @DeleteDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  @Type(() => Date)
  deletedAt: Date;

  @IsUUID(4)
  @IsNotEmpty()
  @Column({ type: 'uuid', comment: 'tasking_info id' })
  taskingInfoId: string;

  @Index()
  @Column({
    type: 'uuid',
    comment: 'ID assigned to the order by SCS',
    nullable: false,
  })
  scsOrderId: string;

  @ManyToOne(
    () => TaskingInfo,
    (taskingInfo) => taskingInfo.productDataRequests,
    {
      nullable: false,
      orphanedRowAction: 'soft-delete',
      onDelete: 'CASCADE',
    },
  )
  @JoinColumn({ name: 'scs_order_id', referencedColumnName: 'scsOrderId' })
  taskingInfo: TaskingInfo;

  @IsInt()
  @Column({ type: 'int', comment: 'scene number', nullable: false })
  sceneNo: number;

  @IsNumber()
  @IsIn(FlightDirectionValues)
  @Type(() => Number)
  @Column({ type: 'int', comment: 'flight direction' })
  flightDirection: FlightDirection;

  @Column({
    comment: 'id assigned to the batch by DPS',
    nullable: true,
  })
  dpsBatchId: string;

  @IsNumber()
  @IsIn(ProductFormatValues)
  @Type(() => Number)
  @Column({ type: 'int', comment: 'product format' })
  productFormat: ProductFormat;

  @IsNumber()
  @IsIn(ResolutionModeAllValues)
  @Column({ type: 'int', comment: 'resolution mode' })
  resolutionMode: ResolutionMode;

  @IsIn(ProcessingStatusAllValues)
  @Column({
    type: 'varchar',
    comment: 'status',
  })
  @Type(() => String)
  status: ProcessingStatus;

  @OneToOne(() => ProductData, (productData) => productData.productDataRequest)
  productData: ProductData;
}
