import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinTable,
  ManyToMany,
  OneToMany,
  PrimaryGeneratedColumn,
  Unique,
  UpdateDateColumn,
} from 'typeorm';
import { ContractRequiredEntity } from './contract-required.entity';
import { Type } from 'class-transformer';
import { IsDate, IsIn, IsNotEmpty, IsString } from 'class-validator';
import { OrderStatus, OrderStatusAllValues } from '@iris-lib/constants';
import { ReprocessingRequest } from './reprocessing-request.entity';
import { ArchivePurchasedItem } from './archive-purchased-item.entity';
import { ArchivePurchasedProductData } from './archive-purchased-product-data.entity';

/**
 * Archive Purchase Request Entity <br/>
 * Information on archive purchase requests and their status.
 */
@Entity()
@Unique(['requestId'])
export class ArchivePurchaseRequest extends ContractRequiredEntity {
  @PrimaryGeneratedColumn('uuid', { comment: 'archive_purchase id' })
  id: string;

  @IsString()
  @Column({
    type: 'varchar',
    comment: 'archive purchase request external ID',
  })
  requestId: string;

  @IsString()
  @IsNotEmpty()
  @Column({
    comment: 'User ID who ordered this record',
    length: 128,
  })
  orderedUserId: string;

  @Column({
    generated: 'identity',
    generatedIdentity: 'ALWAYS',
    comment: 'serial number of ArchivePurchaseRequest',
  })
  readonly no: number;

  @CreateDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  @Type(() => Date)
  createdAt: Date;

  @UpdateDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  @Type(() => Date)
  updatedAt: Date;

  @DeleteDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  @Type(() => Date)
  deletedAt: Date;

  @IsIn(OrderStatusAllValues)
  @Column({
    type: 'varchar',
    comment: 'status',
  })
  @Type(() => String)
  status: OrderStatus;

  @IsDate()
  @Column({
    type: 'timestamp with time zone',
    precision: 6,
    nullable: true,
    comment: 'archive data download expired date',
  })
  @Type(() => Date)
  downloadExpired: Date;

  @OneToMany(
    () => ArchivePurchasedProductData,
    (appd) => appd.archivePurchaseRequest,
  )
  archivePurchasedProductData?: ArchivePurchasedProductData[];

  @ManyToMany(() => ReprocessingRequest, (req) => req.archivePurchaseRequests)
  @JoinTable({
    name: 'join_archive_purchase_request_on_reprocessing_request',
    joinColumn: {
      name: 'archive_purchase_request_id',
      referencedColumnName: 'id',
    },
    inverseJoinColumn: {
      name: 'reprocessing_request_id',
      referencedColumnName: 'id',
    },
  })
  reprocessingRequests?: ReprocessingRequest[];

  @OneToMany(() => ArchivePurchasedItem, (t) => t.archivePurchaseRequest)
  archivePurchasedItems: ArchivePurchasedItem[];
}
