import {
  Column,
  Entity,
  ManyToOne,
  PrimaryGeneratedColumn,
  Unique,
} from 'typeorm';
import { ArchivePurchaseRequest } from './archive-purchase-request.entity';
import { SceneInfo } from './scene-info.entity';
import { DataSourceType } from '@iris-lib/constants';

@Entity()
@Unique(['archivePurchaseRequest', 'sceneInfo'])
export class ArchivePurchasedItem {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({
    type: 'int',
    nullable: true,
    comment: 'payment registration Id',
  })
  registrationId: number | null;

  @Column({
    type: 'int',
    nullable: true,
    comment: 'payment consumption credit',
  })
  consumptionCredit: number | null;

  @Column({
    type: 'int',
    default: 1,
    nullable: true,
    comment: 'type of data source',
  })
  dataSourceType: DataSourceType | null;

  @ManyToOne(() => ArchivePurchaseRequest, (apr) => apr.archivePurchasedItems)
  archivePurchaseRequest: ArchivePurchaseRequest;

  @ManyToOne(() => SceneInfo, (si) => si.archivePurchasedItems)
  sceneInfo: SceneInfo;
}
