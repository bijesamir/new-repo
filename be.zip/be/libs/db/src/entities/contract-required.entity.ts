import { IsNumber, IsPositive } from 'class-validator';
import { Column } from 'typeorm';
import { OwnershipRequiredEntity } from './ownership-required.entity';
import { Type } from 'class-transformer';

/**
 * Contract Required Entity <br/>
 * Base class of Entity that requires a contract.
 */
export class ContractRequiredEntity extends OwnershipRequiredEntity {
  @Type(() => Number)
  @IsNumber()
  @IsPositive()
  @Column({
    type: 'int',
    comment: 'Contract ID associated with this record',
  })
  contractId: number;
}
