import { Type } from 'class-transformer';
import { IsInt, IsNotEmpty, IsString, IsUUID } from 'class-validator';

import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  Unique,
  UpdateDateColumn,
} from 'typeorm';
import { TaskingInfo } from './tasking-info.entity';
import { ProductData } from './product-data.entity';
import { ArchivePurchasedItem } from './archive-purchased-item.entity';

/**
 * Scene Entity <br/>
 */
@Entity()
@Unique(['taskingInfo', 'sceneNo'])
@Unique(['itemId'])
export class SceneInfo {
  @PrimaryGeneratedColumn('uuid', {
    comment: 'id to be used system internal only',
  })
  id: string;

  @Column({
    generated: 'identity',
    generatedIdentity: 'ALWAYS',
    comment: 'serial number of SceneInfo',
  })
  readonly no: number;

  @Column({
    type: 'int',
    comment: 'scene number',
  })
  @IsInt()
  sceneNo: number;

  @IsString()
  @Column({
    type: 'varchar',
    comment: 'sceneInfo unique ID',
  })
  itemId: string;

  @CreateDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  @Type(() => Date)
  createdAt: Date;

  @UpdateDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  @Type(() => Date)
  updatedAt: Date;

  @DeleteDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  @Type(() => Date)
  deletedAt: Date;

  @IsUUID(4)
  @IsNotEmpty()
  @Column({ type: 'uuid', comment: 'tasking_info id', nullable: true })
  taskingInfoId: string;

  @ManyToOne(() => TaskingInfo, (taskingInfo) => taskingInfo.productData, {
    orphanedRowAction: 'soft-delete',
  })
  @JoinColumn()
  taskingInfo: TaskingInfo;

  @OneToMany(() => ProductData, (productData) => productData.sceneInfo)
  productData: ProductData[];

  @OneToMany(() => ArchivePurchasedItem, (t) => t.sceneInfo)
  archivePurchasedItems: ArchivePurchasedItem[];
}
