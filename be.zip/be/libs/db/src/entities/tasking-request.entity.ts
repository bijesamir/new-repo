import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  ManyToMany,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { TaskingInfo } from './tasking-info.entity';
import {
  IsArray,
  IsIn,
  IsInt,
  IsNumber,
  IsPositive,
  Max,
  Min,
  ValidateNested,
} from 'class-validator';
import {
  AllFlightDirectionValues,
  AllLookingDirectionValues,
  AllPolarizationTypeValues,
  FlightDirection,
  ImagingMode,
  ImagingModeAllValues,
  LookingDirection,
  PolarizationType,
} from '@iris-lib/constants';
import { ContractRequiredEntity } from './contract-required.entity';
import { Type } from 'class-transformer';
import { Aoi } from './aoi.entity';
import { ProductDetailsDto } from '@iris-lib/models';

/**
 * Tasking Request Entity <br/>
 * Template information of TaskingInfo.
 */
@Entity()
export class TaskingRequest extends ContractRequiredEntity {
  @PrimaryGeneratedColumn('uuid', { comment: 'tasking_request id' })
  id: string;

  @Column({
    generated: 'identity',
    generatedIdentity: 'ALWAYS',
    comment: 'serial number of TaskingRequest',
  })
  readonly no: number;

  @CreateDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  createdAt: Date;

  @UpdateDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  updatedAt: Date;

  @DeleteDateColumn({
    type: 'timestamp with time zone',
    precision: 6,
  })
  deletedAt: Date;

  @IsPositive()
  @IsNumber()
  @Min(100000)
  @Max(999999)
  @Column({ type: 'int', comment: 'priority' })
  priority: number;

  @IsIn(ImagingModeAllValues)
  @Column({ type: 'int', comment: 'imaging mode code' })
  imagingMode: ImagingMode;

  @IsIn(AllLookingDirectionValues)
  @Column({ type: 'int', comment: 'looking direction code' })
  lookingDirection: LookingDirection;

  @IsNumber()
  @IsIn(AllFlightDirectionValues)
  @Column({ type: 'int', comment: 'flight direction code' })
  flightDirection: FlightDirection;

  // TODO Should I add a validator?
  @IsNumber()
  @Type(() => Number)
  @Column({
    type: 'decimal',
    precision: 5,
    scale: 2,
    comment: 'offnadir angle min',
  })
  offnadirAngleMin: number;

  // TODO Should I add a validator?
  @IsNumber()
  @Type(() => Number)
  @Column({
    type: 'decimal',
    precision: 5,
    scale: 2,
    comment: 'offnadir angle max',
  })
  offnadirAngleMax: number;

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => ProductDetailsDto)
  @Column({
    type: 'jsonb',
    comment: 'product details',
  })
  productDetails: ProductDetailsDto[];

  @OneToMany(() => TaskingInfo, (taskingInfo) => taskingInfo.taskingRequest)
  taskingInfos: TaskingInfo[];

  @ManyToMany(() => Aoi, (aoi) => aoi.taskingRequests, {
    //cascade: true,
    orphanedRowAction: 'delete',
    onDelete: 'CASCADE',
  })
  aois: Aoi[];

  @Column({
    type: 'varchar',
    length: 255,
    comment: 'tasking request name (option)',
    nullable: true,
  })
  name: string;

  @IsNumber()
  @IsIn(AllPolarizationTypeValues)
  @Column({ type: 'int', comment: 'polarization type' })
  polarization: PolarizationType;

  @Max(7)
  @Min(1)
  @IsInt()
  @Column({ type: 'int', comment: 'number of scene', default: 1 })
  scenes: number;
}
