/* eslint-disable @typescript-eslint/ban-types */
import { IrisUserDto } from '@iris-lib/models';
import { NotFoundException } from '@nestjs/common';
import { In, Repository } from 'typeorm';

/**
 * CustomBaseRepository <br/>
 * Base for extending the repository.
 */
export class CustomBaseRepository<A> extends Repository<A> {
  tablename = this.manager.connection.getMetadata(this.target).tableName;

  /**
   * Added a custom method because the default softRemove cannot set the latestEditorId.
   */
  async softRemoveWithEditor(
    user: IrisUserDto,
    ...ids: string[]
  ): Promise<A[]> {
    return await this.manager.transaction(async (mng) => {
      const deletedAt = new Date();

      const repo = mng.getRepository(this.target);
      const targets = await repo.find({
        where: {
          id: In(ids),
          organizationId: In(user.organizationIds),
        },
      } as A);

      if (targets.length === 0) {
        throw new NotFoundException();
      }

      return await repo.save(
        targets.map((x) => {
          return {
            ...x,
            deletedAt,
            latestEditorId: user.stringUserId(),
          };
        }),
        { reload: true },
      );
    });
  }
}
