import { Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import {
  ValidationArguments,
  ValidatorConstraint,
  ValidatorConstraintInterface,
  isUUID,
} from 'class-validator';
import { TaskingRequest } from '@iris-lib/db/entities';
import { DataSource, In } from 'typeorm';
import { IrisRequestContext } from '@iris-lib/middlewares';

@ValidatorConstraint({
  name: 'isExistingTaskingRequest',
  async: true,
})
@Injectable()
export class IsExistingTaskingRequest implements ValidatorConstraintInterface {
  constructor(@InjectDataSource() protected readonly dataSource: DataSource) {}

  async validate(data: string, args: ValidationArguments) {
    if (!data || data.length == 0) {
      return false;
    }
    if (!isUUID(data, 4)) {
      return false;
    }
    const reqCtx = IrisRequestContext.get().req;
    const orgs =
      'organizationId' in args.object
        ? [args.object['organizationId']]
        : reqCtx.currentUser.organizationIds;
    const tmp = await this.dataSource
      .getRepository(TaskingRequest)
      .findOneOrFail({
        where: {
          id: data,
          organizationId: In(orgs),
        },
      });
    if (tmp) {
      return true;
    }
    return false;
  }

  defaultMessage(args: ValidationArguments) {
    return `${args.property} contains an irrelevant taskingRequestId`;
  }
}
