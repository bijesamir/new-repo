import {
  ValidationArguments,
  ValidatorConstraint,
  ValidatorConstraintInterface,
  isUUID,
} from 'class-validator';
import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, In } from 'typeorm';
import { IrisRequestContext } from '@iris-lib/middlewares';
import { TaskingInfo } from '@iris-lib/db/entities';
import { enableChangeTaskingStatus } from '@iris-lib/constants';

/**
 * Verify if the target tasking_info is updatable to the specified status.
 */
@ValidatorConstraint({ name: 'enableUpdateTaskingStatus', async: true })
@Injectable()
export class EnableUpdateTaskingStatus implements ValidatorConstraintInterface {
  constructor(@InjectDataSource() readonly dataSource: DataSource) {}
  async validate(data: string[], args: ValidationArguments) {
    if (!data || data.length == 0) {
      return false;
    }
    if (!data.every((x) => isUUID(x, 4))) {
      return false;
    }

    if (!('status' in args.object)) {
      return false;
    }

    const reqCtx = IrisRequestContext.get().req;
    const orgs =
      'organizationId' in args.object
        ? [args.object.organizationId]
        : reqCtx.currentUser.organizationIds;

    const tmp = await this.dataSource.getRepository(TaskingInfo).find({
      where: {
        id: In(data),
        organizationId: In(orgs),
      },
    });
    if (data.length != tmp.length) {
      throw new NotFoundException('TaskingInfo(s) not found');
    }

    return tmp.every((x) =>
      enableChangeTaskingStatus(x.status, args.object['status']),
    );
  }
  defaultMessage(args: ValidationArguments) {
    return `${args.property} contains an id or status that cannot be updated`;
  }
}
