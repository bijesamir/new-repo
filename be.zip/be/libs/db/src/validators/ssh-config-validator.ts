import Ajv, { ValidateFunction } from 'ajv/dist/jtd';
import YAML from 'yaml';
import {
  ValidationArguments,
  ValidatorConstraint,
  ValidatorConstraintInterface,
} from 'class-validator';

const DELIVERY_SSH_CONFIG_SCHEMA_YAML = `type: object
properties:
  dest:
     type: string
     minLength: 1
  options:
      anyOf:
      - type: object
        $ref: "#/definitions/sshConfig"
      - type: array
        items:
           $ref: "#/definitions/sshConfig"
  required:
    - dest
    - options
definitions:
  sshConfig:
    type: object
    anyOf:
      - properties:
          host:
            type: string
            minLength: 1
          username:
            type: string
            minLength: 1
          port:
            type: integer
          privateKey:
            type: string
            minLength: 1
        required:
          - host
          - username
          - port
          - privateKey
        additionalProperties: false
      - properties:
          host:
            type: string
            minLength: 1
          username:
            type: string
            minLength: 1
          port:
            type: integer
          password:
            type: string
            minLength: 1
        required:
          - host
          - username
          - port
          - password
        additionalProperties: false`;

@ValidatorConstraint({ name: 'sshConfigValidator', async: false })
export class SshConfigValidator implements ValidatorConstraintInterface {
  private validator: ValidateFunction;
  constructor() {
    const ajv = new Ajv();

    this.validator = ajv.compile(YAML.parse(DELIVERY_SSH_CONFIG_SCHEMA_YAML));
  }
  validate(data: string) {
    return this.validator(YAML.parse(data));
  }

  defaultMessage(args: ValidationArguments) {
    return `${args.property} invalid format`;
  }
}
