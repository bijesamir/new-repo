import {
  ValidationArguments,
  ValidatorConstraint,
  ValidatorConstraintInterface,
  isUUID,
} from 'class-validator';
import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, In } from 'typeorm';
import { Aoi } from '@iris-lib/db/entities';
import { IrisRequestContext } from '@iris-lib/middlewares';

@ValidatorConstraint({ name: 'isExistingAoi', async: true })
@Injectable()
export class IsExistingAoi implements ValidatorConstraintInterface {
  constructor(@InjectDataSource() readonly dataSource: DataSource) {}
  async validate(data: string[], args: ValidationArguments) {
    if (!data || data.length == 0) {
      return false;
    }

    if (!data.every((x) => isUUID(x, 4))) {
      return false;
    }
    const reqCtx = IrisRequestContext.get().req;
    const orgs =
      'organizationId' in args.object
        ? [args.object['organizationId']]
        : reqCtx.currentUser.organizationIds;

    const tmp = await this.dataSource.getRepository(Aoi).find({
      where: {
        id: In(data),
        organizationId: In(orgs),
      },
    });
    if (data.length != tmp.length) {
      throw new NotFoundException('Aoi(s) not found');
    }

    return data.length == tmp.length;
  }
  defaultMessage(args: ValidationArguments) {
    return `${args.property} contains an irrelevant aoiId`;
  }
}
