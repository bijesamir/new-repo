import {
  ValidationArguments,
  ValidatorConstraint,
  ValidatorConstraintInterface,
} from 'class-validator';
import { Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource, In } from 'typeorm';
import { LoggerWrapper } from '@iris-lib/logger';
import {
  IrisUserRole,
  TaskingStatus,
  TaskingType,
  getDetermineDeadlineBaseDate,
  getStandardTaskingEnableStartTime,
} from '@iris-lib/constants';
import { TaskingInfoUpdateStatusDto } from 'apps/backend/src/models/dto/tasking-info/tasking-info-update-status.dto';
import { IrisRequest, IrisRequestContext } from '@iris-lib/middlewares';
import { IrisUserDto } from '@iris-lib/models';
import { TaskingInfo } from '../entities';

@ValidatorConstraint({ name: 'validateCancellationDeadline', async: true })
@Injectable()
export class ValidateCancellationDeadline
  implements ValidatorConstraintInterface
{
  private logger = new LoggerWrapper(ValidateCancellationDeadline.name);

  constructor(@InjectDataSource() readonly dataSource: DataSource) {}

  async validate(status: TaskingStatus, args: ValidationArguments) {
    const parent = args.object as TaskingInfoUpdateStatusDto;
    this.logger.debug('validate CancellationDeadline', { parent });

    const reqCtx: IrisRequest = IrisRequestContext.get().req;
    const user: IrisUserDto = reqCtx.currentUser;
    const isAdmin: boolean = user.roleTypes.includes(
      IrisUserRole.ADMINISTRATOR,
    );

    const taskingInfos: TaskingInfo[] = await this.dataSource
      .getRepository(TaskingInfo)
      .find({
        where: {
          id: In(parent.ids),
          organizationId: In(user.organizationIds),
        },
      });

    const current = new Date();
    const allowedPeriodStartDate = getStandardTaskingEnableStartTime(
      current,
      getDetermineDeadlineBaseDate(current),
    );
    const filtered: TaskingInfo[] = taskingInfos.filter((taskingInfo) => {
      const isCanceled: boolean = status === TaskingStatus.Canceled;
      const isUrgent: boolean = taskingInfo.taskingType === TaskingType.Urgent;
      if (!isAdmin && isCanceled) {
        // urgent task can not be canceled
        if (isUrgent) {
          return false;
        }

        // check cancellation deadline
        // 'observation start' is before 'tasking enable start time' means already observed
        // so that can not be canceled
        if (taskingInfo.observationStart < allowedPeriodStartDate) {
          return false;
        }
      }
      return true;
    });
    return taskingInfos.length === filtered.length;
  }

  defaultMessage(args: ValidationArguments) {
    return `${args.property} contains an exceeded cancellation deadline`;
  }
}
