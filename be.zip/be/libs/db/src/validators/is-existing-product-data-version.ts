import { InjectDataSource } from '@nestjs/typeorm';
import {
  ValidationArguments,
  ValidatorConstraint,
  ValidatorConstraintInterface,
  isUUID,
} from 'class-validator';
import { ProductDataVersion } from '@iris-lib/db/entities';
import { DataSource, In } from 'typeorm';
import { IrisRequestContext } from '@iris-lib/middlewares';
import { Injectable, NotFoundException } from '@nestjs/common';

@ValidatorConstraint({ name: 'IsExistingProductDataVersion', async: true })
@Injectable()
export class IsExistingProductDataVersion
  implements ValidatorConstraintInterface
{
  constructor(@InjectDataSource() readonly dataSource: DataSource) {}
  async validate(data: string[]) {
    if (!data || data.length == 0) {
      return false;
    }

    if (!data.every((x) => isUUID(x, 4))) {
      return false;
    }
    const reqCtx = IrisRequestContext.get().req;

    const tmp = await this.dataSource.getRepository(ProductDataVersion).find({
      where: {
        id: In(data),
        organizationId: In(reqCtx.currentUser.organizationIds),
      },
    });
    if (data.length != tmp.length) {
      throw new NotFoundException('ProductDataVersion(s) not found');
    }

    return data.length == tmp.length;
  }
  defaultMessage(args: ValidationArguments) {
    return `${args.property} contains an irrelevant productDataVersionId`;
  }
}
