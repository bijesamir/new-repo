import { IrisRequestContext } from '@iris-lib/middlewares';
import { Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import {
  ValidationArguments,
  ValidatorConstraint,
  ValidatorConstraintInterface,
  isUUID,
} from 'class-validator';
import { DataSource, In } from 'typeorm';
import { TaskingInfo } from '../entities';
import { enableChangeAltitude } from '@iris-lib/constants';

/**
 * Verifies if the target tasking_info is in advanced update status.
 */
@ValidatorConstraint({ name: 'enableUpdateAltitude', async: true })
@Injectable()
export class EnableUpdateAltitude implements ValidatorConstraintInterface {
  constructor(@InjectDataSource() readonly dataSource: DataSource) {}
  async validate(taskingInfoId: string, args: ValidationArguments) {
    if (!isUUID(taskingInfoId, 4)) {
      return false;
    }

    const reqCtx = IrisRequestContext.get().req;
    const orgs =
      'organizationId' in args.object
        ? [args.object.organizationId]
        : reqCtx.currentUser.organizationIds;

    const tmp = await this.dataSource.getRepository(TaskingInfo).findOneOrFail({
      where: {
        id: taskingInfoId,
        organizationId: In(orgs),
      },
    });
    if (tmp) {
      return enableChangeAltitude(tmp.status);
    }
    return false;
  }

  defaultMessage() {
    return `This does not meet the status that allows changing altitude.`;
  }
}
