import { Aoi } from '@iris-lib/db/entities';
import { CustomBaseRepository } from '../typeorm-ex/custom-base.repository';
import { CustomRepository } from '../typeorm-ex';

@CustomRepository(Aoi)
export class AoiRepository extends CustomBaseRepository<Aoi> {}
