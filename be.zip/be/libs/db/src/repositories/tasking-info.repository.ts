import { TaskingInfo } from '@iris-lib/db/entities';
import {
  CustomBaseRepository,
  CustomRepository,
} from '@iris-lib/db/typeorm-ex';

@CustomRepository(TaskingInfo)
export class TaskingInfoRepository extends CustomBaseRepository<TaskingInfo> {}
