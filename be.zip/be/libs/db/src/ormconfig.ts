import { DataSource, DataSourceOptions, LogLevel } from 'typeorm';
import { envStringValue, envIntValue, envBooleanValue } from '@iris-lib/utils';
import CustomNamingStrategy from './custom-naming-strategy';
import { Injectable } from '@nestjs/common';
import { ConfigService, Path, PathValue } from '@nestjs/config';
import { CustomTypeormLogger } from './custom-typeorm-logger';

export const generateDbConfig = () => {
  const enableLogging = () => {
    if (process.env.NODE_ENV === 'development') {
      if (envBooleanValue('DISABLE_TEST_DB_LOGGING', true)) {
        return false;
      } else {
        return ['query', 'warn', 'error', 'migration', 'schema'] as LogLevel[];
      }
    } else if (process.env.NODE_ENV === 'test') {
      if (!envBooleanValue('DISABLE_TEST_DB_LOGGING', true)) {
        return ['query', 'warn', 'error', 'migration', 'schema'] as LogLevel[];
      } else {
        return false;
      }
    } else {
      return ['warn', 'error'] as LogLevel[];
    }
  };

  return {
    db: {
      type: 'postgres',
      host: envStringValue('DB_HOST'),
      port: envIntValue('DB_PORT'),
      username: envStringValue('DB_USER'),
      password: envStringValue('DB_PASSWORD'),
      database: envStringValue('DB_NAME'),
      logging: enableLogging(),
      entities: [`${__dirname}/entities/**/*.entity.{ts,js}`],
      migrations: [`${__dirname}/../../../migrations/**/*.{ts,js}`],
      namingStrategy: new CustomNamingStrategy(),
      logger: new CustomTypeormLogger(enableLogging()),
    },
    dbOperationLog: {
      enabled: envBooleanValue('DB_OPERATION_LOG_ENABLED', false),
      appName: envStringValue(
        'DB_OPERATION_LOG_APPNAME',
        'IT_IS_BETTER_TO_SET',
      ),
    },
  };
};

export type DbConfig = ReturnType<typeof generateDbConfig>;

@Injectable()
export class DbConfigService extends ConfigService<DbConfig, true> {
  // eslint-disable-next-line no-use-before-define
  get<P extends Path<T>, T = DbConfig>(arg: P): PathValue<T, P> {
    return super.get<T, P, PathValue<T, P>>(arg, { infer: true });
  }
}

export default new DataSource(generateDbConfig().db as DataSourceOptions);
