import {
  DataSource,
  EntitySubscriberInterface,
  EventSubscriber,
  InsertEvent,
  RecoverEvent,
  RemoveEvent,
  SoftRemoveEvent,
  TransactionCommitEvent,
  UpdateEvent,
} from 'typeorm';
import { InjectDataSource } from '@nestjs/typeorm';
import { LoggerWrapper } from '@iris-lib/logger';
import {
  DbOperationLogDto,
  DbOperationLogEvent,
  DbOperationLogEventType,
} from '@iris-lib/models';
import { plainToClass } from 'class-transformer';
import { IrisRequestContext } from '@iris-lib/middlewares';
import { Inject } from '@nestjs/common';
import { DbConfigService } from '../ormconfig';
import { LogData, TransactionSubscriber } from './transaction.subscriber';

/**
 * DbOperationLogSubscriber <br/>
 * Output log of insert, update, soft delete (deleted_at setting) <br/>
 *
 * see below:<br/>
 * https://orkhan.gitbook.io/typeorm/docs/listeners-and-subscribers <br/>
 * https://stackoverflow.com/questions/58918644/nestjs-cannot-inject-a-service-into-a-subscriber <br/>
 * https://docs.nestjs.com/techniques/database#subscribers <br/>
 */
@EventSubscriber()
export class DbOperationLogSubscriber
  extends TransactionSubscriber
  implements EntitySubscriberInterface
{
  private logger = new LoggerWrapper(DbOperationLogSubscriber.name);
  constructor(
    @InjectDataSource() readonly dataSource: DataSource,
    @Inject('DbConfig') readonly config: DbConfigService,
  ) {
    super();
    const isEnabled = this.config.get('dbOperationLog.enabled');

    if (isEnabled) {
      dataSource.subscribers.push(this);
    }
    this.logger.debug(`db subscriber enabled: ${isEnabled}`);
  }

  afterInsert(event: InsertEvent<any>) {
    const dbLog = this.getDbLog(DbOperationLogEvent.Insert, event);

    if (event.queryRunner.isTransactionActive) {
      this.storeEvent(event, dbLog);
    } else {
      this.logger.recorder({ operation: dbLog });
    }
  }

  afterUpdate(event: UpdateEvent<any>) {
    if (event.updatedColumns.length > 0) {
      const dbLog = this.getDbLog(DbOperationLogEvent.Update, event);

      if (event.queryRunner.isTransactionActive) {
        this.storeEvent(event, dbLog);
      } else {
        this.logger.recorder({ operation: dbLog });
      }
    }
  }

  afterRemove(event: RemoveEvent<any>) {
    const dbLog = this.getDbLog(DbOperationLogEvent.Remove, event);

    if (event.queryRunner.isTransactionActive) {
      this.storeEvent(event, dbLog);
    } else {
      this.logger.recorder({ operation: dbLog });
    }
  }

  afterSoftRemove(event: SoftRemoveEvent<any>) {
    const dbLog = this.getDbLog(DbOperationLogEvent.SoftRemove, event);

    if (event.queryRunner.isTransactionActive) {
      this.storeEvent(event, dbLog);
    } else {
      this.logger.recorder({ operation: dbLog });
    }
  }

  afterRecover(event: RecoverEvent<any>) {
    const dbLog = this.getDbLog(DbOperationLogEvent.Recover, event);

    if (event.queryRunner.isTransactionActive) {
      this.storeEvent(event, dbLog);
    } else {
      this.logger.recorder({ operation: dbLog });
    }
  }

  afterTransactionCommit(event: TransactionCommitEvent) {
    const commitedLogs: LogData[] = event.manager[this.logKey];

    for (const logData of commitedLogs) {
      if (logData.dbLog) {
        this.logger.recorder({ operation: logData.dbLog });
      }
    }
  }

  private getDbLog(
    eventType: DbOperationLogEventType,
    event:
      | InsertEvent<any>
      | UpdateEvent<any>
      | RemoveEvent<any>
      | SoftRemoveEvent<any>
      | RecoverEvent<any>,
  ) {
    const tmp = plainToClass(DbOperationLogDto, {
      event: eventType,
      table: event.metadata.tableName,
      row: event.entity,
      application: this.config.get('dbOperationLog.appName'),
      isTransaction: event.queryRunner.isTransactionActive,
    });
    const rc = IrisRequestContext.get() ? IrisRequestContext.get().req : null;
    if (rc) {
      tmp.userId = rc.currentUser.stringUserId();
      tmp.organizationId = rc.currentUser.currentOrganizationId.toString();
      tmp.requestId = rc.requestId;
    } else {
      tmp.userId = 'system';
    }

    return tmp;
  }
}
