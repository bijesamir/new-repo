import { InsertEvent, SoftRemoveEvent, UpdateEvent } from 'typeorm';
import { TransactionStartEvent } from 'typeorm/subscriber/event/TransactionStartEvent';
import { DbOperationLogDto } from '@iris-lib/models';

export interface LogData {
  dbLog: DbOperationLogDto;
  entityName: string;
}

/**
 * TransactionSubscriber <br/>
 * Record operations within a transaction.
 */
export class TransactionSubscriber {
  readonly logKey = 'logs';

  storeEvent(
    event: InsertEvent<any> | UpdateEvent<any> | SoftRemoveEvent<any>,
    dbLog?: DbOperationLogDto,
  ) {
    event.manager[this.logKey] = event.manager[this.logKey] || [];

    event.manager[this.logKey].push({
      dbLog,
      entityName: event.metadata.name,
    } as LogData);
  }

  beforeTransactionStart(event: TransactionStartEvent) {
    event.manager[this.logKey] = event.manager[this.logKey] || [];
  }
}
