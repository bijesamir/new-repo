import { Global, Module } from '@nestjs/common';

import { ConfigModule } from '@nestjs/config';
import { DbConfigService, generateDbConfig } from './ormconfig';

@Global()
@Module({
  imports: [
    ConfigModule.forRoot({
      // .envよみこまない
      ignoreEnvFile: true,
      // 設定ファイル指定
      load: [generateDbConfig],
    }),
  ],

  providers: [
    {
      provide: 'DbConfig',
      useClass: DbConfigService,
    },
  ],
  exports: ['DbConfig'],
})
export class DbConfigModule {}
