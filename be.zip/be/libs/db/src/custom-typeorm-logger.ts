import {
  Logger,
  QueryRunner,
  AdvancedConsoleLogger,
  LoggerOptions,
} from 'typeorm';

// https://cloud.google.com/logging/quotas?hl=ja
const LIMIT = 256 * 1024 - 20;

export class CustomTypeormLogger
  extends AdvancedConsoleLogger
  implements Logger
{
  constructor(options?: LoggerOptions) {
    super(options);
  }

  logQuery(query: string, parameters?: any[], queryRunner?: QueryRunner) {
    let logText = query;

    if (Buffer.byteLength(logText, 'utf-8') > LIMIT) {
      // Truncate the log text if it's too long:
      logText = logText.substring(0, LIMIT) + '...';
      super.logQuery(logText, parameters, queryRunner);
    } else {
      super.logQuery(logText, parameters, queryRunner);
    }
  }
}
