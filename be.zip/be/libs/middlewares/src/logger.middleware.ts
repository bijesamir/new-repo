import { Injectable, Logger, NestMiddleware } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';
import { IrisRequestContext } from './iris-request-context/iris-request-context';

@Injectable()
export class LoggerMiddleware implements NestMiddleware {
  private logger = new Logger(`HTTP`);
  // ignores "/healthz", "/health" and "/"
  private noLogRegExp = new RegExp(/^\/(healthz?)?$/);

  use(req: Request, res: Response, next: NextFunction) {
    const now = Date.now();
    res.on('finish', () => {
      const { statusCode } = res;
      if (!this.noLogRegExp.test(req.path) || statusCode >= 400) {
        // TODO It might be better to set current organizationId.
        const logPayloadBase = {
          requestId: IrisRequestContext.get().req.requestId,
          type: 'access',
          userId: IrisRequestContext.get().req.currentUser
            ? IrisRequestContext.get().req.currentUser.userId
            : 'anonymous',
          method: req.method,
          path: req.path,
          query: JSON.stringify(req.query),
          headers: req.headers,
          duration: `${Date.now() - now}`, // msec
          statusCode,
        };
        let option = {};

        const checkOption = (key: string) => {
          return req.query[key]
            ? req.query[key].toString().toLowerCase() == 'true'
            : process.env.NODE_ENV !== 'production';
        };
        if (checkOption('debug-logging-header')) {
          option = { ...option, header: req.headers };
        }
        if (
          checkOption('debug-logging-user') &&
          IrisRequestContext.get().req.currentUser
        ) {
          option = {
            ...option,
            user: IrisRequestContext.get().req.currentUser,
          };
        }

        if (checkOption('debug-logging-ip')) {
          option = {
            ...option,
            ip: req.ip,
          };
        }

        this.logger.log({ ...logPayloadBase, ...option });
      }
    });
    next();
  }
}
