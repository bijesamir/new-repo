import { RequestContext } from 'nestjs-request-context';
import { IrisUserDto } from '@iris-lib/models';
import { IrisContractPackage } from '@iris-lib/models/payment';
import { Request } from 'express';

/**
 * iris request context. <br/>
 * The purpose is to set the necessary information for various middleware and guards and make it easy to use under the controller.
 */
export interface IrisRequest extends Request {
  /**
   * Numbered by IrisRequestContextMiddleware.
   */
  requestId: string;
  /**
   * Configured in GatewayAuthGuard and forwarded from iris-gateway.
   */
  currentUser: IrisUserDto;
  /**
   * Configured in IrisAuthGuard.
   */
  currentContracts: IrisContractPackage[];
  /**
   * Configured in IpFilterGuard and forwarded from iris-gateway.
   */
  isWhiteListedIp: boolean;
  /**
   * Configured in IpFilterGuard and forwarded from iris-gateway.
   */
  sourceIp: string;
}

export class IrisRequestContext {
  static get(): RequestContext<IrisRequest> {
    return RequestContext.currentContext;
  }
}
