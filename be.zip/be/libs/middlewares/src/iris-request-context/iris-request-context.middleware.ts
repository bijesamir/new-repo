import { Injectable, NestMiddleware } from '@nestjs/common';
import { createId } from '@paralleldrive/cuid2';
import { IrisRequest } from './iris-request-context';
import { NextFunction, Response } from 'express';
import { HEADER_REQUEST_ID } from '@iris-lib/constants';

/**
 * Number requestId for tracing.
 */
@Injectable()
export class IrisRequestContextMiddleware
  implements NestMiddleware<IrisRequest>
{
  use(req: IrisRequest, res: Response, next: NextFunction) {
    req.requestId = createId();
    res.setHeader(HEADER_REQUEST_ID, req.requestId);
    next();
  }
}
