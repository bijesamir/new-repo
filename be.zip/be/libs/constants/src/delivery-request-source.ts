export const DeliveryRequestSource = {
  OnlyDeliveryRequest: 0,
  Observation: 1,
  ReprocessingRequest: 2,
};

export type DeliveryRequestSource =
  (typeof DeliveryRequestSource)[keyof typeof DeliveryRequestSource];

export const DeliveryRequestSourceAllValues = Object.values(
  DeliveryRequestSource,
);
