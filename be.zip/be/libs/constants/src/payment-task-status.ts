import { DeliveryRequestStatus } from './delivery-request-status';
import { OrderStatus } from './order-status';
import {
  TaskingOperationStatus,
  TaskingStatus,
  UnrecordedTaskingStatus,
} from './tasking-status';

export const PaymentTaskStatus = {
  TEMPORAL: 0,
  RESERVED: 1,
  COMPLETED: 2,
  CANCELED: 3,
  EXCEPTIONAL: 4,
  INTERNALERROR: 5,
  OBSERVATIONFAILED: 6,
};

export type PaymentTaskStatus =
  (typeof PaymentTaskStatus)[keyof typeof PaymentTaskStatus];

export const PaymentTaskStatusAllValues = Object.values(PaymentTaskStatus);

export type IrisStatusRelatedToPayment =
  | TaskingOperationStatus
  | DeliveryRequestStatus;

export const fromTaskingOperationStatusToPaymentTaskStatus = (
  src: TaskingOperationStatus,
) => {
  switch (src) {
    case TaskingStatus.Rejected:
    case TaskingStatus.Canceled:
    case UnrecordedTaskingStatus.RegisterFailed:
      return PaymentTaskStatus.CANCELED;
    case DeliveryRequestStatus.Completed:
      return PaymentTaskStatus.COMPLETED;
    case TaskingStatus.ObservationFailed:
      return PaymentTaskStatus.OBSERVATIONFAILED;
    default:
      throw new Error(`unknown tasking status: ${src}`);
  }
};

export const fromOrderStatusToPaymentTaskStatus = (src: OrderStatus) => {
  switch (src) {
    case OrderStatus.New:
      return PaymentTaskStatus.RESERVED;
    case OrderStatus.Failed:
      return PaymentTaskStatus.CANCELED;
    case OrderStatus.Completed:
      return PaymentTaskStatus.COMPLETED;
    default:
      throw new Error(`unknown tasking status: ${src}`);
  }
};
