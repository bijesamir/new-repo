export const DeliveryRequestStatusDetail = {
  None: 0,
};

export type DeliveryRequestStatusDetail =
  (typeof DeliveryRequestStatusDetail)[keyof typeof DeliveryRequestStatusDetail];

export const DeliveryRequestStatusDetailAllValues = Object.values(
  DeliveryRequestStatusDetail,
);
