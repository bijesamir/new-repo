import { envIntValue, envStringValue } from '@iris-lib/utils';

export const TEST_USER_ID = '1000001';
export const TEST_ANOTHER_USER_ID = '1000002';
export const TEST_THIRD_USER_ID = '1000003';
export const TEST_INTERNAL_USER_ID = '1000004';
export const TEST_ORGANIZATION_ID = 1000001;
export const TEST_ANOTHER_ORGANIZATION_ID = 1000002;
export const TEST_THIRD_ORGANIZATION_ID = 1000003;
export const TEST_CONTRACT_ID = 1000001;
export const TEST_ANOTHER_CONTRACT_ID = 1000002;
export const TEST_THIRD_CONTRACT_ID = 1000003;
export const TEST_REGULAR_TASK_CONTRACT_ID = 1100003;
export const TEST_SERVICE_ID = 1000001;

export const getTestUserIdForFixture = () => {
  return envStringValue('OVERWRITE_TEST_USER_ID', TEST_USER_ID);
};

export const getTestOrganizationIdForFixture = () => {
  return envIntValue('OVERWRITE_TEST_ORGANIZATION_ID', TEST_ORGANIZATION_ID);
};

export const getTestContractIdForFixture = () => {
  return envIntValue('OVERWRITE_TEST_CONTRACT_ID', TEST_CONTRACT_ID);
};

export const getTestAnotherUserIdForFixture = () => {
  return envStringValue('OVERWRITE_TEST_ANOTHER_USER_ID', TEST_ANOTHER_USER_ID);
};

export const getTestAnotherOrganizationIdForFixture = () => {
  return envIntValue(
    'OVERWRITE_TEST_ANOTHER_ORGANIZATION_ID',
    TEST_ANOTHER_ORGANIZATION_ID,
  );
};

export const getTestAnotherContractIdForFixture = () => {
  return envIntValue(
    'OVERWRITE_TEST_ANOTHER_CONTRACT_ID',
    TEST_ANOTHER_CONTRACT_ID,
  );
};

export const getTestRegularTaskContractIdForFixture = () => {
  return envIntValue(
    'OVERWRITE_TEST_REGULAR_TASK_CONTRACT_ID',
    TEST_REGULAR_TASK_CONTRACT_ID,
  );
};

export const getTestServiceIdForFixture = () => {
  return envIntValue('OVERWRITE_TEST_SERVICE_ID', TEST_SERVICE_ID);
};
export const getTestThirdUserIdForFixture = () => {
  return envStringValue('OVERWRITE_TEST_THIRD_USER_ID', TEST_THIRD_USER_ID);
};

export const getTestThirdOrganizationIdForFixture = () => {
  return envIntValue(
    'OVERWRITE_TEST_THIRD_ORGANIZATION_ID',
    TEST_THIRD_ORGANIZATION_ID,
  );
};

export const getTestThirdContractIdForFixture = () => {
  return envIntValue(
    'OVERWRITE_TEST_THIRD_CONTRACT_ID',
    TEST_THIRD_CONTRACT_ID,
  );
};

export const getTestInternalUserIdForFixture = () => {
  return envStringValue(
    'OVERWRITE_TEST_INTERNAL_USER_ID',
    TEST_INTERNAL_USER_ID,
  );
};
