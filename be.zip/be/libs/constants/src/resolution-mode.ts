export const ResolutionMode = {
  normal: 1,
  SR: 2, // super resolution
};

export type ResolutionMode =
  (typeof ResolutionMode)[keyof typeof ResolutionMode];

export const ResolutionModeAllValues = Object.values(ResolutionMode);

export const getResolutionModeLabel = (v: ResolutionMode) => {
  switch (v) {
    case ResolutionMode.normal:
      return 'normal';
    case ResolutionMode.SR:
      return 'SR';
  }
};
