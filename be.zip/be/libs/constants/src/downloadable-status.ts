export const DownloadableStatus = {
  NotReady: 'not_ready',
  Ready: 'ready',
  Expired: 'expired',
};

export type DownloadableStatus =
  (typeof DownloadableStatus)[keyof typeof DownloadableStatus];

export const DownloadableStatusAllValues = Object.values(DownloadableStatus);
