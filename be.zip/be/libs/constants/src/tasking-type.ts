import set from 'date-fns/set';
import isBefore from 'date-fns/isBefore';
import { add } from 'date-fns';

export const TaskingType = {
  Unknown: 0,
  Regular: 1,
  Urgent: 2,
};

export const TaskingTypeParamName = {
  Regular: 'regular',
  Urgent: 'urgent',
};

export type TaskingType = (typeof TaskingType)[keyof typeof TaskingType];
export type TaskingTypeParamName =
  (typeof TaskingTypeParamName)[keyof typeof TaskingTypeParamName];

export const TaskingTypeAllValues = Object.values(TaskingType);
export const TaskingTypeParamNameAllValues =
  Object.values(TaskingTypeParamName);

export const AvailableTaskingTypeValues = TaskingTypeAllValues.filter(
  (x) => x !== TaskingType.Unknown,
);

export const getTaskingTypeString = (v: TaskingType) => {
  switch (v) {
    case TaskingType.Regular:
      return 'Standard';
    case TaskingType.Urgent:
      return 'Urgent';
  }
  return '';
};

export const getTaskingTypeParamName = (
  v: TaskingType,
): TaskingTypeParamName => {
  switch (v) {
    case TaskingType.Regular:
      return TaskingTypeParamName.Regular;
    case TaskingType.Urgent:
      return TaskingTypeParamName.Urgent;
  }
  return '';
};

export const getTaskingType = (v: TaskingTypeParamName): TaskingType => {
  switch (v) {
    case TaskingTypeParamName.Regular:
      return TaskingType.Regular;
    case TaskingTypeParamName.Urgent:
      return TaskingType.Urgent;
  }
  return undefined;
};

export const maxEnableEndDays = 10;

export const getDetermineDeadlineBaseDate = (date?: Date | null) => {
  const tmpDate = date ? date : new Date();
  const deadline1 = set(tmpDate, {
    hours: 3, // 12 pm in JST
    minutes: 0,
    seconds: 0,
    milliseconds: 0,
  });
  const deadline2 = set(tmpDate, {
    hours: 15, // 12 am tomorrow in JST
    minutes: 0,
    seconds: 0,
    milliseconds: 0,
  });
  if (isBefore(tmpDate, deadline1)) {
    // If cuurent time is between 00:00 and 03:00 UTC, deadline is 03:00 UTC (12 pm JST today).
    return deadline1;
  } else if (isBefore(tmpDate, deadline2)) {
    // If current time is between 03:00 and 15:00 UTC, deadline is 15:00 UTC (12 am JST tomorrow).
    return deadline2;
  } else {
    // If current time is between 15:00 and 24:00 UTC, deadline is 03:00 UTC tomorrow (12 pm JST tomorrow).
    return add(deadline1, { days: 1 });
  }
};

const addDaysAndSetMidNight = (date: Date, days: number) => {
  return set(add(date, { days }), {
    hours: 15,
    minutes: 0,
    seconds: 0,
    milliseconds: 0,
  });
};

export const getStandardTaskingEnableStartTime = (
  current: Date, // Cuurent deadline definition doesn't use this parameter, but it might be required in the future definition. So, remain it.
  referenceDate: Date,
) => {
  // In the current deadline, regular tasking search start should be 12 hours after the deadline.
  return add(referenceDate, { hours: 12 });
};

export const getTaskingEnableEndTime = (current: Date) => {
  return addDaysAndSetMidNight(current, maxEnableEndDays);
};

export const getUrgentDeadlineTime = (current: Date, referenceDate: Date) => {
  // Urgent deadline is same with standard tasking enable start time.
  return getStandardTaskingEnableStartTime(current, referenceDate);
};

export class TaskingTypeDetermination {
  static getCurrentDatetime(current?: Date | null) {
    return current ? current : new Date();
  }

  static exec(targetDate: Date) {
    // Definition of tasking type
    // https://docs.google.com/document/d/1Vn2b3OKxz41lKIcVTES4w_gZZ3fWOB-4AQl4jded9bg/edit#heading=h.t8lhnqp89cot
    const _current = TaskingTypeDetermination.getCurrentDatetime();
    const referenceDate = getDetermineDeadlineBaseDate(_current);

    const urgentDeadlineTime = getUrgentDeadlineTime(_current, referenceDate);

    if (isBefore(targetDate, urgentDeadlineTime)) {
      return TaskingType.Urgent;
    }
    return TaskingType.Regular;
  }
}
