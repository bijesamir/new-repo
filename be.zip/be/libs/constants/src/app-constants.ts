export const AppConstants = {
  DEFAULT_VERSION: '1',
};

export type AppConstants = (typeof AppConstants)[keyof typeof AppConstants];
