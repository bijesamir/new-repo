import { TaskingStatus } from './tasking-status';

// Synchronization is required when there is a change on the SCS side
export const ScsOrderStatus = {
  PreRegistration: 1,
  WaitForPlanning: 2,
  TentativePlanned: 3,
  MissionPlanFixed: 4,
  UplinkComplete: 5,
  DownlinkComplete: 6,
  SLCCreated: 8,
  CEOSCreated: 9,
  GRDCreated: 10,
  SICDCreated: 11,
  SLCFailed: 72,
  CEOSFailed: 73,
  GRDFailed: 74,
  SICDFailed: 75,
  UploadFailed: 76,
  Accomplished: 7,
  Canceled: 99,
};

export type ScsOrderStatus =
  (typeof ScsOrderStatus)[keyof typeof ScsOrderStatus];

export const ScsOrderStatusValues = Object.values(ScsOrderStatus);

export const shouldUpdateScsOrderStatus = (status: TaskingStatus) => {
  return [TaskingStatus.Ordered, TaskingStatus.Canceled].includes(status);
};

export const toScsOrderStatus = (taskingStatus: TaskingStatus) => {
  switch (taskingStatus) {
    case TaskingStatus.Ordered:
      return ScsOrderStatus.WaitForPlanning;
    case TaskingStatus.Canceled:
      return ScsOrderStatus.Canceled;
    default:
      throw new Error('Corresponding status is not defined');
  }
};
