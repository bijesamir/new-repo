import { add } from 'date-fns';

export const CatalogDelayKind = {
  PERMANENT: -1,
  NO_DELAY: 0,
  THIRTY_DAYS: 1,
  ONE_YEAR: 12,
};

export type CatalogDelayKind =
  (typeof CatalogDelayKind)[keyof typeof CatalogDelayKind];

export const CatalogDelayKindAllValues = Object.values(CatalogDelayKind);

export const getPublicationStartByDelayKind = (
  date: Date,
  delayKind: CatalogDelayKind,
) => {
  if (!date) {
    throw new Error('date is null');
  }

  switch (delayKind) {
    case CatalogDelayKind.NO_DELAY:
      return date;
    case CatalogDelayKind.THIRTY_DAYS:
      return add(date, { days: 30 });
    case CatalogDelayKind.ONE_YEAR:
      return add(date, { years: 1 });
    case CatalogDelayKind.PERMANENT:
      return null;
    default:
      throw new Error(`unknown catalog delay kind: ${delayKind}`);
  }
};
