export const ProcessingStatus = {
  New: 'new',
  Completed: 'completed',
  Failed: 'failed',
};

export type ProcessingStatus =
  (typeof ProcessingStatus)[keyof typeof ProcessingStatus];

export const ProcessingStatusAllValues = Object.values(ProcessingStatus);

export const ProccessingStatusPubsubSelectableValues =
  ProcessingStatusAllValues.filter((x) =>
    [
      ProcessingStatus.New,
      ProcessingStatus.Completed,
      ProcessingStatus.Failed,
    ].includes(x),
  );
