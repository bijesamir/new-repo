// https://docs.google.com/spreadsheets/d/1jMee9c-OVL1ODnCPY7CATyr-NALmLbXjLKW-288OIR8/edit#gid=552207528&range=A10
export const LookingDirection = {
  Both: 0,
  Left: 1,
  Right: 2,
};

export const LookingDirectionParamName = {
  Both: 'both',
  Left: 'left',
  Right: 'right',
};

export type LookingDirection =
  (typeof LookingDirection)[keyof typeof LookingDirection];

export type LookingDirectionParamName =
  (typeof LookingDirectionParamName)[keyof typeof LookingDirectionParamName];

export const AllLookingDirectionValues = Object.values(LookingDirection);
export const AllLookingDirectionParamNameValues = Object.values(
  LookingDirectionParamName,
);

export const LookingDirectionValues = AllLookingDirectionValues.filter(
  (x) => x != LookingDirection.Both,
);

export const getLookingDirectionString = (v: LookingDirection) => {
  switch (v) {
    case LookingDirection.Left:
      return 'Left';
    case LookingDirection.Right:
      return 'Right';
  }
  return '';
};

export const getLookingDirectionParamName = (
  v: LookingDirection,
): LookingDirectionParamName => {
  switch (v) {
    case LookingDirection.Both:
      return LookingDirectionParamName.Both;
    case LookingDirection.Left:
      return LookingDirectionParamName.Left;
    case LookingDirection.Right:
      return LookingDirectionParamName.Right;
  }
  return '';
};
export const getLookingDirection = (
  v: LookingDirectionParamName,
): LookingDirection => {
  switch (v) {
    case LookingDirectionParamName.Both:
      return LookingDirection.Both;
    case LookingDirectionParamName.Left:
      return LookingDirection.Left;
    case LookingDirectionParamName.Right:
      return LookingDirection.Right;
  }
  return undefined;
};
