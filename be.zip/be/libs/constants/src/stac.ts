export enum StacCollection {
  STRIX = 'StriX',
}

export enum StacLicense {
  Proprietary = 'proprietary',
}

export enum StacProviderRole {
  Licensor = 'licensor',
  Producer = 'producer',
}

export enum StacInstrumentName {
  StrixSAR = 'StriX-SAR',
}

export enum StacConstellation {
  Strix = 'StriX',
}

export const StacProvider = {
  synspective: {
    name: 'Synspective Inc.',
    roles: [StacProviderRole.Licensor, StacProviderRole.Producer],
    url: 'https://synspective.com',
  },
};

export const StacInstrument = {
  strixsar: [StacInstrumentName.StrixSAR],
};
