export const DataSourceType = {
  NEW: 0,
  ARCHIVE: 1,
};

export type DataSourceType =
  (typeof DataSourceType)[keyof typeof DataSourceType];

export const DataSourceTypeAllVales = Object.values(DataSourceType);

export const getDataSourceTypeString = (v: DataSourceType) => {
  switch (v) {
    case DataSourceType.NEW:
      return 'New';
    case DataSourceType.ARCHIVE:
      return 'Archive';
  }
  return '';
};
