export const TaskingStatus = {
  PreCreditCheck: 'pre-credit-check',
  PreOrder: 'pre-order',
  Ordered: 'ordered',
  OrderFixed: 'order-fixed',
  ObservationCompleted: 'observation-completed',
  Canceled: 'canceled',
  Rejected: 'rejected',
  ObservationFailed: 'observation-failed',
};

export const UnrecordedTaskingStatus = {
  RegisterFailed: 'register-failed',
};

export type TaskingStatus = (typeof TaskingStatus)[keyof typeof TaskingStatus];

export type UnrecordedTaskingStatus =
  (typeof UnrecordedTaskingStatus)[keyof typeof UnrecordedTaskingStatus];

export type TaskingOperationStatus = TaskingStatus | UnrecordedTaskingStatus;

export const TaskingStatusAllValues = Object.values(TaskingStatus);

export const TaskingStatusSelectableValues = TaskingStatusAllValues.filter(
  (x) =>
    [
      TaskingStatus.Ordered,
      TaskingStatus.Canceled,
      TaskingStatus.ObservationFailed,
    ].includes(x),
);

export const TaskingStatusPubsubSelectableValues =
  TaskingStatusAllValues.filter((x) =>
    [
      TaskingStatus.Rejected,
      TaskingStatus.Ordered,
      TaskingStatus.OrderFixed,
      TaskingStatus.ObservationCompleted,
      TaskingStatus.ObservationFailed,
      TaskingStatus.Canceled,
    ].includes(x),
  );

export const NoNeedToUpdateStatus = TaskingStatusAllValues.filter((x) =>
  [
    TaskingStatus.OrderFixed,
    TaskingStatus.ObservationCompleted,
    TaskingStatus.ObservationFailed,
  ].includes(x),
);

/**
 * Verify if the target tasking_info is updatable to the specified status
 * @param before status before update
 * @param after status after update
 * @returns {boolean} true if the target tasking_info is updatable to the specified status
 */
export const enableChangeTaskingStatus = (
  before: TaskingStatus,
  after: TaskingStatus,
) => {
  switch (after) {
    case TaskingStatus.PreOrder:
      return TaskingStatus.PreCreditCheck === before;
    case TaskingStatus.Ordered:
      return TaskingStatus.PreOrder === before;
    case TaskingStatus.OrderFixed:
      return TaskingStatus.Ordered === before;
    case TaskingStatus.ObservationFailed:
      return [
        TaskingStatus.OrderFixed,
        TaskingStatus.ObservationCompleted,
      ].includes(before);
    case TaskingStatus.Rejected:
      return TaskingStatus.Ordered === before;
    case TaskingStatus.Canceled:
      return [
        TaskingStatus.PreCreditCheck,
        TaskingStatus.PreOrder,
        TaskingStatus.Ordered,
        TaskingStatus.OrderFixed,
      ].includes(before);
    case TaskingStatus.ObservationCompleted:
      return TaskingStatus.OrderFixed === before;
    default:
      return false;
  }
};

/**
 * Returns true if the argument status is a status that allows altitude update.
 * @param status Tasking Status
 * @returns {boolean} true if the argument status is a status that allows altitude update.
 */
export const enableChangeAltitude = (status: TaskingStatus) => {
  return [
    TaskingStatus.PreCreditCheck,
    TaskingStatus.PreOrder,
    TaskingStatus.Ordered,
  ].includes(status);
};
