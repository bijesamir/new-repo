export const PolarizationType = {
  VV: 1,
};
export const PolarizationTypeParamName = {
  VV: 'VV',
};

export type PolarizationType =
  (typeof PolarizationType)[keyof typeof PolarizationType];
export type PolarizationTypeParamName =
  (typeof PolarizationTypeParamName)[keyof typeof PolarizationTypeParamName];

export const AllPolarizationTypeValues = Object.values(PolarizationType);
export const AllPolarizationTypeParamNameValues = Object.values(
  PolarizationTypeParamName,
);

export const PolarizationTypeValues = AllPolarizationTypeValues;
export const PolarizationTypeParamNameValues =
  AllPolarizationTypeParamNameValues;

export const getPolarizationTypeParamName = (
  v: PolarizationType,
): PolarizationTypeParamName => {
  switch (v) {
    case PolarizationType.VV:
      return PolarizationTypeParamName.VV;
  }
  return '';
};

export const getPolarizationType = (
  v: PolarizationTypeParamName,
): PolarizationType => {
  switch (v) {
    case PolarizationTypeParamName.VV:
      return PolarizationType.VV;
  }
  return undefined;
};
