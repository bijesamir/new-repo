export const AuthStrategy = {
  // TODO: to be deprecated
  CitadelCookie: 'citadel-cookie',
  CitadelOAuth: 'citadel-oauth',
  CitadelApiKey: 'citadel-apikey',
};

export type AuthStrategy = (typeof AuthStrategy)[keyof typeof AuthStrategy];
