export const IrisAccessControlType = {
  /**
   * Admin<br/>
   * A value that indicates that a user who is permitted to perform all operations on iris can access.
   */
  Admin: 'admin',
  /**
   * Tasking<br/>
   * A value that indicates that it is accessible to users who are only permitted to perform Tasking-related operations.
   */
  Tasking: 'tasking',
  /**
   * TaskingDownload<br/>
   * A value that indicates that it is accessible to users who are only permitted to perform product data downlod operation for products acquired by their tasking.
   */
  TaskingDownload: 'tasking-download',
  /**
   * Archive<br/>
   * A value that indicates that it is accessible to users who are only permitted to perform Archive-related operations.
   */
  Archive: 'archive',

  Internal: 'internal',

  Collaborator: 'collaborator',
};

export type IrisAccessControlType =
  (typeof IrisAccessControlType)[keyof typeof IrisAccessControlType];
