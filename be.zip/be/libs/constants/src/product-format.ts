export const ProductFormat = {
  GRD_GEOTIFF: 1,
  SLC_SICD: 2,
  SLC_CEOS: 3,
  ORT_GEOTIFF: 4,
};

export type ProductFormat = (typeof ProductFormat)[keyof typeof ProductFormat];

export const ProductFormatValues = Object.values(ProductFormat);

export const getProductFormatLabel = (v: ProductFormat) => {
  switch (v) {
    case ProductFormat.GRD_GEOTIFF:
      return 'GRD GeoTiff';
    case ProductFormat.SLC_SICD:
      return 'SLC SICD';
    case ProductFormat.SLC_CEOS:
      return 'SLC CEOS';
    case ProductFormat.ORT_GEOTIFF:
      return 'ORT GeoTiff';
  }
};

export const getProductFormatLabelSplit = (v: ProductFormat) => {
  return getProductFormatLabel(v).split(' ');
};

export const getProductFormatLabelShort = (v: ProductFormat) => {
  const productFormatSplit = getProductFormatLabelSplit(v);
  const productFormatShort =
    ProductFormat.GRD_GEOTIFF === v || ProductFormat.ORT_GEOTIFF === v
      ? productFormatSplit[0]
      : productFormatSplit[1];

  return productFormatShort;
};

export const getProductFormatOutput = (v: ProductFormat) => {
  switch (v) {
    case ProductFormat.GRD_GEOTIFF:
      return 'GRD_Geotiff';
    case ProductFormat.SLC_SICD:
      return 'SLC_SICD';
    case ProductFormat.SLC_CEOS:
      return 'SLC_CEOS';
    case ProductFormat.ORT_GEOTIFF:
      return 'ORT_Geotiff';
  }
};

export type ProductFormatKey = keyof typeof ProductFormat;
export const ProductFormatKeys = Object.keys(ProductFormat);
