// https://docs.google.com/spreadsheets/d/1jMee9c-OVL1ODnCPY7CATyr-NALmLbXjLKW-288OIR8/edit#gid=552207528&range=A5
export const ImagingMode = {
  Stripmap: 1,
  SlidingSpotlight: 2,
  StaringSpotlight1: 3,
  StaringSpotlight2: 4, // Reserve for future use
  StaringSpotlight3: 5, // Reserve for future use
  StaringSpotlight4: 6, // Reserve for future use
};
export const ImagingModeParamName = {
  Stripmap: 'stripmap',
  SlidingSpotlight: 'sliding_spotlight',
  StaringSpotlight1: 'staring_spotlight1',
  StaringSpotlight2: 'staring_spotlight2', // Reserve for future use
  StaringSpotlight3: 'staring_spotlight3', // Reserve for future use
  StaringSpotlight4: 'staring_spotlight4', // Reserve for future use
};

export type ImagingMode = (typeof ImagingMode)[keyof typeof ImagingMode];
export type ImagingModeParamName =
  (typeof ImagingModeParamName)[keyof typeof ImagingModeParamName];

export const ImagingModeAllValues = Object.values(ImagingMode);
export const ImagingModeParamNameAllValues =
  Object.values(ImagingModeParamName);

export const ImagingModeSingleSceneValues = Object.values(ImagingMode).filter(
  (v) => v !== ImagingMode.Stripmap,
);
export const ImagingModeParamNameSingleSceneValues = Object.values(
  ImagingModeParamName,
).filter((v) => v !== ImagingModeParamName.Stripmap);

export const getImagingModeLabel = (v: ImagingMode) => {
  switch (v) {
    case ImagingMode.Stripmap:
      return 'SM';
    case ImagingMode.SlidingSpotlight:
      return 'SL';
    case ImagingMode.StaringSpotlight1:
      return 'ST1';
    case ImagingMode.StaringSpotlight2:
      return 'ST2';
    case ImagingMode.StaringSpotlight3:
      return 'ST3';
    case ImagingMode.StaringSpotlight4:
      return 'ST4';
  }
};

export const getImagingModeString = (v: ImagingMode) => {
  switch (v) {
    case ImagingMode.Stripmap:
      return 'Stripmap';
    case ImagingMode.SlidingSpotlight:
      return 'Sliding Spotlight';
    case ImagingMode.StaringSpotlight1:
      return 'Staring Spotlight1 (0.9x0.5)';
    case ImagingMode.StaringSpotlight2:
      return 'Staring Spotlight2 (0.9x0.25)';
    case ImagingMode.StaringSpotlight3:
      return 'Staring Spotlight3 (0.46x0.5)';
    case ImagingMode.StaringSpotlight4:
      return 'Staring Spotlight3 (0.46x0.25)';
  }
  return '';
};

export const getImagingModeParamName = (
  v: ImagingMode,
): ImagingModeParamName => {
  switch (v) {
    case ImagingMode.Stripmap:
      return ImagingModeParamName.Stripmap;
    case ImagingMode.SlidingSpotlight:
      return ImagingModeParamName.SlidingSpotlight;
    case ImagingMode.StaringSpotlight1:
      return ImagingModeParamName.StaringSpotlight1;
    case ImagingMode.StaringSpotlight2:
      return ImagingModeParamName.StaringSpotlight2;
    case ImagingMode.StaringSpotlight3:
      return ImagingModeParamName.StaringSpotlight3;
    case ImagingMode.StaringSpotlight4:
      return ImagingModeParamName.StaringSpotlight4;
  }
  return '';
};

export const getImagingMode = (v: ImagingModeParamName): ImagingMode => {
  switch (v) {
    case ImagingModeParamName.Stripmap:
      return ImagingMode.Stripmap;
    case ImagingModeParamName.SlidingSpotlight:
      return ImagingMode.SlidingSpotlight;
    case ImagingModeParamName.StaringSpotlight1:
      return ImagingMode.StaringSpotlight1;
    case ImagingModeParamName.StaringSpotlight2:
      return ImagingMode.StaringSpotlight2;
    case ImagingModeParamName.StaringSpotlight3:
      return ImagingMode.StaringSpotlight3;
    case ImagingModeParamName.StaringSpotlight4:
      return ImagingMode.StaringSpotlight4;
  }
  return undefined;
};
