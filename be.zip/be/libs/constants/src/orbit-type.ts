export const OrbitType = {
  OB: 1, // on-board-computer
  PR: 2, // precise
};

export type OrbitType = (typeof OrbitType)[keyof typeof OrbitType];

export const OrbitTypeAllValues = Object.values(OrbitType);
