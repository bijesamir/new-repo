export const OrderStatus = {
  New: 'new',
  Completed: 'completed',
  Failed: 'failed',
};

export type OrderStatus = (typeof OrderStatus)[keyof typeof OrderStatus];

export const OrderStatusAllValues = Object.values(OrderStatus);
