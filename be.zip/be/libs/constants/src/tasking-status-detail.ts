export const TaskingStatusDetail = {
  None: 0,
  CanceledByOrderer: 1,
  CanceledByOverriden: 2,
  CanceledByProblem: 3,
};

export type TaskingStatusDetail =
  (typeof TaskingStatusDetail)[keyof typeof TaskingStatusDetail];

export const TaskingStatusDetailAllValues = Object.values(TaskingStatusDetail);

export const taskingStatusDetailToString = (
  taskingStatusDetail: TaskingStatusDetail,
): string => {
  switch (taskingStatusDetail) {
    case TaskingStatusDetail.CanceledByOrderer:
      return 'Canceled by ordering person';
    case TaskingStatusDetail.CanceledByOverriden:
      return 'Canceled due to conflict with other orders';
    case TaskingStatusDetail.CanceledByProblem:
      return 'Canceled by operators due to operational restriction';
    default:
      return '';
  }
};
