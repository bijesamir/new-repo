export const DeliveryMethod = {
  DEFAULT: 0,
  FTP: 1,
  SFTP: 2,
};

export type DeliveryMethod =
  (typeof DeliveryMethod)[keyof typeof DeliveryMethod];

export const DeliveryMethodAllValues = Object.values(DeliveryMethod);
