export const TaskingPriorityKind = {
  STANDARD: 0,
  HIGH: 1,
};

export type TaskingPriorityKind =
  (typeof TaskingPriorityKind)[keyof typeof TaskingPriorityKind];

export const TaskingPriorityKindAllValues = Object.values(TaskingPriorityKind);
