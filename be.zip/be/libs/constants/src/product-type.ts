import { ProductFormat } from './product-format';
import { ResolutionMode } from './resolution-mode';

export const ProductType = {
  GRD_GEOTIFF: 'GRD_GEOTIFF',
  SLC_SICD: 'SLC_SICD',
  SLC_CEOS: 'SLC_CEOS',
  SR_GRD_GEOTIFF: 'SR-GRD_GEOTIFF',
  ORT_GEOTIFF: 'ORT_GEOTIFF',
};

export type ProductType = (typeof ProductType)[keyof typeof ProductType];

export const ProductTypeValues = Object.values(ProductType);

export const getProductType = (
  format: ProductFormat,
  resolution: ResolutionMode,
): ProductType => {
  if (resolution === ResolutionMode.normal) {
    switch (format) {
      case ProductFormat.GRD_GEOTIFF:
        return ProductType.GRD_GEOTIFF;
      case ProductFormat.SLC_SICD:
        return ProductType.SLC_SICD;
      case ProductFormat.SLC_CEOS:
        return ProductType.SLC_CEOS;
      case ProductFormat.ORT_GEOTIFF:
        return ProductType.ORT_GEOTIFF;
    }
  } else if (resolution === ResolutionMode.SR) {
    switch (format) {
      case ProductFormat.GRD_GEOTIFF:
        return ProductType.SR_GRD_GEOTIFF;
    }
  }
  return '';
};

export const getProductFormat = (v: ProductType): ProductFormat => {
  switch (v) {
    case ProductType.GRD_GEOTIFF:
    case ProductType.SR_GRD_GEOTIFF:
      return ProductFormat.GRD_GEOTIFF;
    case ProductType.SLC_SICD:
      return ProductFormat.SLC_SICD;
    case ProductType.SLC_CEOS:
      return ProductFormat.SLC_CEOS;
    case ProductType.ORT_GEOTIFF:
      return ProductFormat.ORT_GEOTIFF;
  }
  return undefined;
};

export const getResolutionMode = (v: ProductType): ResolutionMode => {
  switch (v) {
    case ProductType.GRD_GEOTIFF:
    case ProductType.SLC_SICD:
    case ProductType.SLC_CEOS:
    case ProductType.ORT_GEOTIFF:
      return ResolutionMode.normal;
    case ProductType.SR_GRD_GEOTIFF:
      return ResolutionMode.SR;
  }
  return undefined;
};
