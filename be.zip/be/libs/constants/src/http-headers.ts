export const HEADER_REQUEST_ID = 'x-iris-request-id';
export const HEADER_REQUEST_INFO = 'x-iris-request-info';
export const HEADER_USER_INFO = 'x-iris-user-info';
