// https://docs.google.com/spreadsheets/d/1jMee9c-OVL1ODnCPY7CATyr-NALmLbXjLKW-288OIR8/edit#gid=552207528&range=A7
export const FlightDirection = {
  Both: 0,
  Ascending: 1,
  Descending: 2,
};

export const FlightDirectionParamName = {
  Both: 'both',
  Ascending: 'ascending',
  Descending: 'descending',
};

export type FlightDirection =
  (typeof FlightDirection)[keyof typeof FlightDirection];

export type FlightDirectionParamName =
  (typeof FlightDirectionParamName)[keyof typeof FlightDirectionParamName];

export const AllFlightDirectionValues = Object.values(FlightDirection);
export const AllFlightDirectionParamNameValues = Object.values(
  FlightDirectionParamName,
);

export const FlightDirectionValues = AllFlightDirectionValues.filter(
  (x) => x != FlightDirection.Both,
);

export const getFlightDirectionString = (v: FlightDirection) => {
  switch (v) {
    case FlightDirection.Ascending:
      return 'Ascending';
    case FlightDirection.Descending:
      return 'Descending';
  }
  return '';
};

export const getFlightDirectionParamName = (
  v: FlightDirection,
): FlightDirectionParamName => {
  switch (v) {
    case FlightDirection.Ascending:
      return FlightDirectionParamName.Ascending;
    case FlightDirection.Descending:
      return FlightDirectionParamName.Descending;
  }
  return '';
};

export const getFlightDirection = (
  v: FlightDirectionParamName,
): FlightDirection => {
  switch (v) {
    case FlightDirectionParamName.Both:
      return FlightDirection.Both;
    case FlightDirectionParamName.Ascending:
      return FlightDirection.Ascending;
    case FlightDirectionParamName.Descending:
      return FlightDirection.Descending;
  }
  return null;
};
