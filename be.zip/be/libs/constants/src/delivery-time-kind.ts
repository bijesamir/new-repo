export const DeliveryTimeKind = {
  STANDARD: 0,
  RUSH: 1,
};

export type DeliveryTimeKind =
  (typeof DeliveryTimeKind)[keyof typeof DeliveryTimeKind];

export const DeliveryTimeKindAllValues = Object.values(DeliveryTimeKind);
