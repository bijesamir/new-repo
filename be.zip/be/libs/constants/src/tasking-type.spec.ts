import { TaskingType, TaskingTypeDetermination } from './tasking-type';

import { parseJSON } from 'date-fns';

describe('TaskingType', () => {
  let mockGetCurrentDatetime;
  describe('1 Current time：5/1 3:00:00 - 5/1 14:59:59 UTC (5/1 12:00:00 - 5/1 23:59:59 JST)', () => {
    describe('1-1 Current time：5/1 3:00:00 UTC (5/1 12:00:00 JST)', () => {
      beforeAll(() => {
        mockGetCurrentDatetime = jest
          .fn()
          .mockReturnValue(parseJSON('2023-05-01T03:00:00.000Z'));
        TaskingTypeDetermination.getCurrentDatetime = mockGetCurrentDatetime;
      });
      afterAll(() => {
        mockGetCurrentDatetime.mockReset();
      });
      it('5/2 2:59:59 UTC (5/2 11:59:59 JST) -> urgent', () => {
        const result = TaskingTypeDetermination.exec(
          parseJSON('2023-05-02T02:59:59.999Z'),
        );
        expect(mockGetCurrentDatetime).toBeCalledTimes(1);
        expect(result).toEqual(TaskingType.Urgent);
      });
      it('5/2 3:00:00 UTC (5/2 12:00:00 JST) -> regular', () => {
        const result = TaskingTypeDetermination.exec(
          parseJSON('2023-05-02T03:00:00.000Z'),
        );
        expect(mockGetCurrentDatetime).toBeCalledTimes(2);
        expect(result).toEqual(TaskingType.Regular);
      });
    });
    describe('1-2 Current time：5/1 14:59:59 UTC (5/1 23:59:59 JST)', () => {
      beforeAll(() => {
        mockGetCurrentDatetime = jest
          .fn()
          .mockReturnValue(parseJSON('2023-05-01T14:59:59.999Z'));
        TaskingTypeDetermination.getCurrentDatetime = mockGetCurrentDatetime;
      });
      afterAll(() => {
        mockGetCurrentDatetime.mockReset();
      });
      it('5/2 2:59:59 UTC (5/2 11:59:59 JST) -> urgent', () => {
        const result = TaskingTypeDetermination.exec(
          parseJSON('2023-05-02T02:59:59.999Z'),
        );
        expect(mockGetCurrentDatetime).toBeCalledTimes(1);
        expect(result).toEqual(TaskingType.Urgent);
      });
      it('5/2 3:00:00 UTC (5/2 12:00:00 JST) -> regular', () => {
        const result = TaskingTypeDetermination.exec(
          parseJSON('2023-05-02T03:00:00.000Z'),
        );
        expect(mockGetCurrentDatetime).toBeCalledTimes(2);
        expect(result).toEqual(TaskingType.Regular);
      });
    });
  });

  describe('2 Current time：5/1 15:00:00 - 5/2 2:59:59 UTC (5/2 00:00:00 - 5/2 11:59:59 JST)', () => {
    describe('2-1 Current time：5/1 15:00:00', () => {
      beforeAll(() => {
        mockGetCurrentDatetime = jest
          .fn()
          .mockReturnValue(parseJSON('2023-05-01T15:00:00.000Z'));
        TaskingTypeDetermination.getCurrentDatetime = mockGetCurrentDatetime;
      });
      afterAll(() => {
        mockGetCurrentDatetime.mockReset();
      });
      it('5/2 14:59:59 UTC (5/2 23:59:59 JST) -> urgent', () => {
        const result = TaskingTypeDetermination.exec(
          parseJSON('2023-05-02T14:59:59.999Z'),
        );
        expect(mockGetCurrentDatetime).toBeCalledTimes(1);
        expect(result).toEqual(TaskingType.Urgent);
      });
      it('5/2 15:00:00 UTC (5/3 00:00:00 JST) -> regular', () => {
        const result = TaskingTypeDetermination.exec(
          parseJSON('2023-05-02T15:00:00.000Z'),
        );
        expect(mockGetCurrentDatetime).toBeCalledTimes(2);
        expect(result).toEqual(TaskingType.Regular);
      });
    });

    describe('2-2 Current time：5/1 23:59:59', () => {
      beforeAll(() => {
        mockGetCurrentDatetime = jest
          .fn()
          .mockReturnValue(parseJSON('2023-05-01T23:59:59.999Z'));
        TaskingTypeDetermination.getCurrentDatetime = mockGetCurrentDatetime;
      });
      afterAll(() => {
        mockGetCurrentDatetime.mockReset();
      });
      it('5/2 14:59:59 UTC (5/2 23:59:59 JST) -> urgent', () => {
        const result = TaskingTypeDetermination.exec(
          parseJSON('2023-05-02T14:59:59.999Z'),
        );
        expect(mockGetCurrentDatetime).toBeCalledTimes(1);
        expect(result).toEqual(TaskingType.Urgent);
      });
      it('5/2 15:00:00 UTC (5/3 00:00:00 JST) -> regular', () => {
        const result = TaskingTypeDetermination.exec(
          parseJSON('2023-05-02T15:00:00.000Z'),
        );
        expect(mockGetCurrentDatetime).toBeCalledTimes(2);
        expect(result).toEqual(TaskingType.Regular);
      });
    });

    describe('2-3 Current time：5/2 00:00:00', () => {
      beforeAll(() => {
        mockGetCurrentDatetime = jest
          .fn()
          .mockReturnValue(parseJSON('2023-05-02T00:00:00.000Z'));
        TaskingTypeDetermination.getCurrentDatetime = mockGetCurrentDatetime;
      });
      afterAll(() => {
        mockGetCurrentDatetime.mockReset();
      });
      it('5/2 14:59:59 UTC (5/2 23:59:59 JST) -> urgent', () => {
        const result = TaskingTypeDetermination.exec(
          parseJSON('2023-05-02T14:59:59.999Z'),
        );
        expect(mockGetCurrentDatetime).toBeCalledTimes(1);
        expect(result).toEqual(TaskingType.Urgent);
      });
      it('5/2 15:00:00 UTC (5/3 00:00:00 JST) -> regular', () => {
        const result = TaskingTypeDetermination.exec(
          parseJSON('2023-05-02T15:00:00.000Z'),
        );
        expect(mockGetCurrentDatetime).toBeCalledTimes(2);
        expect(result).toEqual(TaskingType.Regular);
      });
    });

    describe('2-4 Current time：5/2 02:59:59', () => {
      beforeAll(() => {
        mockGetCurrentDatetime = jest
          .fn()
          .mockReturnValue(parseJSON('2023-05-02T02:59:59.999Z'));
        TaskingTypeDetermination.getCurrentDatetime = mockGetCurrentDatetime;
      });
      afterAll(() => {
        mockGetCurrentDatetime.mockReset();
      });
      it('5/2 14:59:59 UTC (5/2 23:59:59 JST) -> urgent', () => {
        const result = TaskingTypeDetermination.exec(
          parseJSON('2023-05-02T14:59:59.999Z'),
        );
        expect(mockGetCurrentDatetime).toBeCalledTimes(1);
        expect(result).toEqual(TaskingType.Urgent);
      });
      it('5/2 15:00:00 UTC (5/3 00:00:00 JST) -> regular', () => {
        const result = TaskingTypeDetermination.exec(
          parseJSON('2023-05-02T15:00:00.000Z'),
        );
        expect(mockGetCurrentDatetime).toBeCalledTimes(2);
        expect(result).toEqual(TaskingType.Regular);
      });
    });
  });
});
