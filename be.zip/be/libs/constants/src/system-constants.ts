export const SystemUser = {
  DPS_SYSTEM: 'dps-system',
  SCS_SYSTEM: 'scs-system',
  PSC_SYSTEM: 'psc-system', // PubSub-Center
  ARCHIVE_SYSTEM: 'archive-system',
};

export const SystemSetting = {
  PAGINATION_MAX_LIMIT: 999,
};

export type SystemUser = (typeof SystemUser)[keyof typeof SystemUser];

export const SystemOrganization = {
  NO_ORGANIZATION: -1,
};

export type SystemOrganization =
  (typeof SystemOrganization)[keyof typeof SystemOrganization];

export const SystemContract = {
  NO_CONTRACT: -1,
};

export type SystemContract =
  (typeof SystemContract)[keyof typeof SystemContract];

export type SystemSetting = (typeof SystemSetting)[keyof typeof SystemSetting];
