export const DeliveryRequestStatus = {
  Prepared: 'prepared',
  Failed: 'failed',
  Completed: 'completed',
};

export type DeliveryRequestStatus =
  (typeof DeliveryRequestStatus)[keyof typeof DeliveryRequestStatus];

export const DeliveryRequestStatusAllValues = Object.values(
  DeliveryRequestStatus,
);
