import { plainToInstance } from 'class-transformer';
import { DeliveryRequestStatus } from './delivery-request-status';
import { ProcessingStatus } from './processing-status';
import {
  TaskingOperationStatus,
  TaskingStatus,
  UnrecordedTaskingStatus,
} from './tasking-status';
import * as ejs from 'ejs';
import {
  TaskingStatusDetail,
  taskingStatusDetailToString,
} from './tasking-status-detail';
import { OrderStatus } from './order-status';
import { ImagingMode, getImagingModeString } from './imaging-mode';
import { FlightDirection, getFlightDirectionString } from './flight-direction';
import {
  LookingDirection,
  getLookingDirectionString,
} from './looking-direction';
import { OmitType } from '@nestjs/swagger';
import { formatNotificationDate } from '@iris-lib/utils';
import { DataSourceType, getDataSourceTypeString } from './data-source-type';

export class NotificationProductParam {
  filename?: string;
  productLabel?: string;
  link?: string;
}

export class NotificationTaskingRegistrationParam {}

export class NotificationParamItem {
  scsOrderCode?: string;
  archiveReqNo?: string;
  updatedAt?: Date;
  obsStart?: Date;
  reason?: TaskingStatusDetail;
  files?: NotificationProductParam[];
  aoiName?: string;
  satellite?: string;
  imagingMode?: ImagingMode;
  flightDirection?: FlightDirection;
  lookingDirection?: LookingDirection;
  offnadirAngle?: number;
  taskingType?: number;
  itemId?: string;
  dataSourceType?: DataSourceType;
  productLabel?: string;
  expiredAt?: Date;
}

export class NotificationParam {
  env: string;
  taskMgmtLink?: string;
  items?: NotificationParamItem[];
  reqNo?: string;
  orderUrl?: string;
}

class NotificationText extends OmitType(NotificationParam, ['items'] as const) {
  items?: NotificationTextItem[];
}

class NotificationTextItem extends OmitType(NotificationParamItem, [
  'updatedAt',
  'obsStart',
  'reason',
  'imagingMode',
  'flightDirection',
  'lookingDirection',
  'offnadirAngle',
  'taskingType',
  'dataSourceType',
  'expiredAt',
] as const) {
  updatedAtUtc?: string;
  observationStartUtc?: string;
  observationStartJst?: string;
  reason?: string;
  imagingMode?: string;
  flightDirection?: string;
  lookingDirection?: string;
  offnadirAngle?: string;
  taskingType?: string;
  dataSourceType?: string;
  expiredAt?: string;
}

export const NotificationType = {
  Reserved: 0,
  TaskCompleted: 1,
  Invoice: 2,
  Cancel: 3,
  Error: 4,
};

export type NotifiableStatus =
  | TaskingOperationStatus
  | DeliveryRequestStatus
  | ProcessingStatus
  | OrderStatus;

// https://app.diagrams.net/#G1wQ5O3-4FaLziAag8HPg90dR0O0BwJylo
export const NotifiableStatusList: NotifiableStatus[] = [
  TaskingStatus.PreCreditCheck,
  TaskingStatus.Ordered,
  TaskingStatus.Canceled,
  TaskingStatus.ObservationFailed,
  ProcessingStatus.Failed,
  DeliveryRequestStatus.Completed,
  DeliveryRequestStatus.Failed,
];

export type NotificationType =
  (typeof NotificationType)[keyof typeof NotificationType];

export const NotificationTypeAllValues = Object.values(NotificationType);

export class NotificationTemplate {
  allowStatus: NotifiableStatus[];
  type: NotificationType;
  title: string;
  text: string;
}

export class NotificationContents extends NotificationTemplate {}

// TODO データベースで管理するようにしても良いかも
export const NotificationTemplates: NotificationTemplate[] = [
  {
    allowStatus: [TaskingStatus.Ordered],
    type: NotificationType.Reserved,
    title:
      '<% if(param.env !== "production"){ %> [<%= param.env %>] <% } %>[Synspective] Notice of order registration',
    text: `Thank you for ordering data provision service of Synspective's SAR satellite StriX.
The following order of new acquisition has been registered.
この度は株式会社SynspectiveのSAR衛星StriXのデータ提供サービスをご注文いただき誠にありがとうございます。
以下の新規撮像が登録されました事をお知らせいたします。<% param.items.forEach((x) => { %>
--
OrderCode: <%= x.scsOrderCode %>
AOI name: <%= x.aoiName %>
Observation start [UTC]: <%= x.observationStartUtc %>
Observation start [JST]: <%= x.observationStartJst %>
Satellite: <%= x.satellite %>
Imaging mode: <%= x.imagingMode %>
Flight direction: <%= x.flightDirection %>
Looking direction: <%= x.lookingDirection %>
Offnadir angle: <%= x.offnadirAngle %>
Tasking type: <%= x.taskingType %>
<% }) %>
You can check information about your new acquisitions in the following URL.
撮像状況は下記よりご確認いただけます。
<%= param.taskMgmtLink %>

*This message was automatically generated. Please do not reply to this message. 
本メールは自動で作成されています。ご返信いただかないようお願いいたします。

Best regards,

Synspective Inc./株式会社Synspective
Miyoshi 3-10-3, Koto-ku, Tokyo, Japan`,
  },
  {
    allowStatus: [TaskingStatus.Canceled, TaskingStatus.Rejected],
    type: NotificationType.Cancel,
    title:
      '<% if(param.env !== "production"){ %> [<%= param.env %>] <% } %>[Synspective] Notice of order cancellation (<%= param.items[0].scsOrderCode %>)',
    text: `Thank you for ordering data provision service of Synspective's SAR satellite StriX.
The following order of new acquisition has been cancelled.
この度は株式会社SynspectiveのSAR衛星StriXのデータ提供サービスをご注文いただき誠にありがとうございます。
以下の新規撮像がキャンセルされました事をお知らせいたします。

OrderCode: <%= param.items[0].scsOrderCode %>
AOI name: <%= param.items[0].aoiName %>
Observation start [UTC]: <%= param.items[0].observationStartUtc %>
Observation start [JST]: <%= param.items[0].observationStartJst %>
Reason: <%= param.items[0].reason %>

You can check information about your new acquisitions in the following URL.
撮像状況は下記よりご確認いただけます。
<%= param.taskMgmtLink %>

*This message was automatically generated. Please do not reply to this message.
本メールは自動で作成されています。ご返信いただかないようお願いいたします。

Best regards,

Synspective Inc./株式会社Synspective
Miyoshi 3-10-3, Koto-ku, Tokyo, Japan`,
  },
  {
    allowStatus: [
      TaskingStatus.ObservationFailed,
      // DeliveryRequestStatus.Failed,
    ],
    type: NotificationType.Cancel,
    title:
      '<% if(param.env !== "production"){ %> [<%= param.env %>] <% } %>[Synspective] Notice of observation failure (<%= param.items[0].scsOrderCode %>)',
    text: `Thank you for ordering data provision service of Synspective's SAR satellite StriX.
The following observation of new acquisition has failed.
この度は株式会社SynspectiveのSAR衛星StriXのデータ提供サービスをご注文いただき誠にありがとうございます。
以下の新規撮像の観測が失敗した事をお知らせいたします。

OrderCode: <%= param.items[0].scsOrderCode %>
AOI name: <%= param.items[0].aoiName %>
Observation start [UTC]: <%= param.items[0].observationStartUtc %>
Observation start [JST]: <%= param.items[0].observationStartJst %>
Reason: Due to operational issue

You can check information about your new acquisitions in the following URL.
撮像状況は下記よりご確認いただけます。
<%= param.taskMgmtLink %>

*This message was automatically generated. Please do not reply to this message.
本メールは自動で作成されています。ご返信いただかないようお願いいたします。

Best regards,

Synspective Inc./株式会社Synspective
Miyoshi 3-10-3, Koto-ku, Tokyo, Japan`,
  },
  {
    allowStatus: [DeliveryRequestStatus.Completed],
    type: NotificationType.TaskCompleted,
    title:
      '<% if(param.env !== "production"){ %> [<%= param.env %>] <% } %>[Synspective] Notice of product delivery (<%= param.items[0].scsOrderCode %>)',
    text: `Thank you for ordering data provision service of Synspective's SAR satellite StriX.
The following product of new acquisition has been delivered.
この度は株式会社SynspectiveのSAR衛星StriXのデータ提供サービスをご注文いただき誠にありがとうございます。
以下の新規撮像の製品が納品されました事をお知らせいたします。

OrderCode: <%= param.items[0].scsOrderCode %>
AOI name: <%= param.items[0].aoiName %>
Observation start [UTC]: <%= param.items[0].observationStartUtc %>
Observation start [JST]: <%= param.items[0].observationStartJst %>

Product: <% if(param.items[0].files.length) { %><% param.items[0].files.forEach((x) => { %>
  File name: <%= x.filename %> <% if(x.link !== '') { %>
  Download: <%= x.link %>
<% } %><% })} %>

*This message was automatically generated. Please do not reply to this message. 
本メールは自動で作成されています。ご返信いただかないようお願いいたします。

Best regards,

Synspective Inc./株式会社Synspective
Miyoshi 3-10-3, Koto-ku, Tokyo, Japan`,
  },
  {
    allowStatus: [UnrecordedTaskingStatus.RegisterFailed], // RegisterFailed shouldn't send email. Set empty to title and text
    type: NotificationType.Cancel,
    title: '',
    text: '',
  },
];

// NOTE: To avoid allowStatus overlapped by DeliveryRequestStatus and OrderStatus.
//       separate templates.
export const ArchiveOrderNotificationTemplates: NotificationTemplate[] = [
  {
    allowStatus: [OrderStatus.New],
    type: NotificationType.Reserved,
    title:
      '<% if(param.env !== "production"){ %> [<%= param.env %>] <% } %>[Synspective] Notice of new archive order registration (<%= param.reqNo %>)',
    text: `Thank you for ordering data provision service of Synspective's SAR satellite StriX.
The following archives products have been ordered.
この度は株式会社SynspectiveのSAR衛星StriXのデータ提供サービスをご注文いただき誠にありがとうございます。
以下のアーカイブプロダクトがオーダーされました事をお知らせいたします。    

ArchiveReqNo: <%= param.reqNo %>
itemId:<% param.items.forEach((x) => { %>
  <%= x.itemId %><% }) %>
Product format:<% param.items[0].files.forEach((x) => { %> <%= x.productLabel %>, <% }) %>

You can check information about your orders in the following URL.
オーダーの状況は下記よりご確認いただけます。
<%= param.orderUrl %>

*This message was automatically generated. Please do not reply to this message.
本メールは自動で作成されています。ご返信いただかないようお願いいたします。

Best regards,

Synspective Inc./株式会社Synspective
Miyoshi 3-10-3, Koto-ku, Tokyo, Japan`,
  },
  {
    allowStatus: [OrderStatus.Completed],
    type: NotificationType.TaskCompleted,
    title:
      '<% if(param.env !== "production"){ %> [<%= param.env %>] <% } %>[Synspective] Notice of product delivery (<%= param.reqNo %>)',
    text: `Thank you for ordering data provision service of Synspective's SAR satellite StriX.
The following order  has been delivered.
この度は株式会社SynspectiveのSAR衛星StriXのデータ提供サービスをご注文いただき誠にありがとうございます。
以下の注文が納品されました事をお知らせいたします。

ArchiveReqNo: <%= param.reqNo %>

<% param.items.forEach((x) => { %>
--
itemId: <%= x.itemId %>
ImagingMode:  <%= x.imagingMode %>
DataType:  <%= x.dataSourceType %>

Product: <% if(x.files.length) { %><% x.files.forEach((x) => { %>
File name: <%= x.filename %> <% if(x.link !== '') { %>
Download: <%= x.link %>
<% } %><% })} %>
<% }) %>

*This message was automatically generated. Please do not reply to this message. 
本メールは自動で作成されています。ご返信いただかないようお願いいたします。
Best regards,

Synspective Inc./株式会社Synspective
Miyoshi 3-10-3, Koto-ku, Tokyo, Japan`,
  },
];

export const ArchiveProductDataNotificationTemplates: NotificationTemplate[] = [
  {
    allowStatus: [ProcessingStatus.Completed],
    type: NotificationType.TaskCompleted,
    title:
      '<% if(param.env !== "production"){ %> [<%= param.env %>] <% } %>[Synspective] Notice of product delivery (<%= param.reqNo %>)',
    text: `Thank you for ordering data provision service of Synspective's SAR satellite StriX.
The following product has been ready to download.
この度は株式会社SynspectiveのSAR衛星StriXのデータ提供サービスをご注文いただき誠にありがとうございます。
以下のプロダクトのダウンロード準備が完了した事をお知らせいたします。

ArchiveReqNo: <%= param.reqNo %> <% param.items.forEach((x) => { %>
Item Id: <%= x.itemId %> <% if(x.files.length) { %><% x.files.forEach((x) => { %>
Product Format: <%= x.productLabel %> <% if(x.link !== '') { %>
Download: <%= x.link %> <% } %><% })} %> <% }) %>
Download expiration time [UTC]:<%= param.items[0].expiredAt %>

You can check information about your orders in the following URL.
オーダーの状況は下記よりご確認いただけます。
<%= param.orderUrl %>

*This message was automatically generated. Please do not reply to this message.
本メールは自動で作成されています。ご返信いただかないようお願いいたします。

Best regards,

Synspective Inc./株式会社Synspective
Miyoshi 3-10-3, Koto-ku, Tokyo, Japan`,
  },
];

export const generateNotificationContents = async (
  status: NotifiableStatus,
  data?: NotificationParam,
  templates: NotificationTemplate[] = NotificationTemplates,
) => {
  const template = templates.find((template) =>
    template.allowStatus.includes(status),
  );
  const tmpData: NotificationText = plainToInstance(NotificationText, {});
  if (data) {
    tmpData.env = data.env;
    tmpData.taskMgmtLink = data.taskMgmtLink;
    tmpData.items = data.items.length
      ? data.items.map((x) => convertToNotificationTextItem(x))
      : [];
    tmpData.reqNo = data.reqNo;
    tmpData.orderUrl = data.orderUrl;
  }
  return plainToInstance(NotificationContents, {
    title: await ejs.render(template.title, { param: tmpData, async: true }),
    text: await ejs.render(template.text, { param: tmpData, async: true }),
  });
};

const convertToNotificationTextItem = (
  param: NotificationParamItem,
): NotificationTextItem => {
  const textData = plainToInstance(NotificationTextItem, param);

  if (param.reason) {
    textData.reason = taskingStatusDetailToString(param.reason);
  }
  if (param.updatedAt) {
    textData.updatedAtUtc = formatNotificationDate(param.updatedAt);
  }
  if (param.obsStart) {
    textData.observationStartUtc = formatNotificationDate(param.obsStart);
    textData.observationStartJst = formatNotificationDate(
      new Date(
        param.obsStart.getTime() +
          (new Date().getTimezoneOffset() + 9 * 60) * 60 * 1000,
      ),
    );
  }
  if (param.imagingMode) {
    textData.imagingMode = getImagingModeString(param.imagingMode);
  }
  if (param.flightDirection) {
    textData.flightDirection = getFlightDirectionString(param.flightDirection);
  }
  if (param.lookingDirection) {
    textData.lookingDirection = getLookingDirectionString(
      param.lookingDirection,
    );
  }
  if (param.offnadirAngle) {
    const place = 100;
    textData.offnadirAngle = (
      Math.round(param.offnadirAngle * place) / place
    ).toString();
  }
  if (param.taskingType) {
    textData.taskingType = param.taskingType.toString();
  }
  if (param.itemId) {
    textData.itemId = param.itemId;
  }
  if (param.dataSourceType !== undefined) {
    textData.dataSourceType = getDataSourceTypeString(param.dataSourceType);
  }
  if (param.expiredAt !== undefined) {
    textData.expiredAt = formatNotificationDate(param.expiredAt);
  }

  return textData;
};
