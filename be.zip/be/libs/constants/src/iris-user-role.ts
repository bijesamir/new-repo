export const IrisUserRole = {
  ADMINISTRATOR: 2,
  INTERNAL: 3,
  CUSTOMER: 4,
  COLLABORATOR: 5,
};

export type IrisUserRole = (typeof IrisUserRole)[keyof typeof IrisUserRole];

export const IrisUserRoleAllValues = Object.values(IrisUserRole);

export const IrisUserRoleInternalValues = [
  IrisUserRole.ADMINISTRATOR,
  IrisUserRole.INTERNAL,
];

export const IrisUserRoleTaskingValues = [
  IrisUserRole.ADMINISTRATOR,
  IrisUserRole.INTERNAL,
  IrisUserRole.COLLABORATOR,
];

export const getIrisUserRoleLabel = (value: IrisUserRole): string => {
  switch (value) {
    case IrisUserRole.ADMINISTRATOR:
      return 'Administrator';
    case IrisUserRole.INTERNAL:
      return 'Internal';
    case IrisUserRole.CUSTOMER:
      return 'Customer';
    case IrisUserRole.COLLABORATOR:
      return 'Collaborator';
  }
};
