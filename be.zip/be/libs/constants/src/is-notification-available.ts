export const IsNotificationAvailable = {
  Yes: 1,
  No: 2,
};

export type IsNotificationAvailable =
  (typeof IsNotificationAvailable)[keyof typeof IsNotificationAvailable];

export const AllIsNotificationAvailableValues = Object.values(
  IsNotificationAvailable,
);
