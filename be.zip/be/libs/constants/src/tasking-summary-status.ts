export const TaskingSummaryStatus = {
  PreCreditCheck: 'pre-credit-check',
  PreOrder: 'pre-order',
  Ordered: 'ordered',
  Acquiring: 'acquiring',
  Processing: 'processing',
  ProductCreated: 'product-created',
  Delivered: 'delivered',
  Canceled: 'canceled',
  Rejected: 'rejected',
  AcquisitionFailed: 'acquisition-failed',
  ProductFailed: 'product-failed',
  DeliveryFailed: 'delivery-failed',
  NotApplicable: 'N/A',
};

export type TaskingSummaryStatus =
  (typeof TaskingSummaryStatus)[keyof typeof TaskingSummaryStatus];

export const TaskingSummaryStatusAllValues =
  Object.values(TaskingSummaryStatus);
