export const ContractType = {
  Tasking: 'Tasking',
  Archive: 'Archive',
};

export type ContractType = (typeof ContractType)[keyof typeof ContractType];

export const ContractTypeAllValues = Object.values(ContractType);
