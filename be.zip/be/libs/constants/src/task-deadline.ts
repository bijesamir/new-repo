export const TaskDeadline = {
  STANDARD: 0,
  URGENT: 1,
};

export type TaskDeadline = (typeof TaskDeadline)[keyof typeof TaskDeadline];

export const TaskDeadlineAllValues = Object.values(TaskDeadline);
