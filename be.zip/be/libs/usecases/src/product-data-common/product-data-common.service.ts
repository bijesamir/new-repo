import { ProductData, SceneInfo } from '@iris-lib/db/entities';
import { LoggerWrapper } from '@iris-lib/logger';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { EntityManager, Repository } from 'typeorm';

@Injectable()
export class ProductDataCommonService {
  private logger = new LoggerWrapper(ProductDataCommonService.name);

  constructor(
    @InjectRepository(ProductData)
    private readonly productDataRepo: Repository<ProductData>,
  ) {}

  async linkSceneInfoWithEntityManager(
    em: EntityManager,
    userId: string,
    productData: ProductData[],
    sceneInfo: SceneInfo,
  ) {
    const param = productData.map((target) => {
      delete target.productDataVersions;

      target.latestEditorId = userId;
      target.sceneInfo = sceneInfo;
      return target;
    });
    return em.getRepository(ProductData).save(param, { reload: true });
  }
}
