import { ProductData } from '@iris-lib/db/entities';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ProductDataCommonService } from './product-data-common.service';

@Module({
  imports: [TypeOrmModule.forFeature([ProductData])],
  providers: [ProductDataCommonService],
  exports: [ProductDataCommonService],
})
export class ProductDataCommonModule {}
