import { Test, TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { mockRepo, testModuleBase } from '@iris-lib/test-support';
import { AppConfigModuleBase } from '@iris-lib/utils';
import { ProductDataCommonService } from './product-data-common.service';
import { ProductData } from '@iris-lib/db/entities';

describe('ProductDataCommonService', () => {
  let m: TestingModule;
  let service: ProductDataCommonService;

  beforeEach(async () => {
    const meta = testModuleBase(() => AppConfigModuleBase);
    meta.providers.push(ProductDataCommonService);
    meta.providers.push({
      provide: getRepositoryToken(ProductData),
      useValue: mockRepo,
    });

    m = await Test.createTestingModule(meta).compile();

    service = m.get<ProductDataCommonService>(ProductDataCommonService);
  });

  afterAll(async () => {
    await m.close();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
