import { SceneInfo } from '@iris-lib/db/entities';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SceneInfoCommonService } from './scene-info-common.service';

@Module({
  imports: [TypeOrmModule.forFeature([SceneInfo])],
  providers: [SceneInfoCommonService],
  exports: [SceneInfoCommonService],
})
export class SceneInfoCommonModule {}
