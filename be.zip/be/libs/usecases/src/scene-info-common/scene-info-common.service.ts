import { SceneInfo } from '@iris-lib/db/entities';
import { LoggerWrapper } from '@iris-lib/logger';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { EntityManager, Repository } from 'typeorm';

@Injectable()
export class SceneInfoCommonService {
  private logger = new LoggerWrapper(SceneInfoCommonService.name);

  constructor(
    @InjectRepository(SceneInfo) private sceneInfoRepo: Repository<SceneInfo>,
  ) {}

  async insertWithEntityManager(em: EntityManager, sceneInfo: SceneInfo) {
    const tmp = em.getRepository(SceneInfo).create(sceneInfo);

    // performs upsert, if "id" is provided
    return await em.getRepository(SceneInfo).save(tmp);
  }
}
