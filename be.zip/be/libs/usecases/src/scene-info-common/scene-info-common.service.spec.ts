import { Test, TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { mockRepo, testModuleBase } from '@iris-lib/test-support';
import { AppConfigModuleBase } from '@iris-lib/utils';
import { SceneInfoCommonService } from './scene-info-common.service';
import { SceneInfo } from '@iris-lib/db/entities';

describe('SceneInfoCommonService', () => {
  let m: TestingModule;
  let service: SceneInfoCommonService;

  beforeEach(async () => {
    const meta = testModuleBase(() => AppConfigModuleBase);
    meta.providers.push(SceneInfoCommonService);
    meta.providers.push({
      provide: getRepositoryToken(SceneInfo),
      useValue: mockRepo,
    });

    m = await Test.createTestingModule(meta).compile();

    service = m.get<SceneInfoCommonService>(SceneInfoCommonService);
  });

  afterAll(async () => {
    await m.close();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
