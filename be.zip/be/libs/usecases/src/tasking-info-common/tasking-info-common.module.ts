import { Module } from '@nestjs/common';
import { TaskingInfo } from '@iris-lib/db/entities';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TypeOrmExModule } from '@iris-lib/db/typeorm-ex';
import { TaskingInfoRepository } from '@iris-lib/db/repositories';
import { TaskingInfoCommonService } from './tasking-info-common.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([TaskingInfo]),
    TypeOrmExModule.forCustomRepository([TaskingInfoRepository]),
  ],
  providers: [TaskingInfoCommonService],
  exports: [TaskingInfoCommonService],
})
export class TaskingInfoCommonModule {}
