import { Injectable } from '@nestjs/common';
import { LoggerWrapper } from '@iris-lib/logger';
import { TaskingInfoRepository } from '@iris-lib/db/repositories';
import { EntityManager, In } from 'typeorm';
import { TaskingStatus, TaskingStatusDetail } from '@iris-lib/constants';
import { TaskingInfo } from '@iris-lib/db/entities';

@Injectable()
export class TaskingInfoCommonService {
  private logger = new LoggerWrapper(TaskingInfoCommonService.name);

  constructor(private readonly taskingInfoRepo: TaskingInfoRepository) {}

  async getManyByOrderIdsWithEntityManager(
    em: EntityManager,
    scsOrderIds: string[],
  ) {
    return await em.getRepository(TaskingInfo).find({
      where: {
        scsOrderId: In(scsOrderIds),
      },
    });
  }

  async updateStatusWithEntityManager(
    em: EntityManager,
    userId: string,
    taskingInfos: TaskingInfo[],
    status: TaskingStatus,
    statusDetail: TaskingStatusDetail,
  ) {
    const param = taskingInfos.map((target) => {
      target.latestEditorId = userId;
      target.status = status;
      target.statusDetail = statusDetail;
      return target;
    });
    return await em.getRepository(TaskingInfo).save(param, { reload: true });
  }
}
