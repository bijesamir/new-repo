import { Test, TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { TaskingInfoRepository } from '@iris-lib/db/repositories';
import { TaskingInfoCommonService } from './tasking-info-common.service';
import { mockRepo, testModuleBase } from '@iris-lib/test-support';
import { AppConfigModuleBase } from '@iris-lib/utils';

describe('TaskingInfoCommonService', () => {
  let m: TestingModule;
  let service: TaskingInfoCommonService;

  beforeEach(async () => {
    const meta = testModuleBase(() => AppConfigModuleBase);
    meta.providers.push(TaskingInfoCommonService);
    meta.providers.push({
      provide: getRepositoryToken(TaskingInfoRepository),
      useValue: mockRepo,
    });

    m = await Test.createTestingModule(meta).compile();

    service = m.get<TaskingInfoCommonService>(TaskingInfoCommonService);
  });

  afterAll(async () => {
    await m.close();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
