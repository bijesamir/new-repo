import { ProductDataVersion } from '@iris-lib/db/entities';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ProductDataVersionCommonService } from './product-data-version-common.service';

@Module({
  imports: [TypeOrmModule.forFeature([ProductDataVersion])],
  providers: [ProductDataVersionCommonService],
  exports: [ProductDataVersionCommonService],
})
export class ProductDataVersionCommonModule {}
