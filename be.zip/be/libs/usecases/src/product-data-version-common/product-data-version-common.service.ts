import { ProductDataVersion } from '@iris-lib/db/entities';
import { LoggerWrapper } from '@iris-lib/logger';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { EntityManager, FindManyOptions, Repository } from 'typeorm';

@Injectable()
export class ProductDataVersionCommonService {
  private logger = new LoggerWrapper(ProductDataVersionCommonService.name);

  constructor(
    @InjectRepository(ProductDataVersion)
    private readonly productDataVersionRepo: Repository<ProductDataVersion>,
  ) {}

  async getMany(options: FindManyOptions<ProductDataVersion>) {
    return await this.productDataVersionRepo.find(options);
  }

  async setSourceDeletedWithEntityManager(
    em: EntityManager,
    userId: string,
    productDataVersions: ProductDataVersion[],
    isSourceDeleted: boolean,
  ) {
    const param = productDataVersions.map((target) => {
      target.latestEditorId = userId;
      target.isSourceDeleted = isSourceDeleted;
      return target;
    });
    return await em
      .getRepository(ProductDataVersion)
      .save(param, { reload: true });
  }
}
