import { Test, TestingModule } from '@nestjs/testing';
import { ProductDataVersionCommonService } from './product-data-version-common.service';
import { mockRepo, testModuleBase } from '@iris-lib/test-support';
import { AppConfigModuleBase } from '@iris-lib/utils';
import { getRepositoryToken } from '@nestjs/typeorm';
import { ProductDataVersion } from '@iris-lib/db/entities';

describe('ProductDataVersionCommonService', () => {
  let m: TestingModule;
  let service: ProductDataVersionCommonService;

  beforeEach(async () => {
    const meta = testModuleBase(() => AppConfigModuleBase);
    meta.providers.push(ProductDataVersionCommonService);
    meta.providers.push({
      provide: getRepositoryToken(ProductDataVersion),
      useValue: mockRepo,
    });

    m = await Test.createTestingModule(meta).compile();

    service = m.get<ProductDataVersionCommonService>(
      ProductDataVersionCommonService,
    );
  });

  afterAll(async () => {
    await m.close();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
