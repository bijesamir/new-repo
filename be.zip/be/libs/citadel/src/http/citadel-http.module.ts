import { HttpModule as BaseHttpModule, HttpService } from '@nestjs/axios';
import { Inject, Module } from '@nestjs/common';
import { CitadelHttpService } from './citadel-http.service';
import { LoggerWrapper } from '@iris-lib/logger';
import { ConfigModule } from '@nestjs/config';
import {
  CitadelHttpConfigService,
  loadCitadelHttpConfig,
} from '../config/citadel-http-config';

@Module({
  imports: [
    ConfigModule.forRoot({
      ignoreEnvFile: true,
      load: [loadCitadelHttpConfig],
    }),
    BaseHttpModule,
  ],
  providers: [
    {
      provide: 'CitadelHttpConfig',
      useClass: CitadelHttpConfigService,
    },
    CitadelHttpService,
  ],
  exports: [CitadelHttpService],
})
export class CitadelHttpModule {
  private logger = new LoggerWrapper(CitadelHttpModule.name);

  constructor(
    @Inject('CitadelHttpConfig')
    private readonly config: CitadelHttpConfigService,
    private readonly httpService: HttpService,
  ) {}

  // https://github.com/axios/axios#interceptors
  public onModuleInit(): any {
    if (this.config.get('citadelHttp.doLogging')) {
      const axios = this.httpService.axiosRef;
      axios.interceptors.request.use(
        async (c) => {
          this.logger.debug('request', c);
          return c;
        },
        async (err) => {
          // Something went wrong before making the request
          this.logger.error('failed request', err.message, err);
          throw err;
        },
      );
      axios.interceptors.response.use(
        async (response) => {
          this.logger.debug('response', response);
          return response;
        },
        async (err) => {
          // Any status codes that falls outside the range of 2xx cause this function to trigger
          this.logger.error('failed response', err.message, err);
          throw err;
        },
      );
    }
  }
}
