import { HttpModule } from '@nestjs/axios';
import { Test, TestingModule } from '@nestjs/testing';
import { CitadelHttpService } from './citadel-http.service';
import { LoggerModule } from '@iris-lib/logger';
import { ConfigModule } from '@nestjs/config';
import {
  CitadelHttpConfigService,
  loadCitadelHttpConfig,
} from '../config/citadel-http-config';

jest.useRealTimers();

describe('CitadelHttpService', () => {
  let service: CitadelHttpService;
  let module: TestingModule;
  beforeEach(async () => {
    module = await Test.createTestingModule({
      imports: [
        ConfigModule.forRoot({
          ignoreEnvFile: true,
          load: [loadCitadelHttpConfig],
        }),
        HttpModule,
        LoggerModule,
      ],
      providers: [
        {
          provide: 'CitadelHttpConfig',
          useClass: CitadelHttpConfigService,
        },
        CitadelHttpService,
      ],
    }).compile();

    service = module.get<CitadelHttpService>(CitadelHttpService);
  });

  afterEach(async () => {
    //await module.close();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  }, 15000);
});
