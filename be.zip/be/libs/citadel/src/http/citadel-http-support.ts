import { IrisContractPackage } from '@iris-lib/models/payment';
import {
  ModelsContract,
  ModelsDeliveryTimeKind,
  ModelsProductDeliveryMethod,
  ModelsTaskPriorityKind,
  ModelsTaskDeadlineKind,
  ModelsCatalogDelayKind,
} from '../models/http/auto-gen/usermgmt';
import { plainToInstance } from 'class-transformer';
import parseISO from 'date-fns/parseISO';
import {
  DeliveryMethod,
  DeliveryTimeKind,
  TaskingPriorityKind,
  TaskDeadline,
  CatalogDelayKind,
} from '@iris-lib/constants';

// Convert definition in citadel to definition in iris
const fromModelsCatalogDelayKind = (src: ModelsCatalogDelayKind) => {
  switch (src) {
    case ModelsCatalogDelayKind.ICC_PERMANENT:
      return CatalogDelayKind.PERMANENT;
    case ModelsCatalogDelayKind.ICC_NO_DELAY:
      return CatalogDelayKind.NO_DELAY;
    case ModelsCatalogDelayKind.ICC_THIRTY_DAYS:
      return CatalogDelayKind.THIRTY_DAYS;
    case ModelsCatalogDelayKind.ICC_ONE_YEAR:
      return CatalogDelayKind.ONE_YEAR;
    default:
      throw new Error(`unknown catalog delay kind: ${src}`);
  }
};

const fromModelsProductDeliveryMethod = (src: ModelsProductDeliveryMethod) => {
  switch (src) {
    case ModelsProductDeliveryMethod.ICPD_DIRECT_LINK:
      return DeliveryMethod.DEFAULT;
    case ModelsProductDeliveryMethod.ICPD_FTP: // Not used in iris. But, defined to keep compatibility with citadel
      return DeliveryMethod.FTP;
    case ModelsProductDeliveryMethod.ICPD_SFTP:
      return DeliveryMethod.SFTP;
    default:
      throw new Error(`unknown product delivery method: ${src}`);
  }
};

const fromModelsDeliveryTimeKind = (src: ModelsDeliveryTimeKind) => {
  switch (src) {
    case ModelsDeliveryTimeKind.ICDT_STANDARD:
      return DeliveryTimeKind.STANDARD;
    case ModelsDeliveryTimeKind.ICDT_RUSH:
      return DeliveryTimeKind.RUSH;
    default:
      throw new Error(`unknown delivery time kind: ${src}`);
  }
};

const fromModelsTaskingPriorityKind = (src: ModelsTaskPriorityKind) => {
  switch (src) {
    case ModelsTaskPriorityKind.ICTP_STANDARD:
      return TaskingPriorityKind.STANDARD;
    case ModelsTaskPriorityKind.ICTP_HIGH:
      return TaskingPriorityKind.HIGH;
    default:
      throw new Error(`unknown task priority kind: ${src}`);
  }
};

const fromModelsTaskDeadlineMethod = (src: ModelsTaskDeadlineKind) => {
  switch (src) {
    case ModelsTaskDeadlineKind.ICTD_STANDARD:
      return TaskDeadline.STANDARD;
    case ModelsTaskDeadlineKind.ICTD_URGENT:
      return TaskDeadline.URGENT;
    default:
      throw new Error(`unknown task deadline method: ${src}`);
  }
};

export const toContracts = (src: ModelsContract[]): IrisContractPackage[] => {
  return src.reduce((accC, c) => {
    const tmpAccC = c.packages.reduce((accP, p) => {
      const tmpStart = parseISO(c.contract.startDate);
      const tmpEnd = parseISO(c.contract.endDate);
      const icp = plainToInstance(IrisContractPackage, {
        contractId: c.contract.id,
        organizationId: c.contract.organizationId,
        serviceId: c.contract.serviceId,
        catalogDelayKind: fromModelsCatalogDelayKind(
          c.options.catalogDelayKind,
        ),
        startAt: tmpStart,
        endAt: tmpEnd,
        packageId: p.id,
        packageName: p.name,
        isInternal: c.options.isInternalUse,
        availableTasking: c.options.isTasking,
        availableArchivePurchase: c.options.isArchive,
        canAccessTaskingConsole: c.options.canAccessTaskingConsole,
        deliveryMode: fromModelsProductDeliveryMethod(
          c.options.productDeliveryMethod,
        ),
        deliveryTimeKind: fromModelsDeliveryTimeKind(
          p.taskParameters.deliveryTimeKind,
        ),
        taskingPriorityKind: fromModelsTaskingPriorityKind(
          p.taskParameters.taskPriorityKind,
        ),
        // If at least one dataProductOrder has ICTD_URGENT, the contract should be deal as ICTD_URGENT
        taskDeadline: fromModelsTaskDeadlineMethod(
          p.taskParameters.dataProductOrders.some(
            (v) => v.taskDeadlineKind === ModelsTaskDeadlineKind.ICTD_URGENT,
          )
            ? ModelsTaskDeadlineKind.ICTD_URGENT
            : ModelsTaskDeadlineKind.ICTD_STANDARD,
        ),
      } as IrisContractPackage);
      accP.push(icp);
      return accP;
    }, new Array<IrisContractPackage>());
    accC.push(...tmpAccC);
    return accC;
  }, new Array<IrisContractPackage>());
};
