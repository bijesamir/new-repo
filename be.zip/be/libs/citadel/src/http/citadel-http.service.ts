import { HttpService } from '@nestjs/axios';
import { Inject, Injectable } from '@nestjs/common';
import { AxiosError } from 'axios';
import { catchError, firstValueFrom } from 'rxjs';

import { LoggerWrapper } from '@iris-lib/logger';
import { CitadelError, CitadelRelatedError } from '../models';
import { UsermgmtListOrganizationServiceContractsResponse } from '../models/http/auto-gen/usermgmt';
import { toContracts } from './citadel-http-support';
import { IrisContractPackage } from '@iris-lib/models/payment';
import { keysToCamel } from '@iris-lib/utils';
import { CitadelHttpConfigService } from '../config/citadel-http-config';

@Injectable()
export class CitadelHttpService {
  private logger = new LoggerWrapper(CitadelHttpService.name);
  constructor(
    @Inject('CitadelHttpConfig')
    private readonly config: CitadelHttpConfigService,
    private readonly httpService: HttpService,
  ) {}

  async getContracts(
    token: string,
    organizationId: number,
  ): Promise<IrisContractPackage[]> {
    const res = await this.doGet(
      token,
      `/v1/usermanagement/organizations/${organizationId}/services/${this.config.get(
        'citadelHttp.serviceId',
      )}/contracts`,
    );
    this.logger.debug('fetched data', res);
    try {
      const citadelContracts = keysToCamel(
        res,
      ) as UsermgmtListOrganizationServiceContractsResponse;
      return toContracts(citadelContracts.contracts);
    } catch (err) {
      this.logger.error('error occurred in getContracts', err['stack'] || err);
      throw new CitadelRelatedError(err.toString());
    }
  }

  private async doGet(token: string, endPointPath: string) {
    try {
      const { data } = await firstValueFrom(
        this.httpService
          .get(this.config.get('citadelHttp.baseUrl') + endPointPath, {
            responseType: 'json',
            headers: {
              'Content-Type': 'application/json',
              Authorization: 'Bearer ' + token,
            },
          })
          .pipe(
            catchError((error: AxiosError) => {
              throw error;
            }),
          ),
      );
      return data;
    } catch (err) {
      this.logger.error(
        'error occurred when calling citadel http service',
        err['stack'] || err,
        { endPointPath },
      );
      throw new CitadelError(err.toString());
    }
  }

  async getAllContracts(
    orgIds: number[],
    token: string,
  ): Promise<IrisContractPackage[]> {
    const tmp = await Promise.all(
      orgIds.map(async (x) => {
        return await this.getContracts(token, x);
      }),
    );
    return tmp.flat();
  }
}
