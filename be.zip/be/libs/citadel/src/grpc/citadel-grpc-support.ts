/* eslint-disable @typescript-eslint/no-namespace */
import {
  ImagingMode,
  IrisUserRoleAllValues,
  ProductFormat,
  ResolutionMode,
  TaskingType,
} from '@iris-lib/constants';
import { DeliveryTimeKind } from '@iris-lib/constants/delivery-time-kind';
import { NotificationContents } from '@iris-lib/constants/notification';
import { DataSourceType } from '@iris-lib/constants/data-source-type';
import {
  PaymentTaskStatus,
  PaymentTaskStatusAllValues,
} from '@iris-lib/constants/payment-task-status';
import { TaskingPriorityKind } from '@iris-lib/constants/tasking-priority-kind';
import { IrisUserDto } from '@iris-lib/models';
import { CheckQuotaDto, EmitRequestDto } from '@iris-lib/models/payment';
import {
  PaymentReplyDto,
  VerifyItemDto,
} from '@iris-lib/models/payment/payment-reply.dto';
import { getProductName } from '@iris-lib/utils';
import {
  BaseFeeDataType,
  BaseFeeObservationMode,
  FormulaParameters,
  Notification,
  OptionDeliveryTime,
  OptionProcessingType,
  OptionTaskingDeadline,
  OptionTaskingPriority,
  Privilege,
  ProcessingFailedResult,
  ProcessingResult,
  TaskDeliveryStatus,
  TaskFormulaParameters,
  TaskManipulationResult,
  TaskResult,
  TaskVerifyResult,
  VerifyUserIdentityTokenReply,
} from '@syns-platform/citadel-grpc-js';
import { plainToInstance } from 'class-transformer';
import { VerifyCustomerAccessTokenReply } from '@syns-platform/citadel-grpc-js/build/citadel/types/services/verification/verification_pb';

export namespace toCitadelGrpcSupport {
  export const fromCheckQuotaDto = (src: CheckQuotaDto) => {
    const taskParam = new TaskFormulaParameters();
    taskParam.setTaskId(src.id);
    taskParam.setScenes(src.scene);
    const formulaParams = new FormulaParameters();
    formulaParams.setDataType(fromDataSourceType(src.dataSourceType));
    formulaParams.setObservationMode(fromImagingMode(src.imagingMode));
    formulaParams.setTaskingDeadline(fromTaskingType(src.taskingType));
    formulaParams.setProcessingTypeList(
      src.productDetails.map((x) =>
        fromProductFormatAndResolution(x.productFormat, x.resolutionMode),
      ),
    );
    formulaParams.setDeliveryTime(fromDeliveryTimeKind(src.deliveryTimeKind));
    formulaParams.setTaskingPriority(
      fromTaskingPriorityKind(src.taskPriorityKind),
    );
    taskParam.setParameters(formulaParams);
    return taskParam;
  };
  const fromDataSourceType = (src: DataSourceType) => {
    switch (src) {
      case DataSourceType.NEW:
        return BaseFeeDataType.NEWACQUISITION;
      case DataSourceType.ARCHIVE:
        return BaseFeeDataType.ARCHIVE;
      default:
        throw new Error(`unknown operation kind: ${src}`);
    }
  };
  const fromImagingMode = (src: ImagingMode) => {
    switch (src) {
      case ImagingMode.SlidingSpotlight:
        return BaseFeeObservationMode.SLIDINGSPOTLIGHT;
      case ImagingMode.Stripmap:
        return BaseFeeObservationMode.STRIPMAP;
      case ImagingMode.StaringSpotlight1:
        return BaseFeeObservationMode.STARINGSPOTLIGHT1;
      case ImagingMode.StaringSpotlight2:
        return BaseFeeObservationMode.STARINGSPOTLIGHT2;
      case ImagingMode.StaringSpotlight3:
        return BaseFeeObservationMode.STARINGSPOTLIGHT3;
      case ImagingMode.StaringSpotlight4:
        return BaseFeeObservationMode.STARINGSPOTLIGHT4;
      default:
        throw new Error(`unknown imaging mode: ${src}`);
    }
  };

  const fromTaskingType = (src: TaskingType) => {
    switch (src) {
      case TaskingType.Regular:
        return OptionTaskingDeadline.STANDARDDEADLINE;
      case TaskingType.Urgent:
        return OptionTaskingDeadline.URGENT;
      default:
        throw new Error(`unknown tasking type: ${src}`);
    }
  };

  const fromDeliveryTimeKind = (src: DeliveryTimeKind) => {
    switch (src) {
      case DeliveryTimeKind.STANDARD:
        return OptionDeliveryTime.STANDARDDELIVERYTIME;
      case DeliveryTimeKind.RUSH:
        return OptionDeliveryTime.RUSH;
      default:
        throw new Error(`unknown delivery time kind: ${src}`);
    }
  };

  const fromTaskingPriorityKind = (src: TaskingPriorityKind) => {
    switch (src) {
      case TaskingPriorityKind.STANDARD:
        return OptionTaskingPriority.STANDARDPRIORITY;
      case TaskingPriorityKind.HIGH:
        return OptionTaskingPriority.HIGH;
      default:
        throw new Error(`unknown tasking priority kind: ${src}`);
    }
  };

  export const fromEmitRequestDto = (src: EmitRequestDto) => {
    const tmp = new TaskResult();
    tmp.setTaskId(src.registrationId);
    tmp.setTaskDeliveryStatus(fromPaymentTaskStatus(src.status));
    tmp.setRushDeliveryResult(src.isRushDelivery);
    if (src.processingSuccessList && src.processingSuccessList.length > 0) {
      tmp.setSuccessResultsList(
        src.processingSuccessList.map((x) => {
          const tmpItem = new ProcessingResult();
          tmpItem.setProductVersionId(x.productDataVersionId);
          tmpItem.setType(
            fromProductFormatAndResolution(x.productFormat, x.resolutionMode),
          );
          return tmpItem;
        }),
      );
    }
    if (src.processingFailureList && src.processingFailureList.length > 0) {
      tmp.setFailedResultsList(
        src.processingFailureList.map((x) => {
          const tmpItem = new ProcessingFailedResult();
          tmpItem.setScene(x.sceneNo);
          tmpItem.setType(
            fromProductFormatAndResolution(x.productFormat, x.resolutionMode),
          );
          return tmpItem;
        }),
      );
    }
    return tmp;
  };

  export const fromNotificationContents = (src: NotificationContents) => {
    const tmp = new Notification();
    tmp.setText(src.text);
    tmp.setTitle(src.title);
    return tmp;
  };

  export const fromPaymentTaskStatus = (src: PaymentTaskStatus) => {
    switch (src) {
      case PaymentTaskStatus.TEMPORAL:
        return TaskDeliveryStatus.TEMPORAL;
      case PaymentTaskStatus.RESERVED:
        return TaskDeliveryStatus.RESERVED;
      case PaymentTaskStatus.COMPLETED:
        return TaskDeliveryStatus.COMPLETED;
      case PaymentTaskStatus.CANCELED:
        return TaskDeliveryStatus.CANCELED;
      case PaymentTaskStatus.EXCEPTIONAL:
        return TaskDeliveryStatus.EXCEPTIONAL;
      case PaymentTaskStatus.OBSERVATIONFAILED:
        return TaskDeliveryStatus.OBSERVATIONFAILURE;
      case PaymentTaskStatus.INTERNALERROR:
        return TaskDeliveryStatus.INTERNALERROR;
      default:
        throw new Error(`unknown payment task status: ${src}`);
    }
  };
}

export const fromProductFormatAndResolution = (
  productFormat: ProductFormat,
  resolutionMode: ResolutionMode,
) => {
  switch (productFormat) {
    case ProductFormat.GRD_GEOTIFF:
      if (resolutionMode === ResolutionMode.SR) {
        return OptionProcessingType.SR_GRD_GEOTIFF;
      } else {
        return OptionProcessingType.GRD_GEOTIFF;
      }
    case ProductFormat.SLC_CEOS:
      return OptionProcessingType.SLC_CEOS;
    case ProductFormat.SLC_SICD:
      return OptionProcessingType.SLC_SICD;
    case ProductFormat.ORT_GEOTIFF:
      return OptionProcessingType.ORT_GEOTIFF;
    default:
      throw new Error(`unknow product format: ${productFormat}`);
  }
};

export namespace fromCitadelGrpcSupport {
  export const toPaymentReplyDto = (src: TaskManipulationResult.AsObject) => {
    return plainToInstance(PaymentReplyDto, {
      registrationId: src.registrationId,
      taskId: src.taskId,
      status: toPaymentStatus(src.taskDeliveryStatus),
      consumptionCredit: src.consumptionCredit,
    });
  };
  export const toVerifyItemDto = (src: TaskVerifyResult.AsObject) => {
    return plainToInstance(VerifyItemDto, {
      taskId: src.taskId,
      consumptionCredit: src.consumptionCredit,
      dataSourceType: toDataSourceType(src.baseFeeDataType),
      imagingMode: toImagingMode(src.baseFeeObservationMode),
      numberOfLicense: src.numberOfLicense,
      options: src.optionProcessingTypeList.map((x) => toProductName(x)),
    });
  };
  const toIrisUserRole = (src: Privilege.UserRole) => {
    return IrisUserRoleAllValues.find((x) => x === src);
  };
  const toPaymentStatus = (src: TaskDeliveryStatus) => {
    const tmp = PaymentTaskStatusAllValues.find((x) => x === src);
    if (tmp === undefined) {
      throw new Error(`unknown payment status: ${src}`);
    }
    return tmp;
  };
  // const toDeliveryMethod = (src: ProductDeliveryMethod) => {
  //   const tmp = DeliveryMethodAllValues.find((x) => x === src);
  //   if (!tmp) {
  //     throw new Error(`unknown delivery method: ${src}`);
  //   }
  //   return tmp;
  // };
  const toDataSourceType = (src: BaseFeeDataType) => {
    switch (src) {
      case BaseFeeDataType.NEWACQUISITION:
        return DataSourceType.NEW;
      case BaseFeeDataType.ARCHIVE:
        return DataSourceType.ARCHIVE;
      default:
        throw new Error(`unknown payment kind: ${src}`);
    }
  };
  const toImagingMode = (src: BaseFeeObservationMode) => {
    switch (src) {
      case BaseFeeObservationMode.SLIDINGSPOTLIGHT:
        return ImagingMode.SlidingSpotlight;
      case BaseFeeObservationMode.STRIPMAP:
        return ImagingMode.Stripmap;
      case BaseFeeObservationMode.STARINGSPOTLIGHT1:
        return ImagingMode.StaringSpotlight1;
      case BaseFeeObservationMode.STARINGSPOTLIGHT2:
        return ImagingMode.StaringSpotlight2;
      case BaseFeeObservationMode.STARINGSPOTLIGHT3:
        return ImagingMode.StaringSpotlight3;
      case BaseFeeObservationMode.STARINGSPOTLIGHT4:
        return ImagingMode.StaringSpotlight4;
      default:
        throw new Error(`unknown imaging mode: ${src}`);
    }
  };
  const toProductName = (src: OptionProcessingType) => {
    switch (src) {
      case OptionProcessingType.GRD_GEOTIFF:
        return getProductName(ProductFormat.GRD_GEOTIFF, ResolutionMode.normal);
      case OptionProcessingType.SLC_CEOS:
        return getProductName(ProductFormat.SLC_CEOS, ResolutionMode.normal);
      case OptionProcessingType.SLC_SICD:
        return getProductName(ProductFormat.SLC_SICD, ResolutionMode.normal);
      case OptionProcessingType.SR_GRD_GEOTIFF:
        return getProductName(ProductFormat.GRD_GEOTIFF, ResolutionMode.SR);
      case OptionProcessingType.ORT_GEOTIFF:
        return getProductName(ProductFormat.ORT_GEOTIFF, ResolutionMode.normal);
      default:
        throw new Error(`unknown product format: ${src}`);
    }
  };

  export const toIrisUserDto = (
    token: string,
    src: VerifyCustomerAccessTokenReply.AsObject,
  ) => {
    return plainToInstance(IrisUserDto, {
      userId: src.claims.token.sub,
      userToken: token,
      roleTypes: src.claims.rolesList.flatMap((x) => {
        return toIrisUserRole(x) || [];
      }),
      currentOrganizationId: src.claims.token.context.currentOrganization,
      organizationIds: src.claims.token.organizationsList,
    } as IrisUserDto);
  };

  // TODO: to be deprecated
  export const toIrisUserDtoWithUserIdentityToken = (
    userIdentityToken: string,
    src: VerifyUserIdentityTokenReply.AsObject,
  ) => {
    return plainToInstance(IrisUserDto, {
      userId: src.claims.token.userId,
      userToken: userIdentityToken,
      roleTypes: src.claims.rolesList.flatMap((x) => {
        return toIrisUserRole(x) || [];
      }),
      currentOrganizationId: src.claims.token.context.currentOrganization,
      organizationIds: src.claims.token.organizationsList,
    } as IrisUserDto);
  };
}
