import { Inject, Injectable } from '@nestjs/common';
import { LoggerWrapper } from '@iris-lib/logger';
import {
  TaskDeliveryStatus,
  TaskManipulationReply,
  VerificationClient,
  VerifyUserIdentityTokenReply,
} from '@syns-platform/citadel-grpc-js';
import { IrisUserDto } from '@iris-lib/models';
import {
  fromCitadelGrpcSupport,
  toCitadelGrpcSupport,
} from './citadel-grpc-support';
import { CheckQuotaDto } from '@iris-lib/models/payment/check-quota.dto';

import {
  CitadelError,
  CitadelQuotaExceedError,
  CitadelRelatedError,
} from '../models';
import { NotificationContents } from '@iris-lib/constants/notification';
import {
  EmitRequestDto,
  PaymentReplyDto,
  PaymentsDto,
  VerifyItemDto,
} from '@iris-lib/models/payment';
import { CitadelGrpcConfigService } from '../config/citadel-grpc-config';
import { plainToInstance } from 'class-transformer';

import { PaymentTaskStatus } from '@iris-lib/constants/payment-task-status';
import { ImagingMode, DataSourceType } from '@iris-lib/constants';
import { VerifyCustomerAccessTokenReply } from '@syns-platform/citadel-grpc-js/build/citadel/types/services/verification/verification_pb';

@Injectable()
export class CitadelGrpcService {
  private logger = new LoggerWrapper(CitadelGrpcService.name);
  private verificationClient: VerificationClient;

  constructor(
    @Inject('CitadelGrpcConfig')
    private readonly config: CitadelGrpcConfigService,
  ) {
    this.verificationClient = new VerificationClient(
      this.config.get('citadelGrpc.host'),
      this.config.get('citadelGrpc.serverToken'),
      '',
      // values are from https://github.com/camunda-community-hub/zeebe-client-node-js/blob/7969ce1808c96a87519cb1a3f279287f30637c4b/src/lib/GrpcClient.ts#L193
      {
        'grpc.enable_retries': 1,
        'grpc.initial_reconnect_backoff_ms': 1000,
        'grpc.max_reconnect_backoff_ms': 10000,
        'grpc.min_reconnect_backoff_ms': 5000,
        'grpc.keepalive_time_ms': 360000,
        'grpc.keepalive_timeout_ms': 120000,
        'grpc.http2.min_time_between_pings_ms': 90000,
        'grpc.http2.min_ping_interval_without_data_ms': 90000,
        'grpc.keepalive_permit_without_calls': 1,
        'grpc.http2.max_pings_without_data': 0,
      },
    );
  }

  async verifyAccessToken(
    accessToken: string,
  ): Promise<[boolean, IrisUserDto | null]> {
    let citadelUser: VerifyCustomerAccessTokenReply.AsObject;
    try {
      const res =
        await this.verificationClient.verifyCustomerAccessToken(accessToken);
      citadelUser = res.toObject();
    } catch (err) {
      this.logger.error(
        'error occurred in verifyAccessToken',
        err['stack'] || err,
      );
      throw new CitadelError(err.toString());
    }
    this.logger.debug('fetched citadel user with provided access token', {
      citadelUser,
    });
    try {
      if (citadelUser.isAuthenticated) {
        return [
          true,
          fromCitadelGrpcSupport.toIrisUserDto(accessToken, citadelUser),
        ];
      } else {
        this.logger.warn(
          'verifyAccessToken response from citadel is invalid',
          citadelUser,
        );
        return [false, null];
      }
    } catch (err) {
      throw new CitadelRelatedError(err.toString());
    }
  }

  // TODO: to be deprecated
  async verifyUserIdentityToken(
    userIdentityToken: string,
  ): Promise<[boolean, IrisUserDto | null]> {
    let citadelUser: VerifyUserIdentityTokenReply.AsObject;
    try {
      const res =
        await this.verificationClient.verifyUserIdentityToken(
          userIdentityToken,
        );
      citadelUser = res.toObject();
    } catch (err) {
      this.logger.error(
        'error occurred in verifyUserIdentityToken',
        err['stack'] || err,
      );
      throw new CitadelError(err.toString());
    }
    this.logger.debug('fetched citadel user with provided identity token', {
      citadelUser,
    });
    try {
      if (citadelUser.isAuthenticated) {
        return [
          true,
          fromCitadelGrpcSupport.toIrisUserDtoWithUserIdentityToken(
            userIdentityToken,
            citadelUser,
          ),
        ];
      } else {
        this.logger.warn(
          'VerifyUserIdentityToken response from citadel is invalid',
          citadelUser,
        );
        return [false, null];
      }
    } catch (err) {
      throw new CitadelRelatedError(err.toString());
    }
  }

  async verifyQuota(
    contractId: number,
    checkList: CheckQuotaDto[],
  ): Promise<PaymentsDto> {
    if (this.config.get('citadelGrpc.skip')) {
      return plainToInstance(PaymentsDto, {
        totalConsumptionCredit: 0,
        remainingCredit: 0,
        results: checkList.map((x) => {
          return this.dummyResponse(x.id, PaymentTaskStatus.RESERVED);
        }),
        verifyResults: checkList.map((x) => {
          return this.dummyVerifyResponse(x.id);
        }),
      } as PaymentsDto);
    }
    let res: TaskManipulationReply.AsObject;
    try {
      const taskParameters = checkList.map((x) =>
        toCitadelGrpcSupport.fromCheckQuotaDto(x),
      );
      this.logger.debug('fetch verifyTaskQuotation', {
        contractId,
        original: checkList,
        converted: taskParameters,
      });
      res = (
        await this.verificationClient.verifyTaskQuotation(
          contractId,
          taskParameters,
        )
      ).toObject();
    } catch (err) {
      const errMsg = err['stack'] || err;
      this.logger.error('error occurred in verifyTaskQuotation', errMsg);
      if (errMsg.includes('not enough credit')) {
        throw new CitadelQuotaExceedError(
          'Your orders exceed quotation of the contract.',
        );
      } else {
        throw new CitadelError(errMsg);
      }
    }
    this.logger.debug('fetched verifyTaskQuotation result', {
      res,
    });
    try {
      if (res.isOk) {
        return plainToInstance(PaymentsDto, {
          totalConsumptionCredit: res.consumptionCredit,
          remainingCredit: res.remainingQuotation,
          results: res.resultsList.map((x) =>
            fromCitadelGrpcSupport.toPaymentReplyDto(x),
          ),
          verifyResults: res.verifyResultsList.map((x) =>
            fromCitadelGrpcSupport.toVerifyItemDto(x),
          ),
        } as PaymentsDto);
      } else {
        this.logger.warn(
          'verifyTaskQuotation response from citadel is invalid',
          res,
        );
        throw new CitadelRelatedError(
          'verifyTaskQuotation response from citadel is invalid',
        );
      }
    } catch (err) {
      throw new CitadelRelatedError(err.toString());
    }
  }

  async checkQuota(
    contractId: number,
    checkList: CheckQuotaDto[],
  ): Promise<PaymentReplyDto[]> {
    // skip
    if (this.config.get('citadelGrpc.skip')) {
      return checkList.map((x) => {
        return this.dummyResponse(x.id, PaymentTaskStatus.RESERVED);
      });
    }
    let res: TaskManipulationReply.AsObject;
    try {
      const taskParameters = checkList.map((x) =>
        toCitadelGrpcSupport.fromCheckQuotaDto(x),
      );
      this.logger.debug('fetch verifyTaskQuotationAndReserveTentative', {
        contractId,
        original: checkList,
        converted: taskParameters,
      });
      res = (
        await this.verificationClient.verifyTaskQuotationAndReserveTentative(
          contractId,
          taskParameters,
        )
      ).toObject();
    } catch (err) {
      const errMsg = err['stack'] || err;
      this.logger.error(
        'error occurred in verifyTaskQuotationAndReserveTentative',
        errMsg,
      );
      if (errMsg.includes('not enough credit')) {
        throw new CitadelQuotaExceedError(
          'Your orders exceed quotation of the contract.',
        );
      } else {
        throw new CitadelError(errMsg);
      }
    }
    this.logger.debug('fetched verifyTaskQuotationAndReserveTentative result', {
      res,
    });
    try {
      if (res.isOk) {
        return res.resultsList.map((x) =>
          fromCitadelGrpcSupport.toPaymentReplyDto(x),
        );
      } else {
        this.logger.warn(
          'verifyTaskQuotationAndReserveTentative response from citadel is invalid',
          res,
        );
        throw new CitadelRelatedError(
          'verifyTaskQuotationAndReserveTentative response from citadel is invalid',
        );
      }
    } catch (err) {
      throw new CitadelRelatedError(err.toString());
    }
  }

  async reserveTask(
    taskingIds: string[],
    notificationContents: NotificationContents,
  ): Promise<PaymentsDto> {
    // skip
    if (this.config.get('citadelGrpc.skip')) {
      return plainToInstance(PaymentsDto, {
        totalConsumptionCredit: 0,
        remainingCredit: 0,
        results: taskingIds.map((x) => {
          return this.dummyResponse(x, PaymentTaskStatus.RESERVED);
        }),
        verifyResults: taskingIds.map((x) => {
          return this.dummyVerifyResponse(x);
        }),
      } as PaymentsDto);
    }

    const citadelReq =
      toCitadelGrpcSupport.fromNotificationContents(notificationContents);
    this.logger.debug('fetch reserveTask', {
      original: taskingIds,
      converted: citadelReq,
      taskingIds: taskingIds,
    });
    let citadelRes: TaskManipulationReply.AsObject;
    try {
      citadelRes = (
        await this.verificationClient.reserveTask(
          taskingIds,
          TaskDeliveryStatus.RESERVED,
          citadelReq,
        )
      ).toObject();
    } catch (err) {
      this.logger.error('error occurred in reserveTask', err['stack'] || err);
      throw new CitadelError(err.toString());
    }
    this.logger.debug('fetched reserveTask result', { citadelRes });
    try {
      if (citadelRes.isOk) {
        return plainToInstance(PaymentsDto, {
          totalConsumptionCredit: citadelRes.consumptionCredit,
          remainingCredit: citadelRes.remainingQuotation,
          results: citadelRes.resultsList.map((x) =>
            fromCitadelGrpcSupport.toPaymentReplyDto(x),
          ),
          verifyResults: citadelRes.verifyResultsList.map((x) =>
            fromCitadelGrpcSupport.toVerifyItemDto(x),
          ),
        } as PaymentsDto);
      } else {
        this.logger.warn(
          'reserveTask response from citadel is invalid',
          citadelRes,
        );
        throw new CitadelRelatedError(
          'reserveTask response from citadel is invalid',
        );
      }
    } catch (err) {
      throw new CitadelRelatedError(err.toString());
    }
  }

  // https://app.diagrams.net/#G1wQ5O3-4FaLziAag8HPg90dR0O0BwJylo
  async emitTaskResult(
    emitRequests: EmitRequestDto[],
    notificationContents: NotificationContents,
  ) {
    // skip
    if (this.config.get('citadelGrpc.skip')) {
      return emitRequests.map((x) => {
        return this.dummyResponse(x.registrationId, x.status);
      });
    }
    const citadelReq = emitRequests.map((x) =>
      toCitadelGrpcSupport.fromEmitRequestDto(x),
    );
    this.logger.debug('fetch emitTaskResult', {
      original: emitRequests,
      converted: citadelReq,
    });
    let citadelRes;
    try {
      citadelRes = (
        await this.verificationClient.emitTaskResult(
          citadelReq,
          toCitadelGrpcSupport.fromNotificationContents(notificationContents),
        )
      ).toObject();
    } catch (err) {
      this.logger.error(
        'error occurred in emitTaskResult',
        err['stack'] || err,
      );
      throw new CitadelError(err.toString());
    }
    this.logger.debug('fetched emitTaskResult result', { citadelRes });
    try {
      if (citadelRes.isOk) {
        return citadelRes.resultsList.map((x) =>
          fromCitadelGrpcSupport.toPaymentReplyDto(x),
        );
      } else {
        this.logger.warn(
          'emitTaskResult response from citadel is invalid',
          citadelRes,
        );
        throw new CitadelRelatedError(
          'emitTaskResult response from citadel is invalid',
        );
      }
    } catch (err) {
      throw new CitadelRelatedError(err.toString());
    }
  }

  private dummyResponse(taskId: string, status: PaymentTaskStatus) {
    return plainToInstance(PaymentReplyDto, {
      // It is an ID issued by citadel, but it is only issued at the moment and is not used in communication with citadel.
      // Therefore, use an appropriate random number.
      registrationId: Math.floor(Math.random() * (1000000 - 10000)) + 10000,
      taskId,
      status,
      consumptionCredit: 0,
    } as PaymentReplyDto);
  }
  private dummyVerifyResponse(taskId: string) {
    return plainToInstance(VerifyItemDto, {
      taskId,
      consumptionCredit: 0,
      dataSourceType: DataSourceType.ARCHIVE,
      imagingMode: ImagingMode.Stripmap,
      numberOfLicense: 1,
      options: [],
    } as VerifyItemDto);
  }
}
