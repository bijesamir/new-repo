import { Test, TestingModule } from '@nestjs/testing';
import { CitadelGrpcService } from './citadel-grpc.service';
import { LoggerModule } from '@iris-lib/logger';
import { ConfigModule } from '@nestjs/config';
import {
  CitadelGrpcConfigService,
  loadCitadelGrpcConfig,
} from '../config/citadel-grpc-config';

jest.useRealTimers();

describe('CitadelGrpcService', () => {
  let service: CitadelGrpcService;
  let module: TestingModule;
  beforeEach(async () => {
    module = await Test.createTestingModule({
      imports: [
        ConfigModule.forRoot({
          ignoreEnvFile: true,
          load: [loadCitadelGrpcConfig],
        }),
        LoggerModule,
      ],
      providers: [
        {
          provide: 'CitadelGrpcConfig',
          useClass: CitadelGrpcConfigService,
        },
        CitadelGrpcService,
      ],
    }).compile();

    service = module.get<CitadelGrpcService>(CitadelGrpcService);
  });

  afterEach(async () => {
    await module.close();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  }, 15000);
});
