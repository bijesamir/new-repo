import { ConfigModule } from '@nestjs/config';
import { CitadelGrpcService } from './citadel-grpc.service';
import { Module, Global } from '@nestjs/common';
import {
  CitadelGrpcConfigService,
  loadCitadelGrpcConfig,
} from '../config/citadel-grpc-config';

@Global()
@Module({
  imports: [
    ConfigModule.forRoot({
      ignoreEnvFile: true,
      load: [loadCitadelGrpcConfig],
    }),
  ],
  providers: [
    {
      provide: 'CitadelGrpcConfig',
      useClass: CitadelGrpcConfigService,
    },
    CitadelGrpcService,
  ],
  exports: [CitadelGrpcService],
})
export class CitadelGrpcModule {}
