import {
  Claim,
  TokenContext,
  UserIdentityToken,
  VerifyUserIdentityTokenReply,
} from '@syns-platform/citadel-grpc-js';
import { IrisUserRole } from '@iris-lib/constants';
import { fromCitadelGrpcSupport } from './citadel-grpc-support';
import { IrisUserDto } from '@iris-lib/models';
import { plainToInstance } from 'class-transformer';
import { CustomerAccessToken } from '@syns-platform/citadel-grpc-js/build/citadel/types/models/token_pb';
import {
  CustomerAccessTokenClaim,
  VerifyCustomerAccessTokenReply,
} from '@syns-platform/citadel-grpc-js/build/citadel/types/services/verification/verification_pb';

describe('CitadelGrpcSupport', () => {
  // TODO: to be deprecated
  it('toIrisUserDtoWithUserIdentityToken - multiple user role ok', () => {
    const { userIdentityToken, reply, expected } = prepareTest();
    const res = fromCitadelGrpcSupport.toIrisUserDtoWithUserIdentityToken(
      userIdentityToken,
      reply.toObject(),
    );
    expect(res).toEqual(expected);

    function prepareTest() {
      const dummyUserId = 1;
      const dummyCurrentOrganization = 2;
      const dummyOrganizationList = [2, 3, 4];

      const token = new UserIdentityToken();
      token.setUserId(dummyUserId);
      token.setContext(
        new TokenContext().setCurrentOrganization(dummyCurrentOrganization),
      );
      token.setOrganizationsList(dummyOrganizationList);

      const claims = new Claim();
      const dummyRole = 1;
      claims.setRolesList([IrisUserRole.INTERNAL, dummyRole]);
      claims.setToken(token);

      const reply = new VerifyUserIdentityTokenReply();
      reply.setClaims(claims);
      const userIdentityToken = 'AAA';

      const expected = plainToInstance(IrisUserDto, {
        userId: dummyUserId,
        userToken: userIdentityToken,
        roleTypes: [IrisUserRole.INTERNAL],
        currentOrganizationId: dummyCurrentOrganization,
        organizationIds: dummyOrganizationList,
      });

      return { userIdentityToken, reply, expected };
    }
  });

  it('toIrisUserDto - multiple user role ok', () => {
    const { accessToken, reply, expected } = prepareTest();
    const res = fromCitadelGrpcSupport.toIrisUserDto(
      accessToken,
      reply.toObject(),
    );
    expect(res).toEqual(expected);

    function prepareTest() {
      const dummyUserId = 1;
      const dummyCurrentOrganization = 2;
      const dummyOrganizationList = [2, 3, 4];

      const token = new CustomerAccessToken();
      token.setSub(dummyUserId);
      token.setContext(
        new TokenContext().setCurrentOrganization(dummyCurrentOrganization),
      );
      token.setOrganizationsList(dummyOrganizationList);

      const claims = new CustomerAccessTokenClaim();
      const dummyRole = 1;
      claims.setRolesList([IrisUserRole.INTERNAL, dummyRole]);
      claims.setToken(token);

      const reply = new VerifyCustomerAccessTokenReply();
      reply.setClaims(claims);
      const accessToken = 'AAA';

      const expected = plainToInstance(IrisUserDto, {
        userId: dummyUserId,
        userToken: accessToken,
        roleTypes: [IrisUserRole.INTERNAL],
        currentOrganizationId: dummyCurrentOrganization,
        organizationIds: dummyOrganizationList,
      });

      return { accessToken, reply, expected };
    }
  });
});
