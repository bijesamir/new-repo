import { envBooleanValue, envStringValue } from '@iris-lib/utils';
import { Injectable } from '@nestjs/common';
import { ConfigService, Path, PathValue } from '@nestjs/config';

export const loadCitadelHttpConfig = () => {
  return {
    citadelHttp: {
      baseUrl: envStringValue('CITADEL_HTTP_URL'),
      doLogging: envBooleanValue('CITADEL_HTTP_LOGGING', false),
      serviceId: envStringValue('IRIS_SERVICE_ID'),
    },
  };
};

export type CitadelHttpConfig = ReturnType<typeof loadCitadelHttpConfig>;

@Injectable()
export class CitadelHttpConfigService extends ConfigService<
  CitadelHttpConfig,
  true
> {
  // eslint-disable-next-line no-use-before-define
  get<P extends Path<T>, T = CitadelHttpConfig>(arg: P): PathValue<T, P> {
    return super.get<T, P, PathValue<T, P>>(arg, { infer: true });
  }
}
