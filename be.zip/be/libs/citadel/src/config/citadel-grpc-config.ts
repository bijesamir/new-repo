import { envBooleanValue, envStringValue } from '@iris-lib/utils';
import { Injectable } from '@nestjs/common';
import { ConfigService, Path, PathValue } from '@nestjs/config';

export const loadCitadelGrpcConfig = () => {
  return {
    citadelGrpc: {
      host: envStringValue('CITADEL_GRPC_HOST'),
      serverToken: envStringValue('IRIS_SERVER_ID_TOKEN'),
      skip: envBooleanValue('SKIP_CITADEL_PAYMENT_API_CALLS', false),
    },
  };
};

export type CitadelGrpcConfig = ReturnType<typeof loadCitadelGrpcConfig>;

@Injectable()
export class CitadelGrpcConfigService extends ConfigService<
  CitadelGrpcConfig,
  true
> {
  // eslint-disable-next-line no-use-before-define
  get<P extends Path<T>, T = CitadelGrpcConfig>(arg: P): PathValue<T, P> {
    return super.get<T, P, PathValue<T, P>>(arg, { infer: true });
  }
}
