export class CitadelQuotaExceedError extends Error {
  name = 'CitadelQuotaExceedError';
}

export class CitadelError extends Error {
  name = 'CitadelError';
}

export class CitadelRelatedError extends Error {
  name = 'CitadelRelatedError';
}
