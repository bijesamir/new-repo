import { IrisUserRole } from '@iris-lib/constants';

export class IrisUserDto {
  userId: number;

  userToken: string;

  roleTypes: IrisUserRole[];

  currentOrganizationId: number;

  organizationIds: number[];

  // as the backend, we don't need these fields for now.
  // email: string;

  // givenNames: string;

  // surname: string;

  public stringUserId() {
    return this.userId.toString();
  }
}
