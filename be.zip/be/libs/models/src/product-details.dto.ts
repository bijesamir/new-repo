import {
  ProductFormat,
  ProductFormatValues,
  ResolutionMode,
  ResolutionModeAllValues,
} from '@iris-lib/constants';
import { IsIn } from 'class-validator';

export class ProductDetailsDto {
  @IsIn(ProductFormatValues)
  productFormat: ProductFormat;

  @IsIn(ResolutionModeAllValues)
  resolutionMode: ResolutionMode;
}
