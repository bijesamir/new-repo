import {
  AllFlightDirectionValues,
  AllLookingDirectionValues,
  FlightDirection,
  ImagingMode,
  ImagingModeAllValues,
  LookingDirection,
  OrbitType,
  OrbitTypeAllValues,
  PolarizationType,
  PolarizationTypeValues,
  ProductFormat,
  ProductFormatValues,
  ResolutionMode,
  ResolutionModeAllValues,
} from '@iris-lib/constants';
import { Transform, Type } from 'class-transformer';
import {
  IsDate,
  IsIn,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsString,
  Matches,
  ValidateNested,
} from 'class-validator';

class Observation {
  @IsNotEmpty()
  @IsString()
  sceneId: string;

  @IsInt()
  sceneNo: number;

  @IsNotEmpty()
  @IsString()
  @Matches(/ST\d{4}$/)
  satelliteId: string;

  @Transform(({ value }) => new Date(value))
  @IsDate()
  sceneStartDateTime: Date;

  @Transform(({ value }) => new Date(value))
  @IsDate()
  sceneEndDateTime: Date;

  @Transform(({ value }) => new Date(value))
  @IsDate()
  sceneCenterDateTime: Date;

  @IsIn(ImagingModeAllValues)
  imagingMode: ImagingMode;

  @IsIn(PolarizationTypeValues)
  polarization: PolarizationType;

  @IsNumber()
  offnadirAngle: number;

  @IsIn(AllFlightDirectionValues)
  flightDirection: FlightDirection;

  @IsIn(AllLookingDirectionValues)
  lookingDirection: LookingDirection;

  @IsNotEmpty()
  @IsString()
  orderCode: string;
}

class Geometry {
  @IsNotEmpty()
  @IsString()
  sceneCenterLocation: string;

  @IsNotEmpty()
  @IsString()
  sceneCornerLocations: string;
}

class Product {
  @IsNotEmpty()
  @IsString()
  productSoftwareVersion: string;

  @IsIn(ProductFormatValues)
  productFormat: ProductFormat;

  @IsNotEmpty()
  @IsString()
  dataProcessingSoftwareVersion: string;

  @IsIn(OrbitTypeAllValues)
  orbitType: OrbitType;

  @IsNotEmpty()
  @IsString()
  focusSoftwareType: string;

  @IsNotEmpty()
  @IsString()
  focusSoftwareVersion: string;

  @IsIn(ResolutionModeAllValues)
  resolutionMode: ResolutionMode;
}

export class ProductMetadataDto {
  @ValidateNested()
  @Type(() => Observation)
  @IsNotEmpty()
  observation: Observation;

  @ValidateNested()
  @Type(() => Geometry)
  @IsNotEmpty()
  geometry: Geometry;

  @ValidateNested()
  @Type(() => Product)
  @IsNotEmpty()
  product: Product;
}
