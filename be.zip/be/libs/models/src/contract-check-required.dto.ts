import {
  ContractType,
  IrisUserRole,
  IrisUserRoleAllValues,
  IrisUserRoleTaskingValues,
  TaskDeadline,
} from '@iris-lib/constants';
import { Exclude } from 'class-transformer';
import { Validate } from 'class-validator';
import { ApiHideProperty } from '@nestjs/swagger';
import {
  IsValidTaskDeadline,
  IsValidContractWithOrganization,
  IsValidContract,
} from '@iris-lib/validators';

export interface ContractCheckRequiredDto {
  roles: IrisUserRole[];

  contractType: ContractType;
}

export class TaskingContractCheckRequiredDto
  implements ContractCheckRequiredDto
{
  @ApiHideProperty()
  @Exclude()
  roles = IrisUserRoleTaskingValues;

  @ApiHideProperty()
  @Exclude()
  @Validate(IsValidContractWithOrganization)
  contractType = ContractType.Tasking;
}

export class ArchiveContractCheckRequiredDto
  implements ContractCheckRequiredDto
{
  @ApiHideProperty()
  @Exclude()
  roles = IrisUserRoleAllValues;

  @ApiHideProperty()
  @Exclude()
  @Validate(IsValidContract)
  contractType = ContractType.Archive;
}

export class UrgentTaskingContractCheckRequiredDto
  implements ContractCheckRequiredDto
{
  @ApiHideProperty()
  @Exclude()
  roles = IrisUserRoleTaskingValues;

  @ApiHideProperty()
  @Exclude()
  @Validate(IsValidContractWithOrganization)
  contractType = ContractType.Tasking;

  @ApiHideProperty()
  @Exclude()
  @Validate(IsValidTaskDeadline)
  taskingDeadline = TaskDeadline.URGENT;
}
