import {
  FlightDirection,
  ImagingMode,
  LookingDirection,
  OrbitType,
  PolarizationType,
  ProductFormat,
  ResolutionMode,
} from '@iris-lib/constants';
import { plainToClass } from 'class-transformer';
import { validate } from 'class-validator';
import { ProductMetadataDto } from './product-metadata.dto';

describe('ProductMetadataDto Validation', () => {
  let initProductMetadata;

  beforeEach(() => {
    initProductMetadata = {
      observation: {
        sceneId: '<satellite_name>-<scene_center_datetime>',
        sceneNo: 0,
        satelliteId: 'ST0002',
        sceneStartDateTime: '2022-08-21T01:30:44.000Z',
        sceneEndDateTime: '2022-08-21T01:40:44.000Z',
        sceneCenterDateTime: '2022-08-21T01:35:44.000Z',
        imagingMode: ImagingMode.Stripmap,
        polarization: PolarizationType.VV,
        offnadirAngle: -35.36,
        flightDirection: FlightDirection.Ascending,
        lookingDirection: LookingDirection.Right,
        orderCode: '<order_code>',
      },
      geometry: {
        sceneCenterLocation: '-27.35446666895787 -66.67473904120934',
        sceneCornerLocations:
          '-27.300620979817765 -66.79206392164848 -27.44122412677884 -66.76265748962582 -27.408312358097973 -66.55741416077018 -27.267709211136896 -66.58682059279283 -27.300620979817765 -66.79206392164848',
      },
      product: {
        productSoftwareVersion: 'v007.000',
        productFormat: ProductFormat.GRD_GEOTIFF,
        dataProcessingSoftwareVersion: 'v0.10.0',
        orbitType: OrbitType.PR,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.normal,
      },
    };
  });

  it('should be ok', async () => {
    const target = plainToClass(ProductMetadataDto, initProductMetadata);

    const result = await validate(target);
    expect(result).toHaveLength(0);
  });

  it('should be ng (enum values)', async () => {
    initProductMetadata.observation.imagingMode = -1;
    initProductMetadata.observation.polarization = -1;
    initProductMetadata.observation.flightDirection = -1;
    initProductMetadata.observation.lookingDirection = -1;
    initProductMetadata.product.productFormat = -1;
    initProductMetadata.product.orbitType = -1;
    initProductMetadata.product.resolutionMode = -1;
    const target = plainToClass(ProductMetadataDto, initProductMetadata);

    const result = await validate(target);
    // error in "observation" & "product"
    expect(result).toHaveLength(2);
    expect(result[0].children).toHaveLength(4);
    expect(result[1].children).toHaveLength(3);
  });

  it('should be ng (dates)', async () => {
    initProductMetadata.observation.sceneStartDateTime = new Date(
      '2022/08/21T01:30:44Z',
    );
    initProductMetadata.observation.sceneEndDateTime = new Date(
      '202208/21T01:30:44Z',
    );
    initProductMetadata.observation.sceneCenterDateTime = new Date(
      '2022/08/21T01:30:44Z',
    );
    const target = plainToClass(ProductMetadataDto, initProductMetadata);

    const result = await validate(target);
    // error in "observation"
    expect(result).toHaveLength(1);
    expect(result[0].children).toHaveLength(3);
  });

  it('should be ng (sceneNo & offnadirAngle not number)', async () => {
    initProductMetadata.observation.sceneNo = '1';
    initProductMetadata.observation.offnadirAngle = '1.0';
    const target = plainToClass(ProductMetadataDto, initProductMetadata);

    const result = await validate(target);
    // error in "observation"
    expect(result).toHaveLength(1);
    expect(result[0].children).toHaveLength(2);
  });

  it('should be ng (empty strings)', async () => {
    initProductMetadata.observation.sceneId = '';
    initProductMetadata.observation.satelliteId = '';
    initProductMetadata.observation.orderCode = '';
    initProductMetadata.geometry.sceneCenterLocation = '';
    initProductMetadata.geometry.sceneCornerLocations = '';
    initProductMetadata.product.productSoftwareVersion = '';
    initProductMetadata.product.dataProcessingSoftwareVersion = '';
    initProductMetadata.product.focusSoftwareType = '';
    initProductMetadata.product.focusSoftwareVersion = '';
    const target = plainToClass(ProductMetadataDto, initProductMetadata);

    const result = await validate(target);
    // error in "observation", "geometry" & "product"
    expect(result).toHaveLength(3);
    expect(result[0].children).toHaveLength(3);
    expect(result[1].children).toHaveLength(2);
    expect(result[2].children).toHaveLength(4);
  });

  it('should be ng (not strings)', async () => {
    initProductMetadata.observation.sceneId = 1;
    initProductMetadata.observation.satelliteId = 1;
    initProductMetadata.observation.orderCode = 1;
    initProductMetadata.geometry.sceneCenterLocation = 1;
    initProductMetadata.geometry.sceneCornerLocations = 1;
    initProductMetadata.product.productSoftwareVersion = 1;
    initProductMetadata.product.dataProcessingSoftwareVersion = 1;
    initProductMetadata.product.focusSoftwareType = 1;
    initProductMetadata.product.focusSoftwareVersion = 1;
    const target = plainToClass(ProductMetadataDto, initProductMetadata);

    const result = await validate(target);
    // error in "observation", "geometry" & "product"
    expect(result).toHaveLength(3);
    expect(result[0].children).toHaveLength(3);
    expect(result[1].children).toHaveLength(2);
    expect(result[2].children).toHaveLength(4);
  });
});
