import { ApiProperty } from '@nestjs/swagger';
import { plainToClass } from 'class-transformer';
import { ValidationError } from 'class-validator';

export class CustomValidationErrorDto {
  @ApiProperty({ description: 'property name' })
  name: string;

  @ApiProperty({
    description: 'error messages',
  })
  messages: string[];

  @ApiProperty({
    description: 'parent property name',
    required: false,
  })
  parentName?: string;
}

export const getCustomValidationErrors = (errors: ValidationError[]) => {
  return errors.reduce((t, currentError) => {
    if (currentError.children.length > 0) {
      currentError.children.forEach((c) => {
        if (Array.isArray(c.children) && c.children.length > 0) {
          const tmp = c.children.reduce((cp, cc) => {
            const tmp = generateCustomValidationErrorDtos(
              cc,
              `${currentError.property}.${c.property}`,
            );
            cp.push(...tmp);
            return cp;
          }, new Array<CustomValidationErrorDto>());
          t.push(...tmp);
        } else {
          const tmp = generateCustomValidationErrorDtos(c);
          t.push(...tmp);
        }
      });
    } else {
      const tmp = generateCustomValidationErrorDtos(currentError);
      t.push(...tmp);
    }
    return t;
  }, new Array<CustomValidationErrorDto>());
};

const generateCustomValidationErrorDto = (
  error: ValidationError,
  parentName?: string,
) => {
  if (error.constraints && Object.keys(error.constraints).length > 0) {
    const messages = Object.keys(error.constraints).reduce(
      (t, currentProperty) => {
        t.push(error.constraints[currentProperty]);
        return t;
      },
      new Array<string>(),
    );
    return plainToClass(CustomValidationErrorDto, {
      name: error.property,
      messages: messages,
      parentName: parentName,
    });
  } else {
    return null;
  }
};

const generateCustomValidationErrorDtos = (
  error: ValidationError,
  parentName?: string,
) => {
  const rtn = generateCustomValidationErrorDto(error, parentName);
  if (!rtn) {
    const a = error.children.reduce((p, c) => {
      const tmp = generateCustomValidationErrorDto(
        c,
        `${parentName}.${error.property}`,
      );
      if (tmp) {
        p.push(tmp);
      } else {
        //console.warn('Unexpected errors may occur');
      }
      return p;
    }, new Array<CustomValidationErrorDto>());
    return a;
  }
  return [rtn];
};
