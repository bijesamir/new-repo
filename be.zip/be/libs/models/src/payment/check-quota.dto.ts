import {
  DeliveryTimeKind,
  TaskingPriorityKind,
  ImagingMode,
  DataSourceType,
  TaskingType,
  getResolutionMode,
  getProductFormat,
  ProductType,
} from '@iris-lib/constants';
import { TaskingInfo } from '@iris-lib/db/entities';
import { plainToInstance } from 'class-transformer';
import { IrisContractPackage } from './iris-contract.dto';
import { ProductDetailsDto } from '../product-details.dto';
import { OrderItemProductType } from 'apps/backend/src/models/dto/order/order-create.dto';

export class CheckQuotaDto {
  id: string;
  dataSourceType: DataSourceType;
  imagingMode: ImagingMode;
  taskingType: TaskingType;
  scene: number;
  productDetails: ProductDetailsDto[];
  deliveryTimeKind: DeliveryTimeKind;
  taskPriorityKind: TaskingPriorityKind;
}

export const fromTaskingInfoAndContractPackage = (
  src: TaskingInfo,
  contract: IrisContractPackage,
): CheckQuotaDto => {
  // deliveryTimeKind and taskPriorityKind are specified from contract. In the future, users will select them when register tasking.
  // So, set these parameter from iris to citadel.
  return plainToInstance(CheckQuotaDto, {
    id: src.id,
    dataSourceType: DataSourceType.NEW,
    imagingMode: src.imagingMode,
    taskingType: src.taskingType,
    scene: src.scenes,
    productDetails: src.productDetails,
    deliveryTimeKind: contract.deliveryTimeKind,
    taskPriorityKind: contract.taskingPriorityKind,
  } as CheckQuotaDto);
};

export const fromArchiveOrder = (
  src: OrderItemProductType,
  itemId: string,
  dataSourceType: DataSourceType,
  ti: TaskingInfo,
): CheckQuotaDto => {
  return plainToInstance(CheckQuotaDto, {
    id: itemId,
    dataSourceType,
    imagingMode: ti.imagingMode,
    taskingType: TaskingType.Regular,
    scene: 1,
    productDetails: src.productDetails.map((p: ProductType) =>
      plainToInstance(ProductDetailsDto, {
        productFormat: getProductFormat(p),
        resolutionMode: getResolutionMode(p),
      } as ProductDetailsDto),
    ),
    deliveryTimeKind: DeliveryTimeKind.STANDARD,
    taskPriorityKind: TaskingPriorityKind.STANDARD,
  } as CheckQuotaDto);
};
