import {
  DeliveryMethod,
  TaskingPriorityKind,
  DeliveryTimeKind,
  TaskDeadline,
  CatalogDelayKind,
} from '@iris-lib/constants';
export class IrisContractPackage {
  contractId: number;
  organizationId: number;
  serviceId: number;
  catalogDelayKind: CatalogDelayKind;
  startAt: Date;
  endAt: Date;
  packageId: number;
  packageName: string;
  isInternal: boolean;
  availableTasking: boolean;
  availableArchivePurchase: boolean;
  canAccessTaskingConsole: boolean;
  deliveryMode: DeliveryMethod;
  deliveryTimeKind: DeliveryTimeKind;
  taskingPriorityKind: TaskingPriorityKind;
  taskDeadline: TaskDeadline;
}
