import { ProductFormat, ResolutionMode } from '@iris-lib/constants';
import { PaymentTaskStatus } from '@iris-lib/constants/payment-task-status';

export class ProcessingSuccessResult {
  productDataVersionId: string;
  productFormat: ProductFormat;
  resolutionMode: ResolutionMode;
}

export class ProcessingFailureResult {
  sceneNo: number; // sceneNo of the product
  productFormat: ProductFormat;
  resolutionMode: ResolutionMode;
}

export class EmitRequestDto {
  registrationId: string;
  isRushDelivery: boolean;
  status: PaymentTaskStatus;
  processingSuccessList?: ProcessingSuccessResult[];
  processingFailureList?: ProcessingFailureResult[];
}
