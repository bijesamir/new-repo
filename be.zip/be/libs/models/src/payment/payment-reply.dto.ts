import { PaymentTaskStatus } from '@iris-lib/constants/payment-task-status';
import { ImagingMode, DataSourceType } from '@iris-lib/constants';

export class PaymentReplyDto {
  registrationId: number;
  taskId: string;
  status: PaymentTaskStatus;
  consumptionCredit: number;
}

export class VerifyItemDto {
  taskId: string;
  itemId?: string;
  previouslyOrdered?: boolean;
  consumptionCredit: number;
  dataSourceType: DataSourceType;
  imagingMode: ImagingMode;
  numberOfLicense: number;
  options: string[];
}

export enum VerifyStatus {
  OK = 'ok',
  INSUFFICIENT = 'The balance is insufficient',
}

export class PaymentsDto {
  totalConsumptionCredit: number;
  remainingCredit: number;
  results?: PaymentReplyDto[];
  verifyStatus?: VerifyStatus;
  verifyResults: VerifyItemDto[];
}
