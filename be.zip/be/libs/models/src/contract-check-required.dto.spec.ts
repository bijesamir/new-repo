import { IrisRequestContext } from '@iris-lib/middlewares';
import { mockIrisRequestContext_get } from '../../../apps/backend/test/utils';
import { plainToClass } from 'class-transformer';
import { UrgentTaskingContractCheckRequiredDto } from './contract-check-required.dto';
import { validate } from 'class-validator';
import {
  TEST_CONTRACT_ID,
  TEST_ORGANIZATION_ID,
  TEST_REGULAR_TASK_CONTRACT_ID,
} from '@iris-lib/constants';
import { DUMMY_USER, DUMMY_CONTRACTS } from '@iris-lib/guards';

describe('ContractCheckRequiredDto', () => {
  beforeAll(async () => {
    IrisRequestContext.get = mockIrisRequestContext_get(
      DUMMY_USER,
      DUMMY_CONTRACTS,
    );
  });

  describe('UrgentContract', () => {
    it('ok urgent contract', async () => {
      const target = plainToClass(UrgentTaskingContractCheckRequiredDto, {
        contractId: TEST_CONTRACT_ID,
        organizationId: TEST_ORGANIZATION_ID,
      });
      const result = await validate(target);
      expect(result).toHaveLength(0);
    });
    it('ng not urgent contract', async () => {
      const target = plainToClass(UrgentTaskingContractCheckRequiredDto, {
        contractId: TEST_REGULAR_TASK_CONTRACT_ID,
        organizationId: TEST_ORGANIZATION_ID,
      });
      const result = await validate(target);
      expect(result).toHaveLength(1);
    });
    it('ng invalid contract', async () => {
      const target = plainToClass(UrgentTaskingContractCheckRequiredDto, {
        contractId: 99999,
        organizationId: TEST_ORGANIZATION_ID,
      });
      const result = await validate(target);
      expect(result).toHaveLength(2);
    });
  });
});
