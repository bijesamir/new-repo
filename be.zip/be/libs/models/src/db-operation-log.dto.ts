export const DbOperationLogEvent = {
  Insert: 'insert',
  Update: 'update',
  Remove: 'remove',
  SoftRemove: 'soft-remove',
  Recover: 'recover',
};

export type DbOperationLogEventType =
  (typeof DbOperationLogEvent)[keyof typeof DbOperationLogEvent];

export class DbOperationLogDto {
  type = 'db';
  application: string;
  requestId: string;
  event: DbOperationLogEventType;
  table: string;
  organizationId: string;
  userId: string;
  row: any;
}
