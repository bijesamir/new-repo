import { IsArray, IsIn, IsNumber } from 'class-validator';
import {
  AllFlightDirectionValues,
  AllLookingDirectionValues,
  FlightDirection,
  ImagingMode,
  ImagingModeAllValues,
  LookingDirection,
  TaskingType,
  TaskingTypeAllValues,
} from '@iris-lib/constants';
import { ApiProperty } from '@nestjs/swagger';

export class SatelliteParameterDto {
  @IsIn(ImagingModeAllValues)
  imagingMode: ImagingMode;

  @ApiProperty({
    isArray: true,
    enum: TaskingTypeAllValues,
    example: TaskingTypeAllValues,
  })
  @IsArray()
  @IsIn(TaskingTypeAllValues, { each: true })
  taskingType: TaskingType[];

  @ApiProperty({
    isArray: true,
    enum: AllFlightDirectionValues,
    example: AllFlightDirectionValues,
  })
  @IsArray()
  @IsIn(AllFlightDirectionValues, { each: true })
  flightDirection: FlightDirection[];

  @ApiProperty({
    isArray: true,
    enum: AllLookingDirectionValues,
    example: AllLookingDirectionValues,
  })
  @IsArray()
  @IsIn(AllLookingDirectionValues, { each: true })
  lookingDirection: LookingDirection[];

  @IsNumber()
  offnadirUpperLimit: number;

  @IsNumber()
  offnadirLowerLimit: number;
}
