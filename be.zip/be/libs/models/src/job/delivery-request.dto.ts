import {
  AllIsNotificationAvailableValues,
  IsNotificationAvailable,
} from '@iris-lib/constants';
import { Type } from 'class-transformer';
import {
  IsIn,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsPositive,
  IsString,
  IsUUID,
} from 'class-validator';

export class DeliveryRequestDto {
  @IsUUID(4)
  @IsString()
  productDataVersionId: string;

  @IsPositive()
  @IsNumber()
  @IsNotEmpty()
  @Type(() => Number)
  organizationId: number;

  @IsPositive()
  @IsNumber()
  @IsNotEmpty()
  @Type(() => Number)
  contractId: number;

  @IsPositive()
  @IsNumber()
  @IsOptional()
  @Type(() => Number)
  priority?: number;

  @IsIn(AllIsNotificationAvailableValues)
  @Type(() => Number)
  isNotificationAvailable: IsNotificationAvailable;
}
