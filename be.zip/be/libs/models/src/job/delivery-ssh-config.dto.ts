import SSHConfig from 'ssh2-promise/lib/sshConfig';

export class DeliverySshConfigDto {
  dest: string;

  options: SSHConfig | SSHConfig[];
}
