export class WorkerResponseDto {
  dest: string;
  duration: string;
  size: number;
}
