import { DeliveryConfig } from '@iris-lib/db/entities';
import { OmitType } from '@nestjs/swagger';
import { DeliveryRequestDto } from './delivery-request.dto';

export class WorkerRequestDto extends OmitType(
  DeliveryRequestDto,
  [] as const,
) {
  deliveryConfig: DeliveryConfig;

  bucket: string;

  path: string;

  deliveryRequestId: string;
}
