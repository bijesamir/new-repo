import { CanActivate, ExecutionContext } from '@nestjs/common';
import {
  getTestAnotherContractIdForFixture,
  getTestAnotherOrganizationIdForFixture,
  getTestAnotherUserIdForFixture,
  getTestContractIdForFixture,
  getTestOrganizationIdForFixture,
  getTestRegularTaskContractIdForFixture,
  getTestServiceIdForFixture,
  getTestUserIdForFixture,
} from '@iris-lib/constants/test-support';
import { plainToInstance } from 'class-transformer';
import { IrisRequest } from '@iris-lib/middlewares';
import { IrisUserDto } from '@iris-lib/models';
import { LoggerWrapper } from '@iris-lib/logger';
import {
  DeliveryMethod,
  IrisUserRole,
  TaskDeadline,
  DeliveryTimeKind,
  TaskingPriorityKind,
  CatalogDelayKind,
} from '@iris-lib/constants';

import { parseJSON, add } from 'date-fns';
import { IrisContractPackage } from '@iris-lib/models/payment';

export const DUMMY_USER = plainToInstance(IrisUserDto, {
  userId: parseInt(getTestUserIdForFixture()),
  userToken: 'DUMMY',
  roleTypes: [IrisUserRole.ADMINISTRATOR],
  organizationIds: [91],
  //organizationIds: [getTestOrganizationIdForFixture()],
  currentOrganizationId: 91,
  //currentOrganizationId: getTestOrganizationIdForFixture(),
} as IrisUserDto);

export const DUMMY_CONTRACTS: IrisContractPackage[] = [
  plainToInstance(IrisContractPackage, {
    //contractId: getTestContractIdForFixture(),
    //organizationId: getTestOrganizationIdForFixture(),
    contractId: 124,
    organizationId: 91,
    serviceId: getTestServiceIdForFixture(),
    catalogDelayKind: CatalogDelayKind.NO_DELAY,
    startAt: parseJSON('2023-01-01T00:00:00.000Z'),
    endAt: add(parseJSON('2023-01-01T00:00:00.000Z'), { years: 100 }),
    packageId: 1,
    packageName: 'dummy 1',
    isInternal: true,
    availableTasking: true,
    availableArchivePurchase: true,
    canAccessTaskingConsole: true,
    deliveryMode: DeliveryMethod.SFTP,
    deliveryTimeKind: DeliveryTimeKind.RUSH,
    taskingPriorityKind: TaskingPriorityKind.HIGH,
    taskDeadline: TaskDeadline.URGENT,
  } as IrisContractPackage),
  plainToInstance(IrisContractPackage, {
    contractId: getTestRegularTaskContractIdForFixture(),
    organizationId: getTestOrganizationIdForFixture(),
    serviceId: getTestServiceIdForFixture(),
    catalogDelayKind: CatalogDelayKind.PERMANENT,
    startAt: parseJSON('2023-01-01T00:00:00.000Z'),
    endAt: add(parseJSON('2023-01-01T00:00:00.000Z'), { years: 100 }),
    packageId: 2,
    packageName: 'dummy 2',
    isInternal: true,
    availableTasking: true,
    availableArchivePurchase: true,
    canAccessTaskingConsole: true,
    deliveryMode: DeliveryMethod.SFTP,
    deliveryTimeKind: DeliveryTimeKind.RUSH,
    taskingPriorityKind: TaskingPriorityKind.HIGH,
    taskDeadline: TaskDeadline.STANDARD,
  } as IrisContractPackage),
];

export const DUMMY_CONTRACTS_FOR_GENERAL_DATA_CUSTOMER: IrisContractPackage[] =
  [
    plainToInstance(IrisContractPackage, {
      contractId: getTestContractIdForFixture(),
      organizationId: getTestOrganizationIdForFixture(),
      serviceId: getTestServiceIdForFixture(),
      catalogDelayKind: CatalogDelayKind.NO_DELAY,
      startAt: parseJSON('2023-01-01T00:00:00.000Z'),
      endAt: add(parseJSON('2023-01-01T00:00:00.000Z'), { years: 100 }),
      packageId: 1,
      packageName: 'dummy 1',
      isInternal: true,
      availableTasking: true,
      availableArchivePurchase: true,
      canAccessTaskingConsole: false,
      deliveryMode: DeliveryMethod.SFTP,
      deliveryTimeKind: DeliveryTimeKind.RUSH,
      taskingPriorityKind: TaskingPriorityKind.HIGH,
      taskDeadline: TaskDeadline.URGENT,
    } as IrisContractPackage),
  ];

export const DUMMY_ANOTHER_USER = plainToInstance(IrisUserDto, {
  userId: parseInt(getTestAnotherUserIdForFixture()),
  userToken: 'DUMMY',
  roleTypes: [IrisUserRole.ADMINISTRATOR],
  organizationIds: [getTestAnotherOrganizationIdForFixture()],
  currentOrganizationId: getTestAnotherOrganizationIdForFixture(),
} as IrisUserDto);

export const DUMMY_ANOTHER_CONTRACTS: IrisContractPackage[] = [
  plainToInstance(IrisContractPackage, {
    contractId: getTestAnotherContractIdForFixture(),
    organizationId: getTestAnotherOrganizationIdForFixture(),
    serviceId: getTestServiceIdForFixture(),
    catalogDelayKind: CatalogDelayKind.NO_DELAY,
    startAt: parseJSON('2023-01-01T00:00:00.000Z'),
    endAt: add(parseJSON('2023-01-01T00:00:00.000Z'), { years: 100 }),
    packageId: 1,
    packageName: 'dummy 1',
    isInternal: true,
    availableTasking: true,
    availableArchivePurchase: true,
    canAccessTaskingConsole: true,
    deliveryMode: DeliveryMethod.SFTP,
    deliveryTimeKind: DeliveryTimeKind.RUSH,
    taskingPriorityKind: TaskingPriorityKind.HIGH,
    taskDeadline: TaskDeadline.URGENT,
  } as IrisContractPackage),
];

/**
 * guard for development. <br/>
 * Set up a do-anything user for development.<br/>
 */
export class DummyAuthGuard implements CanActivate {
  private logger = new LoggerWrapper(DummyAuthGuard.name);
  private static dummyUser = DUMMY_USER;
  private static dummyContracts = DUMMY_CONTRACTS;

  static setDummy(user: IrisUserDto, contracts: IrisContractPackage[]) {
    DummyAuthGuard.dummyUser = user;
    DummyAuthGuard.dummyContracts = contracts;
  }

  async canActivate(context: ExecutionContext) {
    const req = context.switchToHttp().getRequest() as IrisRequest;
    req.currentUser = DummyAuthGuard.dummyUser;
    req.currentContracts = DummyAuthGuard.dummyContracts;

    return true;
  }
}
