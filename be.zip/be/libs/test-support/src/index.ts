import { DbConfigModule, DbConfigService } from '@iris-lib/db';
import { DbOperationLogSubscriber } from '@iris-lib/db/subscribers';
import { CustomExceptionFilter } from '@iris-lib/filters';
import { LoggerModule } from '@iris-lib/logger';
import { AppConfigModuleBase } from '@iris-lib/utils';
import { ModuleMetadata, Type } from '@nestjs/common';
import { APP_FILTER } from '@nestjs/core';
import { TypeOrmModule, TypeOrmModuleOptions } from '@nestjs/typeorm';

import { DataSource } from 'typeorm';

export type MockType<T> = {
  // eslint-disable-next-line @typescript-eslint/ban-types
  [P in keyof T]?: jest.Mock<{}>;
};

export const dataSourceMockFactory: () => MockType<DataSource> = jest.fn(
  () => ({
    createQueryRunner: jest.fn().mockImplementation(() => ({
      connect: jest.fn(),
      startTransaction: jest.fn(),
      release: jest.fn(),
      rollbackTransaction: jest.fn(),
      manager: {
        insert: jest.fn(),
        update: jest.fn(),
        delete: jest.fn(),
        softRemove: jest.fn(),
      },
    })),
  }),
);

export const mockRepo = {
  metadata: {
    connection: {
      options: { type: '' },
    },
    columns: [{ propertyName: 'id', isPrimary: true }],
    relations: [],
  },
};

export const testModuleDataSourceMockBase = (
  setAppConfig: () => Type<AppConfigModuleBase>,
): ModuleMetadata => {
  return {
    imports: [setAppConfig(), LoggerModule],
    providers: [
      {
        provide: DataSource,
        useFactory: dataSourceMockFactory,
      },
    ],
    controllers: [],
    exports: [],
  };
};

export function testModuleBase(
  setAppConfig: () => Type<AppConfigModuleBase>,
): ModuleMetadata {
  return {
    imports: [
      setAppConfig(),
      DbConfigModule,
      LoggerModule,
      TypeOrmModule.forRootAsync({
        inject: ['DbConfig'],
        useFactory: async (configService: DbConfigService) => {
          return configService.get('db') as TypeOrmModuleOptions;
        },
      }),
    ],
    providers: [
      {
        provide: APP_FILTER,
        useFactory: () => {
          return new CustomExceptionFilter('NONE');
        },
      },
      DbOperationLogSubscriber,
    ],
    controllers: [],
  };
}
