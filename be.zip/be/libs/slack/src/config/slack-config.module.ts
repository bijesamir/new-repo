import { Module } from '@nestjs/common';
import { SlackNotificationConfigService } from './slack-notification-config';

@Module({
  providers: [SlackNotificationConfigService],
  exports: [SlackNotificationConfigService],
})
export class SlackConfigModule {}
