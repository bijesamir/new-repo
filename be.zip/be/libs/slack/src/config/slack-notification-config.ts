import { envBooleanValue, envStringValue } from '@iris-lib/utils';
import { Injectable } from '@nestjs/common';
import { ConfigService, Path, PathValue } from '@nestjs/config';

export const loadSlackNotificationConfig = () => {
  return {
    slackNotification: {
      mentions: process.env.SLACK_NOTIFICATION_MENTIONS, // optional
      channels: {
        defaultUrl: envStringValue(
          'SLACK_NOTIFICATION_DEFAULT_CHANNEL_URL',
          'NONE',
        ),
        urgentTaskingUrl: envStringValue(
          'SLACK_NOTIFICATION_URGENTTASKING_CHANNEL_URL',
          'NONE',
        ),
        archiveUrl: envStringValue(
          'SLACK_NOTIFICATION_ARCHIVE_CHANNEL_URL',
          'NONE',
        ),
      },
      skip: envBooleanValue('SKIP_SLACK_NOTIFICATION', true),
    },
  };
};

export type SlackNotificationConfig = ReturnType<
  typeof loadSlackNotificationConfig
>;

@Injectable()
export class SlackNotificationConfigService extends ConfigService<
  SlackNotificationConfig,
  true
> {
  // eslint-disable-next-line no-use-before-define
  get<P extends Path<T>, T = SlackNotificationConfig>(arg: P): PathValue<T, P> {
    return super.get<T, P, PathValue<T, P>>(arg, { infer: true });
  }
}
