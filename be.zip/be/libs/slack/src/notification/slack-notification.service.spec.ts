import { Test, TestingModule } from '@nestjs/testing';
import { SlackNotificationService } from './slack-notification.service';
import { LoggerModule } from '@iris-lib/logger';
import { ConfigModule } from '@nestjs/config';
import {
  SlackNotificationConfigService,
  loadSlackNotificationConfig,
} from '../config/slack-notification-config';
import { SlackModule } from 'nestjs-slack';

describe('SlackNotificationService', () => {
  let module: TestingModule;
  let service: SlackNotificationService;

  beforeEach(async () => {
    module = await Test.createTestingModule({
      imports: [
        ConfigModule.forRoot({
          ignoreEnvFile: true,
          load: [loadSlackNotificationConfig],
        }),
        SlackModule.forRootAsync({
          useFactory: () => {
            return {
              type: 'webhook',
              channels: [
                {
                  name: 'default',
                  url: 'none',
                },
              ],
            };
          },
        }),
        LoggerModule,
      ],
      providers: [
        {
          provide: 'SlackNotificationConfig',
          useClass: SlackNotificationConfigService,
        },
        SlackNotificationService,
      ],
    }).compile();

    service = module.get<SlackNotificationService>(SlackNotificationService);
  });

  afterEach(async () => {
    await module.close();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
