import { Global, Module } from '@nestjs/common';
import { SlackNotificationService } from './slack-notification.service';
import { SlackModule } from 'nestjs-slack';
import { ConfigModule } from '@nestjs/config';
import {
  SlackNotificationConfigService,
  loadSlackNotificationConfig,
} from '../config/slack-notification-config';
import { SlackConfigModule } from '../config/slack-config.module';
import { SlackChannel } from '../models/dtos/slack-message.dto';

@Global()
@Module({
  imports: [
    ConfigModule.forRoot({
      ignoreEnvFile: true,
      load: [loadSlackNotificationConfig],
    }),
    SlackModule.forRootAsync({
      imports: [SlackConfigModule],
      inject: [SlackNotificationConfigService],
      useFactory: (configService: SlackNotificationConfigService) => {
        return {
          type: 'webhook',
          channels: [
            {
              name: SlackChannel.DEFAULT,
              url: configService.get('slackNotification.channels.defaultUrl'),
            },
            {
              name: SlackChannel.URGENTTASKING,
              url: configService.get(
                'slackNotification.channels.urgentTaskingUrl',
              ),
            },
            {
              name: SlackChannel.ARCHIVE,
              url: configService.get('slackNotification.channels.archiveUrl'),
            },
          ],
          defaultChannel: SlackChannel.DEFAULT,
        };
      },
    }),
  ],
  providers: [
    {
      provide: 'SlackNotificationConfig',
      useClass: SlackNotificationConfigService,
    },
    SlackNotificationService,
  ],
  exports: [SlackNotificationService],
})
export class SlackNotificationModule {}
