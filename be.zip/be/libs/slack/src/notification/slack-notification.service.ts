import { LoggerWrapper } from '@iris-lib/logger';
import { Inject, Injectable } from '@nestjs/common';
import { SlackService } from 'nestjs-slack';
import { SlackNotificationConfigService } from '../config/slack-notification-config';
import { SlackMessage } from '../models/dtos/slack-message.dto';

@Injectable()
export class SlackNotificationService {
  private logger = new LoggerWrapper(SlackNotificationService.name);

  mentions: string[] = [];

  constructor(
    @Inject('SlackNotificationConfig')
    private readonly config: SlackNotificationConfigService,
    private readonly slackService: SlackService,
  ) {
    this.mentions = this.config.get('slackNotification.mentions')
      ? this.config
          .get('slackNotification.mentions')
          .split(',')
          .filter(
            (user) =>
              (user.startsWith('<@') || user.startsWith('<!')) &&
              user.endsWith('>'),
          )
      : [];
    this.logger.debug('slack mentioned users', this.mentions);
  }

  async send(message: SlackMessage) {
    if (this.config.get('slackNotification.skip')) {
      this.logger.debug('slack notification disabled', {
        messageType: message.constructor.name,
        details: message.payload,
      });
      return;
    }
    if (!message.shouldNotify) {
      this.logger.debug('non-notifiable message, skipping slack notification', {
        messageType: message.constructor.name,
        details: message.payload,
      });
      return;
    }

    if (message.options.shouldMention) {
      message.mentions = this.mentions;
    }

    try {
      this.logger.debug('sending slack notification', {
        messageType: message.constructor.name,
        details: message.payload,
      });
      return await this.slackService.postMessage(message.generate());
    } catch (e) {
      this.logger.error('error slack notification', e['stack'] || e, {
        messageType: message.constructor.name,
        details: message.payload,
      });
      // skip throwing slack notification error
    }
  }
}
