export const getSlackColorCode = (name?: string) => {
  switch (name) {
    case 'good':
      return '#2DAF7D';
    case 'warning':
      return '#D4963D';
    case 'danger':
      return '#98090D';
    default:
      return '#2F3033';
  }
};
