export const getSlackSymbol = (name?: string) => {
  switch (name) {
    case 'good':
      return ':white_check_mark:';
    case 'warning':
      return ':information_source:';
    case 'danger':
      return ':warning:';
    default:
      return '';
  }
};
