import { Module, OnModuleDestroy } from '@nestjs/common';
import { LoggerService } from './logger.service';
import { ConfigModule } from '@nestjs/config';
import { LoggerConfigService, loadLoggerConfig } from './logger-config';

@Module({
  imports: [
    ConfigModule.forRoot({
      // .envよみこまない
      ignoreEnvFile: true,
      // 設定ファイル指定
      load: [loadLoggerConfig],
    }),
  ],

  providers: [
    {
      provide: 'LoggerConfig',
      useClass: LoggerConfigService,
    },
    LoggerService,
  ],
  exports: ['LoggerConfig', LoggerService],
})
export class LoggerModule implements OnModuleDestroy {
  constructor(readonly loggerService: LoggerService) {}

  public onModuleDestroy(): any {
    this.loggerService.close();
  }
}
