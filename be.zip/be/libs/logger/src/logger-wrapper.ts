import { Logger } from '@nestjs/common';

export class LoggerWrapper {
  private logger: Logger;
  constructor(context: string) {
    this.logger = new Logger(context);
  }

  debug(message: string, others?: any) {
    this.logger.debug({ message, ...others });
  }

  log(message: string, others?: any) {
    if (!message || message.length < 1) {
      this.logger.log({ ...others });
    } else {
      this.logger.log({ message, ...others });
    }
  }

  info(message: string, others?: any) {
    this.log(message, others);
  }

  recorder(data: any) {
    this.log(null, data);
  }

  warn(message: string, others?: any) {
    this.logger.warn({ message, ...others });
  }

  error(message: string, trace?: string, others?: any) {
    this.logger.error({ message, ...others }, trace);
  }
}
