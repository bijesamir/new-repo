import { envBooleanValue, envStringValue } from '@iris-lib/utils';
import { Injectable } from '@nestjs/common';
import { ConfigService, Path, PathValue } from '@nestjs/config';

export const loadLoggerConfig = () => {
  return {
    level: envStringValue('LOG_LEVEL', 'debug').toLocaleLowerCase(),
    silent: envBooleanValue('LOG_SILENT', false),
    env: envStringValue('NODE_ENV', 'development'),
  };
};

export type LoggerConfig = ReturnType<typeof loadLoggerConfig>;

@Injectable()
export class LoggerConfigService extends ConfigService<LoggerConfig, true> {
  // eslint-disable-next-line no-use-before-define
  get<P extends Path<T>, T = LoggerConfig>(arg: P): PathValue<T, P> {
    return super.get<T, P, PathValue<T, P>>(arg, { infer: true });
  }
}
