import { Injectable, Scope, ConsoleLogger, Inject } from '@nestjs/common';
import * as winston from 'winston';
import * as os from 'os';
import { LoggerConfigService } from './logger-config';

@Injectable({ scope: Scope.DEFAULT })
export class LoggerService extends ConsoleLogger {
  private logger: winston.Logger;

  constructor(
    @Inject('LoggerConfig') private readonly config: LoggerConfigService,
  ) {
    super();
    this.logger = winston.createLogger({
      level: this.config.get('level'),
      silent: this.config.get('silent'),
      format: winston.format.combine(
        winston.format.timestamp({ alias: 'time' }),
        winston.format((info) => {
          if (info.timestamp) {
            delete info.timestamp;
          }
          return info;
        })(),
        winston.format.splat(),
        winston.format.errors({ stack: true }),
        winston.format.json(),
      ),
      transports: [new winston.transports.Console()],
      defaultMeta: {
        type: 'application',
        environment: process.env.NODE_ENV,
        hostname: os.hostname(),
      },
    });
  }

  private record(
    log: winston.LeveledLogMethod,
    message: any,
    context?: string,
    trace?: string,
  ) {
    if (typeof message === 'string') {
      log(message, { context, trace });
    } else {
      log(undefined, { context, trace, ...message });
    }
  }

  log(message: any, context?: string) {
    this.record(this.logger.info, message, context);
  }

  error(message: any, trace?: string, context?: string) {
    this.record(this.logger.error, message, context, trace);
  }

  warn(message: any, context?: string) {
    this.record(this.logger.warn, message, context);
  }

  debug(message: any, context?: string) {
    this.record(this.logger.debug, message, context);
  }

  verbose(message: any, context?: string) {
    this.record(this.logger.verbose, message, context);
  }

  close() {
    this.logger.close();
  }
}
