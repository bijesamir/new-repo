import {
  Catch,
  ExceptionFilter,
  ArgumentsHost,
  HttpException,
  InternalServerErrorException,
  UnauthorizedException,
  NotFoundException,
  ForbiddenException,
} from '@nestjs/common';
import { EntityNotFoundError } from 'typeorm/error/EntityNotFoundError';
import { Response } from 'express';
import { LoggerWrapper } from '@iris-lib/logger';
import { IrisRequestContext } from '@iris-lib/middlewares';
import { ApiExtraModels, ApiProperty, getSchemaPath } from '@nestjs/swagger';
import { CustomValidationErrorDto } from '@iris-lib/models/errors/custom-validation-error';
import { CitadelQuotaExceedError } from '@iris-lib/citadel/models';

@ApiExtraModels(CustomValidationErrorDto)
export class ErrorResponse {
  @ApiProperty({ description: 'http response status' })
  statusCode: number;

  @ApiProperty({
    oneOf: [
      { type: 'string' },
      {
        type: 'array',
        items: { $ref: getSchemaPath(CustomValidationErrorDto) },
      },
    ],
  })
  message: string | CustomValidationErrorDto[];

  @ApiProperty({
    description: 'error summary',
    required: false,
  })
  error?: string;
}

/**
 * Custom exception filter to convert EntityNotFoundError from TypeOrm to NestJs responses
 * @see also @https://docs.nestjs.com/exception-filters
 */
@Catch(EntityNotFoundError, Error)
export class CustomExceptionFilter implements ExceptionFilter {
  logger = new LoggerWrapper(CustomExceptionFilter.name);

  constructor(private loginPageUrl: string) {}

  public catch(exception: Error, host: ArgumentsHost) {
    const reqCtx = IrisRequestContext.get()?.req;

    if (
      exception instanceof EntityNotFoundError ||
      exception instanceof UnauthorizedException ||
      exception instanceof ForbiddenException ||
      exception instanceof CitadelQuotaExceedError ||
      (exception instanceof HttpException && exception.getStatus() < 500)
    ) {
      this.logger.warn(`error occurred: ${exception.message}`, {
        exception,
        requestId: reqCtx?.requestId,
      });
    } else {
      this.logger.error(
        `error occurred: ${exception.message}`,
        exception.stack,
        {
          exception,
          requestId: reqCtx?.requestId,
        },
      );
    }

    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    if (exception instanceof EntityNotFoundError) {
      return response.status(404).json(new NotFoundException().getResponse());
    } else if (exception instanceof UnauthorizedException) {
      if (this.loginPageUrl && this.loginPageUrl != 'NONE') {
        return response
          .status(exception.getStatus())
          .redirect(
            `${this.loginPageUrl}?redirect=${ctx.getRequest().originalUrl}`,
          );
      } else {
        return response
          .status(exception.getStatus())
          .json(exception.getResponse());
      }
    } else if (exception instanceof HttpException) {
      const tmp = exception.getResponse();
      return response.status(exception.getStatus()).json(tmp);
    } else if (exception instanceof CitadelQuotaExceedError) {
      return response.status(400).json({
        error: exception.name,
        message: exception.message,
      });
    } else {
      if (ctx.getRequest().query['showDetailError']) {
        return response.status(500).json({
          error: exception.name,
          message: exception.message,
        });
      } else {
        return response
          .status(500)
          .json(new InternalServerErrorException().getResponse());
      }
    }
  }
}
