import { LoggerWrapper } from '@iris-lib/logger';
import {
  Catch,
  ArgumentsHost,
  BadRequestException,
  RpcExceptionFilter,
} from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import { Observable, throwError } from 'rxjs';

@Catch()
export class GcPubsubExceptionFilter
  implements RpcExceptionFilter<RpcException>
{
  private logger = new LoggerWrapper(GcPubsubExceptionFilter.name);

  catch(exception: any, host: ArgumentsHost): Observable<any> {
    if (exception instanceof BadRequestException) {
      const message = host.switchToRpc();
      this.logger.warn(`validation failed`, {
        exception,
        data: message.getData(),
        pattern: message.getContext().getPattern(),
      });
    } else {
      this.logger.error(
        `error occurred: ${exception.message}`,
        exception.stack,
        {
          exception,
        },
      );
    }
    return throwError(() => exception.getError());
  }
}
