import { Point, Polygon } from 'geojson';

export const toPoint = (...args: number[]): Point => {
  return {
    type: 'Point',
    coordinates: args,
  } as Point;
};

export const toPolygon = (args: number[][], isClosed = false): Polygon => {
  if (!isClosed) {
    // Polygon should be closed polygon. It means the first corner and the last corner should be same point.
    // Thus, push the first corner to the end of the corner array.
    args.push(args[0]);
  }
  return {
    type: 'Polygon',
    coordinates: new Array(args),
  } as Polygon;
};
