export class AppConfigModuleBase {}
