// https://matthiashager.com/converting-snake-case-to-camel-case-object-keys-with-javascript
const toCamel = (s: string) => {
  return s.replace(/([-_][a-z])/gi, ($1) => {
    return $1.toUpperCase().replace('-', '').replace('_', '');
  });
};

const isArray = function (a: object) {
  return Array.isArray(a);
};

const isObject = function (o: object) {
  return o === Object(o) && !isArray(o) && typeof o !== 'function';
};

export const keysToCamel = function (o: object) {
  if (isObject(o)) {
    const n = {};
    if (o instanceof Date) {
      return o;
    }
    Object.keys(o).forEach((k) => {
      n[toCamel(k)] = keysToCamel(o[k]);
    });

    return n;
  } else if (isArray(o)) {
    return (o as Array<object>).map((i) => {
      return keysToCamel(i);
    });
  }

  return o;
};
