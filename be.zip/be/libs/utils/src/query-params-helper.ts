export const stripFilterOperatorFromQueryParam = (s: string) => {
  return s.replace(/\$(eq|gt|gte|in|null|lt|lte|btw|not|ilike):/gi, '');
};
