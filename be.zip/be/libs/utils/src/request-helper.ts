import { IrisRequest } from '@iris-lib/middlewares';
import { Request } from 'express';
import { isIP } from 'net';

type options = {
  forwardedForIndex: number;
};

export const getForwardedIps = function (req: Request | IrisRequest): string[] {
  if (req.headers?.['x-forwarded-for'] != null) {
    if (typeof req.headers['x-forwarded-for'] !== 'string') {
      throw new TypeError(
        `expected a string, got ${typeof req.headers['x-forwarded-for']}`,
      );
    }
    return req.headers['x-forwarded-for'].split(',').map((x) => {
      const ip = x.trim();
      if (ip.includes(':')) {
        const ipWithPort = ip.split(':');
        if (ipWithPort.length === 2) {
          return ip.split(':')[0];
        }
      }
      return ip;
    });
  }
  return null;
};

const getClientIpFromXForwardedFor = function (
  req: Request,
  options: options = { forwardedForIndex: 0 },
): string {
  const forwardedIps = getForwardedIps(req);

  if (forwardedIps != null && forwardedIps.length > 0) {
    if (forwardedIps.length === 1) {
      return forwardedIps[0];
    }
    if (forwardedIps.length > 1) {
      return forwardedIps.at(options.forwardedForIndex);
    }
  }
  return null;
};

export const getClientIp = function (
  req: Request,
  options: options = { forwardedForIndex: 0 },
): string {
  const xForwardedFor = getClientIpFromXForwardedFor(req, options);
  if (xForwardedFor != null && isIP(xForwardedFor)) {
    return xForwardedFor;
  }

  if (req.socket?.remoteAddress != null && isIP(req.socket.remoteAddress)) {
    return req.socket.remoteAddress;
  }
  return null;
};
