import * as util from 'util';

export const print = (obj: any) =>
  console.log(
    util.inspect(obj, { showHidden: false, depth: null, colors: true }),
  );
