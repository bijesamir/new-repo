import {
  ProductFormat,
  ResolutionMode,
  getProductFormatLabel,
  getProductFormatOutput,
  getResolutionModeLabel,
} from '@iris-lib/constants';

export const getProductName = (
  format: ProductFormat,
  resolution: ResolutionMode,
): string => {
  return resolution === ResolutionMode.SR
    ? `${getResolutionModeLabel(resolution)}-${getProductFormatOutput(format)}`
    : getProductFormatOutput(format);
};

export const getProductLabel = (
  format: ProductFormat,
  resolution: ResolutionMode,
): string => {
  return resolution === ResolutionMode.SR
    ? `${getResolutionModeLabel(resolution)}-${getProductFormatLabel(format)}`
    : getProductFormatLabel(format);
};
