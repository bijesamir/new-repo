import { format } from 'date-fns';

export const formatNotificationDate = (date: Date): string => {
  // Return format: 2021-01-01 01:00:00 AM (Hour is 01 - 12)
  return format(date, 'yyyy-MM-dd hh:mm:ss a');
};
