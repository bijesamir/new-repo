export const envStringValue = (
  envKey,
  defaultValue?: string | undefined,
): string => {
  const raw = process.env[envKey];
  if (!raw) {
    if (defaultValue && defaultValue !== '') {
      return defaultValue;
    } else {
      throw new Error(`key: ${envKey} was not set.`);
    }
  }
  return raw;
};

export const envIntValue = (
  envKey,
  defaultValue?: number | undefined,
): number => {
  const raw = process.env[envKey];
  if (!raw) {
    if (defaultValue || defaultValue == 0) {
      return defaultValue;
    } else {
      throw new Error(`key: ${envKey} was not set.`);
    }
  }
  const parsed = Number.parseInt(raw, 10);

  return parsed;
};

export const envBooleanValue = (
  envKey: string,
  defaultValue?: boolean | undefined,
): boolean => {
  const raw = process.env[envKey];
  if (
    !raw ||
    !(raw.toLowerCase() === 'true' || raw.toLowerCase() === 'false')
  ) {
    if (defaultValue !== undefined) {
      return defaultValue;
    } else {
      throw new Error(`key: ${envKey} was not set.`);
    }
  }
  if (raw.toLowerCase() === 'true') return true;
  if (raw.toLowerCase() === 'false') return false;
  return false;
};
