import { BadRequestException } from '@nestjs/common';
import { OrderStacSearchDto } from 'apps/backend/src/models/dto/order/order.dto';
import {
  StacQueryOperators,
  StacSimpleSearchDto,
} from 'apps/backend/src/models/dto/stac/stac-search.dto';
import { SelectQueryBuilder } from 'typeorm';

export const addQueryFilter = <T>(
  query: StacSimpleSearchDto['query'],
  queryBuilder: SelectQueryBuilder<T>,
  fromPropsToSqlFilter,
  ignoreUnknownKey = false,
) => {
  if (!query) {
    return;
  }
  const queryFilters = [];
  const filterParams = {};

  query.forEach((o: StacQueryOperators, p: string) => {
    if (!fromPropsToSqlFilter[p]) {
      if (ignoreUnknownKey) {
        return;
      } else {
        throw new BadRequestException(`Unknown filter: ${p}`);
      }
    }

    const paramsKey = p.startsWith('syns:') ? p.replace('syns:', '') : p;
    if (o.eq !== undefined && o.eq !== null) {
      queryFilters.push(`${fromPropsToSqlFilter[p]} = :eq_${paramsKey}`);
      Object.assign(filterParams, { [`eq_${paramsKey}`]: o.eq });
    }
    if (o.neq !== undefined && o.neq !== null) {
      queryFilters.push(`${fromPropsToSqlFilter[p]} <> :neq_${paramsKey}`);
      Object.assign(filterParams, { [`neq_${paramsKey}`]: o.neq });
    }
    if (o.lt !== undefined && o.lt !== null) {
      queryFilters.push(`${fromPropsToSqlFilter[p]} < :lt_${paramsKey}`);
      Object.assign(filterParams, { [`lt_${paramsKey}`]: o.lt });
    }
    if (o.lte !== undefined && o.lte !== null) {
      queryFilters.push(`${fromPropsToSqlFilter[p]} <= :lte_${paramsKey}`);
      Object.assign(filterParams, { [`lte_${paramsKey}`]: o.lte });
    }
    if (o.gt !== undefined && o.gt !== null) {
      queryFilters.push(`${fromPropsToSqlFilter[p]} > :gt_${paramsKey}`);
      Object.assign(filterParams, { [`gt_${paramsKey}`]: o.gt });
    }
    if (o.gte !== undefined && o.gte !== null) {
      queryFilters.push(`${fromPropsToSqlFilter[p]} >= :gte_${paramsKey}`);
      Object.assign(filterParams, { [`gte_${paramsKey}`]: o.gte });
    }
    if (o.startsWith !== undefined && o.startsWith !== null) {
      queryFilters.push(`${fromPropsToSqlFilter[p]} ILIKE '${o.startsWith}%'`);
    }
    if (o.endsWith !== undefined && o.endsWith !== null) {
      queryFilters.push(`${fromPropsToSqlFilter[p]} ILIKE '%${o.endsWith}'`);
    }
    if (o.contains !== undefined && o.contains !== null) {
      queryFilters.push(`${fromPropsToSqlFilter[p]} ILIKE '%${o.contains}%'`);
    }
    if (o.in !== undefined && o.in !== null) {
      queryFilters.push(`${fromPropsToSqlFilter[p]} IN (:...in_${paramsKey})`);
      Object.assign(filterParams, { [`in_${paramsKey}`]: o.in });
    }
  });
  if (queryFilters.length > 0) {
    queryBuilder.andWhere(queryFilters.join(' AND '), filterParams);
  }
};

export const addQuerySort = <T>(
  sortby: StacSimpleSearchDto['sortby'] | OrderStacSearchDto['sortby'],
  queryBuilder: SelectQueryBuilder<T>,
  fromPropsToSqlSort,
  ignoreUnknownKey = false,
) => {
  if (!sortby) {
    return;
  }
  sortby.reduce((p, c) => {
    const order = c.direction.toUpperCase() as 'ASC' | 'DESC';
    if (!fromPropsToSqlSort[c.field]) {
      if (ignoreUnknownKey) {
        return p;
      } else {
        throw new BadRequestException(`Unknown filter: ${p}`);
      }
    }
    p.addOrderBy(fromPropsToSqlSort[c.field], order);
    return p;
  }, queryBuilder);
};
