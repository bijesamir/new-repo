import { ImagingMode, getImagingModeLabel } from '@iris-lib/constants';
import {
  ProductData,
  ProductDataView,
  TaskingInfo,
} from '@iris-lib/db/entities';
import { SceneInfo } from '@iris-lib/db/entities/scene-info.entity';
import { format } from 'date-fns';
import { EntityManager } from 'typeorm';

export const generateItemId = (
  satName: string,
  imagingMode: ImagingMode,
  date: Date,
) => {
  const dateString = format(date, "yyyyMMdd'_'HHmmss");
  return `${satName}_${dateString}_${getImagingModeLabel(imagingMode)}`;
};

// itemId needs to be consistent with the above migration
export const getSceneInfo = (
  taskingInfo: TaskingInfo,
  no: number,
  centerDate: Date,
) => {
  return {
    taskingInfo,
    sceneNo: no,
    itemId: generateItemId(
      taskingInfo.satellite.name,
      taskingInfo.imagingMode,
      centerDate,
    ),
  };
};

export const checkAndCreateSceneInfo = async (
  manager: EntityManager,
  p: ProductData,
  taskingInfo?: TaskingInfo,
) => {
  const ti = taskingInfo
    ? taskingInfo
    : await manager.getRepository(TaskingInfo).findOneOrFail({
        where: { id: p.taskingInfoId },
        relations: { satellite: true },
      });

  const sceneRepo = manager.getRepository(SceneInfo);
  const foundEntity = await sceneRepo.findOne({
    where: {
      taskingInfo: { id: ti.id },
      sceneNo: p.sceneNo,
    },
    relations: { taskingInfo: true },
  });

  if (!foundEntity) {
    const pdv = await manager.findOneByOrFail(ProductDataView, {
      id: p.id,
    });
    const newEntity = sceneRepo.create(
      getSceneInfo(ti, p.sceneNo, pdv.metadata.observation.sceneCenterDateTime),
    );
    await sceneRepo.save(newEntity);
    return newEntity;
  }
  return foundEntity;
};
