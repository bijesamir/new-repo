// https://github.com/open-telemetry/opentelemetry-js/discussions/3503
import * as tracer from '@iris-lib/ops/tracing';
import { getNodeAutoInstrumentations } from '@opentelemetry/auto-instrumentations-node';
import { PubSubInstrumentation } from 'opentelemetry-instrumentation-pubsub';
import { BullMQInstrumentation } from '@jenniferplusplus/opentelemetry-instrumentation-bullmq';
import { envBooleanValue } from '@iris-lib/utils';

if (envBooleanValue('TRACING_ENABLED', false)) {
  const instrumentations = [
    new PubSubInstrumentation(),
    new BullMQInstrumentation(),
    getNodeAutoInstrumentations({
      '@opentelemetry/instrumentation-http': {
        ignoreIncomingRequestHook: (request) => {
          // ignores "/healthz", "/health" and "/"
          const expression = /^\/(healthz?)?$/;
          return new RegExp(expression).test(request.url);
        },
      },
      '@opentelemetry/instrumentation-grpc': {
        ignoreGrpcMethods: [new RegExp(/^streaming/, 'i')],
      },
      '@opentelemetry/instrumentation-ioredis': {
        enabled: false,
      },
      '@opentelemetry/instrumentation-fs': {
        enabled: false,
      },
      '@opentelemetry/instrumentation-net': {
        enabled: false,
      },
      '@opentelemetry/instrumentation-dns': {
        enabled: false,
      },
    }),
  ];
  tracer.initTracing('iris-delivery-center', instrumentations);
}

import { NestFactory } from '@nestjs/core';
import { DeliveryCenterModule } from './delivery-center.module';
import { AppConfigService } from './config/app-config.service';
import { LoggerService } from '@iris-lib/logger';
import { GcPubsubServer } from '@iris-lib/transporters';
import { useContainer as useValidatorContainer } from 'class-validator';
import { NestExpressApplication } from '@nestjs/platform-express';

import { getCustomValidationErrors } from '@iris-lib/models/errors';
import { ValidationPipe, BadRequestException } from '@nestjs/common';
import cookieParser from 'cookie-parser';
import helmet from 'helmet';
import { SwaggerModule } from '@nestjs/swagger';
import * as fs from 'node:fs/promises';
import * as YAML from 'yaml';
import { getDocumentBuilder } from './config/openapi-info';

async function bootstrap() {
  const app =
    await NestFactory.create<NestExpressApplication>(DeliveryCenterModule);
  const config = await app.get<AppConfigService>('AppConfig');
  const logger = await app.get<LoggerService>(LoggerService);
  app.useLogger(logger);
  app.disable('x-powered-by');
  app.use(cookieParser(), helmet());
  app.useGlobalPipes(
    new ValidationPipe({
      transform: true,
      skipMissingProperties: false,
      forbidUnknownValues: true,
      transformOptions: {
        exposeDefaultValues: true,
        //enableImplicitConversion: true,
      },
      exceptionFactory(errors) {
        logger.debug(
          { message: 'Error content before processing', errors },
          'exceptionFactory',
        );
        const tmp = getCustomValidationErrors(errors);

        throw new BadRequestException(tmp);
      },
    }),
  );
  useValidatorContainer(app.select(DeliveryCenterModule), {
    fallbackOnErrors: true,
  });
  app.connectMicroservice(
    {
      strategy: new GcPubsubServer({
        subscription: config.get('pubsub.deliveryCenterSubscription'),
        client: {
          apiEndpoint: config.get('pubsub.emulatorHost'),
          projectId: config.get('pubsub.projectId'),
        },
      }),
    },
    { inheritAppConfig: true },
  );
  await app.startAllMicroservices();

  if (config.get('env') === 'development') {
    const swaggerOption = getDocumentBuilder();
    const document = SwaggerModule.createDocument(app, swaggerOption, {
      deepScanRoutes: true,
    });

    await fs.writeFile(
      './delivery-center-swagger.yaml',
      YAML.stringify(document, {}),
    );
    SwaggerModule.setup('swagger', app, document);
  }

  await app.listen(config.get('queueManager.port'));
}
bootstrap();
