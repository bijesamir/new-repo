import { DocumentBuilder } from '@nestjs/swagger';

export const getDocumentBuilder = () => {
  return new DocumentBuilder()
    .setTitle('iris delivery-center api')
    .setVersion('0.1')
    .setDescription('iris delivery-center api')
    .addServer('http://localhost:4001')
    .build();
};
