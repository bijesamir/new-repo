import { envIntValue, envStringValue } from '@iris-lib/utils';
import * as fs from 'fs';

export const generateApplicationConfig = () => {
  return {
    env: envStringValue('NODE_ENV', 'development'),
    queueManager: {
      port: envIntValue('QUEUE_MANAGER_PORT', 4001),
    },
    pubsub: {
      emulatorHost: process.env.PUBSUB_EMULATOR_HOST, // optional
      projectId: envStringValue('PUBSUB_PROJECT_ID', 'syns-daas-dev-local'),
      deliveryCenterTopic: envStringValue('PUBSUB_DELIVERY_NOTIFICATION_TOPIC'),
      deliveryCenterSubscription: envStringValue(
        'PUBSUB_DELIVERY_NOTIFICATION_SUBSCRIPTION',
      ),
    },
    redis: {
      disconnectTimeout: envIntValue('REDIS_DISCONNECT_TIMEOUT', 1000),
      host: envStringValue('REDIS_HOST', 'localhost'),
      port: envIntValue('REDIS_PORT', 63790),
      db: envIntValue('REDIS_DELIVERY_CONTROL_DB', 0),
      password: envStringValue('REDIS_PASSWORD'),
      maxRetriesPerRequest: null,
      tls: {
        key:
          envStringValue('REDIS_SERVER_KEY_PATH', 'NO_NEED') == 'NO_NEED'
            ? null
            : fs.readFileSync(envStringValue('REDIS_SERVER_KEY_PATH')),
        ca: fs.readFileSync(envStringValue('REDIS_CA_CERT_PATH')),
        checkServerIdentity: () => undefined,
      },
    },
    enqueueOption: {
      attempt: 0, // TODO
    },
    deliveryControlQueue: {
      name: 'deliveryControl',
      option: {
        concurrency: 5, // TODO
        removeOnComplete: {
          age: 3600 * 24, // keep up to 1 hour
          count: 100, // keep up to 100 jobs
        },
        removeOnFail: {
          age: 24 * 3600 * 7, // keep up to 7 days
        },
      },
    },
    workerOptionBase: {
      removeOnComplete: {
        age: 3600 * 24, // keep up to 1 day
        count: 100, // keep up to 100 jobs
      },
      removeOnFail: {
        age: 24 * 3600 * 7, // keep up to 7 days
      },
    },
    sandboxedProcessors: {
      dir: envStringValue('SANDBOXED_PROCESSORS_DIR'),
    },
  };
};

export type AppConfig = ReturnType<typeof generateApplicationConfig>;
