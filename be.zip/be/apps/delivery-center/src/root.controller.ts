import { Controller, Get, HttpStatus, Response } from '@nestjs/common';
import { ApiExcludeController } from '@nestjs/swagger';

@ApiExcludeController()
@Controller()
export class RootController {
  @Get('favicon.ico')
  favicon(@Response() res) {
    res.status(HttpStatus.NO_CONTENT).end();
  }

  @Get()
  ok() {
    return 'ok';
  }
}
