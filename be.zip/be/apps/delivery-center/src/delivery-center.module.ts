import { Module } from '@nestjs/common';
import { LoggerModule } from '@iris-lib/logger';
import { AppConfigModule } from './config/app-config.module';
import { DeliveryControlUsecaseModule } from './usecases/delivery-control-usecase/delivery-control-usecase.module';
import { CustomExceptionFilter } from '@iris-lib/filters';
import { APP_FILTER } from '@nestjs/core';
import { DbConfigModule, DbConfigService } from '@iris-lib/db';
import { TypeOrmModule, TypeOrmModuleOptions } from '@nestjs/typeorm';
import { DeliveryWorkerManagerUsecaseModule } from './usecases/delivery-worker-manager-usecase/delivery-worker-manager-usecase.module';
import { DbOperationLogSubscriber } from '@iris-lib/db/subscribers';
import { QueueManagerUsecaseModule } from './usecases/queue-manager-usecase/queue-manager-usecase.module';
import { RootController } from './root.controller';
import { SlackNotificationModule } from '@iris-lib/slack';
import { CacheModule } from '@nestjs/cache-manager';

@Module({
  imports: [
    AppConfigModule,
    CacheModule.register({ isGlobal: true }),
    LoggerModule,
    DbConfigModule,
    TypeOrmModule.forRootAsync({
      inject: ['DbConfig'],
      useFactory: async (configService: DbConfigService) => {
        return configService.get('db') as TypeOrmModuleOptions;
      },
    }),
    DeliveryControlUsecaseModule,
    DeliveryWorkerManagerUsecaseModule,
    QueueManagerUsecaseModule,
    SlackNotificationModule,
  ],
  providers: [
    {
      provide: APP_FILTER,
      useValue: new CustomExceptionFilter('NONE'),
    },
    DbOperationLogSubscriber,
  ],
  controllers: [RootController],
})
export class DeliveryCenterModule {}
