import {
  Controller,
  Delete,
  Get,
  HttpStatus,
  Query,
  Res,
} from '@nestjs/common';
import { QueueManagerUsecaseService } from '../usecases/queue-manager-usecase/queue-manager-usecase.service';
import {
  ApiInternalServerErrorResponse,
  ApiNoContentResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
} from '@nestjs/swagger';
import { ErrorResponse } from '@iris-lib/filters';
import { JobSummaryDto } from '../models/dto/job-summary.dto';
import { JobsQuery } from '../models/dto/jobs-query.dto';
import { JobSearchResultDto } from '../models/dto/job-search-result.dto';
import { Job } from 'bullmq';
import { DeleteJobDto } from '../models/dto/delete-job.dto';
import { Response } from 'express';

@Controller('queue-manager')
export class QueueManagerController {
  constructor(
    private readonly queueManagerService: QueueManagerUsecaseService,
  ) {}

  @ApiOperation({ summary: 'Get all summary' })
  @ApiOkResponse({
    type: [JobSummaryDto],
    description:
      '[refer to](https://api.docs.bullmq.io/classes/v4.Queue.html#getJobCounts)',
  })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Get('all-summary')
  async getAllSummary() {
    return await this.queueManagerService.getAllSummary();
  }

  @ApiOperation({ summary: 'Get root summary' })
  @ApiOkResponse({
    type: JobSummaryDto,
    description:
      '[refer to this link](https://api.docs.bullmq.io/classes/v4.Queue.html#getJobCounts)',
  })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Get('root-summary')
  async getRootSummary() {
    return await this.queueManagerService.getRootSummary();
  }

  @ApiOperation({ summary: 'Get job history' })
  @ApiOkResponse({
    type: JobSearchResultDto<Job>,
    description: 'list of job history',
  })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Get('job-history')
  async getJobHistory(@Query() q: JobsQuery) {
    return await this.queueManagerService.getJobHistory(q);
  }

  @ApiOperation({ summary: 'Get job names' })
  @ApiOkResponse({
    type: [String],
    description: 'active job queue name list',
  })
  @ApiNotFoundResponse({
    type: ErrorResponse,
  })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Get('job-names')
  async getJobNames() {
    return await this.queueManagerService.getJobNames();
  }

  @ApiOperation({ summary: 'Delete job' })
  @ApiOkResponse()
  @ApiNoContentResponse()
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Delete('job')
  async deleteJob(@Query() q: DeleteJobDto, @Res() res: Response) {
    const result = await this.queueManagerService.deleteJob(q);
    if (!result) {
      res.status(HttpStatus.NO_CONTENT);
    }
    res.send();
  }
}
