import { Controller, UseFilters } from '@nestjs/common';
import { EventPattern, Payload } from '@nestjs/microservices';
import { DeliveryRequestDto } from '../../../../libs/models/src/job/delivery-request.dto';
import { LoggerWrapper } from '@iris-lib/logger';
import { DeliveryControlUsecaseService } from '../usecases/delivery-control-usecase/delivery-control-usecase.service';
import { GcPubsubExceptionFilter } from '@iris-lib/filters';

@UseFilters(new GcPubsubExceptionFilter())
@Controller('delivery-center-notification')
export class DeliveryControlController {
  private logger = new LoggerWrapper(DeliveryControlController.name);

  constructor(private service: DeliveryControlUsecaseService) {}

  @EventPattern('register-product-data-delivery')
  async fromRegisterProductDataProcess(@Payload() dto: DeliveryRequestDto) {
    this.logger.debug('register-product-data-delivery', { dto });
    return await this.service.enqueueToRoot(dto);
  }
}
