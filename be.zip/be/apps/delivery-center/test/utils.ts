import { DbConfigModule, DbConfigService } from '@iris-lib/db';
import { LoggerModule } from '@iris-lib/logger';
import { ValidationPipe } from '@nestjs/common';
import { TypeOrmModule, TypeOrmModuleOptions } from '@nestjs/typeorm';
import { AppConfigModule } from '../src/config/app-config.module';
import { APP_FILTER, APP_PIPE } from '@nestjs/core';
import { GcPubsubExceptionFilter } from '@iris-lib/filters';
import { CacheModule } from '@nestjs/cache-manager';

export const seqTestModuleBase = (m) => {
  return {
    imports: [
      AppConfigModule,
      CacheModule.register({ isGlobal: true }),
      LoggerModule,
      DbConfigModule,
      TypeOrmModule.forRootAsync({
        inject: ['DbConfig'],
        useFactory: async (configService: DbConfigService) => {
          return configService.get('db') as TypeOrmModuleOptions;
        },
      }),
      m,
    ],
    providers: [
      {
        provide: APP_PIPE,
        useValue: new ValidationPipe({
          transform: true,
          skipMissingProperties: false,
          forbidUnknownValues: true,
          transformOptions: {
            exposeDefaultValues: true,
          },
        }),
      },
      {
        provide: APP_FILTER,
        useValue: new GcPubsubExceptionFilter(),
      },
    ],
  };
};
