// https://github.com/open-telemetry/opentelemetry-js/discussions/3503
import * as tracer from '@iris-lib/ops/tracing';
import { getNodeAutoInstrumentations } from '@opentelemetry/auto-instrumentations-node';
import { envBooleanValue } from '@iris-lib/utils';

if (envBooleanValue('TRACING_ENABLED', false)) {
  const instrumentations = [
    getNodeAutoInstrumentations({
      '@opentelemetry/instrumentation-http': {
        ignoreIncomingRequestHook: (request) => {
          // ignores "/healthz", "/health" and "/"
          const expression = /^\/(healthz?)?$/;
          return new RegExp(expression).test(request.url);
        },
      },
      '@opentelemetry/instrumentation-grpc': {
        ignoreGrpcMethods: [new RegExp(/^streaming/, 'i')],
      },
      '@opentelemetry/instrumentation-ioredis': {
        enabled: false,
      },
      '@opentelemetry/instrumentation-fs': {
        enabled: false,
      },
      '@opentelemetry/instrumentation-net': {
        enabled: false,
      },
      '@opentelemetry/instrumentation-dns': {
        enabled: false,
      },
    }),
  ];
  tracer.initTracing('iris-gateway', instrumentations);
}

import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { NestExpressApplication } from '@nestjs/platform-express';
import { AppConfigService } from './config/app-config.service';
import { NestApplicationOptions } from '@nestjs/common';
import { decorateApp } from './bootstrap-support';

const bootstrap = async () => {
  const serverOptions: NestApplicationOptions = {
    bodyParser: false,
  };

  const app = await decorateApp(
    await NestFactory.create<NestExpressApplication>(AppModule, serverOptions),
  );
  const config = await app.get<AppConfigService>('AppConfig');

  await app.listen(config.get('app.port'));
};
bootstrap();
