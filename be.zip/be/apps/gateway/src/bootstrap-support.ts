import { LoggerService } from '@iris-lib/logger';
import { NestExpressApplication } from '@nestjs/platform-express';
import { VersioningType } from '@nestjs/common';
import cookieParser from 'cookie-parser';
import { HEADER_REQUEST_ID, AppConstants } from '@iris-lib/constants';
import helmet from 'helmet';

export const decorateApp = async (app: NestExpressApplication) => {
  const logger = await app.get<LoggerService>(LoggerService);
  app.useLogger(logger);
  app.disable('x-powered-by');
  app.enableVersioning({
    type: VersioningType.URI,
    defaultVersion: [AppConstants.DEFAULT_VERSION],
  });
  app.enableCors({
    exposedHeaders: [HEADER_REQUEST_ID],
    credentials: true,
    origin: [
      /^https?:\/\/.*data\.synspective\.io$/,
      /^https?:\/\/localhost:\d{4}$/,
    ],
  });
  app.use(helmet());
  app.use(cookieParser());
  return app;
};
