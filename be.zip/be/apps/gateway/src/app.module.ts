import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { LoggerModule } from '@iris-lib/logger';
import { AppConfigModule } from './config/app-config.module';
import { AoiController } from './controllers/aoi.controller';
import { CandidateController } from './controllers/candidate.controller';
import { TaskingBundleController } from './controllers/tasking-bundle.controller';
import { TaskingInfoController } from './controllers/tasking-info.controller';
import { TaskingRequestController } from './controllers/tasking-request.controller';
import { ObservableAreaController } from './controllers/observable-area.controller';
import { ProductDataRequestController } from './controllers/product-data-request.controller';
import { ProductDataController } from './controllers/product-data.controller';
import { ProductDataVersionController } from './controllers/product-data-version.controller';
import { ProductDataRelatedStatusController } from './controllers/product-data-related-status.controller';
import { CatalogController } from './controllers/catalog.controller';
import { ArchiveOrderController } from './controllers/archive-order.controller';
import { ArchivePurchaseRequestController } from './controllers/archive-purchase-request.controller';
import { ArchiveCartController } from './controllers/archive-cart.controller';
import { ReprocessingRequestController } from './controllers/reprocessing-request.controller';
import { DeliveryRequestController } from './controllers/delivery-request.controller';
import { SatelliteController } from './controllers/satellite.controller';
import { MasterController } from './controllers/master.controller';
import { UserController } from './controllers/user.controller';
import { HealthModule } from './usecases/health/health.module';
import { APP_FILTER, APP_GUARD } from '@nestjs/core';
import { AppConfigService } from './config/app-config.service';
import { CustomExceptionFilter } from '@iris-lib/filters';
import { GatewayAuthGuard } from './guards/gateway-auth.guard';
import { DummyAuthGuard } from '@iris-lib/guards';
import { CitadelGrpcModule } from '@iris-lib/citadel';
import { BackendHttpProxyModule } from './infra/backend-http-proxy/backend-http-proxy.module';
import { IpFilterGuard } from './guards/ip-filter.guard';

@Module({
  imports: [
    AppConfigModule,
    LoggerModule,
    HealthModule,
    BackendHttpProxyModule,
    CitadelGrpcModule,
  ],
  controllers: [
    AppController,
    AoiController,
    CandidateController,
    TaskingBundleController,
    TaskingInfoController,
    TaskingRequestController,
    ObservableAreaController,
    ProductDataRequestController,
    ProductDataController,
    ProductDataVersionController,
    ProductDataRelatedStatusController,
    CatalogController,
    ArchiveOrderController,
    ArchivePurchaseRequestController,
    ArchiveCartController,
    ReprocessingRequestController,
    DeliveryRequestController,
    SatelliteController,
    MasterController,
    UserController,
  ],
  providers: [
    GatewayAuthGuard,
    IpFilterGuard,
    {
      provide: APP_FILTER,
      useFactory: (config: AppConfigService) => {
        return new CustomExceptionFilter(config.get('app.loginPageUrl'));
      },
      inject: ['AppConfig'],
    },
    {
      provide: APP_GUARD,
      useExisting: IpFilterGuard,
    },
    {
      provide: APP_GUARD,
      useFactory: (config: AppConfigService, guard: GatewayAuthGuard) => {
        if (config.get('app.useDummyUser')) {
          return new DummyAuthGuard();
        } else {
          return guard;
        }
      },
      inject: ['AppConfig', GatewayAuthGuard],
    },
  ],
})
export class AppModule {}
