import { Public } from '@iris-lib/decorators';
import { LoggerWrapper } from '@iris-lib/logger';
import { Controller, Get, Options, VERSION_NEUTRAL } from '@nestjs/common';

@Controller({
  version: VERSION_NEUTRAL,
})
export class AppController {
  private logger = new LoggerWrapper(AppController.name);

  constructor() {}

  @Public()
  @Get()
  ok(): string {
    return 'ok';
  }

  @Options()
  options(): string {
    return 'option check';
  }
}
