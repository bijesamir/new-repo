import { LoggerWrapper } from '@iris-lib/logger';
import { All, Controller, Get, Next, Post, Req, Res } from '@nestjs/common';
import { NextFunction, Response } from 'express';
import { BackendHttpProxyService } from '../infra/backend-http-proxy/backend-http-proxy.service';
import { IpFilter } from '../decorators/ip-filter.decorator';
import { IrisRequest } from '@iris-lib/middlewares';
import { AuthStrategy, AppConstants } from '@iris-lib/constants';

@Controller({
  path: 'order',
  version: [AppConstants.DEFAULT_VERSION],
})
export class ArchiveOrderController {
  private readonly logger = new LoggerWrapper(ArchiveOrderController.name);

  constructor(private proxyService: BackendHttpProxyService) {}

  @IpFilter(false, [
    AuthStrategy.CitadelCookie,
    AuthStrategy.CitadelOAuth,
    AuthStrategy.CitadelApiKey,
  ])
  @Get(['/:id'])
  getOne(
    @Req() req: IrisRequest,
    @Res() res: Response,
    @Next() next: NextFunction,
  ) {
    return this.proxyService.proxy(req, res, next);
  }

  @IpFilter(false, [
    AuthStrategy.CitadelCookie,
    AuthStrategy.CitadelOAuth,
    AuthStrategy.CitadelApiKey,
  ])
  @Post(['', '/search', '/review'])
  allowPost(
    @Req() req: IrisRequest,
    @Res() res: Response,
    @Next() next: NextFunction,
  ) {
    return this.proxyService.proxy(req, res, next);
  }

  @All(['', '*'])
  all(
    @Req() req: IrisRequest,
    @Res() res: Response,
    @Next() next: NextFunction,
  ) {
    return this.proxyService.proxy(req, res, next);
  }
}
