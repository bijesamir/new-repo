import { AuthStrategy } from '@iris-lib/constants';
import { SetMetadata } from '@nestjs/common';

export const IP_FILTER_KEY = 'ipFilter';

export const IpFilter = (
  enable: boolean,
  // specify external auth strategies when ip filter is disabled
  externalAuthStrategies: AuthStrategy[] = [],
) => {
  return SetMetadata<string, [boolean, AuthStrategy[]]>(IP_FILTER_KEY, [
    enable ?? true,
    externalAuthStrategies,
  ]);
};
