import { envBooleanValue, envIntValue, envStringValue } from '@iris-lib/utils';

export const generateApplicationConfig = () => {
  return {
    env: envStringValue('NODE_ENV', 'development'),
    app: {
      useDummyUser: envBooleanValue('USE_DUMMY_USER', false),
      port: envIntValue('GATEWAY_PORT', 4002),
      loginPageUrl: `${envStringValue('IRIS_WEBPAGE_URL', 'NONE')}/login`,
      ipFilterListSource: envStringValue('IP_FILTER_LIST_SOURCE', 'env'),
      ipFilterList: envStringValue('IP_FILTER_LIST', 'COMMA_SEPARATED_IP_LIST'),
      ipFilterListPath: envStringValue('IP_FILTER_LIST_PATH', 'NONE'),
    },
  };
};

export type AppConfig = ReturnType<typeof generateApplicationConfig>;
