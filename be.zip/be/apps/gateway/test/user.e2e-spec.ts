import { INestApplication } from '@nestjs/common';
import { ExpressAdapter } from '@nestjs/platform-express';
import {
  IpFilterGuardSpies,
  TEST_IP_FILTER_LIST,
  createAppForE2ETest,
  createBaseRequest,
  generateMockCitadelGrpcService,
  generateMockProxyService,
  spyOnIpFilterGuard,
} from './utils';
import { BackendHttpProxyService } from '../src/infra/backend-http-proxy/backend-http-proxy.service';
import { CitadelGrpcService } from '@iris-lib/citadel';
import { DUMMY_USER } from '@iris-lib/guards';
import { IpFilterGuard } from '../src/guards/ip-filter.guard';

const baseUrl = '/v1/user';

describe('UserController (e2e)', () => {
  let app: INestApplication;
  let httpServer: ExpressAdapter;
  let ipFilterGuard: IpFilterGuard;
  let ipFilterGuardSpies: IpFilterGuardSpies;
  const mockProxyService = generateMockProxyService();
  const mockCitadelGrpcService = generateMockCitadelGrpcService();

  beforeAll(async () => {
    app = await createAppForE2ETest((tm) => {
      tm.overrideProvider(BackendHttpProxyService).useValue(mockProxyService);
      tm.overrideProvider(CitadelGrpcService).useValue(mockCitadelGrpcService);
    });
    await app.init();
    httpServer = app.getHttpServer();

    ipFilterGuard = app.get(IpFilterGuard);
    ipFilterGuardSpies = spyOnIpFilterGuard(ipFilterGuard);
  });

  beforeEach(() => {
    // ipFilterGuard.whiteList is a setter, so we need to reset it
    ipFilterGuard.whiteList = [];
    // use mockClear() to keep spies or mock implementations intact
    ipFilterGuardSpies.whiteList.mockClear();
    mockProxyService.proxy.mockClear();
    // use mockReset() to reset initial mock state including implementation
    mockCitadelGrpcService.verifyUserIdentityToken.mockReset();
    mockCitadelGrpcService.verifyAccessToken.mockReset();
  });

  afterAll(async () => {
    jest.restoreAllMocks();
    await app.close();
  });

  describe('Internal endpoints', () => {
    // TODO: to be deprecated
    it.each([
      { method: 'GET', path: `${baseUrl}/any/any`, handler: 'all' },
      { method: 'POST', path: `${baseUrl}/any`, handler: 'all' },
      { method: 'PATCH', path: `${baseUrl}`, handler: 'all' },
      { method: 'DELETE', path: `${baseUrl}`, handler: 'all' },
      { method: 'GET', path: `${baseUrl}`, handler: 'current' },
    ])(
      `$path ($method): should proxy using COOKIE ($handler)`,
      async ({ method, path }) => {
        ipFilterGuard.whiteList = TEST_IP_FILTER_LIST;
        mockCitadelGrpcService.verifyUserIdentityToken.mockResolvedValue([
          true,
          DUMMY_USER,
        ]);

        const res = await createBaseRequest(httpServer, method, path)
          .set('Cookie', ['iat=mock-cookie'])
          .set('Content-Type', 'application/json')
          .send();
        expect(res.text).toEqual('mock-response');
        expect(mockProxyService.proxy).toHaveBeenCalledTimes(1);
      },
    );

    it(`should not proxy with non-whitelisted ip using COOKIE`, async () => {
      ipFilterGuard.whiteList = ['1.1.1.1'];

      const res = await createBaseRequest(httpServer, 'POST', baseUrl + '/any')
        .set('Cookie', ['iat=mock-cookie'])
        .set('Content-Type', 'application/json')
        .send();
      expect(res.status).toEqual(404);
      expect(mockProxyService.proxy).toHaveBeenCalledTimes(0);
    });

    it.each([
      { method: 'GET', path: `${baseUrl}/any/any`, handler: 'all' },
      { method: 'POST', path: `${baseUrl}/any`, handler: 'all' },
      { method: 'PATCH', path: `${baseUrl}`, handler: 'all' },
      { method: 'DELETE', path: `${baseUrl}`, handler: 'all' },
      { method: 'GET', path: `${baseUrl}`, handler: 'current' },
    ])(`$path ($method): should proxy ($handler)`, async ({ method, path }) => {
      ipFilterGuard.whiteList = TEST_IP_FILTER_LIST;
      mockCitadelGrpcService.verifyAccessToken.mockResolvedValue([
        true,
        DUMMY_USER,
      ]);

      const res = await createBaseRequest(httpServer, method, path)
        .auth('mock-token', { type: 'bearer' })
        .set('Content-Type', 'application/json')
        .send();
      expect(res.text).toEqual('mock-response');
      expect(mockProxyService.proxy).toHaveBeenCalledTimes(1);
    });

    it(`should not proxy with non-whitelisted ip`, async () => {
      ipFilterGuard.whiteList = ['1.1.1.1'];

      const res = await createBaseRequest(httpServer, 'POST', baseUrl + '/any')
        .auth('mock-token', { type: 'bearer' })
        .set('Content-Type', 'application/json')
        .send();
      expect(res.status).toEqual(404);
      expect(mockProxyService.proxy).toHaveBeenCalledTimes(0);
    });

    it(`should not proxy with APIKEY`, async () => {
      ipFilterGuard.whiteList = TEST_IP_FILTER_LIST;

      const res = await createBaseRequest(httpServer, 'POST', baseUrl + '/any')
        .set('Content-Type', 'application/json')
        .send();
      expect(res.status).toEqual(403);
      expect(mockProxyService.proxy).toHaveBeenCalledTimes(0);
    });
  });

  // TODO: to be deprecated
  describe('External endpoints with COOKIE', () => {
    it.each([{ method: 'GET', path: `${baseUrl}`, handler: 'current' }])(
      `$path ($method): should proxy ($handler)`,
      async ({ method, path }) => {
        ipFilterGuard.whiteList = ['1.1.1.1'];
        mockCitadelGrpcService.verifyUserIdentityToken.mockResolvedValue([
          true,
          DUMMY_USER,
        ]);

        const res = await createBaseRequest(httpServer, method, path)
          .set('Cookie', ['iat=mock-cookie'])
          .set('Content-Type', 'application/json')
          .send();
        expect(res.text).toEqual('mock-response');
        expect(mockProxyService.proxy).toHaveBeenCalledTimes(1);
      },
    );
  });

  describe('External endpoints with ACCESS TOKEN', () => {
    it.each([{ method: 'GET', path: `${baseUrl}`, handler: 'current' }])(
      `$path ($method): should proxy ($handler)`,
      async ({ method, path }) => {
        ipFilterGuard.whiteList = ['1.1.1.1'];
        mockCitadelGrpcService.verifyAccessToken.mockResolvedValue([
          true,
          DUMMY_USER,
        ]);

        const res = await createBaseRequest(httpServer, method, path)
          .auth('mock-token', { type: 'bearer' })
          .set('Content-Type', 'application/json')
          .send();
        expect(res.text).toEqual('mock-response');
        expect(mockProxyService.proxy).toHaveBeenCalledTimes(1);
      },
    );
  });
});
