import { INestApplication } from '@nestjs/common';
import * as request from 'supertest';
import { ExpressAdapter } from '@nestjs/platform-express';
import { createAppForE2ETest } from './utils';

describe('AppController (e2e)', () => {
  let app: INestApplication;
  let httpServer: ExpressAdapter;

  beforeAll(async () => {
    app = await createAppForE2ETest();
    await app.init();
    httpServer = app.getHttpServer();
  });

  afterAll(async () => {
    await app.close();
  });

  it('/ (GET)', async () => {
    const res = await request.default(httpServer).get('/');
    expect(res.status).toEqual(200);
    expect(res.text).toEqual('ok');
  });
});
