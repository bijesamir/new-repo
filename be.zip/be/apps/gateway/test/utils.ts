import { Test, TestingModuleBuilder } from '@nestjs/testing';
import { AppModule } from '../src/app.module';
import { Logger } from '@nestjs/common';
import { decorateApp } from '../src/bootstrap-support';
import { GatewayAuthGuard } from '../src/guards/gateway-auth.guard';
import { IpFilterGuard } from '../src/guards/ip-filter.guard';
import { Response } from 'express';
import { ExpressAdapter } from '@nestjs/platform-express';
import * as request from 'supertest';

export type GtwAuthGuardSpies = {
  extractTokenFromCookie: jest.SpyInstance;
  extractTokenFromHeader: jest.SpyInstance;
  validateCitadelCookie: jest.SpyInstance;
  validateCitadelAccessToken: jest.SpyInstance;
  validateCitadelApiKey: jest.SpyInstance;
};

export type IpFilterGuardSpies = {
  whiteList: jest.SpyInstance;
};

export const TEST_IP_FILTER_LIST = ['::ffff:127.0.0.1'];

export const createAppForE2ETest = async (
  overrideFunction?: (m: TestingModuleBuilder) => void,
) => {
  const m = Test.createTestingModule({
    imports: [AppModule],
  });

  if (overrideFunction) {
    overrideFunction(m);
  }
  const tm = await m.compile();
  tm.useLogger(new Logger());
  return await decorateApp(
    tm.createNestApplication({ forceCloseConnections: true }),
  );
};

export const generateMockProxyService = () => {
  return {
    proxy: jest.fn((_, res: Response) => {
      res.send('mock-response');
    }),
  };
};

export const generateMockCitadelGrpcService = () => {
  return {
    verifyUserIdentityToken: jest.fn(),
    verifyAccessToken: jest.fn(),
  };
};

export const spyOnGtwAuthGuard = (
  guard: GatewayAuthGuard,
): GtwAuthGuardSpies => {
  return {
    extractTokenFromHeader: jest.spyOn(guard as any, 'extractTokenFromHeader'),
    extractTokenFromCookie: jest.spyOn(guard as any, 'extractTokenFromCookie'),
    validateCitadelCookie: jest.spyOn(guard as any, 'validateCitadelCookie'),
    validateCitadelAccessToken: jest.spyOn(
      guard as any,
      'validateCitadelAccessToken',
    ),
    validateCitadelApiKey: jest.spyOn(guard as any, 'validateCitadelApiKey'),
  };
};

export const spyOnIpFilterGuard = (
  guard: IpFilterGuard,
): IpFilterGuardSpies => {
  return {
    whiteList: jest.spyOn(guard as any, 'whiteList', 'set'),
  };
};

export const createBaseRequest = (
  app: ExpressAdapter,
  method: string,
  path: string,
) => {
  switch (method) {
    case 'GET':
      return request.default(app).get(path);
    case 'POST':
      return request.default(app).post(path);
    case 'PATCH':
      return request.default(app).patch(path);
    case 'DELETE':
      return request.default(app).delete(path);
    case 'PUT':
      return request.default(app).put(path);
    case 'OPTIONS':
      return request.default(app).options(path);
    case 'HEAD':
      return request.default(app).head(path);
    default:
      throw new Error(`Unsupported method: ${method}`);
  }
};
