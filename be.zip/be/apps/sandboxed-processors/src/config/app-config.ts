import { envStringValue } from '@iris-lib/utils';

export const generateApplicationConfig = () => {
  return {
    sftpProcessor: {
      tempDir: envStringValue('SFTP_PROCESSOR_TEMP_DIR', './.tmp'),
    },
  };
};

export type AppConfig = ReturnType<typeof generateApplicationConfig>;
