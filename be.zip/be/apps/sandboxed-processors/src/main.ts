import sftpProcessorExecutor from './sftp-processor';
import fs from 'node:fs/promises';
const args = process.argv.slice(2);

(async () => {
  if (args[0] == 'sftp') {
    const input = await fs.readFile('/dev/stdin', 'utf8');
    const job = JSON.parse(input);
    await sftpProcessorExecutor(job);
  }
})();
