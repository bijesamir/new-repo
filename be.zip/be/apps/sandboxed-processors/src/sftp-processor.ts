import { Job } from 'bullmq';
import { NestFactory } from '@nestjs/core';
import { DataSource } from 'typeorm';
import { LoggerService } from '@iris-lib/logger';
import { SftpProcessorUsecaseModule } from './usecases/sftp-processor-usecase/sftp-processor-usecase.module';
import { SftpProcessorUsecaseService } from './usecases/sftp-processor-usecase/sftp-processor-usecase.service';

const sftpProcessorExecutor = async (job: Job) => {
  const app = await NestFactory.create(SftpProcessorUsecaseModule, {
    forceCloseConnections: true,
  });
  const logger = await app.get<LoggerService>(LoggerService);
  app.useLogger(logger);

  const service = app.get<SftpProcessorUsecaseService>(
    SftpProcessorUsecaseService,
  );
  const result = await service.run(job);
  const ds = app.get(DataSource);
  await ds.destroy();
  await app.close();
  return result;
};
export default async (job: Job) => {
  try {
    const result = await sftpProcessorExecutor(job);
    process.exitCode = 0;
    return result;
  } catch (e) {
    process.exitCode = 1;
  }
};
