/* eslint-disable @typescript-eslint/no-unused-vars */
import {
  ImagingMode,
  NotificationContents,
  NotificationParam,
  DataSourceType,
  ProcessingStatus,
  ProductFormat,
  ResolutionMode,
  TaskingStatus,
  TaskingStatusDetail,
  generateNotificationContents,
  SystemOrganization,
  SystemContract,
  NotificationParamItem,
} from '@iris-lib/constants';
import { ProductDataRequest, TaskingInfo } from '@iris-lib/db/entities';
import { INestApplication } from '@nestjs/common';
import { DataSource } from 'typeorm';
import { loadFixtureTaskingInfo } from './fixtures';
import { TaskingInfoUpdateStatusDto } from '../src/models/dto/tasking-info/tasking-info-update-status.dto';
import { GcPubsubClient, GcPubsubServer } from '@iris-lib/transporters';
import { lastValueFrom } from 'rxjs';
import { Test, TestingModule } from '@nestjs/testing';
import { ScsNotificationUsecaseModule } from '../src/usecases/scs-notification-usecase/scs-notification-usecase.module';
import { LoggerService } from '@iris-lib/logger';
import { ValidatorsModule } from '../validators/validators.module';
import { useContainer as useValidatorContainer } from 'class-validator';
import { CitadelGrpcService } from '@iris-lib/citadel';
import { plainToInstance } from 'class-transformer';
import {
  EmitRequestDto,
  PaymentReplyDto,
  PaymentsDto,
  VerifyItemDto,
} from '@iris-lib/models/payment';
import {
  PaymentTaskStatus,
  fromTaskingOperationStatusToPaymentTaskStatus,
} from '@iris-lib/constants/payment-task-status';
import {
  SlackChannel,
  SlackMessage,
  SlackNotificationService,
  SlackTaskingInfoStatusMessage,
} from '@iris-lib/slack';
import { ProductDetailsDto } from '@iris-lib/models';
import { TaskingInfoUsecaseService } from '../src/usecases/tasking-info-usecase/tasking-info-usecase.service';
import { add, getUnixTime } from 'date-fns';

describe('TaskingInfoUpdateStatus (e2e)', () => {
  let app: INestApplication;
  let dataSource: DataSource;
  let fixtureTaskingInfos: TaskingInfo[];
  let pubSubClient: GcPubsubClient;

  let createdProductDataRequests = new Array<ProductDataRequest>();
  const allProductDetailsValues = plainToInstance(ProductDetailsDto, [
    {
      productFormat: ProductFormat.GRD_GEOTIFF,
      resolutionMode: ResolutionMode.normal,
    },
    {
      productFormat: ProductFormat.GRD_GEOTIFF,
      resolutionMode: ResolutionMode.SR,
    },
    {
      productFormat: ProductFormat.SLC_SICD,
      resolutionMode: ResolutionMode.normal,
    },
    {
      productFormat: ProductFormat.SLC_CEOS,
      resolutionMode: ResolutionMode.normal,
    },
    {
      productFormat: ProductFormat.ORT_GEOTIFF,
      resolutionMode: ResolutionMode.normal,
    },
  ]);

  const mockCitadelGrpcService = {
    reserveTask: jest.fn(),
    emitTaskResult: jest.fn(),
  };

  const mockSlackNotificationService = {
    send: jest.fn(),
  };

  const taskMgmtUrl = `${process.env.IRIS_WEBPAGE_URL ?? 'NONE'}/tasks`;

  beforeAll(async () => {
    pubSubClient = new GcPubsubClient({
      topic: process.env.PUBSUB_SCS_NOTIFICATION_TOPIC,
      client: {
        apiEndpoint: process.env.PUBSUB_EMULATOR_HOST,
        projectId: process.env.PUBSUB_PROJECT_ID,
      },
    });

    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [ScsNotificationUsecaseModule, ValidatorsModule],
    })
      .overrideProvider(CitadelGrpcService)
      .useValue(mockCitadelGrpcService)
      .overrideProvider(SlackNotificationService)
      .useValue(mockSlackNotificationService)
      .compile();
    useValidatorContainer(moduleFixture, { fallbackOnErrors: true });

    app = moduleFixture.createNestApplication();
    app.connectMicroservice(
      {
        strategy: new GcPubsubServer({
          subscription: process.env.PUBSUB_SCS_NOTIFICATION_SUBSCRIPTION,
          client: {
            apiEndpoint: process.env.PUBSUB_EMULATOR_HOST,
            projectId: process.env.PUBSUB_PROJECT_ID,
          },
        }),
      },
      { inheritAppConfig: true },
    );

    // If you set LOG_SILENT=true, no logs will be output
    const logger = await app.get<LoggerService>(LoggerService);
    await app.useLogger(logger);

    await app.startAllMicroservices();
    await app.init();

    dataSource = app.get(DataSource);
    fixtureTaskingInfos = await loadFixtureTaskingInfo(dataSource);
  });

  beforeEach(async () => {
    mockSlackNotificationService.send = jest.fn((message: SlackMessage) => {
      return Promise.resolve(message.shouldNotify);
    });

    fixtureTaskingInfos[0].status = TaskingStatus.PreOrder;
    fixtureTaskingInfos[1].status = TaskingStatus.Ordered;
    fixtureTaskingInfos[2].status = TaskingStatus.OrderFixed;
    fixtureTaskingInfos[3].status = TaskingStatus.OrderFixed;
    fixtureTaskingInfos[4].status = TaskingStatus.PreOrder;
    fixtureTaskingInfos[5].status = TaskingStatus.Ordered;
    fixtureTaskingInfos[7].status = TaskingStatus.OrderFixed;
    fixtureTaskingInfos.map((taskingInfo) => {
      taskingInfo.statusDetail = TaskingStatusDetail.None;
      return taskingInfo;
    });
    await dataSource.getRepository(TaskingInfo).save(fixtureTaskingInfos);
  });

  afterAll(async () => {
    await fixtureTaskingInfos.reduce(async (p, c) => {
      await p;
      await dataSource.manager
        .getRepository(TaskingInfo)
        .update({ id: c.id }, { status: c.status });
    }, Promise.resolve());
    fixtureTaskingInfos.map((taskingInfo) => {
      taskingInfo.status = TaskingStatus.PreOrder;
      taskingInfo.statusDetail = TaskingStatusDetail.None;
      return taskingInfo;
    });
    await dataSource.getRepository(TaskingInfo).save(fixtureTaskingInfos);

    await dataSource.destroy();
    await app.close();
    await pubSubClient.close();
  });

  afterEach(async () => {
    await createdProductDataRequests.reduce(async (p, c) => {
      await p;
      await dataSource.manager.getRepository(ProductDataRequest).remove(c);
    }, Promise.resolve());
    createdProductDataRequests = [];
  });

  it.each([
    ['Regular', 0],
    // fixture-tasking_info-5 has TaskingType.Urgent
    ['Urgent', 4],
  ])(
    'tasking-info-update-status-sub event: ok (taskingType: %s, status: ordered)',
    async (_, fixtureTaskingInfoIdx) => {
      const targetStatus = TaskingStatus.Ordered;
      const targetTaskingInfo = fixtureTaskingInfos[fixtureTaskingInfoIdx];

      mockCitadelGrpcService.reserveTask = jest.fn(
        (registrationIds: string[]) => {
          const tmp = plainToInstance(PaymentsDto, {
            totalConsumptionCredit: 0,
            remainingCredit: 0,
            results: registrationIds.map((x) => {
              return plainToInstance(PaymentReplyDto, {
                registrationId: targetTaskingInfo.paymentId,
                taskId: x,
                status: PaymentTaskStatus.RESERVED,
                consumptionCredit: 0,
              } as PaymentReplyDto);
            }),
            verifyResults: registrationIds.map((x) => {
              return plainToInstance(VerifyItemDto, {
                taskId: x,
                consumptionCredit: 0,
                dataSourceType: DataSourceType.ARCHIVE,
                imagingMode: ImagingMode.Stripmap,
                numberOfLicense: 1,
                options: [],
              } as VerifyItemDto);
            }),
          } as PaymentsDto);

          return Promise.resolve(tmp);
        },
      );

      const msg: TaskingInfoUpdateStatusDto = {
        orderId: targetTaskingInfo.scsOrderId,
        status: targetStatus,
      };
      await lastValueFrom(pubSubClient.emit('tasking-info-update-status', msg));
      // wait for pubsub handler to complete
      await new Promise((r) => setTimeout(r, 300));
      const found = await dataSource
        .getRepository(TaskingInfo)
        .findOneOrFail({ where: { id: targetTaskingInfo.id } });
      expect(found.status).toEqual(targetStatus);
      expect(found.statusDetail).toEqual(TaskingStatusDetail.None);
      expect(getUnixTime(found.downloadExpired)).toEqual(
        getUnixTime(targetTaskingInfo.downloadExpired),
      );

      expect(mockCitadelGrpcService.reserveTask).toHaveBeenNthCalledWith(
        1,
        [targetTaskingInfo.id],
        await generateNotificationContents(
          targetStatus,
          plainToInstance(NotificationParam, {
            env: process.env.NODE_ENV,
            taskMgmtLink: taskMgmtUrl,
            items: [
              plainToInstance(NotificationParamItem, {
                scsOrderCode: found.scsOrderCode,
                obsStart: found.observationStart,
                updatedAt: found.updatedAt,
                reason: found.statusDetail,
                aoiName: found.name,
              } as NotificationParamItem),
            ],
          } as NotificationParam),
        ),
      );

      expect(mockSlackNotificationService.send).toHaveBeenCalledTimes(1);
      expect(mockSlackNotificationService.send).toHaveBeenNthCalledWith(
        1,
        new SlackTaskingInfoStatusMessage(
          {
            name: found.name,
            status: targetStatus,
            orderCode: found.scsOrderCode,
            observationStart: found.observationStart,
          },
          {
            channel:
              found.status === TaskingStatus.Ordered ||
              found.status === TaskingStatus.Rejected
                ? SlackChannel.URGENTTASKING
                : SlackChannel.DEFAULT,
            shouldMention:
              found.status === TaskingStatus.Ordered ||
              found.status === TaskingStatus.Rejected
                ? true
                : false,
          },
        ),
      );
      // TaskingStatus.Ordered should be notified to Slack
      await expect(
        mockSlackNotificationService.send.mock.results[0].value,
      ).resolves.toEqual(true);
    },
  );

  it('tasking-info-update-status-sub event: ok (status: order-fixed)', async () => {
    const targetStatus = TaskingStatus.OrderFixed;
    const targetTaskingInfo = fixtureTaskingInfos[1];

    const msg: TaskingInfoUpdateStatusDto = {
      orderId: targetTaskingInfo.scsOrderId,
      status: targetStatus,
    };
    await lastValueFrom(pubSubClient.emit('tasking-info-update-status', msg));
    // wait for pubsub handler to complete
    await new Promise((r) => setTimeout(r, 300));
    const found = await dataSource
      .getRepository(TaskingInfo)
      .findOneOrFail({ where: { id: targetTaskingInfo.id } });
    expect(found.status).toEqual(targetStatus);
    expect(found.statusDetail).toEqual(TaskingStatusDetail.None);
    expect(getUnixTime(found.downloadExpired)).toEqual(
      getUnixTime(targetTaskingInfo.downloadExpired),
    );

    expect(mockSlackNotificationService.send).toHaveBeenCalledTimes(1);
    expect(mockSlackNotificationService.send).toHaveBeenNthCalledWith(
      1,
      new SlackTaskingInfoStatusMessage(
        {
          name: found.name,
          status: targetStatus,
          orderCode: found.scsOrderCode,
          observationStart: found.observationStart,
        },
        {
          channel:
            found.status === TaskingStatus.Ordered ||
            found.status === TaskingStatus.Rejected
              ? SlackChannel.URGENTTASKING
              : SlackChannel.DEFAULT,
          shouldMention:
            found.status === TaskingStatus.Ordered ||
            found.status === TaskingStatus.Rejected
              ? true
              : false,
        },
      ),
    );
    // TaskingStatus.OrderFixed should NOT be notified to Slack
    await expect(
      mockSlackNotificationService.send.mock.results[0].value,
    ).resolves.toEqual(false);
  });

  it('tasking-info-update-status-sub event: ok (status: observation-completed)', async () => {
    const targetStatus = TaskingStatus.ObservationCompleted;
    // fixture-tasking_info-2 has 4 ProductFormats & 1 scene
    const targetTaskingInfo = fixtureTaskingInfos[1];
    targetTaskingInfo.status = TaskingStatus.OrderFixed;
    await dataSource.getRepository(TaskingInfo).save(fixtureTaskingInfos);

    const msg: TaskingInfoUpdateStatusDto = {
      orderId: targetTaskingInfo.scsOrderId,
      status: targetStatus,
    };
    await lastValueFrom(pubSubClient.emit('tasking-info-update-status', msg));
    // wait for pubsub handler to complete
    await new Promise((r) => setTimeout(r, 300));
    const found = await dataSource.getRepository(TaskingInfo).findOneOrFail({
      where: { id: targetTaskingInfo.id },
      relations: { productDataRequests: true },
    });
    createdProductDataRequests.push(...found.productDataRequests);

    expect(found.status).toEqual(targetStatus);
    expect(found.statusDetail).toEqual(TaskingStatusDetail.None);
    expect(getUnixTime(found.downloadExpired)).toBeGreaterThan(
      // at least 7 days
      getUnixTime(add(new Date(), { days: 6, hours: 23, minutes: 55 })),
    );

    expect(found.productDataRequests.length).toEqual(5); // 5 ProductFormats * 1 Scene
    expect(found.productDataRequests).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          scsOrderId: targetTaskingInfo.scsOrderId,
          taskingInfoId: targetTaskingInfo.id,
          flightDirection: targetTaskingInfo.flightDirection,
          contractId: targetTaskingInfo.contractId,
          organizationId: targetTaskingInfo.organizationId,
          status: ProcessingStatus.New,
        }),
      ]),
    );
    allProductDetailsValues.forEach((item) => {
      expect(found.productDataRequests).toEqual(
        expect.arrayContaining([
          expect.objectContaining({
            productFormat: item.productFormat,
            resolutionMode: item.resolutionMode,
            sceneNo: 0, // Non-LongSM starts numbering from 0
          }),
        ]),
      );
    });

    expect(mockSlackNotificationService.send).toHaveBeenCalledTimes(1);
    expect(mockSlackNotificationService.send).toHaveBeenNthCalledWith(
      1,
      new SlackTaskingInfoStatusMessage(
        {
          name: found.name,
          status: targetStatus,
          orderCode: found.scsOrderCode,
          observationStart: found.observationStart,
        },
        {
          channel:
            found.status === TaskingStatus.Ordered ||
            found.status === TaskingStatus.Rejected
              ? SlackChannel.URGENTTASKING
              : SlackChannel.DEFAULT,
          shouldMention:
            found.status === TaskingStatus.Ordered ||
            found.status === TaskingStatus.Rejected
              ? true
              : false,
        },
      ),
    );
    // TaskingStatus.ObservationCompleted should NOT be notified to Slack
    await expect(
      mockSlackNotificationService.send.mock.results[0].value,
    ).resolves.toEqual(false);
  });

  it('tasking-info-update-status-sub event: ok (status: observation-completed for LongSM)', async () => {
    const targetStatus = TaskingStatus.ObservationCompleted;
    // fixture-tasking_info-3 has 4 ProductFormats & 2 scenes
    const targetTaskingInfo = fixtureTaskingInfos[2];

    const msg: TaskingInfoUpdateStatusDto = {
      orderId: targetTaskingInfo.scsOrderId,
      status: targetStatus,
    };
    await lastValueFrom(pubSubClient.emit('tasking-info-update-status', msg));
    // wait for pubsub handler to complete
    await new Promise((r) => setTimeout(r, 300));
    const found = await dataSource.getRepository(TaskingInfo).findOneOrFail({
      where: { id: targetTaskingInfo.id },
      relations: { productDataRequests: true },
    });
    createdProductDataRequests.push(...found.productDataRequests);

    expect(found.status).toEqual(targetStatus);
    expect(found.statusDetail).toEqual(TaskingStatusDetail.None);
    expect(getUnixTime(found.downloadExpired)).toBeGreaterThan(
      // at least 7 days
      getUnixTime(add(new Date(), { days: 6, hours: 23, minutes: 55 })),
    );

    expect(found.productDataRequests.length).toEqual(10); // 5 ProductFormats * 2 Scenes
    expect(found.productDataRequests).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          scsOrderId: targetTaskingInfo.scsOrderId,
          taskingInfoId: targetTaskingInfo.id,
          flightDirection: targetTaskingInfo.flightDirection,
          contractId: targetTaskingInfo.contractId,
          organizationId: targetTaskingInfo.organizationId,
          status: ProcessingStatus.New,
        }),
      ]),
    );
    allProductDetailsValues.forEach((item) => {
      expect(found.productDataRequests).toEqual(
        expect.arrayContaining([
          expect.objectContaining({
            productFormat: item.productFormat,
            resolutionMode: item.resolutionMode,
            sceneNo: 1, // LongSM starts numbering from 1
          }),
          expect.objectContaining({
            productFormat: item.productFormat,
            resolutionMode: item.resolutionMode,
            sceneNo: 2,
          }),
        ]),
      );
    });

    expect(mockSlackNotificationService.send).toHaveBeenCalledTimes(1);
    expect(mockSlackNotificationService.send).toHaveBeenNthCalledWith(
      1,
      new SlackTaskingInfoStatusMessage(
        {
          name: found.name,
          status: targetStatus,
          orderCode: found.scsOrderCode,
          observationStart: found.observationStart,
        },
        {
          channel:
            found.status === TaskingStatus.Ordered ||
            found.status === TaskingStatus.Rejected
              ? SlackChannel.URGENTTASKING
              : SlackChannel.DEFAULT,
          shouldMention:
            found.status === TaskingStatus.Ordered ||
            found.status === TaskingStatus.Rejected
              ? true
              : false,
        },
      ),
    );
    // TaskingStatus.ObservationCompleted should NOT be notified to Slack
    await expect(
      mockSlackNotificationService.send.mock.results[0].value,
    ).resolves.toEqual(false);
  });

  it('tasking-info-update-status-sub event: ok (status: observation-completed for LongSM w/o default ProductData requested by user)', async () => {
    const targetStatus = TaskingStatus.ObservationCompleted;
    // fixture-tasking_info-8 has 3 ProductFormats (CEOS & SICD requested by user) & 2 scenes
    const targetTaskingInfo = fixtureTaskingInfos[7];

    const msg: TaskingInfoUpdateStatusDto = {
      orderId: targetTaskingInfo.scsOrderId,
      status: targetStatus,
    };
    await lastValueFrom(pubSubClient.emit('tasking-info-update-status', msg));
    // wait for pubsub handler to complete
    await new Promise((r) => setTimeout(r, 300));
    const found = await dataSource.getRepository(TaskingInfo).findOneOrFail({
      where: { id: targetTaskingInfo.id },
      relations: { productDataRequests: true },
    });
    createdProductDataRequests.push(...found.productDataRequests);
    const userRequestedProductDetails = found.productDetails;
    const nonUserRequestedProductDetails = plainToInstance(ProductDetailsDto, [
      {
        productFormat: ProductFormat.GRD_GEOTIFF,
        resolutionMode: ResolutionMode.normal,
      },
    ]);

    expect(found.status).toEqual(targetStatus);
    expect(found.statusDetail).toEqual(TaskingStatusDetail.None);
    expect(getUnixTime(found.downloadExpired)).toBeGreaterThan(
      // at least 7 days
      getUnixTime(add(new Date(), { days: 6, hours: 23, minutes: 55 })),
    );

    expect(found.productDataRequests.length).toEqual(6); // 3 ProductFormats * 2 Scenes
    expect(found.productDataRequests).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          scsOrderId: targetTaskingInfo.scsOrderId,
          taskingInfoId: targetTaskingInfo.id,
          flightDirection: targetTaskingInfo.flightDirection,
          contractId: targetTaskingInfo.contractId,
          organizationId: targetTaskingInfo.organizationId,
          status: ProcessingStatus.New,
        }),
      ]),
    );
    userRequestedProductDetails.forEach((item) => {
      expect(found.productDataRequests).toEqual(
        expect.arrayContaining([
          expect.objectContaining({
            organizationId: targetTaskingInfo.organizationId,
            contractId: targetTaskingInfo.contractId,
            productFormat: item.productFormat,
            resolutionMode: item.resolutionMode,
            sceneNo: 1, // LongSM starts numbering from 1
          }),
          expect.objectContaining({
            organizationId: targetTaskingInfo.organizationId,
            contractId: targetTaskingInfo.contractId,
            productFormat: item.productFormat,
            resolutionMode: item.resolutionMode,
            sceneNo: 2,
          }),
        ]),
      );
    });
    nonUserRequestedProductDetails.forEach((item) => {
      expect(found.productDataRequests).toEqual(
        expect.arrayContaining([
          expect.objectContaining({
            organizationId: SystemOrganization.NO_ORGANIZATION,
            contractId: SystemContract.NO_CONTRACT,
            productFormat: item.productFormat,
            resolutionMode: item.resolutionMode,
            sceneNo: 1, // LongSM starts numbering from 1
          }),
          expect.objectContaining({
            organizationId: SystemOrganization.NO_ORGANIZATION,
            contractId: SystemContract.NO_CONTRACT,
            productFormat: item.productFormat,
            resolutionMode: item.resolutionMode,
            sceneNo: 2,
          }),
        ]),
      );
    });

    expect(mockSlackNotificationService.send).toHaveBeenCalledTimes(1);
    expect(mockSlackNotificationService.send).toHaveBeenNthCalledWith(
      1,
      new SlackTaskingInfoStatusMessage(
        {
          name: found.name,
          status: targetStatus,
          orderCode: found.scsOrderCode,
          observationStart: found.observationStart,
        },
        {
          channel:
            found.status === TaskingStatus.Ordered ||
            found.status === TaskingStatus.Rejected
              ? SlackChannel.URGENTTASKING
              : SlackChannel.DEFAULT,
          shouldMention:
            found.status === TaskingStatus.Ordered ||
            found.status === TaskingStatus.Rejected
              ? true
              : false,
        },
      ),
    );
    // TaskingStatus.ObservationCompleted should NOT be notified to Slack
    await expect(
      mockSlackNotificationService.send.mock.results[0].value,
    ).resolves.toEqual(false);
  });

  it.each([
    // fixture-tasking_info-3 has no fixtureProductDataRequests
    [
      'Regular',
      TaskingStatus.ObservationFailed,
      TaskingStatusDetail.None,
      2,
      true,
    ],
    [
      'Regular',
      TaskingStatus.Canceled,
      TaskingStatusDetail.CanceledByOverriden,
      0,
      false,
    ],
    ['Regular', TaskingStatus.Rejected, TaskingStatusDetail.None, 1, false],
    // fixture-tasking_info-4 has TaskingType.Urgent
    [
      'Urgent',
      TaskingStatus.ObservationFailed,
      TaskingStatusDetail.None,
      3,
      false,
    ],
    // fixture-tasking_info-5 has TaskingType.Urgent
    [
      'Urgent',
      TaskingStatus.Canceled,
      TaskingStatusDetail.CanceledByOverriden,
      4,
      false,
    ],
    ['Urgent', TaskingStatus.Rejected, TaskingStatusDetail.None, 5, false],
  ])(
    'tasking-info-update-status-sub event: ok (taskingType: %s, status: %s, statusDetail: %s',
    async (
      _,
      targetStatus,
      targetStatusDetail,
      fixtureTaskingInfoIdx,
      checkProductDataRequests,
    ) => {
      const targetTaskingInfo = fixtureTaskingInfos[fixtureTaskingInfoIdx];

      mockCitadelGrpcService.emitTaskResult = jest
        .fn()
        .mockImplementationOnce(
          (
            emitRequests: EmitRequestDto[],
            notificationContents: NotificationContents,
          ) => {
            return Promise.resolve(
              emitRequests.map((x) => {
                return plainToInstance(PaymentReplyDto, {
                  registrationId: targetTaskingInfo.paymentId,
                  taskId: x.registrationId,
                  status: x.status,
                  consumptionCredit: 0,
                } as PaymentReplyDto);
              }),
            );
          },
        );

      const msg: TaskingInfoUpdateStatusDto = {
        orderId: targetTaskingInfo.scsOrderId,
        status: targetStatus,
      };
      await lastValueFrom(pubSubClient.emit('tasking-info-update-status', msg));
      // wait for pubsub handler to complete
      await new Promise((r) => setTimeout(r, 300));
      const found = await dataSource.getRepository(TaskingInfo).findOneOrFail({
        where: { id: targetTaskingInfo.id },
        relations: { productDataRequests: true },
      });
      expect(found.status).toEqual(targetStatus);
      expect(found.statusDetail).toEqual(targetStatusDetail);
      expect(getUnixTime(found.downloadExpired)).toEqual(
        getUnixTime(targetTaskingInfo.downloadExpired),
      );

      if (checkProductDataRequests) {
        expect(found.productDataRequests.length).toEqual(0);
      }

      expect(mockCitadelGrpcService.emitTaskResult).toHaveBeenNthCalledWith(
        1,
        [
          plainToInstance(EmitRequestDto, {
            registrationId: targetTaskingInfo.id,
            status: fromTaskingOperationStatusToPaymentTaskStatus(targetStatus), // FIXME
          } as EmitRequestDto),
        ],
        await generateNotificationContents(
          targetStatus,
          plainToInstance(NotificationParam, {
            env: process.env.NODE_ENV,
            taskMgmtLink: taskMgmtUrl,
            items: [
              plainToInstance(NotificationParamItem, {
                scsOrderCode: found.scsOrderCode,
                obsStart: found.observationStart,
                updatedAt: found.updatedAt,
                reason: found.statusDetail,
                aoiName: found.name,
              } as NotificationParamItem),
            ],
          } as NotificationParam),
        ),
      );

      expect(mockSlackNotificationService.send).toHaveBeenCalledTimes(1);
      expect(mockSlackNotificationService.send).toHaveBeenNthCalledWith(
        1,
        new SlackTaskingInfoStatusMessage(
          {
            name: found.name,
            status: targetStatus,
            orderCode: found.scsOrderCode,
            observationStart: found.observationStart,
          },
          {
            channel:
              found.status === TaskingStatus.Ordered ||
              found.status === TaskingStatus.Rejected
                ? SlackChannel.URGENTTASKING
                : SlackChannel.DEFAULT,
            shouldMention:
              found.status === TaskingStatus.Ordered ||
              found.status === TaskingStatus.Rejected
                ? true
                : false,
          },
        ),
      );
      // TaskingStatus.ObservationFailed/Canceled/Rejected should be notified to Slack
      await expect(
        mockSlackNotificationService.send.mock.results[0].value,
      ).resolves.toEqual(true);
    },
  );

  it('tasking-info-update-status-sub event: ng (status: pre-credit-check)', async () => {
    const targetTaskingInfo = fixtureTaskingInfos[0];
    const targetStatus = TaskingStatus.PreCreditCheck;

    const msg: TaskingInfoUpdateStatusDto = {
      orderId: targetTaskingInfo.scsOrderId,
      status: targetStatus,
    };
    await lastValueFrom(pubSubClient.emit('tasking-info-update-status', msg));
    // wait for pubsub handler to complete
    await new Promise((r) => setTimeout(r, 300));
    const found = await dataSource
      .getRepository(TaskingInfo)
      .findOneOrFail({ where: { id: targetTaskingInfo.id } });
    expect(found.status).toEqual(targetTaskingInfo.status);
    expect(found.statusDetail).toEqual(targetTaskingInfo.statusDetail);
    expect(getUnixTime(found.downloadExpired)).toEqual(
      getUnixTime(targetTaskingInfo.downloadExpired),
    );
  });

  it('tasking-info-update-status-sub event: ng (status: observation-completed for LongSM, tasking-status update error)', async () => {
    const targetStatus = TaskingStatus.ObservationCompleted;
    // fixture-tasking_info-3 has 3 ProductFormates & 2 scenes
    const targetTaskingInfo = fixtureTaskingInfos[2];

    const mockUpdateTaskingInfoStatus = jest
      .spyOn(
        TaskingInfoUsecaseService.prototype as any,
        'updateStatusAndSetDownloadExpired',
      )
      .mockImplementationOnce(() => {
        return new Promise(() => {
          throw new Error('may be db error');
        });
      });

    const msg: TaskingInfoUpdateStatusDto = {
      orderId: targetTaskingInfo.scsOrderId,
      status: targetStatus,
    };
    await lastValueFrom(pubSubClient.emit('tasking-info-update-status', msg));
    // wait for pubsub handler to complete
    await new Promise((r) => setTimeout(r, 300));
    const found = await dataSource.getRepository(TaskingInfo).findOneOrFail({
      where: { id: targetTaskingInfo.id },
      relations: { productDataRequests: true },
    });
    createdProductDataRequests.push(...found.productDataRequests);

    expect(found.status).toEqual(targetTaskingInfo.status);
    expect(found.statusDetail).toEqual(targetTaskingInfo.statusDetail);
    expect(getUnixTime(found.downloadExpired)).toEqual(
      getUnixTime(targetTaskingInfo.downloadExpired),
    );

    expect(mockUpdateTaskingInfoStatus).toBeCalledTimes(1);

    expect(found.productDataRequests.length).toEqual(0);

    mockUpdateTaskingInfoStatus.mockRestore();
  });

  it('tasking-info-update-status-sub event: ng (status: ordered, reserveTask citadel error)', async () => {
    const targetStatus = TaskingStatus.Ordered;
    const targetTaskingInfo = fixtureTaskingInfos[0];

    mockCitadelGrpcService.reserveTask = jest
      .fn()
      .mockRejectedValueOnce(new Error('citadel error'));

    const msg: TaskingInfoUpdateStatusDto = {
      orderId: targetTaskingInfo.scsOrderId,
      status: targetStatus,
    };
    await lastValueFrom(pubSubClient.emit('tasking-info-update-status', msg));
    // wait for pubsub handler to complete
    await new Promise((r) => setTimeout(r, 300));
    const found = await dataSource.getRepository(TaskingInfo).findOneOrFail({
      where: { id: targetTaskingInfo.id },
    });
    expect(found.status).toEqual(targetTaskingInfo.status);
    expect(found.statusDetail).toEqual(targetTaskingInfo.statusDetail);
    expect(getUnixTime(found.downloadExpired)).toEqual(
      getUnixTime(targetTaskingInfo.downloadExpired),
    );

    expect(mockCitadelGrpcService.reserveTask).toHaveBeenNthCalledWith(
      1,
      [targetTaskingInfo.id],
      // Updated time won't returned from finalize function in the case of rollback.
      // Thus, check with anything.
      expect.anything(),
    );
  });

  it.each([
    [TaskingStatus.ObservationFailed, 2],
    [TaskingStatus.Canceled, 0],
    [TaskingStatus.Rejected, 1],
  ])(
    'tasking-info-update-status-sub event: ng (status: %s, emitTaskResult citadel error)',
    async (targetStatus, fixtureTaskingInfoIdx) => {
      const targetTaskingInfo = fixtureTaskingInfos[fixtureTaskingInfoIdx];

      mockCitadelGrpcService.emitTaskResult = jest
        .fn()
        .mockRejectedValueOnce(new Error('citadel error'));

      const msg: TaskingInfoUpdateStatusDto = {
        orderId: targetTaskingInfo.scsOrderId,
        status: targetStatus,
      };
      await lastValueFrom(pubSubClient.emit('tasking-info-update-status', msg));
      // wait for pubsub handler to complete
      await new Promise((r) => setTimeout(r, 300));
      const found = await dataSource.getRepository(TaskingInfo).findOneOrFail({
        where: { id: targetTaskingInfo.id },
      });
      expect(found.status).toEqual(targetTaskingInfo.status);
      expect(found.statusDetail).toEqual(targetTaskingInfo.statusDetail);
      expect(getUnixTime(found.downloadExpired)).toEqual(
        getUnixTime(targetTaskingInfo.downloadExpired),
      );

      expect(mockCitadelGrpcService.emitTaskResult).toHaveBeenNthCalledWith(
        1,
        [
          plainToInstance(EmitRequestDto, {
            registrationId: targetTaskingInfo.id,
            status: fromTaskingOperationStatusToPaymentTaskStatus(targetStatus), // FIXME
          } as EmitRequestDto),
        ],
        // Updated time won't returned from finalize function in the case of rollback.
        // Thus, check with anything.
        expect.anything(),
      );
    },
  );
});
