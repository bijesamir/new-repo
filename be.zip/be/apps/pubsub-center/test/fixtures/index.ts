import {
  SystemContract,
  TEST_ANOTHER_CONTRACT_ID,
  TEST_CONTRACT_ID,
  TEST_REGULAR_TASK_CONTRACT_ID,
} from '@iris-lib/constants';
import {
  ArchivePurchaseRequest,
  ProductData,
  ProductDataRequest,
  ProductDataVersion,
  TaskingInfo,
} from '@iris-lib/db/entities';
import { DataSource, In, Like, Not } from 'typeorm';

export const loadFixtureTaskingInfo = async (ds: DataSource) => {
  return await ds.manager.getRepository(TaskingInfo).find({
    where: {
      name: Like('fixture%'),
      contractId: Not(TEST_REGULAR_TASK_CONTRACT_ID),
    },
    order: { no: 'ASC' },
  });
};

export const loadFixtureArchiveTaskingInfo = async (ds: DataSource) => {
  return await ds.manager.getRepository(TaskingInfo).find({
    where: {
      name: Like('Afixture%'),
      contractId: Not(TEST_REGULAR_TASK_CONTRACT_ID),
    },
    order: { no: 'ASC' },
  });
};

export const loadFixtureProductDataRequest = async (ds: DataSource) => {
  return await ds.manager.getRepository(ProductDataRequest).find({
    where: { contractId: In([TEST_CONTRACT_ID, TEST_ANOTHER_CONTRACT_ID]) },
  });
};

export const loadFixtureProductDataVersion = async (ds: DataSource) => {
  return await ds.manager.getRepository(ProductDataVersion).find({});
};

export const loadFixtureArchiveProductData = async (ds: DataSource) => {
  return await ds.manager.getRepository(ProductData).find({
    where: {
      contractId: In([TEST_ANOTHER_CONTRACT_ID, SystemContract.NO_CONTRACT]),
    },
    relations: [
      'productDataRequest',
      'reprocessingRequests',
      'productDataVersions',
    ],
    order: { no: 'ASC' },
  });
};

export const loadFixtureArchivePurchaseRequests = async (ds: DataSource) => {
  return await ds.manager.getRepository(ArchivePurchaseRequest).find({
    relations: {
      reprocessingRequests: true,
      archivePurchasedItems: { sceneInfo: { taskingInfo: true } },
      archivePurchasedProductData: {
        productData: { sceneInfo: true },
        productDataVersion: true,
      },
    },
  });
};
