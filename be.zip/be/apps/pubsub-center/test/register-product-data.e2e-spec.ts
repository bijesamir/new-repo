import { GcPubsubClient, GcPubsubServer } from '@iris-lib/transporters';
import { INestApplication } from '@nestjs/common';
import { Test, TestingModule } from '@nestjs/testing';
import { DataSource, EntityNotFoundError, In, TypeORMError } from 'typeorm';
import { DpsNotificationUsecaseModule } from '../src/usecases/dps-notification-usecase/dps-notification-usecase.module';
import { GcsServiceService } from '../src/infra/gcs-service/gcs-service.service';
import { lastValueFrom } from 'rxjs';
import { RegisterProductDataDto } from '../src/models/dto/product-data/register-product-data.dto';
import {
  loadFixtureArchiveProductData,
  loadFixtureArchivePurchaseRequests,
  loadFixtureArchiveTaskingInfo,
  loadFixtureProductDataRequest,
  loadFixtureTaskingInfo,
} from './fixtures';
import {
  ArchivePurchaseRequest,
  ArchivePurchasedProductData,
  ProductData,
  ProductDataRequest,
  ProductDataVersion,
  ReprocessingRequest,
  TaskingInfo,
} from '@iris-lib/db/entities';
import { Readable, Writable } from 'stream';
import { GcPubsubServiceService } from '../src/infra/gc-pubsub-service/gc-pubsub-service.service';
import {
  FlightDirection,
  ImagingMode,
  IsNotificationAvailable,
  LookingDirection,
  OrbitType,
  PolarizationType,
  ProcessingStatus,
  ProductFormat,
  ResolutionMode,
  getProductFormatLabelShort,
  getProductFormatLabel,
  getResolutionModeLabel,
  getPublicationStartByDelayKind,
  getProductFormatOutput,
  getImagingModeLabel,
  OrderStatus,
  SystemOrganization,
  getTestAnotherOrganizationIdForFixture,
  getTestOrganizationIdForFixture,
} from '@iris-lib/constants';
import { GetFilesOptions } from '@google-cloud/storage';
import { LoggerService } from '@iris-lib/logger';
import * as YAML from 'yaml';
import * as df from 'date-fns';
import * as Jimp from 'jimp';
import { ProductMetadataDto } from '@iris-lib/models';
import { instanceToInstance, plainToInstance } from 'class-transformer';
import {
  SlackArchivePurchaseRequestStatusMessage,
  SlackChannel,
  SlackErrorMessage,
  SlackMessage,
  SlackNoRequestStatusMessage,
  SlackNotificationService,
  SlackProductDataRequestStatusMessage,
  SlackReprocessingRequestStatusMessage,
} from '@iris-lib/slack';
import { DeliveryRequestDto } from '@iris-lib/models/job';
import { getQueueToken } from '@nestjs/bullmq';
import { REGISTER_PRODUCT_DATA_QUEUE } from '../src/constants/queues';
import { Queue, QueueEvents } from 'bullmq';
import { toPolygon } from '@iris-lib/utils';
import geojsonExtent from '@mapbox/geojson-extent';
import {
  ProductDataQuicklookImgRegEx,
  ProductDataQuicklookImgScaleFactor,
  ProductDataZipFilesRegEx,
} from '../src/usecases/dps-product-access-usecase/dps-product-access-usecase.service';
import { TaskingInfoUsecaseService } from '../src/usecases/tasking-info-usecase/tasking-info-usecase.service';
import { ProductDataRequestUsecaseService } from '../src/usecases/product-data-request-usecase/product-data-request-usecase.service';
import { ProductDataUsecaseService } from '../src/usecases/product-data-usecase/product-data-usecase.service';
import { ProductDataVersionUsecaseService } from '../src/usecases/product-data-version-usecase/product-data-version-usecase.service';
import { CreateSceneInfoDto } from '../src/models/dto/scene-info/create-scene-info.dto';
import { NotifyProductReadyDto } from '../src/models/dto/product-data/notify-product-ready.dto';
import { add, getUnixTime, set } from 'date-fns';

const baseProductMetadataYaml = plainToInstance(ProductMetadataDto, {
  product: {
    productSoftwareVersion: 'v007.000',
    productFormat: ProductFormat.GRD_GEOTIFF,
    dataProcessingSoftwareVersion: 'v0.10.0',
    orbitType: OrbitType.OB,
    focusSoftwareType: 'msar',
    focusSoftwareVersion: 'v702',
    resolutionMode: ResolutionMode.normal,
  },
  geometry: {
    sceneCenterLocation: '-27.35446666895787 -66.67473904120934',
    sceneCornerLocations:
      '-27.300620979817765 -66.79206392164848 -27.44122412677884 -66.76265748962582 -27.408312358097973 -66.55741416077018 -27.267709211136896 -66.58682059279283 -27.300620979817765 -66.79206392164848',
  },
  observation: {
    sceneId: 'STRIXB-00010101T010101Z',
    sceneNo: 1,
    orderCode: '202302-10003',
    imagingMode: ImagingMode.Stripmap,
    satelliteId: 'ST0002',
    polarization: PolarizationType.VV,
    offnadirAngle: -30.55,
    flightDirection: FlightDirection.Descending,
    lookingDirection: LookingDirection.Right,
    sceneEndDateTime: '2023-02-03T03:03:04.000Z',
    sceneStartDateTime: '2023-02-03T03:03:02.000Z',
    sceneCenterDateTime: '2023-02-03T03:03:03.000Z',
  },
});
const basePubsubMessage = plainToInstance(RegisterProductDataDto, {
  orderId: '<scs_order_id>',
  productFormat: ProductFormat.GRD_GEOTIFF,
  resolutionMode: ResolutionMode.normal,
  sceneNo: 1,
  batchId: '<batch_id>',
  version: '<pipeline_id>',
  path: `datasets/<scs_order_code>/<pipeline_id>/GRD`,
  bucket: 'gs://syns-gro-dev_product-data-store',
});
// 1x1 green dot PNG
const image = `
iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M/wHwAEBgIApD5fRAAAAABJRU5ErkJggg==
`;

const mockGcsServiceListFilesFunction = (_bucket, options: GetFilesOptions) => {
  let data;
  const ProductFormatShort = options.prefix.split('/')[3];

  switch (ProductFormatShort) {
    case 'GRD':
    case 'SR-GRD':
      data = [
        'datasets/<scs_order_code>/<pipeline_id>/GRD/IMG-xxx-SMGRD_warp.tif',
        'datasets/<scs_order_code>/<pipeline_id>/GRD/PAR-xxx-SMGRD_warp.xml',
        'datasets/<scs_order_code>/<pipeline_id>/GRD/IMG-xxx-SMGRD.jpeg',
        'datasets/<scs_order_code>/<pipeline_id>/GRD/product-metadata.yaml',
      ];
      break;
    case 'SICD':
      data = [
        'datasets/<scs_order_code>/<pipeline_id>/SICD/IMG-xxx-SLC-SICD.nitf',
        'datasets/<scs_order_code>/<pipeline_id>/SICD/IMG-xxx-SLC-SICD.jpeg',
        'datasets/<scs_order_code>/<pipeline_id>/SICD/product-metadata.yaml',
      ];
      break;
    case 'CEOS':
      data = [
        'datasets/<scs_order_code>/<pipeline_id>/CEOS/BRS-xxx-SLC.png',
        'datasets/<scs_order_code>/<pipeline_id>/CEOS/IMG-xxx-SLC',
        'datasets/<scs_order_code>/<pipeline_id>/CEOS/LED-xxx-SLC',
        'datasets/<scs_order_code>/<pipeline_id>/CEOS/TRL-xxx-SLC',
        'datasets/<scs_order_code>/<pipeline_id>/CEOS/VOL-xxx-SLC',
        'datasets/<scs_order_code>/<pipeline_id>/CEOS/product-metadata.yaml',
        'datasets/<scs_order_code>/<pipeline_id>/CEOS/summary.txt',
      ];
      break;
    case 'ORT':
      data = [
        'datasets/<scs_order_code>/<pipeline_id>/ORT/IMG-xxx-SMORT_warp.tif',
        'datasets/<scs_order_code>/<pipeline_id>/ORT/PAR-xxx-SMORT_warp.xml',
        'datasets/<scs_order_code>/<pipeline_id>/ORT/IMG-xxx-SMORT.jpeg',
        'datasets/<scs_order_code>/<pipeline_id>/ORT/product-metadata.yaml',
      ];
      break;
  }
  return Promise.resolve([
    data.map((fileName) => ({ name: fileName, metadata: { size: 1 } })),
  ]);
};

const mockGcsServiceGetMetadataFunction = (_bucket, fromPath: string) => {
  let metadata;
  switch (fromPath) {
    case 'datasets/<scs_order_code>/<pipeline_id>/GRD/IMG-xxx-SMGRD.jpeg':
    case 'datasets/<scs_order_code>/<pipeline_id>/SR-GRD/IMG-xxx-SMGRD.jpeg':
    case 'datasets/<scs_order_code>/<pipeline_id>/SICD/IMG-xxx-SLC-SICD.jpeg':
    case 'datasets/<scs_order_code>/<pipeline_id>/ORT/IMG-xxx-SMORT.jpeg':
      metadata = { contentType: 'image/jpeg' };
      break;
    case 'datasets/<scs_order_code>/<pipeline_id>/CEOS/BRS-xxx-SLC.png':
      metadata = { contentType: 'image/png' };
      break;
  }
  return Promise.resolve([metadata]);
};

const mockGcsServiceDownloadFileFunction = (_bucket, fromPath: string) => {
  let data: Buffer;
  switch (fromPath) {
    case 'datasets/<scs_order_code>/<pipeline_id>/GRD/product-metadata.yaml': {
      const metadata = instanceToInstance(baseProductMetadataYaml);
      data = Buffer.from(YAML.stringify(metadata));
      break;
    }
    case 'datasets/<scs_order_code>/<pipeline_id>/SR-GRD/product-metadata.yaml': {
      const metadata = instanceToInstance(baseProductMetadataYaml);
      metadata.product.resolutionMode = ResolutionMode.SR;
      data = Buffer.from(YAML.stringify(metadata));
      break;
    }
    case 'datasets/<scs_order_code>/<pipeline_id>/SICD/product-metadata.yaml': {
      const metadata = instanceToInstance(baseProductMetadataYaml);
      metadata.product.productFormat = ProductFormat.SLC_SICD;
      data = Buffer.from(YAML.stringify(metadata));
      break;
    }
    case 'datasets/<scs_order_code>/<pipeline_id>/CEOS/product-metadata.yaml': {
      const metadata = instanceToInstance(baseProductMetadataYaml);
      metadata.product.productFormat = ProductFormat.SLC_CEOS;
      data = Buffer.from(YAML.stringify(metadata));
      break;
    }
    case 'datasets/<scs_order_code>/<pipeline_id>/ORT/product-metadata.yaml': {
      const metadata = instanceToInstance(baseProductMetadataYaml);
      metadata.product.productFormat = ProductFormat.ORT_GEOTIFF;
      data = Buffer.from(YAML.stringify(metadata));
      break;
    }
    case 'datasets/<scs_order_code>/<pipeline_id>/GRD/IMG-xxx-SMGRD.jpeg':
    case 'datasets/<scs_order_code>/<pipeline_id>/SR-GRD/IMG-xxx-SMGRD.jpeg':
    case 'datasets/<scs_order_code>/<pipeline_id>/SICD/IMG-xxx-SLC-SICD.jpeg':
    case 'datasets/<scs_order_code>/<pipeline_id>/CEOS/BRS-xxx-SLC.png':
    case 'datasets/<scs_order_code>/<pipeline_id>/ORT/IMG-xxx-SMORT.jpeg':
      data = Buffer.from(image, 'base64');
      break;
  }
  return Promise.resolve([data]);
};

const mockGcsServiceUploadDataFunction = (
  _bucket: string,
  _fileName: string,
  buffer: string | Buffer,
) => {
  // fs.writeFileSync(__dirname + '/img.jpeg', buffer);
  return buffer;
};

const mockGcsServiceCreateReadStreamFunction = (
  _bucket: string,
  name: string,
) => {
  const readable = new Readable();
  readable.push(`write: ${name}`);
  readable.push(null);

  return readable;
};

const mockGcsServiceCreateWriteStreamFunction = () => {
  // return fs.createWriteStream(__dirname + '/test.zip');

  const writable = new Writable();
  writable._write = (_chunk, _encoding, next) => {
    next();
  };

  return writable;
};

const mockGcPubsubServiceEmitDeliveryProductDataFunction = (
  productDataVersion: ProductDataVersion,
  isNotificationAvailable: IsNotificationAvailable,
) => {
  return plainToInstance(DeliveryRequestDto, {
    productDataVersionId: productDataVersion.id,
    organizationId: productDataVersion.organizationId,
    contractId: productDataVersion.contractId,
    isNotificationAvailable,
  } as DeliveryRequestDto);
};

const mockGcPubsubServiceEmitCreateSceneInfoFunction = (
  productDataRequest: ProductDataRequest,
) => {
  return plainToInstance(CreateSceneInfoDto, {
    taskingInfoId: productDataRequest.taskingInfoId,
    sceneNo: productDataRequest.sceneNo,
  });
};

const mockGcPubsubServiceNotifyProductReadyFunction = (
  apr: ArchivePurchaseRequest,
  pdv: ProductDataVersion,
) => {
  return plainToInstance(NotifyProductReadyDto, {
    orderId: apr.id,
    productDataVersionId: pdv.id,
  } as NotifyProductReadyDto);
};

const mockSlackNotificationServiceSendFunction = (message: SlackMessage) => {
  return Promise.resolve(message.shouldNotify);
};

describe('RegisterProductData (e2e)', () => {
  let pubSubClient: GcPubsubClient;

  beforeAll(async () => {
    jest.useFakeTimers({
      advanceTimers: true,
      now: new Date('2024-03-01T01:00:00.000Z'),
    });

    pubSubClient = new GcPubsubClient({
      topic: process.env.PUBSUB_DPS_NOTIFICATION_TOPIC,
      client: {
        apiEndpoint: process.env.PUBSUB_EMULATOR_HOST,
        projectId: process.env.PUBSUB_PROJECT_ID,
      },
    });
  });

  afterAll(async () => {
    await pubSubClient.close();
    jest.useRealTimers();
  });

  describe('register-product-data event: ok', () => {
    let app: INestApplication;
    let dataSource: DataSource;
    let queue: Queue;
    let queueEvents: QueueEvents;
    let fixtureTaskingInfos: TaskingInfo[];
    let fixtureProductDataRequests: ProductDataRequest[];
    let fixtureArchiveTaskingInfos: TaskingInfo[];
    let fixtureArchiveProductData: ProductData[];
    let fixtureReprocessingRequests: ReprocessingRequest[];
    let fixtureArchivePurchaseRequests: ArchivePurchaseRequest[];
    let fixtureProductDataVersions: ProductDataVersion[];

    const createdProductData = new Array<ProductData>();

    const mockGcsService = {
      listFiles: jest.fn(),
      getMetadata: jest.fn(),
      downloadFile: jest.fn(),
      uploadData: jest.fn(),
      createReadStream: jest.fn(),
      createWriteStream: jest.fn(),
    };
    // check if we can spy on this.deliveryPubsubClient.emit('register-product-data-delivery', data);
    // instead of mockGcPubsubService.emitDeliveryProductDataEvent
    const mockGcPubsubService = {
      emitDeliveryProductDataEvent: jest.fn(),
      emitCreateSceneInfoEvent: jest.fn(),
      emitNotifyProductReadyEvent: jest.fn(),
    };

    const mockSlackNotificationService = {
      send: jest.fn(),
    };

    beforeAll(async () => {
      const moduleFixture: TestingModule = await Test.createTestingModule({
        imports: [DpsNotificationUsecaseModule],
      })
        .overrideProvider(GcsServiceService)
        .useValue(mockGcsService)
        .overrideProvider(GcPubsubServiceService)
        .useValue(mockGcPubsubService)
        .overrideProvider(SlackNotificationService)
        .useValue(mockSlackNotificationService)
        .compile();

      app = moduleFixture.createNestApplication();
      app.connectMicroservice(
        {
          strategy: new GcPubsubServer({
            subscription: process.env.PUBSUB_DPS_NOTIFICATION_SUBSCRIPTION,
            client: {
              apiEndpoint: process.env.PUBSUB_EMULATOR_HOST,
              projectId: process.env.PUBSUB_PROJECT_ID,
            },
          }),
        },
        { inheritAppConfig: true },
      );

      // If you set LOG_SILENT=true, no logs will be output
      const logger = await app.get<LoggerService>(LoggerService);
      await app.useLogger(logger);

      await app.startAllMicroservices();
      await app.init();

      dataSource = app.get(DataSource);
      queue = app.get(getQueueToken(REGISTER_PRODUCT_DATA_QUEUE));
      queueEvents = new QueueEvents(REGISTER_PRODUCT_DATA_QUEUE, {
        connection: queue.opts.connection,
      });

      fixtureTaskingInfos = await loadFixtureTaskingInfo(dataSource);
      fixtureArchiveTaskingInfos =
        await loadFixtureArchiveTaskingInfo(dataSource);
      fixtureProductDataRequests =
        await loadFixtureProductDataRequest(dataSource);
      fixtureArchiveProductData =
        await loadFixtureArchiveProductData(dataSource);
      fixtureReprocessingRequests = await fixtureArchiveProductData.reduce(
        async (p, c) => {
          const array = await p;
          const rrs = await dataSource.manager
            .getRepository(ReprocessingRequest)
            .find({
              where: { productData: { id: c.id } },
            });
          if (rrs.length) {
            return [...array, ...rrs];
          } else {
            return array;
          }
        },
        Promise.resolve([]),
      );
      fixtureArchivePurchaseRequests =
        await loadFixtureArchivePurchaseRequests(dataSource);
      fixtureProductDataVersions = await dataSource.manager
        .getRepository(ProductDataVersion)
        .find();
    });

    beforeEach(async () => {
      mockGcsService.listFiles = jest.fn(mockGcsServiceListFilesFunction);
      mockGcsService.getMetadata = jest.fn(mockGcsServiceGetMetadataFunction);
      mockGcsService.downloadFile = jest.fn(mockGcsServiceDownloadFileFunction);
      mockGcsService.uploadData = jest.fn(mockGcsServiceUploadDataFunction);
      mockGcsService.createReadStream = jest.fn(
        mockGcsServiceCreateReadStreamFunction,
      );
      mockGcsService.createWriteStream = jest.fn(
        mockGcsServiceCreateWriteStreamFunction,
      );
      mockGcPubsubService.emitDeliveryProductDataEvent = jest.fn(
        mockGcPubsubServiceEmitDeliveryProductDataFunction,
      );
      mockGcPubsubService.emitCreateSceneInfoEvent = jest.fn(
        mockGcPubsubServiceEmitCreateSceneInfoFunction,
      );
      mockGcPubsubService.emitNotifyProductReadyEvent = jest.fn(
        mockGcPubsubServiceNotifyProductReadyFunction,
      );
      mockSlackNotificationService.send = jest.fn(
        mockSlackNotificationServiceSendFunction,
      );
      await queue.clean(0, 0, 'completed');
      await queue.clean(0, 0, 'failed');
    });

    afterAll(async () => {
      await createdProductData.reduce(async (p, c) => {
        await p;
        await dataSource.manager
          .getRepository(ArchivePurchasedProductData)
          .update(
            {
              productDataVersionId: In(
                c.productDataVersions.reduce((p, c) => {
                  if (!fixtureProductDataVersions.find((x) => x.id === c.id)) {
                    p.push(c.id);
                  }
                  return p;
                }, []),
              ),
            },
            {
              productDataVersion: null,
            },
          );
        await dataSource.manager.getRepository(ProductDataVersion).remove(
          c.productDataVersions.reduce((p, c) => {
            if (!fixtureProductDataVersions.find((x) => x.id === c.id)) {
              p.push(c);
            }
            return p;
          }, new Array<ProductDataVersion>()),
        );
        if (!fixtureArchiveProductData.find((pd) => pd.id === c.id)) {
          await dataSource.manager.getRepository(ProductData).remove(c);
        }
      }, Promise.resolve());

      await dataSource.manager
        .getRepository(TaskingInfo)
        .save(fixtureTaskingInfos);

      await dataSource.manager
        .getRepository(ProductDataRequest)
        .save(fixtureProductDataRequests);

      await dataSource.manager
        .getRepository(ReprocessingRequest)
        .save(fixtureReprocessingRequests);

      await dataSource.manager
        .getRepository(ArchivePurchaseRequest)
        .save(fixtureArchivePurchaseRequests);

      await dataSource.manager
        .getRepository(ProductData)
        .save(fixtureArchiveProductData);

      await dataSource.destroy();
      await queue.obliterate();
      await queue.close();
      await queueEvents.close();
      await app.close();
    });

    // fixtureTaskingInfos[4] & [5] has no ProductData items -> new items will be created
    it.each([
      [
        'GRD_GEOTIFF',
        ProductFormat.GRD_GEOTIFF,
        ResolutionMode.normal,
        'fixture-tasking_info-5',
        true,
        false,
      ],
      [
        'SLC_SICD',
        ProductFormat.SLC_SICD,
        ResolutionMode.normal,
        'fixture-tasking_info-5',
        true,
        false,
      ],
      [
        'SLC_CEOS',
        ProductFormat.SLC_CEOS,
        ResolutionMode.normal,
        'fixture-tasking_info-5',
        true,
        false,
      ],
      [
        'SR-GRD_GEOTIFF',
        ProductFormat.GRD_GEOTIFF,
        ResolutionMode.SR,
        'fixture-tasking_info-6',
        true,
        false,
      ],
      [
        'ORT_GEOTIFF',
        ProductFormat.ORT_GEOTIFF,
        ResolutionMode.normal,
        'fixture-tasking_info-23',
        true,
        true,
      ],
      [
        'No PDR',
        ProductFormat.SLC_CEOS,
        ResolutionMode.normal,
        'fixture-tasking_info-3',
        false,
        true,
      ], // downloadExpired extended
    ])(
      '%s',
      async (
        _,
        targetProductFormat,
        targetResolutionMode,
        fixtureName,
        checkPDR,
        isDownloadExpiredExtended,
      ) => {
        const targetTaskingInfo = fixtureTaskingInfos.find(
          (x) => x.name === fixtureName,
        );
        const numberOfZipFiles =
          ProductDataZipFilesRegEx[targetProductFormat].length;
        const quicklookContentType =
          'image/' +
          ProductDataQuicklookImgRegEx[targetProductFormat].replace(
            /(.*)(jpeg|png)(.*)/,
            '$2',
          );
        const quicklookScaleFactor =
          ProductDataQuicklookImgScaleFactor[targetProductFormat];
        const sceneNo = targetTaskingInfo.scenes - 1;
        baseProductMetadataYaml.observation.sceneNo = sceneNo;
        const productNameInput =
          targetResolutionMode === ResolutionMode.SR
            ? `${getResolutionModeLabel(
                targetResolutionMode,
              )}-${getProductFormatLabelShort(targetProductFormat)}`
            : getProductFormatLabelShort(targetProductFormat);

        const msg: RegisterProductDataDto = {
          orderId: targetTaskingInfo.scsOrderId,
          productFormat: targetProductFormat,
          resolutionMode: targetResolutionMode,
          sceneNo,
          batchId: '<batch_id>',
          version: '<pipeline_id>',
          path: `datasets/<scs_order_code>/<pipeline_id>/${productNameInput}`,
          bucket: 'gs://syns-gro-dev_product-data-store',
        };
        await lastValueFrom(pubSubClient.emit('register-product-data', msg));
        // wait for pubsub handler to complete
        await new Promise((r) => setTimeout(r, 300));
        const jobId = `${msg.orderId}_${
          msg.sceneNo
        }_${getProductFormatLabelShort(
          msg.productFormat,
        )}_${getResolutionModeLabel(msg.resolutionMode)}`;
        const job = await queue.getJob(jobId);
        let returnedValue;
        try {
          returnedValue = await job.waitUntilFinished(queueEvents);
        } catch (err: any) {
          returnedValue = err.message;
          // skip throwing error in order to proceed testing
        }

        const createSceneInfo = mockGcPubsubService.emitCreateSceneInfoEvent
          .mock.results[0].value as CreateSceneInfoDto;
        const metadata = baseProductMetadataYaml;
        // product-metadata uses [lat, lng], postgis uses [lng, lat] order
        const centerCoordinates = metadata.geometry.sceneCenterLocation
          .split(' ')
          .map((v) => +v)
          .reverse();
        const cornerCoordinates = metadata.geometry.sceneCornerLocations
          .split(' ')
          .reduce((p, _, idx, arr) => {
            if (idx % 2 === 0) {
              const lat = +arr[idx];
              const lng = +arr[idx + 1];
              p.push([lng, lat]);
            }
            return p;
          }, []) as number[][];
        const bbox = geojsonExtent(toPolygon(cornerCoordinates));
        const pdv = await dataSource
          .getRepository(ProductDataVersion)
          .findOneOrFail({
            where: { id: returnedValue.productDataVersion.id },
            relations: {
              productData: true,
            },
          });
        const pd = await dataSource.getRepository(ProductData).findOneOrFail({
          where: { id: pdv.productDatumId },
          relations: {
            productDataVersions: true,
            productDataRequest: {
              taskingInfo: { taskingRequest: { aois: true } },
            },
            taskingInfo: { taskingRequest: { aois: true } },
            archivePurchasedProductData: true,
          },
        });
        createdProductData.push(pd);

        const productNameOutput =
          targetResolutionMode === ResolutionMode.SR
            ? `${getResolutionModeLabel(
                targetResolutionMode,
              )}-${getProductFormatOutput(targetProductFormat)}`
            : getProductFormatOutput(targetProductFormat);
        const toOutput = [
          'STRIX',
          targetTaskingInfo.scsOrderCode,
          df.formatISO(metadata.observation.sceneCenterDateTime, {
            format: 'basic',
          }),
          getImagingModeLabel(metadata.observation.imagingMode),
          productNameOutput,
        ].join('_');
        const toBucket = `gs://${process.env.GCS_PRODUCT_DATA_STORE}`;
        const toBasePath = `${pd.id}/${pdv.id}`;
        const toZipPath = `${toBasePath}/${toOutput}.zip`;
        const toQuicklookImgPath = `${toBasePath}/${toOutput}_quicklook`;

        const quicklookImg = await Jimp.read(Buffer.from(image, 'base64'));
        const quicklookImgBuffer = await quicklookImg
          .scale(quicklookScaleFactor)
          .getBufferAsync(quicklookContentType);

        // checking QUEUE JOB
        expect(job.isCompleted()).resolves.toEqual(true);
        expect(job.attemptsMade).toEqual(1);
        if (checkPDR) {
          expect(returnedValue).toHaveProperty('productDataRequest');
        } else {
          expect(returnedValue).not.toHaveProperty('productDataRequest');
        }
        expect(returnedValue).toHaveProperty('productData');
        expect(returnedValue).toHaveProperty('productDataVersion');

        // checking DELIVERY-REQUEST PUBSUB EVENT
        if (checkPDR) {
          const deliveryRequest = mockGcPubsubService
            .emitDeliveryProductDataEvent.mock.results[0]
            .value as DeliveryRequestDto;
          expect(
            mockGcPubsubService.emitDeliveryProductDataEvent,
          ).toHaveBeenCalledTimes(1);
          expect(deliveryRequest.productDataVersionId).not.toBeNull();
          expect(deliveryRequest.organizationId).toEqual(pd.organizationId);
          expect(deliveryRequest.contractId).toEqual(pd.contractId);
          expect(deliveryRequest.isNotificationAvailable).toEqual(
            IsNotificationAvailable.Yes,
          );
        } else {
          expect(
            mockGcPubsubService.emitDeliveryProductDataEvent,
          ).toHaveBeenCalledTimes(0);
        }

        // checking CREATE-SCENE-INFO PUBSUB EVENT
        expect(
          mockGcPubsubService.emitCreateSceneInfoEvent,
        ).toHaveBeenCalledTimes(1);
        expect(createSceneInfo.taskingInfoId).toEqual(pd.taskingInfoId);
        expect(createSceneInfo.sceneNo).toEqual(pd.sceneNo);

        // checking PRODUCT-DATA-VERSION
        expect(pdv.productData).not.toBeNull();
        expect(pdv.metadata.observation.offnadirAngle).toEqual(
          Math.abs(baseProductMetadataYaml.observation.offnadirAngle),
        );
        // numDigits set to 8, because scale precision of returned value is at least 8
        expect(pdv.center.coordinates[0]).toBeCloseTo(centerCoordinates[0], 8);
        expect(pdv.center.coordinates[1]).toBeCloseTo(centerCoordinates[1], 8);
        pdv.area.coordinates[0].forEach((c, idx) => {
          expect(c[0]).toBeCloseTo(cornerCoordinates[idx][0], 8);
          expect(c[1]).toBeCloseTo(cornerCoordinates[idx][1], 8);
        });
        expect(pdv.bbox).toEqual(bbox);
        expect(pdv.datetime).toEqual(metadata.observation.sceneCenterDateTime);
        expect(pdv.bucket).toEqual(toBucket);
        expect(pdv.location).toEqual(toZipPath);
        expect(pdv.quicklookBucket).toEqual(toBucket);
        expect(pdv.quicklookLocation).toEqual(toQuicklookImgPath);
        expect(pdv.quicklookContentType).toEqual(quicklookContentType);
        // default sourceMaxDays: 385 days
        expect(getUnixTime(pdv.sourceExpired)).toBeGreaterThan(
          getUnixTime(
            add(
              set(new Date(), {
                hours: 0,
                minutes: 0,
                seconds: 0,
                milliseconds: 0,
              }),
              {
                days: 384,
                hours: 23,
                minutes: 55,
              },
            ),
          ),
        );
        expect(pdv.isSourceDeleted).toEqual(false);

        // checking PRODUCT-DATA
        expect(pd.productFormat).toEqual(targetProductFormat);
        expect(pd.resolutionMode).toEqual(targetResolutionMode);
        expect(pd.taskingInfoId).toEqual(targetTaskingInfo.id);
        expect(pd.aoiId).not.toBeNull();
        expect(pd.publicationStart).toEqual(
          getPublicationStartByDelayKind(
            targetTaskingInfo.observationStart,
            targetTaskingInfo.catalogDelayKind,
          ),
        );
        expect(pd.productDataVersions).toHaveLength(1);

        // checking PRODUCT-DATA-REQUEST
        if (checkPDR) {
          expect(pd.productDataRequest).not.toBeNull();
          expect(pd.productDataRequest.dpsBatchId).toEqual('<batch_id>');
          expect(pd.productDataRequest.status).toEqual(
            ProcessingStatus.Completed,
          );
        } else {
          expect(pd.productDataRequest).toBeNull();
        }

        // checking TASKING-INFO
        if (isDownloadExpiredExtended) {
          expect(targetTaskingInfo.downloadExpired).not.toEqual(
            pd.taskingInfo.downloadExpired,
          );
          // extended by 7 days
          expect(getUnixTime(pd.taskingInfo.downloadExpired)).toBeGreaterThan(
            getUnixTime(add(new Date(), { days: 6, hours: 23, minutes: 55 })),
          );
        } else {
          expect(targetTaskingInfo.downloadExpired).toEqual(
            pd.taskingInfo.downloadExpired,
          );
        }

        // checking ARCHIVE-PURCHASED-PRODUCT-DATA
        expect(pd.archivePurchasedProductData).toHaveLength(0);

        // checking GCS
        expect(mockGcsService.createReadStream).toHaveBeenCalledTimes(
          numberOfZipFiles,
        );
        expect(mockGcsService.createWriteStream).toHaveBeenCalledTimes(1);
        expect(mockGcsService.createWriteStream).toHaveBeenNthCalledWith(
          1,
          toBucket,
          toZipPath,
          {
            validation: 'md5',
            contentType: 'application/zip',
            timeout: 30 * 60 * 1000, // 30 minutes
            chunkSize: 67108864, // 64 * 1024 * 1024
          },
        );
        // product-metadata.yaml and quicklook image
        expect(mockGcsService.downloadFile).toHaveBeenCalledTimes(2);
        // quicklook image
        expect(mockGcsService.uploadData).toHaveBeenCalledTimes(1);
        expect(mockGcsService.uploadData).toHaveBeenNthCalledWith(
          1,
          toBucket,
          toQuicklookImgPath,
          quicklookImgBuffer,
          {
            validation: 'md5',
            contentType: quicklookContentType,
          },
        );

        // checking SLACK NOTIFICATION
        expect(mockSlackNotificationService.send).toHaveBeenCalledTimes(1);
        if (checkPDR) {
          expect(mockSlackNotificationService.send).toHaveBeenNthCalledWith(
            1,
            new SlackProductDataRequestStatusMessage(
              {
                aoiName: pd.taskingInfo.taskingRequest.aois[0].name,
                status: ProcessingStatus.Completed,
                orderCode: pd.taskingInfo.scsOrderCode,
                sceneNo: pd.sceneNo,
                productFormat: getProductFormatLabel(pd.productFormat),
                resolutionMode: getResolutionModeLabel(pd.resolutionMode),
              },
              { channel: SlackChannel.DEFAULT },
            ),
          );
        } else {
          expect(mockSlackNotificationService.send).toHaveBeenNthCalledWith(
            1,
            new SlackNoRequestStatusMessage(
              {
                status: ProcessingStatus.Completed,
                orderCode: pd.taskingInfo.scsOrderCode,
                sceneNo: pd.sceneNo,
                productFormat: getProductFormatLabel(pd.productFormat),
                resolutionMode: getResolutionModeLabel(pd.resolutionMode),
              },
              { channel: SlackChannel.ARCHIVE },
            ),
          );
        }
        // ProcessingStatus.Completed should be notified to Slack
        await expect(
          mockSlackNotificationService.send.mock.results[0].value,
        ).resolves.toEqual(true);
      },
    );

    it.each([
      [
        'pdr:exist pd:1 apr:completed',
        ProductFormat.GRD_GEOTIFF,
        ResolutionMode.normal,
        /info-11$/,
        /^e5000002/,
        /^a0100034/,
        false,
        1,
        OrderStatus.Completed,
        getTestAnotherOrganizationIdForFixture(),
        1, // rr related order count updated to 1
        SystemOrganization.NO_ORGANIZATION,
      ],
      [
        'pdr:not pd:1 apr:completed',
        ProductFormat.SLC_CEOS,
        ResolutionMode.normal,
        /info-21$/,
        /^e5000024/,
        /^a0100022/,
        true,
        2,
        OrderStatus.Completed,
        SystemOrganization.NO_ORGANIZATION,
        2,
        SystemOrganization.NO_ORGANIZATION,
      ],
      [
        'pdr:not pd:2(formats) apr:keep-new',
        ProductFormat.SLC_CEOS,
        ResolutionMode.normal,
        /info-11$/,
        /^e5000042/,
        /^a0100031/,
        false,
        0,
        OrderStatus.New,
        SystemOrganization.NO_ORGANIZATION,
        1,
        SystemOrganization.NO_ORGANIZATION,
      ],
      [
        'pdr:nott pd:2(scenes) apr:keep-new',
        ProductFormat.GRD_GEOTIFF,
        ResolutionMode.SR,
        /info-22$/,
        /^e5000044/,
        /^a0100032/,
        false,
        0,
        OrderStatus.New,
        SystemOrganization.NO_ORGANIZATION,
        1,
        SystemOrganization.NO_ORGANIZATION,
      ],
      [
        'pdr:exist pd:2-1 apr:keep-new',
        ProductFormat.SLC_SICD,
        ResolutionMode.normal,
        /info-11$/,
        /^e5000001/,
        /^a0100033/,
        false,
        0,
        OrderStatus.New,
        getTestAnotherOrganizationIdForFixture(),
        1, // rr related order count updated to 1
        SystemOrganization.NO_ORGANIZATION,
      ],
      [
        'pdr:not pd:2-2 apr:completed',
        ProductFormat.SLC_SICD,
        ResolutionMode.normal,
        /info-11$/,
        /^e5000043/,
        /^a0100033/,
        false,
        2,
        OrderStatus.Completed,
        SystemOrganization.NO_ORGANIZATION,
        2,
        SystemOrganization.NO_ORGANIZATION,
      ],
      [
        'pdr:exist pd:1 (multi org ordered) apr:completed',
        ProductFormat.GRD_GEOTIFF,
        ResolutionMode.normal,
        /info-12$/,
        /^e5000046/,
        /^a0100035/,
        true,
        2,
        OrderStatus.Completed,
        getTestAnotherOrganizationIdForFixture(),
        2,
        SystemOrganization.NO_ORGANIZATION,
      ],
      [
        'pdr:exist pd:2-1 (multi org ordered) apr:keep-new',
        ProductFormat.GRD_GEOTIFF,
        ResolutionMode.normal,
        /info-12$/,
        /^e5000047/,
        /^a0100038/,
        true,
        0,
        OrderStatus.New,
        getTestAnotherOrganizationIdForFixture(),
        2,
        SystemOrganization.NO_ORGANIZATION,
      ],
      [
        'pdr:not pd:2-2 (multi org ordered) apr:completed',
        ProductFormat.GRD_GEOTIFF,
        ResolutionMode.SR,
        /info-12$/,
        /^e5000048/,
        /^a0100038/,
        true,
        2,
        OrderStatus.Completed,
        SystemOrganization.NO_ORGANIZATION,
        2,
        SystemOrganization.NO_ORGANIZATION,
      ],
      [
        'pdr:still-new pd:1 (SR) corner-case apr:completed',
        ProductFormat.GRD_GEOTIFF,
        ResolutionMode.SR,
        /info-12$/,
        /^e5000049/,
        /^a0100039/,
        false,
        1,
        OrderStatus.Completed,
        getTestOrganizationIdForFixture(),
        1,
        getTestOrganizationIdForFixture(),
      ],
    ])(
      'archive order test: %s',
      async (
        _,
        targetProductFormat,
        targetResolutionMode,
        fixtureTaskName,
        fixturePDId,
        fixtureAPRId,
        isDownloadExpiredExtended,
        expectOrderCount,
        expectOrderStatus,
        expectPDOrganizationId,
        expectNotifyCount, //depends on how many order related
        expectPDVOrganizationId,
      ) => {
        const targetAPR = fixtureArchivePurchaseRequests.find((x) =>
          x.id.match(fixtureAPRId),
        );
        const targetPd = fixtureArchiveProductData.find((x) =>
          x.id.match(fixturePDId),
        );
        const sceneNo = targetPd.sceneNo;
        const targetTaskingInfo = fixtureArchiveTaskingInfos.find((x) =>
          x.name.match(fixtureTaskName),
        );
        const numberOfZipFiles =
          ProductDataZipFilesRegEx[targetProductFormat].length;
        const quicklookContentType =
          'image/' +
          ProductDataQuicklookImgRegEx[targetProductFormat].replace(
            /(.*)(jpeg|png)(.*)/,
            '$2',
          );
        const quicklookScaleFactor =
          ProductDataQuicklookImgScaleFactor[targetProductFormat];
        baseProductMetadataYaml.observation.sceneNo = sceneNo;
        const productNameInput =
          targetResolutionMode === ResolutionMode.SR
            ? `${getResolutionModeLabel(
                targetResolutionMode,
              )}-${getProductFormatLabelShort(targetProductFormat)}`
            : getProductFormatLabelShort(targetProductFormat);

        const msg: RegisterProductDataDto = {
          orderId: targetTaskingInfo.scsOrderId,
          productFormat: targetProductFormat,
          resolutionMode: targetResolutionMode,
          sceneNo,
          batchId: '<batch_id>',
          version: '<pipeline_id>',
          path: `datasets/<scs_order_code>/<pipeline_id>/${productNameInput}`,
          bucket: 'gs://syns-gro-dev_product-data-store',
        };
        await lastValueFrom(pubSubClient.emit('register-product-data', msg));
        // wait for pubsub handler to complete
        await new Promise((r) => setTimeout(r, 600));
        const jobId = `${msg.orderId}_${
          msg.sceneNo
        }_${getProductFormatLabelShort(
          msg.productFormat,
        )}_${getResolutionModeLabel(msg.resolutionMode)}`;
        const job = await queue.getJob(jobId);
        let returnedValue;
        try {
          returnedValue = await job.waitUntilFinished(queueEvents);
        } catch (err: any) {
          returnedValue = err.message;
          // skip throwing error in order to proceed testing
        }

        const metadata = baseProductMetadataYaml;
        // product-metadata uses [lat, lng], postgis uses [lng, lat] order
        const centerCoordinates = metadata.geometry.sceneCenterLocation
          .split(' ')
          .map((v) => +v)
          .reverse();
        const cornerCoordinates = metadata.geometry.sceneCornerLocations
          .split(' ')
          .reduce((p, _, idx, arr) => {
            if (idx % 2 === 0) {
              const lat = +arr[idx];
              const lng = +arr[idx + 1];
              p.push([lng, lat]);
            }
            return p;
          }, []) as number[][];
        const bbox = geojsonExtent(toPolygon(cornerCoordinates));
        const pdv = await dataSource
          .getRepository(ProductDataVersion)
          .findOneOrFail({
            where: { id: returnedValue.productDataVersion.id },
            relations: {
              productData: true,
            },
          });
        const pd = await dataSource.getRepository(ProductData).findOneOrFail({
          where: { id: pdv.productDatumId },
          relations: {
            productDataVersions: true,
            productDataRequest: true,
            taskingInfo: { taskingRequest: { aois: true } },
            archivePurchasedProductData: true,
          },
        });
        createdProductData.push(pd);
        const rrs = await dataSource.getRepository(ReprocessingRequest).find({
          where: { productData: { id: pdv.productDatumId } },
          relations: {
            productData: true,
          },
        });
        const apr = await dataSource
          .getRepository(ArchivePurchaseRequest)
          .findOne({
            where: { id: targetAPR.id },
            relations: {
              reprocessingRequests: true,
              archivePurchasedItems: true,
              archivePurchasedProductData: {
                productData: true,
                productDataVersion: true,
              },
            },
          });

        const productNameOutput =
          targetResolutionMode === ResolutionMode.SR
            ? `${getResolutionModeLabel(
                targetResolutionMode,
              )}-${getProductFormatOutput(targetProductFormat)}`
            : getProductFormatOutput(targetProductFormat);
        const toOutput = [
          'STRIX',
          targetTaskingInfo.scsOrderCode,
          df.formatISO(metadata.observation.sceneCenterDateTime, {
            format: 'basic',
          }),
          getImagingModeLabel(metadata.observation.imagingMode),
          productNameOutput,
        ].join('_');
        const toBucket = `gs://${process.env.GCS_PRODUCT_DATA_STORE}`;
        const toBasePath = `${pd.id}/${pdv.id}`;
        const toZipPath = `${toBasePath}/${toOutput}.zip`;
        const toQuicklookImgPath = `${toBasePath}/${toOutput}_quicklook`;

        const quicklookImg = await Jimp.read(Buffer.from(image, 'base64'));
        const quicklookImgBuffer = await quicklookImg
          .scale(quicklookScaleFactor)
          .getBufferAsync(quicklookContentType);

        // checking QUEUE JOB
        expect(job.isCompleted()).resolves.toEqual(true);
        expect(job.attemptsMade).toEqual(1);
        expect(returnedValue).toHaveProperty('productData');
        expect(returnedValue).toHaveProperty('productDataVersion');

        // checking DELIVERY-REQUEST PUBSUB EVENT
        if (targetPd.productDataRequest || returnedValue.productDataRequest) {
          expect(
            mockGcPubsubService.emitDeliveryProductDataEvent,
          ).toHaveBeenCalledTimes(1);
        } else {
          expect(
            mockGcPubsubService.emitDeliveryProductDataEvent,
          ).toHaveBeenCalledTimes(0);
        }

        const orderedPD = mockGcPubsubService.emitNotifyProductReadyEvent.mock
          .results[0].value as NotifyProductReadyDto;
        expect(orderedPD.orderId).not.toBeNull();
        expect(orderedPD.productDataVersionId).not.toBeNull();

        expect(
          mockGcPubsubService.emitNotifyProductReadyEvent,
        ).toHaveBeenCalledTimes(expectNotifyCount);

        // checking CREATE-SCENE-INFO PUBSUB EVENT
        expect(
          mockGcPubsubService.emitCreateSceneInfoEvent,
        ).toHaveBeenCalledTimes(0);

        // checking PRODUCT-DATA-VERSION
        expect(pdv.productDatumId).toMatch(targetPd.id);
        expect(pdv.productData).not.toBeNull();
        expect(pdv.metadata.observation.offnadirAngle).toEqual(
          Math.abs(baseProductMetadataYaml.observation.offnadirAngle),
        );
        // numDigits set to 8, because scale precision of returned value is at least 8
        expect(pdv.center.coordinates[0]).toBeCloseTo(centerCoordinates[0], 8);
        expect(pdv.center.coordinates[1]).toBeCloseTo(centerCoordinates[1], 8);
        pdv.area.coordinates[0].forEach((c, idx) => {
          expect(c[0]).toBeCloseTo(cornerCoordinates[idx][0], 8);
          expect(c[1]).toBeCloseTo(cornerCoordinates[idx][1], 8);
        });
        expect(pdv.bbox).toEqual(bbox);
        expect(pdv.datetime).toEqual(metadata.observation.sceneCenterDateTime);
        expect(pdv.bucket).toEqual(toBucket);
        expect(pdv.location).toEqual(toZipPath);
        expect(pdv.quicklookBucket).toEqual(toBucket);
        expect(pdv.quicklookLocation).toEqual(toQuicklookImgPath);
        expect(pdv.quicklookContentType).toEqual(quicklookContentType);
        // default sourceMaxDays: 385 days
        expect(getUnixTime(pdv.sourceExpired)).toBeGreaterThan(
          getUnixTime(
            add(
              set(new Date(), {
                hours: 0,
                minutes: 0,
                seconds: 0,
                milliseconds: 0,
              }),
              {
                days: 384,
                hours: 23,
                minutes: 55,
              },
            ),
          ),
        );
        expect(pdv.isSourceDeleted).toEqual(false);

        // checking PRODUCT-DATA
        expect(pd.id).toEqual(returnedValue.productData.id);
        expect(pd.id).toEqual(targetPd.id);
        expect(pd.productFormat).toEqual(targetProductFormat);
        expect(pd.resolutionMode).toEqual(targetResolutionMode);
        expect(pd.taskingInfoId).toEqual(targetTaskingInfo.id);
        // when archive order created product data, aoiId is null
        //expect(pd.aoiId).not.toBeNull();
        expect(pd.publicationStart).toEqual(
          getPublicationStartByDelayKind(
            targetTaskingInfo.observationStart,
            targetTaskingInfo.catalogDelayKind,
          ),
        );
        expect(pd.productDataVersions).toHaveLength(
          targetPd.productDataVersions.length + 1,
        );
        //if PDV count is one, and which relate with APR, the PD is created by system
        expect(returnedValue.productData.organizationId).toEqual(
          expectPDOrganizationId,
        );
        expect(returnedValue.productDataVersion.organizationId).toEqual(
          expectPDVOrganizationId,
        );

        // checking PRODUCT-DATA-REQUEST
        if (targetPd.productDataRequest) {
          expect(pd.productDataRequest).not.toBeNull();
          //if archive order case, original PDR should not updated.
          expect(pd.productDataRequest.updatedAt).toEqual(
            targetPd.productDataRequest.updatedAt,
          );
          expect(pd.productDataRequest.dpsBatchId).toEqual(
            targetPd.productDataRequest.dpsBatchId,
          );
          expect(pd.productDataRequest.status).toEqual(
            targetPd.productDataRequest.status,
          );
        }

        // checking REPROCESSING-REQUEST
        expect(rrs).toHaveLength(1);
        expect(rrs[0]).toEqual(
          expect.objectContaining({ status: ProcessingStatus.Completed }),
        );

        // checking ARCHIVE-PURCHASE-REQUEST
        if (expectOrderCount) {
          expect(returnedValue.archivePurchaseRequests).toHaveLength(
            expectOrderCount,
          );
        }
        expect(apr.archivePurchasedItems).toHaveLength(
          targetAPR.archivePurchasedItems.length,
        );
        expect(apr.archivePurchasedProductData).toHaveLength(
          targetAPR.archivePurchasedProductData.length,
        );
        expect(apr.archivePurchasedProductData).toEqual(
          expect.arrayContaining([
            expect.objectContaining({
              archivePurchaseRequestId: expect.any(String),
              productDatumId: expect.any(String),
              productDataVersionId: expect.any(String),
            }),
          ]),
        );
        expect(apr.reprocessingRequests).toHaveLength(
          targetAPR.reprocessingRequests.length,
        );
        expect(apr).toEqual(
          expect.objectContaining({
            status: expectOrderStatus,
          }),
        );
        if (isDownloadExpiredExtended) {
          expect(apr.downloadExpired).not.toEqual(targetAPR.downloadExpired);
          // extended by 7 days
          expect(getUnixTime(apr.downloadExpired)).toBeGreaterThan(
            getUnixTime(add(new Date(), { days: 6, hours: 23, minutes: 55 })),
          );
        } else {
          expect(apr.downloadExpired).toEqual(targetAPR.downloadExpired);
        }

        // checking ARCHIVE-PURCHASED-PRODUCT-DATA
        expect(pd.archivePurchasedProductData.length).toBeGreaterThan(0);
        pd.archivePurchasedProductData.forEach((appd) => {
          expect(appd).toEqual(
            expect.objectContaining({
              archivePurchaseRequestId: expect.any(String),
              productDatumId: expect.any(String),
              productDataVersionId: expect.any(String),
            }),
          );
        });
        expect(
          pd.archivePurchasedProductData[
            pd.archivePurchasedProductData.length - 1
          ].productDataVersionId,
        ).toEqual(pdv.id);

        // checking GCS
        expect(mockGcsService.createReadStream).toHaveBeenCalledTimes(
          numberOfZipFiles,
        );
        expect(mockGcsService.createWriteStream).toHaveBeenCalledTimes(1);
        expect(mockGcsService.createWriteStream).toHaveBeenNthCalledWith(
          1,
          toBucket,
          toZipPath,
          {
            validation: 'md5',
            contentType: 'application/zip',
            timeout: 30 * 60 * 1000, // 30 minutes
            chunkSize: 67108864, // 64 * 1024 * 1024
          },
        );
        // product-metadata.yaml and quicklook image
        expect(mockGcsService.downloadFile).toHaveBeenCalledTimes(2);
        // quicklook image
        expect(mockGcsService.uploadData).toHaveBeenCalledTimes(1);
        expect(mockGcsService.uploadData).toHaveBeenNthCalledWith(
          1,
          toBucket,
          toQuicklookImgPath,
          quicklookImgBuffer,
          {
            validation: 'md5',
            contentType: quicklookContentType,
          },
        );

        // checking SLACK NOTIFICATION
        let expectSlackMessageCount = 1;
        expect(mockSlackNotificationService.send).toHaveBeenCalledWith(
          new SlackReprocessingRequestStatusMessage(
            {
              status: ProcessingStatus.Completed,
              requestNo:
                returnedValue.reprocessingRequests[0].archivePurchaseRequests
                  .map((x) => x.requestId)
                  .join(' '),
              itemId:
                returnedValue.reprocessingRequests[0].productData.sceneInfo
                  .itemId,
              orderCode: pd.taskingInfo.scsOrderCode,
              sceneNo: pd.sceneNo,
              productFormat: getProductFormatLabel(pd.productFormat),
              resolutionMode: getResolutionModeLabel(pd.resolutionMode),
            },
            { channel: SlackChannel.ARCHIVE },
          ),
        );
        if (expectOrderStatus === OrderStatus.Completed) {
          expectSlackMessageCount +=
            returnedValue.archivePurchaseRequests.length;
          expect(mockSlackNotificationService.send).toHaveBeenCalledWith(
            new SlackArchivePurchaseRequestStatusMessage(
              {
                status: OrderStatus.Completed,
                requestNo: returnedValue.archivePurchaseRequests[0].requestId,
                itemIds:
                  returnedValue.archivePurchaseRequests[0].archivePurchasedProductData
                    .map((x) => x.productData.sceneInfo.itemId)
                    .join(' '),
              },
              { channel: SlackChannel.ARCHIVE },
            ),
          );
        }
        if (returnedValue.productDataRequest) {
          expectSlackMessageCount++;
          expect(mockSlackNotificationService.send).toHaveBeenCalledWith(
            new SlackProductDataRequestStatusMessage(
              {
                aoiName: pd.taskingInfo.taskingRequest.aois[0].name,
                status: ProcessingStatus.Completed,
                orderCode: pd.taskingInfo.scsOrderCode,
                sceneNo: pd.sceneNo,
                productFormat: getProductFormatLabel(pd.productFormat),
                resolutionMode: getResolutionModeLabel(pd.resolutionMode),
              },
              { channel: SlackChannel.DEFAULT },
            ),
          );
        }
        expect(mockSlackNotificationService.send).toHaveBeenCalledTimes(
          expectSlackMessageCount,
        );
        // ProcessingStatus.Completed should be notified to Slack
        await expect(
          mockSlackNotificationService.send.mock.results[0].value,
        ).resolves.toEqual(true);
      },
    );
  });

  describe('register-product-data event: ng', () => {
    let app: INestApplication;
    let dataSource: DataSource;
    let queue: Queue;
    let queueEvents: QueueEvents;
    let fixtureTaskingInfos: TaskingInfo[];
    let targetTaskingInfo: TaskingInfo;
    let targetArchiveTaskingInfo: TaskingInfo;
    let taskingInfoUsecaseService: TaskingInfoUsecaseService;
    let productDataRequestUsecaseService: ProductDataRequestUsecaseService;
    let productDataUsecaseService: ProductDataUsecaseService;
    let productDataVersionUsecaseService: ProductDataVersionUsecaseService;

    const mockGcsService = {
      listFiles: jest.fn(),
      getMetadata: jest.fn(),
      downloadFile: jest.fn(),
      uploadData: jest.fn(),
      createReadStream: jest.fn(),
      createWriteStream: jest.fn(),
    };

    const mockGcPubsubService = {
      emitDeliveryProductDataEvent: jest.fn(),
      emitCreateSceneInfoEvent: jest.fn(),
    };

    const mockSlackNotificationService = {
      send: jest.fn(),
    };

    beforeAll(async () => {
      const moduleFixture: TestingModule = await Test.createTestingModule({
        imports: [DpsNotificationUsecaseModule],
      })
        .overrideProvider(GcsServiceService)
        .useValue(mockGcsService)
        .overrideProvider(GcPubsubServiceService)
        .useValue(mockGcPubsubService)
        .overrideProvider(SlackNotificationService)
        .useValue(mockSlackNotificationService)
        .compile();

      app = moduleFixture.createNestApplication();
      app.connectMicroservice(
        {
          strategy: new GcPubsubServer({
            subscription: process.env.PUBSUB_DPS_NOTIFICATION_SUBSCRIPTION,
            client: {
              apiEndpoint: process.env.PUBSUB_EMULATOR_HOST,
              projectId: process.env.PUBSUB_PROJECT_ID,
            },
          }),
        },
        { inheritAppConfig: true },
      );
      // If you set LOG_SILENT=true, no logs will be output
      const logger = await app.get<LoggerService>(LoggerService);
      await app.useLogger(logger);

      await app.startAllMicroservices();
      await app.init();

      dataSource = app.get(DataSource);
      queue = app.get(getQueueToken(REGISTER_PRODUCT_DATA_QUEUE));
      queueEvents = new QueueEvents(REGISTER_PRODUCT_DATA_QUEUE, {
        connection: queue.opts.connection,
      });
      taskingInfoUsecaseService = app.get(TaskingInfoUsecaseService);
      productDataRequestUsecaseService = app.get(
        ProductDataRequestUsecaseService,
      );
      productDataUsecaseService = app.get(ProductDataUsecaseService);
      productDataVersionUsecaseService = app.get(
        ProductDataVersionUsecaseService,
      );

      fixtureTaskingInfos = await loadFixtureTaskingInfo(dataSource);
      // fixtureTaskingInfos[4] has all ProductFormat & resolutionMode combinations
      targetTaskingInfo = fixtureTaskingInfos[4];

      const archiveTaskingInfos =
        await loadFixtureArchiveTaskingInfo(dataSource);
      targetArchiveTaskingInfo = archiveTaskingInfos.find((x) =>
        x.name.match(/info-12$/),
      );

      //reset mock sceneNo
      baseProductMetadataYaml.observation.sceneNo = 1;
    });

    beforeEach(async () => {
      mockGcsService.listFiles = jest.fn(mockGcsServiceListFilesFunction);
      mockGcsService.getMetadata = jest.fn(mockGcsServiceGetMetadataFunction);
      mockGcsService.downloadFile = jest.fn(mockGcsServiceDownloadFileFunction);
      mockGcsService.uploadData = jest.fn(mockGcsServiceUploadDataFunction);
      mockGcsService.createReadStream = jest.fn(
        mockGcsServiceCreateReadStreamFunction,
      );
      mockGcsService.createWriteStream = jest.fn(
        mockGcsServiceCreateWriteStreamFunction,
      );
      mockGcPubsubService.emitDeliveryProductDataEvent = jest.fn(
        mockGcPubsubServiceEmitDeliveryProductDataFunction,
      );
      mockGcPubsubService.emitCreateSceneInfoEvent = jest.fn(
        mockGcPubsubServiceEmitCreateSceneInfoFunction,
      );
      mockSlackNotificationService.send = jest.fn(
        mockSlackNotificationServiceSendFunction,
      );
      jest
        .spyOn(taskingInfoUsecaseService, 'getOneForProductDataRegistration')
        .mockRestore();
      jest
        .spyOn(productDataRequestUsecaseService, 'updateStatusAndBatchId')
        .mockRestore();
      jest.spyOn(productDataUsecaseService, 'insertWithId').mockRestore();
      jest
        .spyOn(productDataVersionUsecaseService, 'insertWithId')
        .mockRestore();
      await queue.clean(0, 0, 'completed');
      await queue.clean(0, 0, 'failed');
    });

    afterAll(async () => {
      await dataSource.destroy();
      await queue.obliterate();
      await queue.close();
      await queueEvents.close();
      await app.close();
    });

    const prepareTestMissingFiles = (productFormat, resolutionMode) => () => {
      mockGcsService.listFiles = jest.fn(() => {
        const data = [];
        return Promise.resolve([data]);
      });

      const productNameInput =
        resolutionMode === ResolutionMode.SR
          ? `${getResolutionModeLabel(
              resolutionMode,
            )}-${getProductFormatLabelShort(productFormat)}`
          : getProductFormatLabelShort(productFormat);
      const pubsubMessage = instanceToInstance(basePubsubMessage);
      pubsubMessage.orderId = targetTaskingInfo.scsOrderId;
      pubsubMessage.productFormat = productFormat;
      pubsubMessage.resolutionMode = resolutionMode;
      pubsubMessage.path = `datasets/<scs_order_code>/<pipeline_id>/${productNameInput}`;

      return {
        pubsubMessage,
        errorMessage: 'validation failed: missing or empty files',
      };
    };

    const prepareTestInvalidProductMetadataFile = () => {
      mockGcsService.downloadFile = jest.fn(() => {
        const invalidProductMetadata = instanceToInstance(
          baseProductMetadataYaml,
        );
        delete invalidProductMetadata.geometry;
        const metadata = JSON.parse(JSON.stringify(invalidProductMetadata));
        const data = Buffer.from(YAML.stringify(metadata));
        return Promise.resolve([data]);
      });

      const pubsubMessage = instanceToInstance(basePubsubMessage);
      pubsubMessage.orderId = targetTaskingInfo.scsOrderId;

      return {
        pubsubMessage,
        errorMessage: 'validation failed: invalid product-metadata file',
      };
    };

    const prepareTestSynsprocessorProductMetadataFile = () => {
      mockGcsService.downloadFile = jest.fn(() => {
        const invalidProductMetadata = instanceToInstance(
          baseProductMetadataYaml,
        );
        invalidProductMetadata.product.focusSoftwareType = 'synsprocessor';
        const metadata = JSON.parse(JSON.stringify(invalidProductMetadata));
        const data = Buffer.from(YAML.stringify(metadata));
        return Promise.resolve([data]);
      });

      const pubsubMessage = instanceToInstance(basePubsubMessage);
      pubsubMessage.orderId = targetTaskingInfo.scsOrderId;

      return {
        pubsubMessage,
        errorMessage:
          'validation failed: Value is not in the product-metadata whitelist',
      };
    };
    const prepareArchiveMissingFiles =
      (productFormat, resolutionMode) => () => {
        mockGcsService.listFiles = jest.fn(() => {
          const data = [];
          return Promise.resolve([data]);
        });

        const productNameInput =
          resolutionMode === ResolutionMode.SR
            ? `${getResolutionModeLabel(
                resolutionMode,
              )}-${getProductFormatLabelShort(productFormat)}`
            : getProductFormatLabelShort(productFormat);
        const pubsubMessage = instanceToInstance(basePubsubMessage);
        pubsubMessage.orderId = targetArchiveTaskingInfo.scsOrderId;
        pubsubMessage.productFormat = productFormat;
        pubsubMessage.resolutionMode = resolutionMode;
        pubsubMessage.path = `datasets/<scs_order_code>/<pipeline_id>/${productNameInput}`;

        return {
          pubsubMessage,
          errorMessage: 'validation failed: missing or empty files',
        };
      };

    const prepareArchiveInvalidProductMetadataFile = () => {
      mockGcsService.downloadFile = jest.fn(() => {
        const invalidProductMetadata = instanceToInstance(
          baseProductMetadataYaml,
        );
        delete invalidProductMetadata.geometry;
        const metadata = JSON.parse(JSON.stringify(invalidProductMetadata));
        const data = Buffer.from(YAML.stringify(metadata));
        return Promise.resolve([data]);
      });

      const pubsubMessage = instanceToInstance(basePubsubMessage);
      pubsubMessage.orderId = targetArchiveTaskingInfo.scsOrderId;
      pubsubMessage.productFormat = ProductFormat.GRD_GEOTIFF;
      pubsubMessage.resolutionMode = ResolutionMode.normal;

      return {
        pubsubMessage,
        errorMessage: 'validation failed: invalid product-metadata file',
      };
    };

    const prepareTestProductMetadataDtoMismatch = () => {
      const pubsubMessage = instanceToInstance(basePubsubMessage);
      pubsubMessage.orderId = targetTaskingInfo.scsOrderId;
      pubsubMessage.productFormat = ProductFormat.SLC_SICD;
      pubsubMessage.resolutionMode = ResolutionMode.SR;
      pubsubMessage.sceneNo = 999999;
      pubsubMessage.path = 'datasets/<scs_order_code>/<pipeline_id>/SICD';

      return {
        pubsubMessage,
        errorMessage: 'validation failed: product-metadata does not match dto',
      };
    };

    const prepareTestWriteZipError = () => {
      const errorMessage = 'test write zip error';
      mockGcsService.createWriteStream = jest.fn(() => {
        throw new Error(errorMessage);
      });

      const pubsubMessage = instanceToInstance(basePubsubMessage);
      pubsubMessage.orderId = targetTaskingInfo.scsOrderId;

      return {
        pubsubMessage,
        errorMessage,
      };
    };

    const prepareTestUploadQuicklookImgError = () => {
      const errorMessage = 'test upload quicklook image error';
      mockGcsService.uploadData = jest.fn(() => {
        throw new Error(errorMessage);
      });

      const pubsubMessage = instanceToInstance(basePubsubMessage);
      pubsubMessage.orderId = targetTaskingInfo.scsOrderId;

      return {
        pubsubMessage,
        errorMessage,
      };
    };

    const prepareTestTaskingInfoNotFound = () => {
      jest
        .spyOn(taskingInfoUsecaseService, 'getOneForProductDataRegistration')
        .mockImplementation(() => {
          throw new EntityNotFoundError(TaskingInfo, {});
        });

      const pubsubMessage = instanceToInstance(basePubsubMessage);
      pubsubMessage.orderId = targetTaskingInfo.scsOrderId;

      return {
        pubsubMessage,
        errorMessage: 'tasking-info not found',
      };
    };

    const prepareTestProductDataInsertError = () => {
      const errorMessage = 'test typeorm error';
      jest
        .spyOn(productDataUsecaseService, 'insertWithId')
        .mockImplementation(() => {
          throw new TypeORMError(errorMessage);
        });

      const pubsubMessage = instanceToInstance(basePubsubMessage);
      pubsubMessage.orderId = targetTaskingInfo.scsOrderId;

      return {
        pubsubMessage,
        errorMessage,
      };
    };

    const prepareTestProductDataVersionInsertError = () => {
      const errorMessage = 'test typeorm error';
      jest
        .spyOn(productDataVersionUsecaseService, 'insertWithId')
        .mockImplementation(() => {
          throw new TypeORMError(errorMessage);
        });

      const pubsubMessage = instanceToInstance(basePubsubMessage);
      pubsubMessage.orderId = targetTaskingInfo.scsOrderId;

      return {
        pubsubMessage,
        errorMessage,
      };
    };

    it.each([
      [
        'missing files: GRD_GEOTIFF',
        prepareTestMissingFiles(
          ProductFormat.GRD_GEOTIFF,
          ResolutionMode.normal,
        ),
        1,
      ],
      [
        'missing files: SR-GRD_GEOTIFF',
        prepareTestMissingFiles(ProductFormat.GRD_GEOTIFF, ResolutionMode.SR),
        1,
      ],
      [
        'missing files: SLC_SICD',
        prepareTestMissingFiles(ProductFormat.SLC_SICD, ResolutionMode.normal),
        1,
      ],
      [
        'missing files: SLC_CEOS',
        prepareTestMissingFiles(ProductFormat.SLC_CEOS, ResolutionMode.normal),
        1,
      ],
      [
        'missing files: ORT_GEOTIFF',
        prepareTestMissingFiles(
          ProductFormat.ORT_GEOTIFF,
          ResolutionMode.normal,
        ),
        1,
      ],
      [
        'invalid product-metadata file',
        prepareTestInvalidProductMetadataFile,
        1,
      ],
      [
        'synsprocessor product-metadata file',
        prepareTestSynsprocessorProductMetadataFile,
        1,
      ],
      [
        'product-metadata does not match dto',
        prepareTestProductMetadataDtoMismatch,
        1,
      ],
      ['write zip error', prepareTestWriteZipError, 3],
      ['upload quicklook image error', prepareTestUploadQuicklookImgError, 3],
      ['tasking-info not found', prepareTestTaskingInfoNotFound, 1],
      ['product-data insert error', prepareTestProductDataInsertError, 3],
      [
        'product-data-version insert error',
        prepareTestProductDataVersionInsertError,
        3,
      ],
      [
        'archive missing files: GRD_GEOTIFF',
        prepareArchiveMissingFiles(
          ProductFormat.GRD_GEOTIFF,
          ResolutionMode.normal,
        ),
        1,
      ],
      [
        'archive missing files: SR-GRD_GEOTIFF',
        prepareArchiveMissingFiles(
          ProductFormat.GRD_GEOTIFF,
          ResolutionMode.SR,
        ),
        1,
      ],
      [
        'invalid product-metadata file',
        prepareArchiveInvalidProductMetadataFile,
        1,
      ],
    ])('%s', async (_, prepareTest, attemptsMade) => {
      const { pubsubMessage, errorMessage } = prepareTest();

      await lastValueFrom(
        pubSubClient.emit('register-product-data', pubsubMessage),
      );
      // wait for pubsub handler to complete
      await new Promise((r) => setTimeout(r, 500));
      const jobId = `${pubsubMessage.orderId}_${
        pubsubMessage.sceneNo
      }_${getProductFormatLabelShort(
        pubsubMessage.productFormat,
      )}_${getResolutionModeLabel(pubsubMessage.resolutionMode)}`;
      const job = await queue.getJob(jobId);
      let returnedValue;
      try {
        returnedValue = await job.waitUntilFinished(queueEvents);
      } catch (err: any) {
        returnedValue = err.message;
        // skip throwing error in order to proceed testing
      }

      const ti = await dataSource.getRepository(TaskingInfo).findOneOrFail({
        where: { id: targetTaskingInfo.id },
        relations: {
          productDataRequests: true,
          productData: {
            productDataVersions: true,
          },
        },
      });

      // checking QUEUE JOB
      expect(job.isFailed()).resolves.toEqual(true);
      expect(job.attemptsMade).toEqual(attemptsMade);
      expect(job.failedReason).toEqual(errorMessage);
      expect(job.failedReason).toEqual(returnedValue);

      // checking TASKING-INFO
      expect(ti.productDataRequests).toEqual(
        expect.arrayContaining([expect.objectContaining({ status: 'new' })]),
      );
      expect(ti.productData).toHaveLength(0);

      // checking SLACK NOTIFICATION
      expect(mockSlackNotificationService.send).toHaveBeenCalledTimes(1);
      expect(mockSlackNotificationService.send).toHaveBeenNthCalledWith(
        1,
        new SlackErrorMessage('Error in registering ProductData', {
          orderId: pubsubMessage.orderId,
          version: pubsubMessage.version,
          batchId: pubsubMessage.batchId,
          sceneNo: pubsubMessage.sceneNo,
          productFormat: getProductFormatLabel(pubsubMessage.productFormat),
          resolutionMode: getResolutionModeLabel(pubsubMessage.resolutionMode),
          location: `${pubsubMessage.bucket.replace(/(^\w+:|^)\/\//, '')}/${
            pubsubMessage.path
          }`,
          error: errorMessage,
          jobId,
          attemptsMade: attemptsMade,
        }),
      );
      await expect(
        mockSlackNotificationService.send.mock.results[0].value,
      ).resolves.toEqual(true);
    });
  });
});
