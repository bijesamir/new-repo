import { INestApplication } from '@nestjs/common';
import { DataSource, In } from 'typeorm';
import { SchedulerUsecaseModule } from '../src/usecases/scheduler-usecase/scheduler-usecase.module';
import { Test, TestingModule } from '@nestjs/testing';
import { LoggerService } from '@iris-lib/logger';
import { GcsServiceService } from '../src/infra/gcs-service/gcs-service.service';
import { Queue, QueueEvents } from 'bullmq';
import { getQueueToken } from '@nestjs/bullmq';
import { SCHEDULER_QUEUE } from '../src/constants/queues';
import { SchedulerUsecaseService } from '../src/usecases/scheduler-usecase/scheduler-usecase.service';
import { loadFixtureProductDataVersion } from './fixtures';
import { ProductDataVersion } from '@iris-lib/db/entities';
import { SystemUser } from '@iris-lib/constants';
import { add, getUnixTime, set } from 'date-fns';
import { DELETE_SOURCE_PDV } from '../src/constants/jobs';
import { ProductDataVersionUsecaseService } from '../src/usecases/product-data-version-usecase/product-data-version-usecase.service';
import { ProductDataVersionCommonService } from '@iris-lib/usecases/product-data-version-common/product-data-version-common.service';

describe('DeleteSourceProductDataVersion (e2e)', () => {
  let app: INestApplication;
  let dataSource: DataSource;
  let queue: Queue;
  let queueEvents: QueueEvents;
  let fixtureProductDataVersions: ProductDataVersion[];
  let productDataVersionUsecaseService: ProductDataVersionUsecaseService;
  let productDataVersionCommonService: ProductDataVersionCommonService;

  class MockSchedulerUsecaseService extends SchedulerUsecaseService {
    async initCronJobs() {
      // override to prevent adding cron jobs
    }
  }

  const mockGcsService = {
    deleteFile: jest.fn(),
  };

  beforeAll(async () => {
    jest.useFakeTimers({
      advanceTimers: true,
      now: new Date('2024-03-01T01:00:00.000Z'),
    });

    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [SchedulerUsecaseModule],
    })
      .overrideProvider(SchedulerUsecaseService)
      .useClass(MockSchedulerUsecaseService)
      .overrideProvider(GcsServiceService)
      .useValue(mockGcsService)
      .compile();

    app = moduleFixture.createNestApplication();

    // If you set LOG_SILENT=true, no logs will be output
    const logger = await app.get<LoggerService>(LoggerService);
    await app.useLogger(logger);

    await app.startAllMicroservices();
    await app.init();

    dataSource = app.get(DataSource);
    queue = app.get(getQueueToken(SCHEDULER_QUEUE));
    queueEvents = new QueueEvents(SCHEDULER_QUEUE, {
      connection: queue.opts.connection,
    });
    productDataVersionUsecaseService = app.get(
      ProductDataVersionUsecaseService,
    );
    productDataVersionCommonService = app.get(ProductDataVersionCommonService);
    fixtureProductDataVersions =
      await loadFixtureProductDataVersion(dataSource);
  });

  beforeEach(async () => {
    await queue.clean(0, 0, 'completed');
    await queue.clean(0, 0, 'failed');
  });

  afterAll(async () => {
    await dataSource.destroy();
    await queue.obliterate();
    await queue.close();
    await queueEvents.close();
    await app.close();

    jest.useRealTimers();
  });

  afterEach(async () => {
    await dataSource.manager
      .getRepository(ProductDataVersion)
      .save(fixtureProductDataVersions);
  });

  describe('delete-source-product-data-version task: ok', () => {
    beforeEach(async () => {
      mockGcsService.deleteFile = jest.fn(() => {
        return Promise.resolve([
          {
            status: 204,
            message: 'No Content',
            headers: { date: new Date() },
          },
        ]);
      });
    });

    it('should delete source product data versions', async () => {
      const jobId = 'delete-source-product-data-version-success';
      await queue.add(DELETE_SOURCE_PDV, {}, { jobId });

      // wait until job finishes
      await new Promise((r) => setTimeout(r, 200));
      const job = await queue.getJob(jobId);
      let returnedValue;
      try {
        returnedValue = await job.waitUntilFinished(queueEvents);
      } catch (err: any) {
        returnedValue = err.message;
        // skip throwing error in order to proceed testing
      }

      const extendedPdvs = await dataSource.manager.find(ProductDataVersion, {
        where: {
          id: In(['c0100051-fcf9-49f9-b467-e4a8bb9e8d41']),
        },
        relations: {
          productData: {
            taskingInfo: true,
          },
          archivePurchasedProductData: {
            archivePurchaseRequest: true,
          },
        },
      });
      const deletedPdvs = await dataSource.manager.find(ProductDataVersion, {
        where: {
          id: In([
            '42b89352-7420-4f02-b153-e9df7660d7bd',
            'e891a198-6661-44de-8b4f-148e24540dbe',
            'e8f348f8-ee26-4643-9dc6-b7550bb6924e',
            '5051dbd0-c712-4c01-a4ff-baa2f5288b1f',
            '383d20a9-8d1e-4706-921a-b1ebda87d2e3',
            '28ce9c86-fcf9-49f9-b467-e4a8bb9e8d41',
            'ae649ec4-4007-4004-a832-ce4cab1b93c1',
            'c4c769f7-fa74-4f49-a863-8789316e38d1',
            '2fe11efa-8906-47e1-bdd7-c6774719e48f',
            '91b6a996-3582-466c-a527-4b26af9ab5cc',
          ]),
        },
      });

      // checking QUEUE JOB
      expect(job.isCompleted()).resolves.toEqual(true);
      expect(job.attemptsMade).toEqual(1);
      expect(returnedValue.extendedProductDataVersions).toHaveLength(1);
      expect(returnedValue.deletedSources).toHaveLength(10);

      // checking EXTENDED PDVs
      expect(getUnixTime(extendedPdvs[0].sourceExpired)).toBeGreaterThan(
        getUnixTime(
          add(
            set(
              extendedPdvs[0].archivePurchasedProductData[0]
                .archivePurchaseRequest.downloadExpired,
              {
                hours: 0,
                minutes: 0,
                seconds: 0,
                milliseconds: 0,
              },
            ),
            {
              days: 6,
              hours: 23,
              minutes: 55,
            },
          ),
        ),
      );
      expect(extendedPdvs[0]).toEqual(
        expect.objectContaining({
          isSourceDeleted: false,
          latestEditorId: SystemUser.PSC_SYSTEM,
        }),
      );
      expect(extendedPdvs[0].id).toEqual(
        returnedValue.extendedProductDataVersions[0].id,
      );

      // checking SOURCE-DELETED PDVs
      expect(deletedPdvs).toEqual(
        expect.arrayContaining([
          expect.objectContaining({
            isSourceDeleted: true,
            latestEditorId: SystemUser.PSC_SYSTEM,
          }),
        ]),
      );
      expect(deletedPdvs.map((pdv) => pdv.id).sort()).toEqual(
        returnedValue.deletedSources.map((s) => s.value.id).sort(),
      );

      // checking GCS
      expect(mockGcsService.deleteFile).toHaveBeenCalledTimes(10);
    });
  });

  describe('delete-source-product-data-version task: ng', () => {
    beforeEach(async () => {
      mockGcsService.deleteFile = jest.fn();

      jest
        .spyOn(productDataVersionUsecaseService, 'updateSourceExpired')
        .mockRestore();
      jest.spyOn(productDataVersionCommonService, 'getMany').mockRestore();
      jest
        .spyOn(
          productDataVersionCommonService,
          'setSourceDeletedWithEntityManager',
        )
        .mockRestore();
    });

    const prepareUpdateSourceExpireFail = () => {
      const errorMessage = 'update source expired failed';

      jest
        .spyOn(productDataVersionUsecaseService, 'updateSourceExpired')
        .mockImplementation(() => {
          throw new Error(errorMessage);
        });

      return {
        jobId: 'update-source-expired-failed',
        errorMessage,
      };
    };

    it.each([
      ['extend source-expired fails', prepareUpdateSourceExpireFail, 3],
    ])('%s', async (_, prepareTest, attemptsMade) => {
      const { jobId, errorMessage } = prepareTest();
      await queue.add(DELETE_SOURCE_PDV, {}, { jobId });

      // wait until job finishes
      await new Promise((r) => setTimeout(r, 300));
      const job = await queue.getJob(jobId);
      let returnedValue;
      try {
        returnedValue = await job.waitUntilFinished(queueEvents);
      } catch (err: any) {
        returnedValue = err.message;
        // skip throwing error in order to proceed testing
      }

      const extendedPdvs = await dataSource.manager.find(ProductDataVersion, {
        where: {
          id: In(['c0100051-fcf9-49f9-b467-e4a8bb9e8d41']),
        },
      });
      const deletedPdvs = await dataSource.manager.find(ProductDataVersion, {
        where: {
          id: In([
            '42b89352-7420-4f02-b153-e9df7660d7bd',
            'e891a198-6661-44de-8b4f-148e24540dbe',
            'e8f348f8-ee26-4643-9dc6-b7550bb6924e',
            '5051dbd0-c712-4c01-a4ff-baa2f5288b1f',
            '383d20a9-8d1e-4706-921a-b1ebda87d2e3',
            '28ce9c86-fcf9-49f9-b467-e4a8bb9e8d41',
            'ae649ec4-4007-4004-a832-ce4cab1b93c1',
            'c4c769f7-fa74-4f49-a863-8789316e38d1',
            '2fe11efa-8906-47e1-bdd7-c6774719e48f',
            '91b6a996-3582-466c-a527-4b26af9ab5cc',
          ]),
        },
      });

      // checking QUEUE JOB
      expect(job.isFailed()).resolves.toEqual(true);
      expect(job.attemptsMade).toEqual(attemptsMade);
      expect(job.failedReason).toEqual(errorMessage);
      expect(job.failedReason).toEqual(returnedValue);

      // checking EXTENDED PDVs
      expect(extendedPdvs[0]).toEqual(
        expect.objectContaining({
          isSourceDeleted: false,
          latestEditorId: SystemUser.DPS_SYSTEM,
        }),
      );

      // checking SOURCE-DELETED PDVs
      const notDeleted = deletedPdvs.filter((pdv) => !pdv.isSourceDeleted);

      expect(notDeleted).toHaveLength(10);
      expect(notDeleted).toEqual(
        expect.arrayContaining([
          expect.objectContaining({
            isSourceDeleted: false,
            latestEditorId: SystemUser.DPS_SYSTEM,
          }),
        ]),
      );

      // checking GCS
      expect(mockGcsService.deleteFile).toHaveBeenCalledTimes(0);
    });

    const prepareGetExpiredFail = () => {
      const errorMessage = 'get expired pdvs failed';
      jest
        .spyOn(productDataVersionCommonService, 'getMany')
        .mockImplementation(() => {
          throw new Error(errorMessage);
        });

      return {
        jobId: 'get-expired-pdvs-failed',
        errorMessage,
      };
    };

    const prepareSetSourceDeletedFail = () => {
      const errorMessage = 'set source-deleted pdv failed';
      jest
        .spyOn(
          productDataVersionCommonService,
          'setSourceDeletedWithEntityManager',
        )
        .mockImplementation(() => {
          throw new Error(errorMessage);
        });

      return {
        jobId: 'set-source-deleted-pdv-failed',
        errorMessage: 'Internal Server Error Exception',
      };
    };

    const prepareDeleteFileFail = () => {
      let count = 0;
      mockGcsService.deleteFile = jest.fn(() => {
        count++;

        if (count === 1 || count > 10) {
          return Promise.reject(new Error('delete file failed'));
        }

        return Promise.resolve([
          {
            status: 204,
            message: 'No Content',
            headers: { date: new Date() },
          },
        ]);
      });

      return {
        jobId: 'delete-source-failed',
        errorMessage: 'Internal Server Error Exception',
      };
    };

    it.each([
      ['get expired-pdvs fails', prepareGetExpiredFail, 3, 0, 0],
      ['set source-deleted fails', prepareSetSourceDeletedFail, 3, 0, 0],
      [
        'delete gcs-source fails',
        prepareDeleteFileFail,
        3,
        9,
        12, // 10 (first run) + 1 (second run) + 1 (third run)
      ],
    ])(
      '%s, extend source-expired ok',
      async (
        _,
        prepareTest,
        attemptsMade,
        deletedCount,
        gcsDeleteCallCount,
      ) => {
        const { jobId, errorMessage } = prepareTest();
        await queue.add(DELETE_SOURCE_PDV, {}, { jobId });

        // wait until job finishes
        await new Promise((r) => setTimeout(r, 200));
        const job = await queue.getJob(jobId);
        let returnedValue;
        try {
          returnedValue = await job.waitUntilFinished(queueEvents);
        } catch (err: any) {
          returnedValue = err.message;
          // skip throwing error in order to proceed testing
        }

        const extendedPdvs = await dataSource.manager.find(ProductDataVersion, {
          where: {
            id: In(['c0100051-fcf9-49f9-b467-e4a8bb9e8d41']),
          },
          relations: {
            productData: {
              taskingInfo: true,
            },
            archivePurchasedProductData: {
              archivePurchaseRequest: true,
            },
          },
        });
        const deletedPdvs = await dataSource.manager.find(ProductDataVersion, {
          where: {
            id: In([
              '42b89352-7420-4f02-b153-e9df7660d7bd',
              'e891a198-6661-44de-8b4f-148e24540dbe',
              'e8f348f8-ee26-4643-9dc6-b7550bb6924e',
              '5051dbd0-c712-4c01-a4ff-baa2f5288b1f',
              '383d20a9-8d1e-4706-921a-b1ebda87d2e3',
              '28ce9c86-fcf9-49f9-b467-e4a8bb9e8d41',
              'ae649ec4-4007-4004-a832-ce4cab1b93c1',
              'c4c769f7-fa74-4f49-a863-8789316e38d1',
              '2fe11efa-8906-47e1-bdd7-c6774719e48f',
              '91b6a996-3582-466c-a527-4b26af9ab5cc',
            ]),
          },
        });

        // checking QUEUE JOB
        expect(job.isFailed()).resolves.toEqual(true);
        expect(job.attemptsMade).toEqual(attemptsMade);
        expect(job.failedReason).toEqual(errorMessage);
        expect(job.failedReason).toEqual(returnedValue);

        // checking EXTENDED PDVs
        expect(getUnixTime(extendedPdvs[0].sourceExpired)).toBeGreaterThan(
          getUnixTime(
            add(
              set(
                extendedPdvs[0].archivePurchasedProductData[0]
                  .archivePurchaseRequest.downloadExpired,
                {
                  hours: 0,
                  minutes: 0,
                  seconds: 0,
                  milliseconds: 0,
                },
              ),
              {
                days: 6,
                hours: 23,
                minutes: 55,
              },
            ),
          ),
        );
        expect(extendedPdvs[0]).toEqual(
          expect.objectContaining({
            isSourceDeleted: false,
            latestEditorId: SystemUser.PSC_SYSTEM,
          }),
        );

        // checking SOURCE-DELETED PDVs
        // transactional per file
        const notDeleted = deletedPdvs.filter((pdv) => !pdv.isSourceDeleted);
        const deleted = deletedPdvs.filter((pdv) => pdv.isSourceDeleted);

        expect(notDeleted).toHaveLength(10 - deletedCount);
        notDeleted.forEach((pdv) => {
          expect(pdv).toEqual(
            expect.objectContaining({
              isSourceDeleted: false,
              latestEditorId: SystemUser.DPS_SYSTEM,
            }),
          );
        });

        expect(deleted).toHaveLength(deletedCount);
        deleted.forEach((pdv) => {
          expect(pdv).toEqual(
            expect.objectContaining({
              isSourceDeleted: true,
              latestEditorId: SystemUser.PSC_SYSTEM,
            }),
          );
        });

        // checking GCS
        expect(mockGcsService.deleteFile).toHaveBeenCalledTimes(
          gcsDeleteCallCount,
        );
      },
    );
  });
});
