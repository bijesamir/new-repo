import { ArchivePurchaseRequest } from '@iris-lib/db/entities';
import { GcPubsubClient, GcPubsubServer } from '@iris-lib/transporters';
import { INestApplication } from '@nestjs/common';
import { DataSource } from 'typeorm';
import { PscNotificationUsecaseModule } from '../src/usecases/psc-notification-usecase/psc-notification-usecase.module';
import { Test, TestingModule } from '@nestjs/testing';
import { LoggerService } from '@iris-lib/logger';
import { Queue, QueueEvents } from 'bullmq';
import { getQueueToken } from '@nestjs/bullmq';
import { NOTIFY_PRODUCT_READY_QUEUE } from '../src/constants/queues';
import { lastValueFrom } from 'rxjs';
import { loadFixtureArchivePurchaseRequests } from './fixtures';
import { NotifyProductReadyDto } from '../src/models/dto/product-data/notify-product-ready.dto';
import { CitadelGrpcService } from '@iris-lib/citadel';
import {
  EmitRequestDto,
  PaymentReplyDto,
  ProcessingSuccessResult,
} from '@iris-lib/models/payment';
import { plainToInstance } from 'class-transformer';
import {
  AppConstants,
  ArchiveProductDataNotificationTemplates,
  DataSourceType,
  NotificationParam,
  NotificationParamItem,
  OrderStatus,
  PaymentTaskStatus,
  fromOrderStatusToPaymentTaskStatus,
  generateNotificationContents,
} from '@iris-lib/constants';
import { basename } from 'path';
import { getProductLabel } from '@iris-lib/utils';

class CitadelRelatedDataForTest {
  taskingId: string;
  paymentId: number;
}

describe('NotifyProductReady (e2e)', () => {
  let app: INestApplication;
  let dataSource: DataSource;
  let queue: Queue;
  let queueEvents: QueueEvents;
  let pubSubClient: GcPubsubClient;
  let fixtures: ArchivePurchaseRequest[];

  const mockCitadelGrpcService = {
    checkQuota: jest.fn(),
    reserveTask: jest.fn(),
    emitTaskResult: jest.fn(),
  };
  const storedCitadelRelatedData: CitadelRelatedDataForTest[] =
    new Array<CitadelRelatedDataForTest>();

  beforeAll(async () => {
    pubSubClient = new GcPubsubClient({
      topic: process.env.PUBSUB_PSC_NOTIFICATION_TOPIC,
      client: {
        apiEndpoint: process.env.PUBSUB_EMULATOR_HOST,
        projectId: process.env.PUBSUB_PROJECT_ID,
      },
    });

    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [PscNotificationUsecaseModule],
    })
      .overrideProvider(CitadelGrpcService)
      .useValue(mockCitadelGrpcService)
      .compile();

    app = moduleFixture.createNestApplication();
    app.connectMicroservice(
      {
        strategy: new GcPubsubServer({
          subscription: process.env.PUBSUB_PSC_NOTIFICATION_SUBSCRIPTION,
          client: {
            apiEndpoint: process.env.PUBSUB_EMULATOR_HOST,
            projectId: process.env.PUBSUB_PROJECT_ID,
          },
        }),
      },
      { inheritAppConfig: true },
    );

    // If you set LOG_SILENT=true, no logs will be output
    const logger = await app.get<LoggerService>(LoggerService);
    await app.useLogger(logger);

    await app.startAllMicroservices();
    await app.init();

    dataSource = app.get(DataSource);
    queue = app.get(getQueueToken(NOTIFY_PRODUCT_READY_QUEUE));
    queueEvents = new QueueEvents(NOTIFY_PRODUCT_READY_QUEUE, {
      connection: queue.opts.connection,
    });
    fixtures = await loadFixtureArchivePurchaseRequests(dataSource);
    storedCitadelRelatedData.push(
      ...fixtures.flatMap((x) =>
        x.archivePurchasedItems.map((y) =>
          plainToInstance(CitadelRelatedDataForTest, {
            taskingId: y.id,
            paymentId: y.registrationId,
          } as CitadelRelatedDataForTest),
        ),
      ),
    );
  });

  beforeEach(async () => {
    await queue.obliterate();
    await queue.clean(0, 0, 'completed');
    await queue.clean(0, 0, 'failed');
    await prepareTest();
  });
  async function prepareTest() {
    // prepare mock of Citadel
    mockCitadelGrpcService.emitTaskResult = jest.fn(
      (emitRequests: EmitRequestDto[]) => {
        return Promise.resolve(
          emitRequests.map((x) => {
            return plainToInstance(PaymentReplyDto, {
              registrationId: storedCitadelRelatedData.find(
                (y) => y.taskingId === x.registrationId,
              ).paymentId,
              taskId: x.registrationId,
              status: PaymentTaskStatus.EXCEPTIONAL,
              consumptionCredit: 0,
            } as PaymentReplyDto);
          }),
        );
      },
    );
  }

  afterEach(async () => {
    mockCitadelGrpcService.checkQuota = jest.fn();
    mockCitadelGrpcService.reserveTask = jest.fn();
    mockCitadelGrpcService.emitTaskResult = jest.fn();
  });

  afterAll(async () => {
    await app.getHttpServer().close();
    await dataSource.destroy();
    await queue.obliterate();
    await queue.close();
    await queueEvents.close();
    await app.close();
    await pubSubClient.close();
  });

  describe('notify-product-ready event: ok', () => {
    it.each([
      ['ARCHIVE', /^a0100043/, DataSourceType.ARCHIVE],
      ['NEW', /^a0100003/, DataSourceType.NEW],
    ])(`notify-product %s`, async (_, targetApr, expDataType) => {
      const target = fixtures.find((apr) => apr.id.match(targetApr));
      const targetApi = target.archivePurchasedItems[0];
      const targetApd = target.archivePurchasedProductData.find(
        (x) => targetApi.sceneInfo.itemId === x.productData.sceneInfo.itemId,
      );
      // fixture-tasking_info-7 with sceneNo = 1 fullfills create condition
      const msg: NotifyProductReadyDto = {
        orderId: target.id,
        productDataVersionId: targetApd.productDataVersionId,
      };
      await lastValueFrom(pubSubClient.emit('notify-product-ready', msg));
      // wait for pubsub handler to complete
      await new Promise((r) => setTimeout(r, 200));
      const jobId = `${msg.orderId}-${msg.productDataVersionId}`;
      const job = await queue.getJob(jobId);
      let returnedValue: ArchivePurchaseRequest;
      try {
        returnedValue = await job.waitUntilFinished(queueEvents);
      } catch (err: any) {
        returnedValue = err.message;
        // skip throwing error in order to proceed testing
      }

      // checking QUEUE JOB
      expect(job.isCompleted()).resolves.toEqual(true);
      expect(job.attemptsMade).toEqual(1);
      expect(job.returnvalue).toHaveProperty('id');
      expect(job.returnvalue).toEqual(returnedValue);
      expect(mockCitadelGrpcService.emitTaskResult).toHaveBeenNthCalledWith(
        1,
        [
          plainToInstance(EmitRequestDto, {
            registrationId: target.archivePurchasedItems[0].id,
            isRushDelivery: false,
            status: fromOrderStatusToPaymentTaskStatus(OrderStatus.Completed),
            processingSuccessList: [
              plainToInstance(ProcessingSuccessResult, {
                productDataVersionId: targetApd.productDataVersionId,
                productFormat: targetApd.productData.productFormat,
                resolutionMode: targetApd.productData.resolutionMode,
              }),
            ],
          } as EmitRequestDto),
        ],
        await generateNotificationContents(
          OrderStatus.Completed,
          plainToInstance(NotificationParam, {
            env: process.env.NODE_ENV,
            reqNo: target.requestId,
            orderUrl: `${process.env.IRIS_WEBPAGE_URL}/archive-order-review/${target.id}`,
            items: [
              plainToInstance(NotificationParam, {
                itemId: targetApi.sceneInfo.itemId,
                imagingMode: targetApi.sceneInfo.taskingInfo.imagingMode,
                dataSourceType: expDataType,
                expiredAt: target.downloadExpired,
                files: [
                  {
                    filename: basename(targetApd.productDataVersion.location),
                    productLabel: getProductLabel(
                      targetApd.productData.productFormat,
                      targetApd.productData.resolutionMode,
                    ),
                    link: `${process.env.IRIS_API_URL || 'NONE'}/v${
                      AppConstants.DEFAULT_VERSION
                    }/product-data-version/${
                      targetApd.productDataVersionId
                    }/download`,
                  },
                ],
              } as NotificationParamItem),
            ],
          }),
          ArchiveProductDataNotificationTemplates,
        ),
      );
    });
  });
});
