import { ProductData, SceneInfo, TaskingInfo } from '@iris-lib/db/entities';
import { GcPubsubClient, GcPubsubServer } from '@iris-lib/transporters';
import { INestApplication } from '@nestjs/common';
import { DataSource, EntityNotFoundError, In } from 'typeorm';
import { PscNotificationUsecaseModule } from '../src/usecases/psc-notification-usecase/psc-notification-usecase.module';
import { Test, TestingModule } from '@nestjs/testing';
import { LoggerService } from '@iris-lib/logger';
import { Queue, QueueEvents } from 'bullmq';
import { getQueueToken } from '@nestjs/bullmq';
import { CREATE_SCENE_INFO_QUEUE } from '../src/constants/queues';
import { CreateSceneInfoDto } from '../src/models/dto/scene-info/create-scene-info.dto';
import { lastValueFrom } from 'rxjs';
import { loadFixtureTaskingInfo } from './fixtures';
import { ProductFormat, ResolutionMode, SystemUser } from '@iris-lib/constants';
import { generateItemId } from '@iris-lib/utils/scene-info-helper';
import { TaskingInfoUsecaseService } from '../src/usecases/tasking-info-usecase/tasking-info-usecase.service';
import { plainToInstance } from 'class-transformer';

describe('CreateSceneInfo (e2e)', () => {
  let app: INestApplication;
  let dataSource: DataSource;
  let queue: Queue;
  let queueEvents: QueueEvents;
  let pubSubClient: GcPubsubClient;
  let fixtureTaskingInfos: TaskingInfo[];
  let taskingInfoUsecaseService: TaskingInfoUsecaseService;

  const createdSceneInfos = new Array<SceneInfo>();

  beforeAll(async () => {
    pubSubClient = new GcPubsubClient({
      topic: process.env.PUBSUB_PSC_NOTIFICATION_TOPIC,
      client: {
        apiEndpoint: process.env.PUBSUB_EMULATOR_HOST,
        projectId: process.env.PUBSUB_PROJECT_ID,
      },
    });

    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [PscNotificationUsecaseModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    app.connectMicroservice(
      {
        strategy: new GcPubsubServer({
          subscription: process.env.PUBSUB_PSC_NOTIFICATION_SUBSCRIPTION,
          client: {
            apiEndpoint: process.env.PUBSUB_EMULATOR_HOST,
            projectId: process.env.PUBSUB_PROJECT_ID,
          },
        }),
      },
      { inheritAppConfig: true },
    );

    // If you set LOG_SILENT=true, no logs will be output
    const logger = await app.get<LoggerService>(LoggerService);
    await app.useLogger(logger);

    await app.startAllMicroservices();
    await app.init();

    dataSource = app.get(DataSource);
    queue = app.get(getQueueToken(CREATE_SCENE_INFO_QUEUE));
    queueEvents = new QueueEvents(CREATE_SCENE_INFO_QUEUE, {
      connection: queue.opts.connection,
    });
    taskingInfoUsecaseService = app.get(TaskingInfoUsecaseService);
    fixtureTaskingInfos = await loadFixtureTaskingInfo(dataSource);
  });

  beforeEach(async () => {
    await queue.clean(0, 0, 'completed');
    await queue.clean(0, 0, 'failed');
  });

  afterAll(async () => {
    await createdSceneInfos.reduce(async (p, c) => {
      await p;
      await dataSource.manager.getRepository(ProductData).update(
        { id: In(c.productData.map((pd) => pd.id)) },
        {
          latestEditorId: SystemUser.DPS_SYSTEM,
          sceneInfo: null,
        },
      );
      await dataSource.manager.getRepository(SceneInfo).remove(c);
    }, Promise.resolve());

    await dataSource.destroy();
    await queue.obliterate();
    await queue.close();
    await queueEvents.close();
    await app.close();
    await pubSubClient.close();
  });

  describe('create-scene-info event: ok', () => {
    it('create (condition fullfilled)', async () => {
      const targetTaskingInfo = fixtureTaskingInfos.find((ti) => {
        return ti.name === 'fixture-tasking_info-7';
      });

      // fixture-tasking_info-7 with sceneNo = 1 fullfills create condition
      const msg: CreateSceneInfoDto = {
        taskingInfoId: targetTaskingInfo.id,
        sceneNo: 1,
        updateItemId: false,
      };
      await lastValueFrom(pubSubClient.emit('create-scene-info', msg));
      // wait for pubsub handler to complete
      await new Promise((r) => setTimeout(r, 200));
      const jobId = `${msg.taskingInfoId}_${msg.sceneNo}`;
      const job = await queue.getJob(jobId);
      let returnedValue;
      try {
        returnedValue = await job.waitUntilFinished(queueEvents);
      } catch (err: any) {
        returnedValue = err.message;
        // skip throwing error in order to proceed testing
      }

      const si = await dataSource.getRepository(SceneInfo).findOne({
        where: {
          taskingInfoId: targetTaskingInfo.id,
          sceneNo: msg.sceneNo,
        },
        relations: {
          productData: {
            productDataVersions: true,
          },
          taskingInfo: {
            satellite: true,
          },
        },
      });
      const pds = await dataSource.getRepository(ProductData).find({
        where: {
          taskingInfoId: targetTaskingInfo.id,
          sceneNo: msg.sceneNo,
        },
        relations: {
          sceneInfo: true,
        },
      });
      createdSceneInfos.push(si);

      const defaultProductData = si.productData.find((pd) => {
        return (
          pd.productFormat === ProductFormat.GRD_GEOTIFF &&
          pd.resolutionMode === ResolutionMode.normal &&
          pd.productDataVersions?.length > 0 &&
          pd.productDataVersions[0].datetime
        );
      });
      const itemId = generateItemId(
        si.taskingInfo.satellite.name,
        si.taskingInfo.imagingMode,
        defaultProductData.productDataVersions[0].datetime,
      );

      // checking QUEUE JOB
      expect(job.isCompleted()).resolves.toEqual(true);
      expect(job.attemptsMade).toEqual(1);
      expect(job.returnvalue).toHaveProperty('id');
      expect(job.returnvalue).toHaveProperty('no');
      expect(job.returnvalue).toHaveProperty('sceneNo');
      expect(job.returnvalue).toHaveProperty('itemId');
      expect(job.returnvalue).toHaveProperty('taskingInfoId');
      expect(job.returnvalue).toEqual(returnedValue);

      // checking SCENE-INFO
      expect(si.sceneNo).toEqual(msg.sceneNo);
      expect(si.taskingInfoId).toEqual(targetTaskingInfo.id);
      expect(si.itemId).toEqual(itemId);
      expect(si.productData.length).toEqual(3);

      // checking PRODUCT-DATA
      expect(pds.length).toEqual(3);
      pds.forEach((pd) => {
        expect(pd.sceneInfo).toEqual(
          expect.objectContaining({
            id: si.id,
            no: expect.any(Number),
            sceneNo: msg.sceneNo,
            itemId: itemId,
            taskingInfoId: targetTaskingInfo.id,
          }),
        );
      });
    });

    it('skip creation (condition not fullfilled)', async () => {
      const targetTaskingInfo = fixtureTaskingInfos.find((ti) => {
        return ti.name === 'fixture-tasking_info-7';
      });

      // fixture-tasking_info-7 with sceneNo = 2 does not fullfill create condition
      const msg: CreateSceneInfoDto = {
        taskingInfoId: targetTaskingInfo.id,
        sceneNo: 2,
        updateItemId: false,
      };
      await lastValueFrom(pubSubClient.emit('create-scene-info', msg));
      // wait for pubsub handler to complete
      await new Promise((r) => setTimeout(r, 200));
      const jobId = `${msg.taskingInfoId}_${msg.sceneNo}`;
      const job = await queue.getJob(jobId);
      let returnedValue;
      try {
        returnedValue = await job.waitUntilFinished(queueEvents);
      } catch (err: any) {
        returnedValue = err.message;
        // skip throwing error in order to proceed testing
      }

      const si = await dataSource.getRepository(SceneInfo).findOne({
        where: {
          taskingInfoId: targetTaskingInfo.id,
          sceneNo: msg.sceneNo,
        },
        relations: {
          productData: {
            productDataVersions: true,
          },
          taskingInfo: {
            satellite: true,
          },
        },
      });
      const pds = await dataSource.getRepository(ProductData).find({
        where: {
          taskingInfoId: targetTaskingInfo.id,
          sceneNo: msg.sceneNo,
        },
        relations: {
          sceneInfo: true,
        },
      });

      // checking QUEUE JOB
      expect(job.isCompleted()).resolves.toEqual(true);
      expect(job.attemptsMade).toEqual(1);
      expect(job.returnvalue).toBeNull();
      expect(job.returnvalue).toEqual(returnedValue);

      // checking SCENE-INFO
      expect(si).toBeNull();

      // checking PRODUCT-DATA
      expect(pds.length).toEqual(2);
      pds.forEach((pd) => {
        expect(pd.sceneInfo).toBeNull();
      });
    });
  });

  describe('create-scene-info event: ng', () => {
    const prepareTestTaskingInfoNotFound = () => {
      jest
        .spyOn(taskingInfoUsecaseService, 'getOneForSceneInfoCreation')
        .mockImplementation(() => {
          throw new EntityNotFoundError(TaskingInfo, {});
        });

      return {
        pubsubMessage: plainToInstance(CreateSceneInfoDto, {
          taskingInfoId: 'd2b7be2c-d8fa-49b2-bee6-9a2e9c77614b',
          sceneNo: 999,
          updateItemId: false,
        }),
        errorMessage: 'tasking-info not found',
      };
    };

    it.each([['tasking-info not found', prepareTestTaskingInfoNotFound, 1]])(
      '%s',
      async (_, prepareTest, attemptsMade) => {
        const { pubsubMessage, errorMessage } = prepareTest();

        await lastValueFrom(
          pubSubClient.emit('create-scene-info', pubsubMessage),
        );
        // wait for pubsub handler to complete
        await new Promise((r) => setTimeout(r, 200));
        const jobId = `${pubsubMessage.taskingInfoId}_${pubsubMessage.sceneNo}`;
        const job = await queue.getJob(jobId);
        let returnedValue;
        try {
          returnedValue = await job.waitUntilFinished(queueEvents);
        } catch (err: any) {
          returnedValue = err.message;
          // skip throwing error in order to proceed testing
        }

        const si = await dataSource.getRepository(SceneInfo).findOne({
          where: {
            taskingInfoId: pubsubMessage.taskingInfoId,
            sceneNo: pubsubMessage.sceneNo,
          },
          relations: {
            productData: {
              productDataVersions: true,
            },
            taskingInfo: {
              satellite: true,
            },
          },
        });

        // checking QUEUE JOB
        expect(job.isFailed()).resolves.toEqual(true);
        expect(job.attemptsMade).toEqual(attemptsMade);
        expect(job.failedReason).toEqual(errorMessage);
        expect(job.failedReason).toEqual(returnedValue);

        // checking SCENE-INFO
        expect(si).toBeNull();
      },
    );
  });
});
