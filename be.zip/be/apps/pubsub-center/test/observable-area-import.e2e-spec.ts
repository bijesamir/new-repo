import { ObservableArea } from '@iris-lib/db/entities';
import { INestApplication } from '@nestjs/common';
import { DataSource } from 'typeorm';
import { Test, TestingModule } from '@nestjs/testing';
import * as df from 'date-fns';

import { GcsServiceService } from '../src/infra/gcs-service/gcs-service.service';
import { GcPubsubClient, GcPubsubServer } from '@iris-lib/transporters';
import { GcsNotificationUsecaseModule } from '../src/usecases/gcs-notification-usecase/gcs-notification-usecase.module';
import { lastValueFrom } from 'rxjs';
import { LoggerService } from '@iris-lib/logger';

describe('ObservableAreaImport (e2e)', () => {
  let app: INestApplication;
  let dataSource: DataSource;
  let pubSubClient: GcPubsubClient;

  const createdObservableAreas = new Array<ObservableArea>();

  const mockService = {
    loadObservableAreaGeoJson: jest.fn(),
  };

  beforeAll(async () => {
    pubSubClient = new GcPubsubClient({
      topic: process.env.PUBSUB_GCS_NOTIFICATION_TOPIC,
      client: {
        apiEndpoint: process.env.PUBSUB_EMULATOR_HOST,
        projectId: process.env.PUBSUB_PROJECT_ID,
      },
    });

    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [GcsNotificationUsecaseModule],
    })
      .overrideProvider(GcsServiceService)
      .useValue(mockService)
      .compile();

    app = moduleFixture.createNestApplication();
    app.connectMicroservice(
      {
        strategy: new GcPubsubServer({
          subscription: process.env.PUBSUB_GCS_NOTIFICATION_SUBSCRIPTION,
          client: {
            apiEndpoint: process.env.PUBSUB_EMULATOR_HOST,
            projectId: process.env.PUBSUB_PROJECT_ID,
          },
        }),
      },
      { inheritAppConfig: true },
    );

    // If you set LOG_SILENT=true, no logs will be output
    const logger = await app.get<LoggerService>(LoggerService);
    await app.useLogger(logger);

    await app.startAllMicroservices();
    await app.init();

    dataSource = app.get(DataSource);
  });

  afterAll(async () => {
    await createdObservableAreas.reduce(async (p, c) => {
      await p;
      await dataSource.manager.getRepository(ObservableArea).remove(c);
    }, Promise.resolve());

    await dataSource.destroy();
    await app.close();
    await pubSubClient.close();
  });

  it('ObservableAreaImport event: ok', async () => {
    mockService.loadObservableAreaGeoJson = jest.fn(() => {
      return Promise.resolve([
        {
          type: 'Polygon',
          coordinates: [
            [
              [-105.794171, -67.59254, 0],
              [-94.539307, -68.57315, 0],
              [-93.883764, -66.71727, 0],
              [-104.351972, -65.799645, 0],
              [-105.794171, -67.59254, 0],
            ],
          ],
        },
        {
          type: 'Polygon',
          coordinates: [
            [
              [-112.250215, -66.611957, 0],
              [-121.401844, -64.557515, 0],
              [-119.190092, -62.959596, 0],
              [-110.432081, -64.884794, 0],
              [-112.250215, -66.611957, 0],
            ],
          ],
        },
      ]);
    });

    await lastValueFrom(
      pubSubClient.emit('import-observable-area', {
        kind: 'storage#object',
        id: 'syns-daas-dev_observable-area-storage/geojson/ST0002/20230328_150000.geojson/1679995995788548',
        selfLink:
          'https://www.googleapis.com/storage/v1/b/syns-daas-dev_observable-area-storage/o/geojson%2FST0002%2F20230328_150000.geojson',
        name: 'geojson/ST0002/20230328_150000.geojson',
        bucket: 'syns-daas-dev_observable-area-storage',
        generation: '1679995995788548',
        metageneration: '1',
        contentType: 'text/plain; charset=utf-8',
        timeCreated: '2023-03-27T09:32:23.405Z',
        updated: '2023-03-27T09:32:23.405Z',
        storageClass: 'REGIONAL',
        timeStorageClassUpdated: '2023-03-27T09:32:23.405Z',
        size: '1217742',
        md5Hash: '1wx69o6bTHMJNcONe/xX8Q==',
        mediaLink:
          'https://storage.googleapis.com/download/storage/v1/b/syns-daas-dev_observable-area-storage/o/geojson%2FST0002%2F20230328_150000.geojson?generation=1679995995788548&alt=media',
        crc32c: 'yrndrA==',
        etag: 'CJmA29zm+/0CEAE=',
      }),
    );
    await new Promise((r) => setTimeout(r, 2000));
    const [found, count] = await dataSource
      .getRepository(ObservableArea)
      .findAndCountBy({
        satId: 'ST0002',
        date: df.parse('20230328_150000', 'yyyyMMdd_HHmmss', new Date()),
      });
    createdObservableAreas.push(...found);
    expect(count).toEqual(2);
  });
});
