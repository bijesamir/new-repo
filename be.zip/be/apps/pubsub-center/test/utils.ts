import { TypeOrmModule, TypeOrmModuleOptions } from '@nestjs/typeorm';
import { LoggerModule } from '@iris-lib/logger';
import { DataSource } from 'typeorm';

import { AppConfigModule } from '../src/config/app-config.module';
import { ModuleMetadata } from '@nestjs/common';
import { DbConfigModule } from '@iris-lib/db/db-config.module';
import { DbConfigService } from '@iris-lib/db';

export function testModuleBase(): ModuleMetadata {
  return {
    imports: [
      AppConfigModule,
      DbConfigModule,
      LoggerModule,
      TypeOrmModule.forRootAsync({
        inject: ['DbConfig'],
        useFactory: async (configService: DbConfigService) => {
          return configService.get('db') as TypeOrmModuleOptions;
        },
      }),
    ],
    providers: [],
    controllers: [],
  };
}

export type MockType<T> = {
  // eslint-disable-next-line @typescript-eslint/ban-types
  [P in keyof T]?: jest.Mock<{}>;
};

export const dataSourceMockFactory: () => MockType<DataSource> = jest.fn(
  () => ({
    createQueryRunner: jest.fn().mockImplementation(() => ({
      connect: jest.fn(),
      startTransaction: jest.fn(),
      release: jest.fn(),
      rollbackTransaction: jest.fn(),
      manager: {
        insert: jest.fn(),
        update: jest.fn(),
        delete: jest.fn(),
        softRemove: jest.fn(),
      },
    })),
  }),
);

export const mockRepo = {
  metadata: {
    connection: {
      options: { type: '' },
    },
    columns: [{ propertyName: 'id', isPrimary: true }],
    relations: [],
  },
};

export const testModuleDataSourceMockBase = (): ModuleMetadata => {
  return {
    imports: [AppConfigModule, LoggerModule],
    providers: [
      {
        provide: DataSource,
        useFactory: dataSourceMockFactory,
      },
    ],
    controllers: [],
    exports: [],
  };
};
