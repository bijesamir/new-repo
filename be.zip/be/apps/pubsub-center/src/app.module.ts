import { Module } from '@nestjs/common';
import { AppConfigModule } from './config/app-config.module';
import { SchedulerUsecaseModule } from './usecases/scheduler-usecase/scheduler-usecase.module';

@Module({
  imports: [AppConfigModule, SchedulerUsecaseModule],
})
export class AppModule {}
