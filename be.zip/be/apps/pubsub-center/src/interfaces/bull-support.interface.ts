/* eslint-disable @typescript-eslint/no-namespace */
import { Job } from 'bullmq';

export interface JobLog {
  queue: string;
  name: string;
  id: string;
  attemptsMade: number;
  finishedOn: Date;
  processedOn: Date;
  data: any;
}

export namespace fromBullSupport {
  export const toJobLog = (job: Job): JobLog => {
    return {
      queue: job.queueName,
      name: job.name,
      id: job.id,
      attemptsMade: job.attemptsMade,
      finishedOn: job.finishedOn ? new Date(job.finishedOn) : null,
      processedOn: job.processedOn ? new Date(job.processedOn) : null,
      data: job.data,
    };
  };
}
