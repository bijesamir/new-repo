export const DELETE_SOURCE_PDV = 'delete-source-product-data-version';
