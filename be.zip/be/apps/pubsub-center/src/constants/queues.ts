export const REGISTER_PRODUCT_DATA_QUEUE = 'register-product-data';
export const REGISTER_PRODUCT_DATA_QUEUE_PREFIX = 'rdp';
export const CREATE_SCENE_INFO_QUEUE = 'create-scene-info';
export const CREATE_SCENE_INFO_QUEUE_PREFIX = 'csi';
export const SCHEDULER_QUEUE = 'psc-scheduler';
export const NOTIFY_PRODUCT_READY_QUEUE = 'notify-product-ready';
export const NOTIFY_PRODUCT_READY_QUEUE_PREFIX = 'npr';
