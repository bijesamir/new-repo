// https://github.com/open-telemetry/opentelemetry-js/discussions/3503
import * as tracer from '@iris-lib/ops/tracing';
import { getNodeAutoInstrumentations } from '@opentelemetry/auto-instrumentations-node';
import { PubSubInstrumentation } from 'opentelemetry-instrumentation-pubsub';
import { BullMQInstrumentation } from '@jenniferplusplus/opentelemetry-instrumentation-bullmq';
import { envBooleanValue } from '@iris-lib/utils';

if (envBooleanValue('TRACING_ENABLED', false)) {
  const instrumentations = [
    new PubSubInstrumentation(),
    new BullMQInstrumentation(),
    getNodeAutoInstrumentations({
      '@opentelemetry/instrumentation-http': {
        ignoreIncomingRequestHook: (request) => {
          // ignores "/healthz", "/health" and "/"
          const expression = /^\/(healthz?)?$/;
          return new RegExp(expression).test(request.url);
        },
      },
      '@opentelemetry/instrumentation-grpc': {
        ignoreGrpcMethods: [new RegExp(/^streaming/, 'i')],
      },
      '@opentelemetry/instrumentation-ioredis': {
        enabled: false,
      },
      '@opentelemetry/instrumentation-fs': {
        enabled: false,
      },
      '@opentelemetry/instrumentation-net': {
        enabled: false,
      },
      '@opentelemetry/instrumentation-dns': {
        enabled: false,
      },
    }),
  ];
  tracer.initTracing('iris-pubsub-center', instrumentations);
}

import { LoggerService } from '@iris-lib/logger';
import {
  GcPubsubOptions,
  GcPubsubServer,
  GcsNotificationDeserializer,
} from '@iris-lib/transporters';
import { INestMicroservice } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { AppConfigService } from './config/app-config.service';
import { DpsNotificationUsecaseModule } from './usecases/dps-notification-usecase/dps-notification-usecase.module';
import { GcsNotificationUsecaseModule } from './usecases/gcs-notification-usecase/gcs-notification-usecase.module';
import { ScsNotificationUsecaseModule } from './usecases/scs-notification-usecase/scs-notification-usecase.module';
import { useContainer as useValidatorContainer } from 'class-validator';
import { PscNotificationUsecaseModule } from './usecases/psc-notification-usecase/psc-notification-usecase.module';

async function createApp<T>(
  rootModule: { new (): T },
  options: GcPubsubOptions,
): Promise<INestMicroservice> {
  const app = await NestFactory.createMicroservice(rootModule, {
    strategy: new GcPubsubServer(options),
  });

  const logger = await app.get<LoggerService>(LoggerService);
  app.useLogger(logger);

  return app;
}

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  const config = await app.get<AppConfigService>('AppConfig');

  const pscApp = await createApp(PscNotificationUsecaseModule, {
    subscription: config.get('pubsub.pscNotificationSubscription'),
    client: {
      apiEndpoint: config.get('pubsub.emulatorHost'),
      projectId: config.get('pubsub.projectId'),
    },
  });

  const dpsApp = await createApp(DpsNotificationUsecaseModule, {
    subscription: config.get('pubsub.dpsNotificationSubscription'),
    client: {
      apiEndpoint: config.get('pubsub.emulatorHost'),
      projectId: config.get('pubsub.projectId'),
    },
  });

  const scsApp = await createApp(ScsNotificationUsecaseModule, {
    subscription: config.get('pubsub.scsNotificationSubscription'),
    client: {
      apiEndpoint: config.get('pubsub.emulatorHost'),
      projectId: config.get('pubsub.projectId'),
    },
  });
  useValidatorContainer(scsApp.select(ScsNotificationUsecaseModule), {
    fallbackOnErrors: true,
  });

  const gcsApp = await createApp(GcsNotificationUsecaseModule, {
    subscription: config.get('pubsub.gcsNotificationSubscription'),
    client: {
      apiEndpoint: config.get('pubsub.emulatorHost'),
      projectId: config.get('pubsub.projectId'),
    },
    deserializer: new GcsNotificationDeserializer(),
  });

  await app.init();
  await pscApp.listen();
  await dpsApp.listen();
  await scsApp.listen();
  await gcsApp.listen();
}
bootstrap();
