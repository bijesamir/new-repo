import { LoggerWrapper } from '@iris-lib/logger';
import { Controller } from '@nestjs/common';
import {
  CREATE_SCENE_INFO_QUEUE,
  CREATE_SCENE_INFO_QUEUE_PREFIX,
  NOTIFY_PRODUCT_READY_QUEUE,
  NOTIFY_PRODUCT_READY_QUEUE_PREFIX,
} from '../constants/queues';
import { InjectQueue } from '@nestjs/bullmq';
import { Queue } from 'bullmq';
import { Ctx, EventPattern, Payload } from '@nestjs/microservices';
import { CreateSceneInfoDto } from '../models/dto/scene-info/create-scene-info.dto';
import { GcPubsubContext } from '@iris-lib/transporters';
import { format } from 'date-fns';
import { NotifyProductReadyDto } from '../models/dto/product-data/notify-product-ready.dto';
import { DownloadHistory } from '@iris-lib/db/entities';
import { PscNotificationUsecaseService } from '../usecases/psc-notification-usecase/psc-notigication-usecase.service';

// PSC: PubSub-Center
@Controller('psc-notification')
export class PscNotificationController {
  private logger = new LoggerWrapper(PscNotificationController.name);

  constructor(
    @InjectQueue(CREATE_SCENE_INFO_QUEUE) private readonly csiQueue: Queue,
    @InjectQueue(NOTIFY_PRODUCT_READY_QUEUE) private readonly nprQueue: Queue,
    private pscNotificationUsecaseService: PscNotificationUsecaseService,
  ) {}

  @EventPattern('create-scene-info')
  async createSceneInfo(
    @Payload() dto: CreateSceneInfoDto,
    @Ctx() context: GcPubsubContext,
  ) {
    // use queue and custom jobId to prevent duplicated scene-info creation (locked by jobId)
    // https://docs.bullmq.io/guide/jobs/job-ids
    // https://docs.bullmq.io/guide/queues/auto-removal-of-jobs#what-about-idempotence
    const pubsubMessage = context.getMessage();
    const jobId = `${dto.taskingInfoId}_${dto.sceneNo}`;
    const jobName = `${CREATE_SCENE_INFO_QUEUE_PREFIX}-${
      pubsubMessage.id
    }-${format(pubsubMessage.publishTime, "yyyyMMdd'T'HHmmssX")}`;
    this.logger.debug('incoming event: create-scene-info', {
      dto,
      job: {
        id: jobId,
        name: jobName,
      },
    });
    await this.csiQueue.add(jobName, dto, { jobId });
  }
  @EventPattern('notify-product-ready')
  async orderedProductData(
    @Payload() dto: NotifyProductReadyDto,
    @Ctx() context: GcPubsubContext,
  ) {
    // use queue and custom jobId to prevent duplicated scene-info creation (locked by jobId)
    // https://docs.bullmq.io/guide/jobs/job-ids
    // https://docs.bullmq.io/guide/queues/auto-removal-of-jobs#what-about-idempotence
    const pubsubMessage = context.getMessage();
    const jobId = `${dto.orderId}-${dto.productDataVersionId}`;
    const jobName = `${NOTIFY_PRODUCT_READY_QUEUE_PREFIX}-${
      pubsubMessage.id
    }-${format(pubsubMessage.publishTime, "yyyyMMdd'T'HHmmssX")}`;
    this.logger.debug('incoming event: notify-product-ready', {
      dto,
      job: {
        id: jobId,
        name: jobName,
      },
    });
    await this.nprQueue.add(jobName, dto, { jobId });
  }
  @EventPattern('download-product-data')
  async downloadProductData(@Payload() dto: DownloadHistory) {
    this.logger.debug('incoming event: download-product-data', { dto });
    return await this.pscNotificationUsecaseService.createDownloadHistory(dto);
  }
}
