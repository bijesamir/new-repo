import { LoggerWrapper } from '@iris-lib/logger';
import { Controller } from '@nestjs/common';
import { RegisterProductDataDto } from '../models/dto/product-data/register-product-data.dto';
import { Ctx, EventPattern, Payload } from '@nestjs/microservices';
import { InjectQueue } from '@nestjs/bullmq';
import { Queue } from 'bullmq';
import {
  REGISTER_PRODUCT_DATA_QUEUE,
  REGISTER_PRODUCT_DATA_QUEUE_PREFIX,
} from '../constants/queues';
import { GcPubsubContext } from '@iris-lib/transporters';
import { format } from 'date-fns';
import {
  getProductFormatLabelShort,
  getResolutionModeLabel,
} from '@iris-lib/constants';

@Controller('dps-notification')
export class DpsNotificationController {
  private logger = new LoggerWrapper(DpsNotificationController.name);

  constructor(
    @InjectQueue(REGISTER_PRODUCT_DATA_QUEUE) private readonly rpdQueue: Queue,
  ) {}

  @EventPattern('register-product-data')
  async registerProductData(
    @Payload() dto: RegisterProductDataDto,
    @Ctx() context: GcPubsubContext,
  ) {
    // use queue and custom jobId to prevent concurrent processing (locked by jobId)
    // https://docs.bullmq.io/guide/jobs/job-ids
    // https://docs.bullmq.io/guide/queues/auto-removal-of-jobs#what-about-idempotence
    const pubsubMessage = context.getMessage();
    const jobId = `${dto.orderId}_${dto.sceneNo}_${getProductFormatLabelShort(
      dto.productFormat,
    )}_${getResolutionModeLabel(dto.resolutionMode)}`;
    const jobName = `${REGISTER_PRODUCT_DATA_QUEUE_PREFIX}-${
      pubsubMessage.id
    }-${format(pubsubMessage.publishTime, "yyyyMMdd'T'HHmmssX")}`;
    this.logger.debug('incoming event: register-product-data', {
      dto,
      job: {
        id: jobId,
        name: jobName,
      },
    });
    await this.rpdQueue.add(jobName, dto, { jobId });
  }
}
