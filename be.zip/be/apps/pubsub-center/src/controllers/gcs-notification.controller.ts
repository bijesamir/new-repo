import { LoggerWrapper } from '@iris-lib/logger';
import { Controller } from '@nestjs/common';
import { EventPattern, Payload } from '@nestjs/microservices';
import { GcsNotificationUsecaseService } from '../usecases/gcs-notification-usecase/gcs-notification-usecase.service';
import { ObservableAreaFinalizedDto } from '../models/dto/observable-area/finalized.dto';

@Controller('gcs-notification')
export class GcsNotificationController {
  private logger = new LoggerWrapper(GcsNotificationController.name);

  constructor(
    private gcsNotificationUsecaseService: GcsNotificationUsecaseService,
  ) {}

  @EventPattern('import-observable-area')
  importObservableArea(@Payload() dto: ObservableAreaFinalizedDto) {
    this.logger.debug('incoming event: import-observable-area', { dto });
    return this.gcsNotificationUsecaseService.importObservableArea(dto);
  }
}
