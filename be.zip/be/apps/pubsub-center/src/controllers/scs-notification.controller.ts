import { LoggerWrapper } from '@iris-lib/logger';
import { Controller } from '@nestjs/common';
import { EventPattern, Payload } from '@nestjs/microservices';
import { TaskingInfoUpdateStatusDto } from '../models/dto/tasking-info/tasking-info-update-status.dto';
import { ScsNotificationUsecaseService } from '../usecases/scs-notification-usecase/scs-notification-usecase.service';

@Controller('scs-notification')
export class ScsNotificationController {
  private logger = new LoggerWrapper(ScsNotificationController.name);

  constructor(
    private scsNotificationUsecaseService: ScsNotificationUsecaseService,
  ) {}

  @EventPattern('tasking-info-update-status')
  updateTaskingInfoStatus(@Payload() dto: TaskingInfoUpdateStatusDto) {
    this.logger.debug('incoming event: tasking-info-update-status', { dto });
    return this.scsNotificationUsecaseService.updateTaskingInfoStatusByOrderId(
      dto,
    );
  }
}
