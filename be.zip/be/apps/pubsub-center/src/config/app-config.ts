import { envIntValue, envStringValue } from '@iris-lib/utils';
import * as fs from 'fs';

export const generateApplicationConfig = () => {
  const setDefaultQueueJobOptions = () => {
    if (process.env.NODE_ENV === 'test') {
      return {
        attempts: 3,
      };
    }
    return {
      attempts: 3,
      backoff: {
        type: 'exponential',
        delay: 10 * 60 * 1000, // 10 minutes
      },
      removeOnComplete: {
        age: 24 * 3600 * 3, // keep up to 3 days
        count: 100, // keep up to 100 jobs
      },
      removeOnFail: {
        age: 24 * 3600 * 7, // keep up to 7 days
      },
    };
  };
  const setNoConcurrentQueueJobOptions = () => {
    if (process.env.NODE_ENV === 'test') {
      return {
        attempts: 3,
      };
    }
    return {
      attempts: 3,
      backoff: {
        type: 'exponential',
        delay: 3 * 60 * 1000, // 3 minute
      },
      // use queue and custom jobId to prevent concurrent processing (locked by jobId)
      // remove completed jobs to unlock
      // https://docs.bullmq.io/guide/queues/auto-removal-of-jobs#remove-all-finalized-jobs
      removeOnComplete: true,
      removeOnFail: true,
    };
  };

  return {
    env: envStringValue('NODE_ENV', 'development'),
    app: {
      taskMgmtUrl: `${envStringValue('IRIS_WEBPAGE_URL', 'NONE')}/tasks`,
      archiveOrderUrl: `${envStringValue(
        'IRIS_WEBPAGE_URL',
        'NONE',
      )}/archive-order-review`,
      taskingDownloadDays: envIntValue('TASKING_DOWNLOAD_DAYS', 365),
      archiveDownloadDays: envIntValue('ARCHIVE_DOWNLOAD_DAYS', 14),
      irisApiUrl: envStringValue('IRIS_API_URL', 'NONE'),
    },
    pubsub: {
      emulatorHost: process.env.PUBSUB_EMULATOR_HOST, // optional
      projectId: envStringValue('PUBSUB_PROJECT_ID', 'syns-daas-dev-local'),
      deliveryNotificationTopic: envStringValue(
        'PUBSUB_DELIVERY_NOTIFICATION_TOPIC',
      ),
      deliveryNotificationSubscription: envStringValue(
        'PUBSUB_DELIVERY_NOTIFICATION_SUBSCRIPTION',
      ),
      pscNotificationTopic: envStringValue('PUBSUB_PSC_NOTIFICATION_TOPIC'),
      pscNotificationSubscription: envStringValue(
        'PUBSUB_PSC_NOTIFICATION_SUBSCRIPTION',
      ),
      scsNotificationTopic: envStringValue('PUBSUB_SCS_NOTIFICATION_TOPIC'),
      scsNotificationSubscription: envStringValue(
        'PUBSUB_SCS_NOTIFICATION_SUBSCRIPTION',
      ),
      dpsNotificationTopic: envStringValue('PUBSUB_DPS_NOTIFICATION_TOPIC'),
      dpsNotificationSubscription: envStringValue(
        'PUBSUB_DPS_NOTIFICATION_SUBSCRIPTION',
      ),
      gcsNotificationTopic: envStringValue('PUBSUB_GCS_NOTIFICATION_TOPIC'),
      gcsNotificationSubscription: envStringValue(
        'PUBSUB_GCS_NOTIFICATION_SUBSCRIPTION',
      ),
    },
    redis: {
      disconnectTimeout: envIntValue('REDIS_DISCONNECT_TIMEOUT', 1000),
      host: envStringValue('REDIS_HOST', 'localhost'),
      port: envIntValue('REDIS_PORT', 63790),
      db: envIntValue('REDIS_PUBSUB_DB', 2),
      password: envStringValue('REDIS_PASSWORD'),
      maxRetriesPerRequest: null,
      tls: {
        key:
          envStringValue('REDIS_SERVER_KEY_PATH', 'NO_NEED') == 'NO_NEED'
            ? null
            : fs.readFileSync(envStringValue('REDIS_SERVER_KEY_PATH')),
        ca: fs.readFileSync(envStringValue('REDIS_CA_CERT_PATH')),
        checkServerIdentity: () => undefined,
      },
    },
    rpdQueueOptions: setNoConcurrentQueueJobOptions(),
    csiQueueOptions: setNoConcurrentQueueJobOptions(),
    defaultQueueOptions: setDefaultQueueJobOptions(),
    nprQueueOptions: setNoConcurrentQueueJobOptions(),
    gcs: {
      productDataStoreBucket: envStringValue('GCS_PRODUCT_DATA_STORE'),
    },
  };
};

export type AppConfig = ReturnType<typeof generateApplicationConfig>;
