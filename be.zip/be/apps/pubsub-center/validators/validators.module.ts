import { Module } from '@nestjs/common';
import { EnableUpdateTaskingStatusByOrderId } from './validate-tasking-info-update-status';

@Module({
  providers: [EnableUpdateTaskingStatusByOrderId],
  exports: [EnableUpdateTaskingStatusByOrderId],
})
export class ValidatorsModule {}
