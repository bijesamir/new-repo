import {
  ValidationArguments,
  ValidatorConstraint,
  ValidatorConstraintInterface,
  isUUID,
} from 'class-validator';
import { Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { TaskingInfo } from '@iris-lib/db/entities';
import { enableChangeTaskingStatus } from '@iris-lib/constants';

@ValidatorConstraint({
  name: 'enableUpdateTaskingStatusByOrderId',
  async: true,
})
@Injectable()
export class EnableUpdateTaskingStatusByOrderId
  implements ValidatorConstraintInterface
{
  constructor(@InjectDataSource() readonly dataSource: DataSource) {}

  async validate(data: string, args: ValidationArguments) {
    if (!data || data.length == 0) {
      return false;
    }
    if (!isUUID(data, 4)) {
      return false;
    }

    if (!('status' in args.object)) {
      return false;
    }

    const tmp = await this.dataSource.getRepository(TaskingInfo).find({
      where: {
        scsOrderId: data,
      },
    });
    if (tmp.length == 0) {
      return false;
    }

    return tmp.every((x) =>
      enableChangeTaskingStatus(x.status, args.object['status']),
    );
  }
  defaultMessage(args: ValidationArguments) {
    return `${args.property} contains an id or status that cannot be updated`;
  }
}
