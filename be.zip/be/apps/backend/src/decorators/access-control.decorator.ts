import { IrisAccessControlType } from '@iris-lib/constants/iris-access-control-type';
import { SetMetadata } from '@nestjs/common';

export const ACCESS_CONTROL_KEY = 'accessControl';

/**
 * Annotations for access control on the controller itself and its methods. <br/>
 * Explicitly define access control types in all controllers
 * @param acTypes {IrisAccessControlType[]} Access control types in Iris
 */
export const AccessControl = (...acTypes: IrisAccessControlType[]) => {
  return SetMetadata<string, IrisAccessControlType[]>(
    ACCESS_CONTROL_KEY,
    acTypes,
  );
};
