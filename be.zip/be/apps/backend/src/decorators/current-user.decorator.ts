import { createParamDecorator } from '@nestjs/common';
import { IrisRequestContext } from '@iris-lib/middlewares';

/**
 * A decorator to make user information easily available in the controller.
 */
export const CurrentUser = createParamDecorator(() => {
  const a = IrisRequestContext.get().req;
  return a.currentUser;
});
