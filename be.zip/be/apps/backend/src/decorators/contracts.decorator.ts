import { createParamDecorator } from '@nestjs/common';
import { IrisRequestContext } from '@iris-lib/middlewares';

/**
 * A decorator for easily using the contract information in the controller. <br/>
 * Since it is only used in UserController, it can be deleted.
 */
export const Contracts = createParamDecorator(() => {
  const a = IrisRequestContext.get().req;
  return a.currentContracts;
});
