import { LoggerWrapper } from '@iris-lib/logger';
import {
  CanActivate,
  ExecutionContext,
  Inject,
  Injectable,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { IrisRequest } from '@iris-lib/middlewares';
import { AppConfigService } from '../config/app-config.service';
import { IrisAccessControlType } from '@iris-lib/constants/iris-access-control-type';
import { ACCESS_CONTROL_KEY } from '../decorators/access-control.decorator';
import { IrisUserRole } from '@iris-lib/constants';
import { IS_PUBLIC_KEY } from '@iris-lib/decorators';

/**
 * Check if the URL you are trying to access has an accessible contract.
 */
@Injectable()
export class AccessControlGuard implements CanActivate {
  private logger = new LoggerWrapper(AccessControlGuard.name);

  constructor(
    private reflector: Reflector,
    @Inject('AppConfig') private readonly config: AppConfigService,
  ) {}

  canActivate(context: ExecutionContext): boolean {
    // Checking flags that can be skipped for development.
    if (this.config.get('app.skipAccessControlGuard')) {
      this.logger.debug('skipAccessControlGuard');
      return true;
    }
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (isPublic) {
      return true;
    }

    // default acTypes from controller, selectively overridden by handler,
    const allowedAcTypes = this.reflector.getAllAndOverride<
      IrisAccessControlType[]
    >(ACCESS_CONTROL_KEY, [context.getHandler(), context.getClass()]);

    const irisRequest = context.switchToHttp().getRequest() as IrisRequest;
    let result = false;
    if (
      irisRequest.currentUser.roleTypes.includes(IrisUserRole.INTERNAL) &&
      allowedAcTypes.includes(IrisAccessControlType.Internal)
    ) {
      result = true;
    }
    if (
      !result &&
      irisRequest.currentUser.roleTypes.includes(IrisUserRole.ADMINISTRATOR) &&
      allowedAcTypes.includes(IrisAccessControlType.Admin)
    ) {
      result = true;
    }
    if (
      !result &&
      irisRequest.currentUser.roleTypes.includes(IrisUserRole.COLLABORATOR) &&
      allowedAcTypes.includes(IrisAccessControlType.Collaborator)
    ) {
      result = true;
    }
    if (!result && allowedAcTypes.includes(IrisAccessControlType.Tasking)) {
      result = irisRequest.currentContracts.some(
        (contract) =>
          contract.availableTasking && contract.canAccessTaskingConsole,
      );
    }
    if (
      !result &&
      allowedAcTypes.includes(IrisAccessControlType.TaskingDownload)
    ) {
      result = irisRequest.currentContracts.some(
        (contract) => contract.availableTasking,
      );
    }
    if (!result && allowedAcTypes.includes(IrisAccessControlType.Archive)) {
      result = irisRequest.currentContracts.some(
        (contract) => contract.availableArchivePurchase,
      );
    }

    this.logger.debug('access control check result', {
      userRoles: irisRequest.currentUser.roleTypes,
      contracts: irisRequest.currentContracts,
      allowedAcTypes,
      result,
    });
    return result;
  }
}
