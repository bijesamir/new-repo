import { CitadelHttpService } from '@iris-lib/citadel';
import { HEADER_REQUEST_INFO, HEADER_USER_INFO } from '@iris-lib/constants';
import { IS_PUBLIC_KEY } from '@iris-lib/decorators';
import { LoggerWrapper } from '@iris-lib/logger';
import { IrisRequest } from '@iris-lib/middlewares';
import { IrisUserDto } from '@iris-lib/models';
import {
  CanActivate,
  ExecutionContext,
  Inject,
  Injectable,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { plainToInstance } from 'class-transformer';

@Injectable()
export class IrisAuthGuard implements CanActivate {
  private logger = new LoggerWrapper(IrisAuthGuard.name);

  constructor(
    private reflector: Reflector,
    @Inject(CitadelHttpService) private citadelHttpService: CitadelHttpService,
  ) {}

  async canActivate(context: ExecutionContext) {
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (isPublic) {
      return true;
    }

    const req = context.switchToHttp().getRequest() as IrisRequest;
    // since plain text header is used to pass userinfo, integrity and
    // confidentiality must be provided by mTLS between iris-gateway and iris-backend
    const [irisUser, requestInfo] = this.extractInfoFromHeaders(req);
    if (!irisUser) {
      return false;
    }
    this.logger.debug('iris user data', irisUser);
    req.currentUser = irisUser;
    if (requestInfo) {
      req.sourceIp = requestInfo.sourceIp;
      req.isWhiteListedIp = requestInfo.isWhiteListedIp;
    }

    try {
      req.currentContracts = await this.citadelHttpService.getAllContracts(
        req.currentUser.organizationIds,
        req.currentUser.userToken,
      );
      return true;
    } catch (e) {
      this.logger.error('error occured', e['stack'] || e);
      throw e;
    }
  }

  private extractInfoFromHeaders(
    req: any,
  ): [IrisUserDto, { [key: string]: any }] {
    let userInfo = undefined;
    let requestInfo = undefined;

    if (req.headers[HEADER_USER_INFO]) {
      try {
        const userInfoString = Buffer.from(
          req.headers[HEADER_USER_INFO],
          'base64',
        ).toString();
        userInfo = plainToInstance(IrisUserDto, JSON.parse(userInfoString));
      } catch (e) {
        this.logger.error(
          'error occured when deserializing user info from header',
          e['stack'] || e,
        );
        throw e;
      }
    }
    if (req.headers[HEADER_REQUEST_INFO]) {
      try {
        const requestInfoString = Buffer.from(
          req.headers[HEADER_REQUEST_INFO],
          'base64',
        ).toString();
        requestInfo = JSON.parse(requestInfoString);
      } catch (e) {
        this.logger.error(
          'error occured when deserializing request info from header',
          e['stack'] || e,
        );
        throw e;
      }
    }
    return [userInfo, requestInfo];
  }
}
