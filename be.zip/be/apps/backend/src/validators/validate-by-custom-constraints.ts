import { LoggerWrapper } from '@iris-lib/logger';
import {
  ValidationArguments,
  ValidatorConstraint,
  ValidatorConstraintInterface,
} from 'class-validator';

@ValidatorConstraint({ name: 'validateByConstraintFunctions', async: true })
export class ValidateByConstraintFunctions
  implements ValidatorConstraintInterface
{
  private logger = new LoggerWrapper(ValidateByConstraintFunctions.name);

  async validate(value: any, args: ValidationArguments) {
    const result = args.constraints.some((constraintFunc) => {
      return constraintFunc(value);
    });
    return result;
  }
}
