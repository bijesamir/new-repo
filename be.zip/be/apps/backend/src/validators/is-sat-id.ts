import { Inject, Injectable } from '@nestjs/common';
import {
  ValidationArguments,
  ValidatorConstraint,
  ValidatorConstraintInterface,
} from 'class-validator';
import { CacheManageService } from '../infra/cache-manage/cache-manage.service';
import { IrisRequestContext } from '@iris-lib/middlewares';

@ValidatorConstraint({ name: 'isSatId', async: true })
@Injectable()
export class IsSatId implements ValidatorConstraintInterface {
  constructor(
    @Inject('CacheManager') private readonly cacheManager: CacheManageService,
  ) {}
  async validate(data: any) {
    const satellites = await this.cacheManager.getSatellitesCache();
    const satIds = satellites.map((x) => x.satId);
    if (Array.isArray(data)) {
      return data.every((x) => satIds.includes(x));
    } else {
      return satIds.includes(data);
    }
  }
  defaultMessage(args: ValidationArguments) {
    return `${args.property} is invalid`;
  }
}

@ValidatorConstraint({ name: 'isVisibleSatId', async: true })
@Injectable()
export class IsVisibleSatId implements ValidatorConstraintInterface {
  constructor(
    @Inject('CacheManager') private readonly cacheManager: CacheManageService,
  ) {}
  async validate(data: any) {
    const reqCtx = IrisRequestContext.get().req;

    const satellites = await this.cacheManager.getSatellitesByRoleType(
      reqCtx.currentUser,
    );
    const satIds = satellites.map((x) => x.satId);
    if (Array.isArray(data)) {
      return data.every((x) => satIds.includes(x));
    } else {
      return satIds.includes(data);
    }
  }
  defaultMessage(args: ValidationArguments) {
    return `${args.property} is invalid`;
  }
}

export const ValidSatIdPattern = /ST\d{4}$/;

export const ValidSatNamePattern = /^Stri[xX]{1}\-[a-zA-Z0-9]{1,10}$/;

export const ValidSatelliteDevelopmentCode = /dsx\d{4}$/;
