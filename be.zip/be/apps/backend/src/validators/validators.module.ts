import { Module } from '@nestjs/common';
import { IsSatId, IsVisibleSatId } from './is-sat-id';
import {
  EnableUpdateAltitude,
  EnableUpdateTaskingStatus,
  IsExistingAoi,
  IsExistingProductDataVersion,
  IsExistingTaskingRequest,
  ValidateCancellationDeadline,
} from '@iris-lib/db/validators';
import { ValidateTaskingType } from './validate-tasking-type';
import { ValidateConfliction } from './validate-confliction';
import { ValidateCandidateSearchOrbitParamCombinations } from './validate-candidate-search-orbit-param-combinations';
import { IsValidContractWithOrganization } from '@iris-lib/validators/is-valid-contract-with-organization';
import { IsValidContract } from '@iris-lib/validators';
import { IsStacDatetime } from './is-stac-datetime';
import { IsValidBbox } from './is-valid-bbox';
import { ValidateByConstraintFunctions } from './validate-by-custom-constraints';

@Module({
  providers: [
    IsSatId,
    IsVisibleSatId,
    IsStacDatetime,
    IsValidBbox,
    IsExistingAoi,
    IsExistingTaskingRequest,
    IsExistingProductDataVersion,
    EnableUpdateTaskingStatus,
    EnableUpdateAltitude,
    ValidateTaskingType,
    ValidateByConstraintFunctions,
    ValidateConfliction,
    ValidateCandidateSearchOrbitParamCombinations,
    ValidateCancellationDeadline,
    IsValidContractWithOrganization,
    IsValidContract,
  ],
  exports: [
    IsSatId,
    IsVisibleSatId,
    IsStacDatetime,
    IsValidBbox,
    IsExistingAoi,
    IsExistingTaskingRequest,
    IsExistingProductDataVersion,
    EnableUpdateTaskingStatus,
    ValidateTaskingType,
    ValidateByConstraintFunctions,
    ValidateConfliction,
    ValidateCandidateSearchOrbitParamCombinations,
    IsValidContractWithOrganization,
    IsValidContract,
  ],
})
export class ValidatorsModule {}
