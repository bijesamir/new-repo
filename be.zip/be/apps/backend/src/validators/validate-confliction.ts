import {
  ValidationArguments,
  ValidatorConstraint,
  ValidatorConstraintInterface,
} from 'class-validator';
import {
  ScsCandidateForViewDto,
  ScsConflictCondition,
} from '../models/dto/mission-portal/scs-candidate.dto';
import { IrisUserDto } from '@iris-lib/models';
import { IrisRequestContext } from '@iris-lib/middlewares';

/**
 * Check if the observation request you are about to register can be overridden.<br/>
 */
@ValidatorConstraint({ name: 'validateConfliction', async: false })
export class ValidateConfliction implements ValidatorConstraintInterface {
  validate(priority: number, args: ValidationArguments) {
    const tmp = args.object as ScsCandidateForViewDto;
    const reqCtx = IrisRequestContext.get().req;
    return enableRgisterTaskingInfo(reqCtx.currentUser, tmp.conflictConditions);
  }
  defaultMessage(args: ValidationArguments) {
    return `${args.property} is invalid`;
  }
}

export const enableRgisterTaskingInfo = (
  user: IrisUserDto,
  conflicts: ScsConflictCondition[] | null,
) => {
  if (Array.isArray(conflicts)) {
    return conflicts.every((x) => {
      return conflictCheck(user, x, (target) => {
        return target.conflictStatus == 0;
      });
    });
  }
  return true;
};

export const conflictCheck = (
  user: IrisUserDto | null,
  conflict: ScsConflictCondition,
  chk?: (target: ScsConflictCondition) => boolean | null,
) => {
  // https://docs.google.com/document/d/1P2_La8TZ2BX8-t8VRdi4qaxC4KxgJF6NOZ8Ioi-3VDs/edit#heading=h.oloi9vhb9vzn
  return (
    (chk ? chk(conflict) : true) ||
    conflict.conflictStatus == 1 ||
    (conflict.conflictStatus == 2 &&
      !isNaN(Number(conflict.organizationId)) &&
      user.organizationIds.includes(Number(conflict.organizationId)))
  );
};
