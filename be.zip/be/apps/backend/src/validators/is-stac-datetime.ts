import {
  ValidationArguments,
  ValidatorConstraint,
  ValidatorConstraintInterface,
} from 'class-validator';
import { isBefore, isValid } from 'date-fns';

const RFC3339_REGEX =
  /^(\d\d\d\d)\-(\d\d)\-(\d\d)T(\d\d):(\d\d):(\d\d)([.]\d+)?(Z|([-+])(\d\d):(\d\d))$/;

@ValidatorConstraint({ name: 'isStacDatetime', async: false })
export class IsStacDatetime implements ValidatorConstraintInterface {
  validate(data: any) {
    // date-time:       "2018-02-12T23:20:50Z"
    // closed interval: "2018-02-12T00:00:00Z/2018-03-18T12:31:12Z"
    // open intervals:  "2018-02-12T00:00:00Z/.." or "../2018-03-18T12:31:12Z"
    const [start, end, ...rest] = data.split('/');
    if (rest.length) {
      return false;
    } else if (
      (!start && !end) ||
      (start === '..' && end === '..') ||
      (!start && end === '..') ||
      (start === '..' && !end)
    ) {
      return false;
    } else {
      let startDateTime;
      let endDateTime;

      if (start && start !== '..') {
        if (!RFC3339_REGEX.test(start)) {
          return false;
        }
        if (!isValid(new Date(start))) {
          return false;
        }
        startDateTime = new Date(start);
      }
      if (end && end !== '..') {
        if (!RFC3339_REGEX.test(end)) {
          return false;
        }
        if (!isValid(new Date(end))) {
          return false;
        }
        endDateTime = new Date(end);
      }

      if (
        startDateTime &&
        endDateTime &&
        !isBefore(startDateTime, endDateTime)
      ) {
        return false;
      }
      return true;
    }
  }
  defaultMessage(args: ValidationArguments) {
    return `${args.property} is invalid`;
  }
}
