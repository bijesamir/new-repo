import {
  ValidationArguments,
  ValidatorConstraint,
  ValidatorConstraintInterface,
} from 'class-validator';

@ValidatorConstraint({ name: 'isValidBbox', async: false })
export class IsValidBbox implements ValidatorConstraintInterface {
  validate(data: any) {
    // at this time we only accept 2d-bbox
    if (data.length !== 4 && data.length !== 6) {
      return false;
    }
    if (
      (data.length === 4 && data[1] > data[3]) ||
      (data.length === 6 && data[1] > data[4])
    ) {
      return false;
    }
    return true;
  }
  defaultMessage(args: ValidationArguments) {
    return `${args.property} is invalid`;
  }
}
