import { LoggerWrapper } from '@iris-lib/logger';
import {
  ValidationArguments,
  ValidatorConstraint,
  ValidatorConstraintInterface,
} from 'class-validator';
import {
  CandidateSearchDto,
  CandidateSearchOrbitParam,
} from '../models/dto/candidate/candidate-search.dto';
import { ImagingModeSingleSceneValues } from '@iris-lib/constants';

@ValidatorConstraint({
  name: 'validateCandidateSearchOrbitParamCombinations',
  async: true,
})
export class ValidateCandidateSearchOrbitParamCombinations
  implements ValidatorConstraintInterface
{
  private logger = new LoggerWrapper(
    ValidateCandidateSearchOrbitParamCombinations.name,
  );

  async validate(data: CandidateSearchOrbitParam, args: ValidationArguments) {
    const parent = args.object as CandidateSearchDto;
    if (ImagingModeSingleSceneValues.some((x) => x == data.imagingMode)) {
      return parent.scenes == 1 && parent.aois.length == 1;
    } else {
      return parent.scenes > 0 && parent.aois.length > 0;
    }
  }

  defaultMessage() {
    return 'There is a problem with the combination of search conditions.';
  }
}
