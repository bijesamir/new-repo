import {
  ValidatorConstraint,
  ValidatorConstraintInterface,
  ValidationArguments,
} from 'class-validator';
import { compareAsc } from 'date-fns';
import {
  OBCTIME_ZERO_POINT_DATE,
  obctime2Date,
} from '../common/business-specifications/obctime';

@ValidatorConstraint({ name: 'isObcTime', async: false })
export class IsObcTime implements ValidatorConstraintInterface {
  validate(a: number | Date) {
    if (a instanceof Date) {
      return compareAsc(a, OBCTIME_ZERO_POINT_DATE) > 0;
    } else {
      return compareAsc(obctime2Date(a), OBCTIME_ZERO_POINT_DATE) > 0;
    }
  }
  defaultMessage(args: ValidationArguments) {
    return `${args.property} is not obctime`;
  }
}
