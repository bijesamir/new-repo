import {
  ValidationArguments,
  ValidatorConstraint,
  ValidatorConstraintInterface,
} from 'class-validator';
import { ScsCandidateForViewDto } from '../models/dto/mission-portal/scs-candidate.dto';
import { LoggerWrapper } from '@iris-lib/logger';
import {
  AvailableTaskingTypeValues,
  TaskingType,
  TaskingTypeDetermination,
} from '@iris-lib/constants';

@ValidatorConstraint({ name: 'validateTaskingType', async: true })
export class ValidateTaskingType implements ValidatorConstraintInterface {
  private logger = new LoggerWrapper(ValidateTaskingType.name);

  async validate(taskingType: TaskingType, args: ValidationArguments) {
    const parent = args.object as ScsCandidateForViewDto;

    const determinedTaskingType = TaskingTypeDetermination.exec(
      parent.observationTiming.obsStartTimeUTC,
    );
    this.logger.debug('check', { taskingType, determinedTaskingType });
    return (
      taskingType == determinedTaskingType &&
      AvailableTaskingTypeValues.includes(taskingType)
    );
  }

  defaultMessage(args: ValidationArguments) {
    return `${args.property} is invalid`;
  }
}
