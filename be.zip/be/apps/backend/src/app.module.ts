import {
  ClassSerializerInterceptor,
  Inject,
  MiddlewareConsumer,
  Module,
  NestModule,
  OnModuleInit,
} from '@nestjs/common';
import { AppConfigService } from './config/app-config.service';
import { LoggerWrapper } from '@iris-lib/logger';
import { CacheManageService } from './infra/cache-manage/cache-manage.service';
import { LoggerMiddleware } from '@iris-lib/middlewares';
import { IrisRequestContextMiddleware } from '@iris-lib/middlewares';
import { CustomExceptionFilter } from '@iris-lib/filters';
import { APP_FILTER, APP_GUARD, APP_INTERCEPTOR } from '@nestjs/core';
import { DbOperationLogSubscriber } from '@iris-lib/db/subscribers';
import { AccessControlGuard } from './guards/access-control.guard';
import { CitadelGrpcModule, CitadelHttpModule } from '@iris-lib/citadel';
import { InternalModule } from './internal.module';
import { TaskingModule } from './public-tasking.module';
import { ArchiveModule } from './public-archive.module';
import { IrisAuthGuard } from './guards/iris-auth.guard';
import { DummyAuthGuard } from '@iris-lib/guards';

@Module({
  imports: [
    InternalModule,
    TaskingModule,
    ArchiveModule,
    CitadelGrpcModule,
    CitadelHttpModule,
  ],
  providers: [
    DbOperationLogSubscriber,
    IrisAuthGuard,
    { provide: APP_INTERCEPTOR, useClass: ClassSerializerInterceptor },
    {
      provide: APP_FILTER,
      useFactory: (config: AppConfigService) => {
        return new CustomExceptionFilter(config.get('app.loginPageUrl'));
      },
      inject: ['AppConfig'],
    },
    {
      provide: APP_GUARD,
      useFactory: (config: AppConfigService, guard: IrisAuthGuard) => {
        if (config.get('app.useDummyUser')) {
          return new DummyAuthGuard();
        } else {
          return guard;
        }
      },
      inject: ['AppConfig', IrisAuthGuard],
    },
    {
      provide: APP_GUARD,
      useClass: AccessControlGuard,
    },
  ],
})
export class AppModule implements NestModule, OnModuleInit {
  constructor(
    @Inject('AppConfig') private readonly config: AppConfigService,
    @Inject('CacheManager') private readonly cacheManager: CacheManageService,
  ) {}
  private logger = new LoggerWrapper(AppModule.name);
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(IrisRequestContextMiddleware, LoggerMiddleware)
      .forRoutes('*');
  }

  async onModuleInit() {
    await this.cacheManager.putSatellitesCache();
    this.logger.info('loaded');
  }
}
