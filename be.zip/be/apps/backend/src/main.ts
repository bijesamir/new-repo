// https://github.com/open-telemetry/opentelemetry-js/discussions/3503
import * as tracer from '@iris-lib/ops/tracing';
import { getNodeAutoInstrumentations } from '@opentelemetry/auto-instrumentations-node';
import { Span } from '@opentelemetry/api';
import { IORedisRequestHookInformation } from '@opentelemetry/instrumentation-ioredis';
import { envBooleanValue, envStringValue } from '@iris-lib/utils';

if (envBooleanValue('TRACING_ENABLED', false)) {
  const instrumentations = [
    getNodeAutoInstrumentations({
      '@opentelemetry/instrumentation-http': {
        ignoreIncomingRequestHook: (request) => {
          // ignores "/healthz", "/health" and "/"
          const expression = /^\/(healthz?)?$/;
          return new RegExp(expression).test(request.url);
        },
      },
      '@opentelemetry/instrumentation-grpc': {
        ignoreGrpcMethods: [new RegExp(/^streaming/, 'i')],
      },
      '@opentelemetry/instrumentation-ioredis': {
        requestHook: (
          span: Span,
          requestInfo: IORedisRequestHookInformation,
        ) => {
          span.updateName(`redis:${requestInfo.cmdName}`);
        },
      },
      '@opentelemetry/instrumentation-fs': {
        enabled: false,
      },
      '@opentelemetry/instrumentation-net': {
        enabled: false,
      },
      '@opentelemetry/instrumentation-dns': {
        enabled: false,
      },
    }),
  ];
  tracer.initTracing('iris-backend', instrumentations);
}

import { NestFactory } from '@nestjs/core';
import { NestExpressApplication } from '@nestjs/platform-express';
import { SwaggerModule } from '@nestjs/swagger';
import { AppModule } from './app.module';
import * as fs from 'node:fs/promises';
import * as YAML from 'yaml';
import { AppConfigService } from './config/app-config.service';
import {
  getDocumentBuilder,
  getDocumentBuilderArchive,
  getDocumentBuilderTasking,
} from './config/openapi-info';
import { decorateApp } from './boostrap-support';
import { NestApplicationOptions } from '@nestjs/common';
import { TaskingModule } from './public-tasking.module';
import { InternalModule } from './internal.module';
import { ArchiveModule } from './public-archive.module';

const bootstrap = async () => {
  let serverOptions: NestApplicationOptions;
  if (envBooleanValue('ENABLE_TLS', true)) {
    serverOptions = {
      httpsOptions: {
        key: await fs.readFile(envStringValue('BACKEND_TLS_KEY_PATH')),
        cert: await fs.readFile(envStringValue('BACKEND_TLS_CERT_PATH')),
        ca: [await fs.readFile(envStringValue('BACKEND_TLS_CA_PATH'))],
        requestCert: true,
        rejectUnauthorized: envBooleanValue(
          'BACKEND_TLS_REJECT_UNAUTHORIZED',
          true,
        ),
      },
    };
  }

  const app = await decorateApp(
    await NestFactory.create<NestExpressApplication>(AppModule, serverOptions),
  );
  const config = await app.get<AppConfigService>('AppConfig');

  if (config.get('env') === 'development') {
    const optionsTasking = getDocumentBuilderTasking();
    const documentTasking = SwaggerModule.createDocument(app, optionsTasking, {
      include: [TaskingModule],
      deepScanRoutes: true,
    });
    await fs.writeFile(
      './swagger-tasking.yaml',
      YAML.stringify(documentTasking, {}),
    );

    const optionsArchive = getDocumentBuilderArchive();
    const documentArchive = SwaggerModule.createDocument(app, optionsArchive, {
      include: [ArchiveModule],
      deepScanRoutes: true,
    });
    await fs.writeFile(
      './swagger-archive.yaml',
      YAML.stringify(documentArchive, {}),
    );

    const swaggerOption = getDocumentBuilder();
    const document = SwaggerModule.createDocument(app, swaggerOption, {
      include: [TaskingModule, ArchiveModule, InternalModule],
      deepScanRoutes: true,
    });
    await fs.writeFile('./swagger.yaml', YAML.stringify(document, {}));
    SwaggerModule.setup('swagger', app, document);
  }
  await app.listen(config.get('app.port'));
};
bootstrap();
