import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { generateApplicationConfig } from './app-config';
import { AppConfigService } from './app-config.service';

@Global()
@Module({
  imports: [
    ConfigModule.forRoot({
      // .envよみこまない
      ignoreEnvFile: true,
      // 設定ファイル指定
      load: [generateApplicationConfig],
    }),
  ],
  providers: [
    {
      provide: 'AppConfig',
      useClass: AppConfigService,
    },
  ],
  exports: ['AppConfig'],
})
export class AppConfigModule {}
