import { envStringValue, envBooleanValue, envIntValue } from '@iris-lib/utils';
import * as fs from 'fs';

export const generateApplicationConfig = () => {
  if (
    !process.env.DB_USER ||
    !process.env.DB_PASSWORD ||
    !process.env.DB_NAME ||
    !process.env.DB_PORT
  ) {
    console.error('environmental variable is missing!');
    process.exit();
  }

  return {
    env: envStringValue('NODE_ENV', 'development'),
    app: {
      doLoadCache: envBooleanValue('DO_CACHE_LOAD', true),
      useDummyUser: envBooleanValue('USE_DUMMY_USER', false),
      port: envIntValue('IRIS_PORT', 4000),
      skipAccessControlGuard: envBooleanValue(
        'SKIP_ACCESS_CONTROL_GUARD',
        false,
      ),
      loginPageUrl: `${envStringValue('IRIS_WEBPAGE_URL', 'NONE')}/login`,
      taskMgmtUrl: `${envStringValue('IRIS_WEBPAGE_URL', 'NONE')}/tasks`,
      archiveOrderUrl: `${envStringValue(
        'IRIS_WEBPAGE_URL',
        'NONE',
      )}/archive-order-review`,
      irisApiUrl: envStringValue('IRIS_API_URL', 'NONE'),
      cartTTL: envIntValue('CART_TTL', 30 * 24 * 60 * 60 * 1000), //30days
      cartItemMax: envIntValue('CART_ITEM_MAX', 100),
      taskingDownloadDays: envIntValue('TASKING_DOWNLOAD_DAYS', 365),
      archiveFreshDays: envIntValue('ARCHIVE_FRESH_DAYS', 30),
      archiveDownloadDays: envIntValue('ARCHIVE_DOWNLOAD_DAYS', 14),
      dataProcessingSoftwareVersion: envStringValue(
        'DATA_PROCESSING_SOFTWARE_VERSION',
        '0.14.1',
      ),
      productSoftwareVersion: envStringValue(
        'PRODUCT_SOFTWARE_VERSION',
        '012.000',
      ),
    },
    pubsub: {
      emulatorHost: process.env.PUBSUB_EMULATOR_HOST, // optional
      projectId: envStringValue('PUBSUB_PROJECT_ID', 'syns-daas-dev-local'),
      pscNotificationTopic: envStringValue('PUBSUB_PSC_NOTIFICATION_TOPIC'),
      pscNotificationSubscription: envStringValue(
        'PUBSUB_PSC_NOTIFICATION_SUBSCRIPTION',
      ),
    },
    cacheKey: {
      satellites: 'satellites',
      archiveCart: 'archiveCart',
    },
    redis: {
      disconnectTimeout: envIntValue('REDIS_DISCONNECT_TIMEOUT', 1000),
      host: envStringValue('REDIS_HOST', 'localhost'),
      port: envIntValue('REDIS_PORT', 63790),
      db: envIntValue('REDIS_BACKEND_DB', 1),
      password: envStringValue('REDIS_PASSWORD'),
      maxRetriesPerRequest: null,
      tls: {
        key:
          envStringValue('REDIS_SERVER_KEY_PATH', 'NO_NEED') == 'NO_NEED'
            ? null
            : fs.readFileSync(envStringValue('REDIS_SERVER_KEY_PATH')),
        ca: fs.readFileSync(envStringValue('REDIS_CA_CERT_PATH')),
        checkServerIdentity: () => undefined,
      },
    },
    gcs: {
      urlSigner: envStringValue('GCS_URL_SIGNER', 'none'),
    },
  };
};

export type AppConfig = ReturnType<typeof generateApplicationConfig>;
