import { DocumentBuilder } from '@nestjs/swagger';

export const getDocumentBuilder = () => {
  return new DocumentBuilder()
    .setTitle('iris backend api')
    .setVersion('0.1')
    .setDescription('iris backend api')
    .addServer(`http://${process.env.BACKEND_HTTP_HOST}`)
    .build();
};

export const getDocumentBuilderTasking = () => {
  return new DocumentBuilder()
    .setTitle('synspective tasking api')
    .setDescription('API for synspective tasking service')
    .setVersion('0.5')
    .build();
};

export const getDocumentBuilderArchive = () => {
  return new DocumentBuilder()
    .setTitle('synspective archive api')
    .setDescription('API for synspective archive service')
    .setVersion('0.5')
    .build();
};
