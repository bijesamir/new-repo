import {
  ArgumentMetadata,
  BadRequestException,
  Injectable,
  PipeTransform,
} from '@nestjs/common';
import { OrganizationIdQueryDto } from '../models/dto/organization-id-query.dto';

import { plainToInstance } from 'class-transformer';
import { validate } from 'class-validator';
import { IsAffiliationOrganization } from '@iris-lib/validators';

/**
 * pipe to check organizationId.
 */
@Injectable()
export class OrganizationIdPipe
  implements PipeTransform<any, Promise<OrganizationIdQueryDto>>
{
  validator = new IsAffiliationOrganization();
  async transform(
    value: any,
    { metatype }: ArgumentMetadata,
  ): Promise<OrganizationIdQueryDto> {
    const result =
      typeof value === 'string'
        ? plainToInstance(metatype, { organizationId: value })
        : value;
    const errors = await validate(result);
    if (errors.length > 0) {
      throw new BadRequestException(errors);
    }
    return result;
  }
}
