import { BadRequestException, Injectable, PipeTransform } from '@nestjs/common';
import { plainToInstance } from 'class-transformer';
import { validate } from 'class-validator';
import { PaginateQuery } from 'nestjs-paginate';

interface ClassConstructor {
  new (...args: any[]);
}

@Injectable()
export class PaginateQueryValidationPipe
  implements PipeTransform<PaginateQuery, Promise<PaginateQuery>>
{
  constructor(private classConstructor: ClassConstructor) {}

  async transform(value: PaginateQuery) {
    if (value.filter) {
      const result = plainToInstance(this.classConstructor, value.filter);
      const errors = await validate(result);
      if (errors.length > 0) {
        throw new BadRequestException(errors);
      }
    }
    return value;
  }
}
