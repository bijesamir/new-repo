import { PipeTransform, Injectable, BadRequestException } from '@nestjs/common';
import { matches } from 'class-validator';

@Injectable()
export class OrderCodePipe implements PipeTransform {
  transform(value: any) {
    if (typeof value === 'string' && matches(value, /^\d{6}-\d{5}$/)) {
      return value;
    } else {
      throw new BadRequestException('Invalid order code');
    }
  }
}
