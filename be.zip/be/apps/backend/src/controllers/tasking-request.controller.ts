import {
  Body,
  Controller,
  Delete,
  Get,
  Logger,
  Param,
  ParseUUIDPipe,
  Post,
  Query,
} from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiBody,
  ApiCreatedResponse,
  ApiInternalServerErrorResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiParam,
  ApiQuery,
  ApiTags,
} from '@nestjs/swagger';
import { CurrentUser } from '../decorators/current-user.decorator';
import { ErrorResponse } from '@iris-lib/filters';
import { IrisUserDto } from '@iris-lib/models';
import { TaskingRequest } from '@iris-lib/db/entities';
import { TaskingRequestCreateDto } from '../models/dto/tasking-request/tasking-request-create.dto';
import { OrganizationIdQueryDto } from '../models/dto/organization-id-query.dto';
import { OrganizationIdPipe } from '../pipes/organization-id.pipe';
import { Paginate, PaginateQuery } from 'nestjs-paginate';
import { PaginateQueryOptions } from '../helper/paginateHelper';
import { TaskingRequestUsecaseService } from '../usecases/tasking-request-usecase/tasking-request-usecase.service';
import { IrisAccessControlType } from '@iris-lib/constants/iris-access-control-type';
import { AccessControl } from '../decorators/access-control.decorator';
import {
  TaskingRequestDto,
  TaskingRequestWithAoisDto,
} from '../models/dto/tasking-request/tasking-request.dto';

@ApiTags('tasking-request')
@AccessControl(
  IrisAccessControlType.Admin,
  IrisAccessControlType.Internal,
  IrisAccessControlType.Tasking,
)
@Controller('tasking-request')
export class TaskingRequestController {
  private readonly logger = new Logger(TaskingRequestController.name);

  constructor(private readonly usecase: TaskingRequestUsecaseService) {}

  /**
   * It seems that there is no operation to create only TaskingRequest,
   * so I feel that it is okay to delete it. This will reduce the number of tests.
   * At the beginning of development, the processing flow was too complicated
   * and too long, so I took it apart and implemented it little by little, and left it
   * assuming that it would be used individually in the future.
   */
  @ApiOperation({
    summary: 'Register tasking-request',
    deprecated: true,
  })
  @ApiBody({ type: TaskingRequestCreateDto })
  @ApiCreatedResponse({ type: TaskingRequestWithAoisDto })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Post('')
  async create(
    @CurrentUser() user: IrisUserDto,
    @Body() createDto: TaskingRequestCreateDto,
  ): Promise<TaskingRequest> {
    return await this.usecase.create(user, createDto);
  }

  @ApiOperation({ summary: 'List tasking-requests' })
  @PaginateQueryOptions(TaskingRequestDto, 'id', 'createdAt', 'updatedAt')
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @AccessControl(
    IrisAccessControlType.Admin,
    IrisAccessControlType.Internal,
    IrisAccessControlType.Collaborator,
    IrisAccessControlType.Tasking,
  )
  @Get('/search')
  async getMany(
    @CurrentUser() user: IrisUserDto,
    @Paginate() query: PaginateQuery,
  ) {
    return await this.usecase.search(user, query);
  }

  @ApiOperation({ summary: 'Get tasking-request' })
  @ApiParam({
    name: 'id',
    type: 'string',
    description: 'tasking-request id',
  })
  @ApiQuery({
    name: 'organizationId',
    type: 'string',
    description: 'organization id',
    required: false,
  })
  @ApiOkResponse({ type: TaskingRequestDto })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @AccessControl(
    IrisAccessControlType.Admin,
    IrisAccessControlType.Internal,
    IrisAccessControlType.Collaborator,
    IrisAccessControlType.Tasking,
  )
  @Get('/:id')
  async getOne(
    @CurrentUser() user: IrisUserDto,
    @Param('id', ParseUUIDPipe) taskingRequestId: string,
    @Query('organizationId', OrganizationIdPipe)
    organizationId: OrganizationIdQueryDto,
  ) {
    return await this.usecase.getOne(user, taskingRequestId, organizationId);
  }

  @ApiOperation({ summary: 'Delete tasking-request', deprecated: true })
  @ApiParam({
    name: 'id',
    type: 'string',
    description: 'tasking-request id',
  })
  @ApiOkResponse({ type: TaskingRequestDto })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Delete('/:id')
  async delete(
    @CurrentUser() user: IrisUserDto,
    @Param('id', ParseUUIDPipe) taskingRequestId: string,
  ) {
    return await this.usecase.remove(user, taskingRequestId);
  }
}
