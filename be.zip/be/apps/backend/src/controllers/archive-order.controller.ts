import {
  Body,
  Controller,
  Get,
  HttpCode,
  Param,
  ParseUUIDPipe,
  Post,
} from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiBody,
  ApiCreatedResponse,
  ApiInternalServerErrorResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiParam,
  ApiTags,
} from '@nestjs/swagger';
import { AccessControl } from '../decorators/access-control.decorator';
import { IrisAccessControlType } from '@iris-lib/constants/iris-access-control-type';
import { LoggerWrapper } from '@iris-lib/logger';
import { ArchivePurchaseRequestUsecaseService } from '../usecases/archive-purchase-request/archive-purchase-request-usecase.service';
import { OrderCreateProductTypeDto } from '../models/dto/order/order-create.dto';
import {
  OrderDto,
  OrderSearchDto,
  OrdersDto,
} from '../models/dto/order/order.dto';
import { ErrorResponse } from '@iris-lib/filters';
import { CurrentUser } from '../decorators/current-user.decorator';
import { IrisUserDto } from '@iris-lib/models';
import { Serialize } from '@iris-lib/interceptors';
import { Contracts } from '../decorators/contracts.decorator';
import { IrisContractPackage, PaymentsDto } from '@iris-lib/models/payment';

@ApiTags('order')
@AccessControl(
  IrisAccessControlType.Admin,
  IrisAccessControlType.Internal,
  IrisAccessControlType.Archive,
)
@Controller('order')
export class ArchiveOrderController {
  private readonly logger = new LoggerWrapper(ArchiveOrderController.name);
  constructor(private readonly service: ArchivePurchaseRequestUsecaseService) {}

  @ApiOperation({ summary: 'Register order' })
  @ApiBody({ type: OrderCreateProductTypeDto })
  @ApiCreatedResponse({ type: OrderDto })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Serialize(OrderDto)
  @Post('')
  async create(
    @CurrentUser() user: IrisUserDto,
    @Contracts() contracts: IrisContractPackage[],
    @Body() createDto: OrderCreateProductTypeDto,
  ): Promise<OrderDto> {
    return await this.service.create(user, contracts, createDto);
  }

  @ApiOperation({ summary: 'Search orders' })
  @ApiOkResponse({ type: OrdersDto, status: 200 })
  @HttpCode(200)
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Post('/search')
  async getManySearch(
    @CurrentUser() user: IrisUserDto,
    @Body() query: OrderSearchDto,
  ): Promise<OrdersDto> {
    return await this.service.getMany(user, query);
  }

  @ApiOperation({ summary: 'Get order' })
  @ApiParam({
    name: 'id',
    type: 'string',
    description: 'archive-order id',
  })
  @ApiOkResponse({ type: OrderDto })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Get('/:id')
  async getOne(
    @CurrentUser() user: IrisUserDto,
    @Param('id', ParseUUIDPipe) orderId: string,
  ): Promise<OrderDto> {
    return await this.service.getOne(user, orderId);
  }

  @ApiOperation({ summary: 'review order' })
  @ApiBody({ type: OrderCreateProductTypeDto })
  @ApiOkResponse({ type: PaymentsDto, status: 200 })
  @HttpCode(200)
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Serialize(PaymentsDto)
  @Post('review')
  async review(
    @Contracts() contracts: IrisContractPackage[],
    @Body() createDto: OrderCreateProductTypeDto,
  ) {
    return await this.service.review(contracts, createDto);
  }
}
