import { Controller, Get, Inject } from '@nestjs/common';
import {
  ApiOperation,
  ApiInternalServerErrorResponse,
  ApiTags,
  ApiOkResponse,
} from '@nestjs/swagger';
import { ErrorResponse } from '@iris-lib/filters';
import { CacheManageService } from '../infra/cache-manage/cache-manage.service';
import { IrisAccessControlType } from '@iris-lib/constants/iris-access-control-type';
import { AccessControl } from '../decorators/access-control.decorator';
import { IrisUserDto } from '@iris-lib/models';
import { CurrentUser } from '../decorators/current-user.decorator';
import { SatelliteForViewDto } from '../models/dto/satellite/satellite.dto';
import { Serialize } from '@iris-lib/interceptors';

/**
 * API for referencing master data such as satellite information
 * The data is cached in the application's memory, but if it is the current usage, it is not particularly effective.
 */
@ApiTags('master')
@AccessControl(
  IrisAccessControlType.Admin,
  IrisAccessControlType.Internal,
  IrisAccessControlType.Tasking,
  IrisAccessControlType.Archive,
)
@Controller('master')
export class MasterController {
  constructor(
    @Inject('CacheManager') private readonly cacheManager: CacheManageService,
  ) {}

  @ApiOperation({ summary: 'Get satellites' })
  @ApiOkResponse({ type: [SatelliteForViewDto] })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Serialize(SatelliteForViewDto)
  @Get('satellites')
  async satellites(@CurrentUser() user: IrisUserDto) {
    return this.cacheManager.getSatellitesByRoleType(user, false);
  }
}
