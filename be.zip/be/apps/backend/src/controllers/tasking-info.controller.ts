import {
  Body,
  Controller,
  Delete,
  Get,
  Logger,
  Param,
  ParseUUIDPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiBody,
  ApiCreatedResponse,
  ApiInternalServerErrorResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiParam,
  ApiQuery,
  ApiTags,
} from '@nestjs/swagger';
import { CurrentUser } from '../decorators/current-user.decorator';
import { ErrorResponse } from '@iris-lib/filters';
import { TaskingInfoCreateDto } from '../models/dto/tasking-info/tasking-info-create.dto';
import { IrisUserDto } from '@iris-lib/models';
import { TaskingInfo } from '@iris-lib/db/entities';
import { TaskingInfoUpdateStatusDto } from '../models/dto/tasking-info/tasking-info-update-status.dto';
import { Paginate, PaginateQuery } from 'nestjs-paginate';
import { PaginateQueryOptions } from '../helper/paginateHelper';
import { OrganizationIdQueryDto } from '../models/dto/organization-id-query.dto';
import { OrganizationIdPipe } from '../pipes/organization-id.pipe';
import { TaskingInfoUsecaseService } from '../usecases/tasking-info-usecase/tasking-info-usecase.service';
import { TaskingInfoUpdateAltitudeDto } from '../models/dto/tasking-info/tasking-info-update-altitude.dto';
import { IrisAccessControlType } from '@iris-lib/constants/iris-access-control-type';
import { AccessControl } from '../decorators/access-control.decorator';
import {
  TaskingInfoDto,
  TaskingInfoWithTaskingRequestDto,
} from '../models/dto/tasking-info/tasking-info.dto';
import { IrisContractPackage } from '@iris-lib/models/payment';
import { Contracts } from '../decorators/contracts.decorator';

@ApiTags('tasking-info')
@AccessControl(
  IrisAccessControlType.Admin,
  IrisAccessControlType.Internal,
  IrisAccessControlType.Tasking,
)
@Controller('tasking-info')
export class TaskingInfoController {
  private readonly logger = new Logger(TaskingInfoController.name);

  constructor(private readonly usecase: TaskingInfoUsecaseService) {}

  /**
   * It seems that there is no operation to create only TaskingInfo,
   * so I feel that it is okay to delete it. This will reduce the number of tests.
   * At the beginning of development, the processing flow was too complicated
   * and too long, so I took it apart and implemented it little by little, and left it
   * assuming that it would be used individually in the future.
   */
  @ApiOperation({
    summary: 'Register tasking-info',
    deprecated: true,
  })
  @ApiBody({ type: TaskingInfoCreateDto })
  @ApiCreatedResponse({ type: [TaskingInfoDto] })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Post('')
  async create(
    @CurrentUser() user: IrisUserDto,
    @Contracts() contracts: IrisContractPackage[],
    @Body() createDto: TaskingInfoCreateDto,
  ): Promise<TaskingInfo[]> {
    return await this.usecase.create(user, contracts, createDto);
  }

  @ApiOperation({ summary: 'Update tasking-info altitude' })
  @ApiBody({ type: TaskingInfoUpdateAltitudeDto })
  @ApiOkResponse({ type: TaskingInfoDto })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Put('/update-altitude')
  async updateAltitude(
    @CurrentUser() user: IrisUserDto,
    @Body() updateDto: TaskingInfoUpdateAltitudeDto,
  ): Promise<TaskingInfo> {
    return await this.usecase.updateAltitude(user, updateDto);
  }

  @ApiOperation({ summary: 'Update tasking-info status' })
  @ApiBody({ type: TaskingInfoUpdateStatusDto })
  @ApiOkResponse({ type: [TaskingInfoDto] })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @AccessControl(
    IrisAccessControlType.Admin,
    IrisAccessControlType.Internal,
    IrisAccessControlType.Collaborator,
    IrisAccessControlType.Tasking,
  )
  @Put('/update-status')
  async updateStatus(
    @CurrentUser() user: IrisUserDto,
    @Body() updateDto: TaskingInfoUpdateStatusDto,
  ): Promise<TaskingInfoDto[]> {
    return await this.usecase.updateStatus(user, updateDto);
  }

  @ApiOperation({ summary: 'List tasking-info' })
  @PaginateQueryOptions(
    TaskingInfoWithTaskingRequestDto,
    'name',
    'organizationId',
    'status',
    'createdAt',
    'updatedAt',
    'observationStart',
    'observationEnd',
    'scsOrderId',
    'scsOrderCode',
    'satId',
    'imagingMode',
    'taskingType',
    'flightDirection',
    'lookingDirection',
    'offnadirAngle',
    'scenes',
    'organizationId',
    'contractId',
    'taskingSummary.summaryUpdatedAt',
    'taskingSummary.summaryStatus',
  )
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @AccessControl(
    IrisAccessControlType.Admin,
    IrisAccessControlType.Internal,
    IrisAccessControlType.Collaborator,
    IrisAccessControlType.Tasking,
  )
  @Get('/search')
  async getMany(
    @CurrentUser() user: IrisUserDto,
    @Paginate() query: PaginateQuery,
  ) {
    return await this.usecase.search(user, query);
  }

  @ApiOperation({ summary: 'Get tasking-info' })
  @ApiParam({
    name: 'id',
    type: 'string',
    description: 'tasking-info id',
  })
  @ApiQuery({
    name: 'organizationId',
    type: 'string',
    description: 'organization id',
    required: false,
  })
  @ApiOkResponse({ type: TaskingInfoWithTaskingRequestDto })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @AccessControl(
    IrisAccessControlType.Admin,
    IrisAccessControlType.Internal,
    IrisAccessControlType.Collaborator,
    IrisAccessControlType.Tasking,
  )
  @Get('/:id')
  async getOne(
    @CurrentUser() user: IrisUserDto,
    @Param('id', ParseUUIDPipe) taskingInfoId: string,
    @Query('organizationId', OrganizationIdPipe)
    organizationId: OrganizationIdQueryDto,
  ) {
    return await this.usecase.getOne(user, taskingInfoId, organizationId);
  }

  @ApiOperation({ summary: 'Delete tasking-info', deprecated: true })
  @ApiParam({
    name: 'id',
    type: 'string',
    description: 'tasking-info id',
  })
  @ApiOkResponse({ type: TaskingInfoDto })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Delete('/:id')
  async delete(
    @CurrentUser() user: IrisUserDto,
    @Param('id', ParseUUIDPipe) taskingInfoId: string,
  ) {
    return this.usecase.remove(user, taskingInfoId);
  }
}
