import { IrisAccessControlType } from '@iris-lib/constants/iris-access-control-type';
import { ErrorResponse } from '@iris-lib/filters';
import { LoggerWrapper } from '@iris-lib/logger';
import { IrisUserDto } from '@iris-lib/models';
import {
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  ParseUUIDPipe,
  Query,
  Req,
  Res,
} from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiFoundResponse,
  ApiInternalServerErrorResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiParam,
  ApiProduces,
  ApiQuery,
  ApiTags,
} from '@nestjs/swagger';
import { Response } from 'express';
import { AccessControl } from '../decorators/access-control.decorator';
import { CurrentUser } from '../decorators/current-user.decorator';
import { OrganizationIdQueryDto } from '../models/dto/organization-id-query.dto';
import {
  ProductDataVersionDto,
  ProductDataVersionExpandedDto,
} from '../models/dto/product-data-version/product-data-version.dto';
import { OrganizationIdPipe } from '../pipes/organization-id.pipe';
import { ProductDataVersionUsecaseService } from '../usecases/product-data-version/product-data-version-usecase.service';
import { IrisRequest } from '@iris-lib/middlewares';

@ApiTags('product-data-version')
@AccessControl(
  IrisAccessControlType.Admin,
  IrisAccessControlType.Internal,
  IrisAccessControlType.Collaborator,
  IrisAccessControlType.Tasking,
  IrisAccessControlType.Archive,
)
@Controller('product-data-version')
export class ProductDataVersionController {
  private readonly logger = new LoggerWrapper(
    ProductDataVersionController.name,
  );

  constructor(
    private readonly productDataVersionUsecaseService: ProductDataVersionUsecaseService,
  ) {}

  @ApiOperation({ summary: 'Get product-data-version expanded' })
  @ApiParam({
    name: 'id',
    type: 'string',
    description: 'product-data-version id',
  })
  @ApiQuery({
    name: 'organizationId',
    type: 'string',
    description: 'organization id',
    required: false,
  })
  @ApiOkResponse({ type: ProductDataVersionExpandedDto })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Get('/:id')
  async getOne(
    @CurrentUser() user: IrisUserDto,
    @Param('id', ParseUUIDPipe) productDataVersionId: string,
    @Query('organizationId', OrganizationIdPipe)
    organizationId: OrganizationIdQueryDto,
  ) {
    return await this.productDataVersionUsecaseService.get(
      user,
      productDataVersionId,
      organizationId,
    );
  }

  @ApiOperation({ summary: 'Download product data' })
  @ApiParam({
    name: 'id',
    type: 'string',
    description: 'product-data-version id',
  })
  @ApiQuery({
    name: 'organizationId',
    type: 'string',
    description: 'organization id',
    required: false,
  })
  @ApiOkResponse({
    schema: {
      type: 'string',
      format: 'binary',
    },
  })
  @ApiFoundResponse()
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @AccessControl(
    IrisAccessControlType.Admin,
    IrisAccessControlType.TaskingDownload,
    IrisAccessControlType.Archive,
  )
  @HttpCode(HttpStatus.FOUND) // Overwrite 200
  @Get('/:id/download')
  async download(
    @Param('id', ParseUUIDPipe) productDataVersionId: string,
    @Query('organizationId', OrganizationIdPipe)
    organizationId: OrganizationIdQueryDto,
    @Res() res: Response,
    @Req() req: IrisRequest,
  ) {
    const signedUrl =
      await this.productDataVersionUsecaseService.handleDownload(
        req.currentUser,
        productDataVersionId,
        organizationId,
        req,
      );
    res.redirect(signedUrl);
  }

  @ApiOperation({ summary: 'Get quicklook image' })
  @ApiParam({
    name: 'id',
    type: 'string',
    description: 'product-data-version id',
  })
  @ApiQuery({
    name: 'organizationId',
    type: 'string',
    description: 'organization id',
    required: false,
  })
  @ApiOkResponse({
    schema: {
      type: 'string',
      format: 'binary',
    },
  })
  @ApiProduces('application/json', 'image/png', 'image/jpeg', 'image/jpg')
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Get('/:id/quicklook')
  async getQuicklook(
    @CurrentUser() user: IrisUserDto,
    @Param('id', ParseUUIDPipe) productDataVersionId: string,
    @Query('organizationId', OrganizationIdPipe)
    organizationId: OrganizationIdQueryDto,
    @Res({ passthrough: true }) res: Response,
  ) {
    const [contentType, file] =
      await this.productDataVersionUsecaseService.downloadQuicklook(
        user,
        productDataVersionId,
        organizationId,
      );
    res.setHeader('Content-Type', contentType);
    res.setHeader('Cross-Origin-Resource-Policy', 'same-site');
    return file;
  }

  @ApiOperation({ summary: 'Delete product-data-version' })
  @ApiParam({
    name: 'id',
    type: 'string',
    description: 'product-data-version id',
  })
  @ApiOkResponse({ type: ProductDataVersionDto })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @AccessControl(IrisAccessControlType.Admin)
  @Delete('/:id')
  async delete(
    @CurrentUser() user: IrisUserDto,
    @Param('id', ParseUUIDPipe) id: string,
  ) {
    return await this.productDataVersionUsecaseService.remove(user, id);
  }
}
