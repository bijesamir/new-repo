import { LoggerWrapper } from '@iris-lib/logger';
import { Body, Controller, Post } from '@nestjs/common';
import { DeliveryRequestUsecaseService } from '../usecases/delivery-request/delivery-request-usecase.service';
import {
  ApiBadRequestResponse,
  ApiBody,
  ApiCreatedResponse,
  ApiInternalServerErrorResponse,
  ApiNotFoundResponse,
  ApiOperation,
  ApiTags,
} from '@nestjs/swagger';
import { AccessControl } from '../decorators/access-control.decorator';
import { IrisAccessControlType } from '@iris-lib/constants/iris-access-control-type';
import { CurrentUser } from '../decorators/current-user.decorator';
import { IrisUserDto } from '@iris-lib/models';
import { ErrorResponse } from '@iris-lib/filters';
import { DeliveryRequestCreateDto } from '../models/dto/delivery-request/delivery-request-register.dto';
import { DeliveryRequest } from '@iris-lib/db/entities';
import { DeliveryRequestDto } from '../models/dto/delivery-request/delivery-request.dto';
import { Serialize } from '@iris-lib/interceptors';

@ApiTags('delivery-request')
@AccessControl(
  IrisAccessControlType.Admin,
  IrisAccessControlType.Internal,
  IrisAccessControlType.Collaborator,
  IrisAccessControlType.Tasking,
  IrisAccessControlType.Archive,
)
@Controller('delivery-request')
export class DeliveryRequestController {
  private readonly logger = new LoggerWrapper(DeliveryRequestController.name);

  constructor(
    private readonly deliveryRequestUsecaseService: DeliveryRequestUsecaseService,
  ) {}

  @ApiOperation({ summary: 'Register delivery-requests' })
  @ApiBody({ type: DeliveryRequestCreateDto })
  @ApiCreatedResponse({ type: DeliveryRequestDto })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @AccessControl(IrisAccessControlType.Admin, IrisAccessControlType.Internal)
  @Serialize(DeliveryRequestDto)
  @Post('')
  async create(
    @CurrentUser() user: IrisUserDto,
    @Body() createDto: DeliveryRequestCreateDto,
  ): Promise<DeliveryRequest[]> {
    return await this.deliveryRequestUsecaseService.createMany(user, createDto);
  }
}
