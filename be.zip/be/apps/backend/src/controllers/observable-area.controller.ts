import { Body, Controller, HttpCode, HttpStatus, Post } from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiBody,
  ApiInternalServerErrorResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
} from '@nestjs/swagger';
import { ObservableAreaService } from '../usecases/observable-area/observable-area.service';
import { ObservableAreaSearchDto } from '../models/dto/observable-area/observable-area-search.dto';
import { ErrorResponse } from '@iris-lib/filters';
import { AccessControl } from '../decorators/access-control.decorator';
import { IrisAccessControlType } from '@iris-lib/constants/iris-access-control-type';
import { ObservableAreaDto } from '../models/dto/observable-area/observable-area.dto';

@ApiTags('observable-area')
@AccessControl(
  IrisAccessControlType.Admin,
  IrisAccessControlType.Internal,
  IrisAccessControlType.Tasking,
)
@Controller('observable-area')
export class ObservableAreaController {
  constructor(readonly usecase: ObservableAreaService) {}

  @ApiOperation({
    summary:
      'Search for observable areas of satellites within the specified area',
  })
  @ApiBody({ type: ObservableAreaSearchDto })
  @ApiOkResponse({ type: [ObservableAreaDto] })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @HttpCode(HttpStatus.OK) // Overwrite 201
  @Post('/search')
  async search(@Body() dto: ObservableAreaSearchDto) {
    return await this.usecase.search(dto);
  }
}
