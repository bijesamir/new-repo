import { ErrorResponse } from '@iris-lib/filters';
import { Body, Controller, Get, Put } from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiBody,
  ApiInternalServerErrorResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
} from '@nestjs/swagger';
import { CurrentUser } from '../decorators/current-user.decorator';
import { IrisUserDto } from '@iris-lib/models';
import { Paginate, PaginateQuery } from 'nestjs-paginate';
import { ReprocessingRequestUsecaseService } from '../usecases/reprocessing-request/reprocessing-request-usecase.service';
import { PaginateQueryOptions } from '../helper/paginateHelper';
import { ReprocessingRequestDto } from '../models/dto/reprocessing-request/reprocessing-request.dto';
import { AccessControl } from '../decorators/access-control.decorator';
import { IrisAccessControlType } from '@iris-lib/constants/iris-access-control-type';
import { Serialize } from '@iris-lib/interceptors';
import { ReprocessingRequestUpdateStatusDto } from '../models/dto/reprocessing-request/reprocessing-reques-update-status.dto';
import { ReprocessingRequestUpdateStatusResDto } from '../models/dto/reprocessing-request/reprocessing-request-update-status-res.dto';

@ApiTags('reprocessing')
@AccessControl(
  IrisAccessControlType.Admin,
  IrisAccessControlType.Internal,
  IrisAccessControlType.Collaborator,
)
@Controller('reprocessing')
export class ReprocessingRequestController {
  constructor(
    private readonly reprocessingRequestUsecaseService: ReprocessingRequestUsecaseService,
  ) {}

  @ApiOperation({ summary: 'List reprocessing requests' })
  @PaginateQueryOptions(
    ReprocessingRequestDto,
    'status',
    'createdAt',
    'updatedAt',
    'dueDate',
  )
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Get('')
  async getMany(
    @CurrentUser() user: IrisUserDto,
    @Paginate() query: PaginateQuery,
  ) {
    return await this.reprocessingRequestUsecaseService.searchWithQuery(
      user,
      query,
    );
  }

  @ApiOperation({ summary: 'Update status' })
  @ApiBody({ type: ReprocessingRequestUpdateStatusDto })
  @ApiOkResponse({ type: [ReprocessingRequestUpdateStatusResDto] })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @AccessControl(IrisAccessControlType.Admin, IrisAccessControlType.Internal)
  @Put('/update-status')
  @Serialize(ReprocessingRequestUpdateStatusResDto)
  async updateStatus(
    @CurrentUser() user: IrisUserDto,
    @Body() updateStatusDto: ReprocessingRequestUpdateStatusDto,
  ) {
    return await this.reprocessingRequestUsecaseService.updateStatus(
      user,
      updateStatusDto,
    );
  }
}
