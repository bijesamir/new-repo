import { Body, Controller, Post } from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiBody,
  ApiCreatedResponse,
  ApiInternalServerErrorResponse,
  ApiOperation,
  ApiTags,
} from '@nestjs/swagger';
import {
  TaskingBundleCreateDto,
  UrgentTaskingBundleCreateDto,
} from '../models/dto/tasking-bundle/tasking-bundle-create.dto';
import { ErrorResponse } from '@iris-lib/filters';
import { IrisUserDto } from '@iris-lib/models';
import { CurrentUser } from '../decorators/current-user.decorator';
import { TaskingBundleUsecaseService } from '../usecases/tasking-bundle-usecase/tasking-bundle-usecase.service';
import { IrisAccessControlType } from '@iris-lib/constants/iris-access-control-type';
import { AccessControl } from '../decorators/access-control.decorator';
import { TaskingInfoDto } from '../models/dto/tasking-info/tasking-info.dto';
import { IrisContractPackage } from '@iris-lib/models/payment';
import { Contracts } from '../decorators/contracts.decorator';

@ApiTags('tasking-bundle')
@AccessControl(
  IrisAccessControlType.Admin,
  IrisAccessControlType.Internal,
  IrisAccessControlType.Tasking,
)
@Controller('tasking-bundle')
export class TaskingBundleController {
  constructor(private readonly usecase: TaskingBundleUsecaseService) {}

  @ApiOperation({ summary: 'Register tasking-request and tasking-info' })
  @ApiBody({ type: TaskingBundleCreateDto })
  @ApiCreatedResponse({ type: [TaskingInfoDto] })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Post()
  async create(
    @CurrentUser() user: IrisUserDto,
    @Contracts() contracts: IrisContractPackage[],
    @Body() createDto: TaskingBundleCreateDto,
  ) {
    return await this.usecase.create(user, contracts, createDto);
  }

  @ApiOperation({
    summary: 'Register tasking-request and tasking-info for urgent tasking',
  })
  @ApiBody({ type: UrgentTaskingBundleCreateDto })
  @ApiCreatedResponse({ type: [TaskingInfoDto] })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Post('/urgent')
  async createUrgent(
    @CurrentUser() user: IrisUserDto,
    @Contracts() contracts: IrisContractPackage[],
    @Body() createDto: TaskingBundleCreateDto,
  ) {
    return await this.usecase.createUrgent(user, contracts, createDto);
  }
}
