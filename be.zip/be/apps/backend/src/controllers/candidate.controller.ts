import { Body, Controller, HttpCode, HttpStatus, Post } from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiBody,
  ApiInternalServerErrorResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
} from '@nestjs/swagger';
import {
  CandidateSearchDto,
  UrgentCandidateSearchDto,
} from '../models/dto/candidate/candidate-search.dto';
import { ErrorResponse } from '@iris-lib/filters';
import { CurrentUser } from '../decorators/current-user.decorator';
import { IrisUserDto } from '@iris-lib/models';
import { CandidateUsecaseService } from '../usecases/candidate-usecase/candidate-usecase.service';
import { ScsCandidateForViewDto } from '../models/dto/mission-portal/scs-candidate.dto';
import { IrisAccessControlType } from '@iris-lib/constants/iris-access-control-type';
import { AccessControl } from '../decorators/access-control.decorator';

@ApiTags('candidate')
@AccessControl(
  IrisAccessControlType.Admin,
  IrisAccessControlType.Internal,
  IrisAccessControlType.Tasking,
)
@Controller('candidate')
export class CandidateController {
  constructor(readonly service: CandidateUsecaseService) {}

  @ApiOperation({ summary: 'Search tasking candidates' })
  @ApiBody({ type: CandidateSearchDto })
  @ApiOkResponse({ type: [ScsCandidateForViewDto] })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @HttpCode(HttpStatus.OK) // Overwrite 201
  @Post('/search')
  async search(
    @CurrentUser() user: IrisUserDto,
    @Body() param: CandidateSearchDto,
  ) {
    return await this.service.search(user, param);
  }

  @ApiOperation({ summary: 'Search urgent tasking candidates' })
  @ApiBody({ type: UrgentCandidateSearchDto })
  @ApiOkResponse({ type: [ScsCandidateForViewDto] })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @HttpCode(HttpStatus.OK) // Overwrite 201
  @Post('search/urgent')
  async searchUrgent(
    @CurrentUser() user: IrisUserDto,
    @Body() param: UrgentCandidateSearchDto,
  ) {
    return await this.service.searchUrgent(user, param);
  }
}
