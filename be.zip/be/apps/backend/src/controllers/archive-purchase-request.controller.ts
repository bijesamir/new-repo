import {
  Body,
  Controller,
  Get,
  HttpCode,
  Param,
  ParseUUIDPipe,
  Post,
  Query,
} from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiBody,
  ApiCreatedResponse,
  ApiInternalServerErrorResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiParam,
  ApiQuery,
  ApiTags,
} from '@nestjs/swagger';
import { AccessControl } from '../decorators/access-control.decorator';
import { IrisAccessControlType } from '@iris-lib/constants/iris-access-control-type';
import { LoggerWrapper } from '@iris-lib/logger';
import { ArchivePurchaseRequestUsecaseService } from '../usecases/archive-purchase-request/archive-purchase-request-usecase.service';
import { OrderCreateDto } from '../models/dto/order/order-create.dto';
import {
  OrderDto,
  OrderSearchDto,
  OrderStacSearchDto,
  OrdersDto,
} from '../models/dto/order/order.dto';
import { ErrorResponse } from '@iris-lib/filters';
import { CurrentUser } from '../decorators/current-user.decorator';
import { IrisUserDto } from '@iris-lib/models';
import { Serialize } from '@iris-lib/interceptors';
import { Contracts } from '../decorators/contracts.decorator';
import { IrisContractPackage, PaymentsDto } from '@iris-lib/models/payment';

@ApiTags('orders')
@AccessControl(
  IrisAccessControlType.Admin,
  IrisAccessControlType.Internal,
  IrisAccessControlType.Archive,
)
@Controller('orders')
export class ArchivePurchaseRequestController {
  private readonly logger = new LoggerWrapper(
    ArchivePurchaseRequestController.name,
  );
  constructor(private readonly service: ArchivePurchaseRequestUsecaseService) {}

  @ApiOperation({ summary: 'Register order', deprecated: true })
  @ApiBody({ type: OrderCreateDto })
  @ApiCreatedResponse({ type: OrderDto })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Serialize(OrderDto)
  @Post('')
  async create(
    @CurrentUser() user: IrisUserDto,
    @Contracts() contracts: IrisContractPackage[],
    @Body() createDto: OrderCreateDto,
  ): Promise<OrderDto> {
    return await this.service.createOldSupport(user, contracts, createDto);
  }

  @ApiOperation({ summary: 'List orders', deprecated: true })
  @ApiQuery({
    name: 'query',
    description: 'query filter',
    example: { query: { requestId: { startsWith: '1000001-2023' } } },
    enum: ['requestId', 'status', 'organizationId', 'contractId'],
    required: false,
  })
  @ApiQuery({
    name: 'sortby',
    description: 'Sort by, post fix +:asc, -:desc',
    example: '-createdAt,+status',
    enum: [
      'requestId',
      'status',
      'organizationId',
      'contractId',
      'createdAt',
      'orderedUserId',
      'updatedAt',
      'downloadExpired',
    ],
    required: false,
  })
  @ApiOkResponse({ type: OrdersDto })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Get('')
  async getMany(
    @CurrentUser() user: IrisUserDto,
    @Query() query: OrderStacSearchDto,
  ): Promise<OrdersDto> {
    return await this.service.getMany(user, query);
  }

  @ApiOperation({ summary: 'Search orders', deprecated: true })
  @ApiOkResponse({ type: OrdersDto, status: 200 })
  @HttpCode(200)
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Post('/search')
  async getManySearch(
    @CurrentUser() user: IrisUserDto,
    @Body() query: OrderSearchDto,
  ): Promise<OrdersDto> {
    return await this.service.getMany(user, query);
  }

  @ApiOperation({ summary: 'Get order', deprecated: true })
  @ApiParam({
    name: 'id',
    type: 'string',
    description: 'product-data id',
  })
  @ApiOkResponse({ type: OrderDto })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Get('/:id')
  async getOne(
    @CurrentUser() user: IrisUserDto,
    @Param('id', ParseUUIDPipe) orderId: string,
  ): Promise<OrderDto> {
    return await this.service.getOne(user, orderId);
  }

  @ApiOperation({ summary: 'review order', deprecated: true })
  @ApiBody({ type: OrderCreateDto })
  @ApiOkResponse({ type: PaymentsDto, status: 200 })
  @HttpCode(200)
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Serialize(PaymentsDto)
  @Post('review')
  async review(
    @Contracts() contracts: IrisContractPackage[],
    @Body() createDto: OrderCreateDto,
  ) {
    return await this.service.reviewOldSupport(contracts, createDto);
  }
}
