import { Controller, Get, Inject } from '@nestjs/common';
import {
  HealthCheck,
  HealthCheckService,
  HttpHealthIndicator,
  TypeOrmHealthIndicator,
} from '@nestjs/terminus';
import { Public } from '@iris-lib/decorators';
import { MissionPortalConfigService } from '../infra/mission-portal/config/mission-portal-config';
import { ApiExcludeController } from '@nestjs/swagger';

@ApiExcludeController()
@Controller('health')
export class HealthController {
  constructor(
    private health: HealthCheckService,
    private db: TypeOrmHealthIndicator,
    private http: HttpHealthIndicator,
    @Inject('MissionPortalConfig')
    private readonly config: MissionPortalConfigService,
  ) {}

  @Public()
  @Get()
  @HealthCheck()
  check() {
    return this.health.check([
      () => this.db.pingCheck('database'),
      () =>
        this.http.pingCheck(
          'missionPortal',
          `${this.config.get('missionPortal.url')}/apigateway/health`,
        ),
    ]);
  }
}
