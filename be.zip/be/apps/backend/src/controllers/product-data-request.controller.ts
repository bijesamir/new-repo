import { LoggerWrapper } from '@iris-lib/logger';
import { ProductDataRequestUsecaseService } from '../usecases/product-data-request/product-data-request-usecase.service';
import { IrisAccessControlType } from '@iris-lib/constants/iris-access-control-type';
import { AccessControl } from '../decorators/access-control.decorator';
import {
  ApiBadRequestResponse,
  ApiBody,
  ApiInternalServerErrorResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
} from '@nestjs/swagger';
import { Body, Controller, Put } from '@nestjs/common';
import { CurrentUser } from '../decorators/current-user.decorator';
import { IrisUserDto } from '@iris-lib/models';
import { ErrorResponse } from '@iris-lib/filters';
import { ProductDataRequestUpdateStatusDto } from '../models/dto/product-data-request/product-data-request-update-status.dto';
import { ProductDataRequestDto } from '../models/dto/product-data-request/product-data-request.dto';
import { Serialize } from '@iris-lib/interceptors';

@ApiTags('product-data-request')
@AccessControl(
  IrisAccessControlType.Admin,
  IrisAccessControlType.Internal,
  IrisAccessControlType.Collaborator,
  IrisAccessControlType.Tasking,
  IrisAccessControlType.Archive,
)
@Controller('product-data-request')
export class ProductDataRequestController {
  private readonly logger = new LoggerWrapper(
    ProductDataRequestController.name,
  );

  constructor(
    private readonly productDataRequestUsecaseService: ProductDataRequestUsecaseService,
  ) {}

  @ApiOperation({ summary: 'Update product-data-request status' })
  @ApiBody({ type: ProductDataRequestUpdateStatusDto })
  @ApiOkResponse({ type: [ProductDataRequestDto] })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @AccessControl(IrisAccessControlType.Admin, IrisAccessControlType.Internal)
  @Put('/update-status')
  @Serialize(ProductDataRequestDto)
  async updateStatus(
    @CurrentUser() user: IrisUserDto,
    @Body() updateDto: ProductDataRequestUpdateStatusDto,
  ) {
    return await this.productDataRequestUsecaseService.updateStatus(
      user,
      updateDto,
    );
  }
}
