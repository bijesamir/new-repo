import { IrisAccessControlType } from '@iris-lib/constants/iris-access-control-type';
import { Controller, Get, Param } from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiInternalServerErrorResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiParam,
  ApiTags,
} from '@nestjs/swagger';
import { AccessControl } from '../decorators/access-control.decorator';
import { ErrorResponse } from '@iris-lib/filters';
import { ProductDataRelatedStatusService } from '../usecases/product-data-related-status/product-data-related-status.service';
import { OrderCodePipe } from '../pipes/order-code.pipe';
import { ProductDataRelatedStatusDto } from '../models/dto/product-data-related-status/product-data-related-status.dto';
import { CurrentUser } from '../decorators/current-user.decorator';
import { IrisUserDto } from '@iris-lib/models';
import { Serialize } from '@iris-lib/interceptors';

@ApiTags('product-data-related-status')
@AccessControl(
  IrisAccessControlType.Admin,
  IrisAccessControlType.Internal,
  IrisAccessControlType.Collaborator,
  IrisAccessControlType.Tasking,
)
@Controller('product-data-related-status')
export class ProductDataRelatedStatusController {
  constructor(private readonly service: ProductDataRelatedStatusService) {}

  @ApiOperation({ summary: 'Get various product-related statuses' })
  @ApiParam({
    name: 'orderCode',
    type: 'string',
    description: 'order code',
  })
  @ApiOkResponse({ type: [ProductDataRelatedStatusDto] })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Serialize(ProductDataRelatedStatusDto)
  @Get('/:orderCode')
  async getByOrderCode(
    @CurrentUser() user: IrisUserDto,
    @Param('orderCode', OrderCodePipe) orderCode: string,
  ) {
    return this.service.getByOrderCode(user, orderCode);
  }
}
