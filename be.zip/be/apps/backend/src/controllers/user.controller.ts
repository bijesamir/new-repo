import { Controller, Get } from '@nestjs/common';
import {
  ApiInternalServerErrorResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
} from '@nestjs/swagger';
import { CurrentUser } from '../decorators/current-user.decorator';
import { IrisUserDto } from '@iris-lib/models';
import { ErrorResponse } from '@iris-lib/filters';
import { Contracts } from '../decorators/contracts.decorator';
import { IrisContractPackage } from '@iris-lib/models/payment';
import { IrisAccessControlType } from '@iris-lib/constants/iris-access-control-type';
import { AccessControl } from '../decorators/access-control.decorator';
import { UserDto } from '../models/dto/user/user.dto';
import { plainToInstance } from 'class-transformer';

@ApiTags('user')
@AccessControl(
  IrisAccessControlType.Admin,
  IrisAccessControlType.Internal,
  IrisAccessControlType.Collaborator,
  IrisAccessControlType.Tasking,
  IrisAccessControlType.Archive,
)
@Controller('user')
export class UserController {
  // It's mainly for debugging, so I think it's okay to remove it if you don't need it anymore.
  @ApiOperation({ summary: 'Get current user' })
  @ApiOkResponse({ type: UserDto })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Get()
  async current(
    @CurrentUser() user: IrisUserDto,
    @Contracts() contracts: IrisContractPackage[],
  ) {
    return plainToInstance(UserDto, { user, contracts });
  }
}
