import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Logger,
  Param,
  ParseUUIDPipe,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiBody,
  ApiCreatedResponse,
  ApiInternalServerErrorResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiParam,
  ApiQuery,
  ApiTags,
} from '@nestjs/swagger';
import { AoiUsecaseService } from '../usecases/aoi-usecase/aoi-usecase.service';

import { AoiCreateDto } from '../models/dto/aoi/aoi-create.dto';
import { AoiSearchDto } from '../models/dto/aoi/aoi-search.dto';
import { CurrentUser } from '../decorators/current-user.decorator';
import { IrisUserDto } from '@iris-lib/models';
import { Aoi } from '@iris-lib/db/entities/aoi.entity';
import { AoiUpdateDto } from '../models/dto/aoi/aoi-update.dto';
import { ErrorResponse } from '@iris-lib/filters';
import { Paginate, PaginateQuery } from 'nestjs-paginate';
import { PaginateQueryOptions } from '../helper/paginateHelper';
import { OrganizationIdQueryDto } from '../models/dto/organization-id-query.dto';
import { OrganizationIdPipe } from '../pipes/organization-id.pipe';
import { AoiDeleteDto } from '../models/dto/aoi/aoi-delete.dto';
import { AccessControl } from '../decorators/access-control.decorator';
import { IrisAccessControlType } from '@iris-lib/constants/iris-access-control-type';
import { AoiDto } from '../models/dto/aoi/aoi.dto';

@ApiTags('aoi')
@AccessControl(
  IrisAccessControlType.Admin,
  IrisAccessControlType.Internal,
  IrisAccessControlType.Collaborator,
  IrisAccessControlType.Tasking,
)
@Controller('aoi')
export class AoiController {
  private readonly logger = new Logger(AoiController.name);
  constructor(readonly service: AoiUsecaseService) {}

  @ApiOperation({
    summary: 'Search for AOIs within the displayed range',
  })
  @ApiBody({ type: AoiSearchDto })
  @ApiOkResponse({ type: [AoiDto] })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @HttpCode(HttpStatus.OK) // Overwrite 201
  @Post('/in-view')
  async search(
    @CurrentUser() user: IrisUserDto,
    @Body() searchDto: AoiSearchDto,
  ) {
    return await this.service.inView(user, searchDto);
  }

  @ApiOperation({ summary: 'List AOIs' })
  @PaginateQueryOptions(
    AoiDto,
    'id',
    'name',
    'organizationId',
    'createdAt',
    'updatedAt',
  )
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Get('/search')
  async getMany(
    @CurrentUser() user: IrisUserDto,
    @Paginate() query: PaginateQuery,
  ) {
    return await this.service.search(user, query);
  }

  @ApiOperation({ summary: 'Get AOI' })
  @ApiParam({
    name: 'id',
    type: 'string',
    description: 'aoi id',
  })
  @ApiQuery({
    name: 'organizationId',
    type: 'string',
    description: 'organization id',
    required: false,
  })
  @ApiOkResponse({ type: AoiDto })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Get('/:id')
  async getOne(
    @CurrentUser() user: IrisUserDto,
    @Param('id', ParseUUIDPipe) aoiId: string,
    @Query('organizationId', OrganizationIdPipe)
    organizationId: OrganizationIdQueryDto,
  ) {
    return await this.service.get(user, aoiId, organizationId);
  }

  @ApiOperation({ summary: 'Register AOI' })
  @ApiBody({ type: AoiCreateDto })
  @ApiCreatedResponse({ type: AoiDto })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Post('')
  async create(
    @CurrentUser() user: IrisUserDto,
    @Body() createDto: AoiCreateDto,
  ): Promise<Aoi> {
    return await this.service.create(user, createDto);
  }

  @ApiOperation({ summary: 'Update AOI' })
  @ApiParam({
    name: 'id',
    type: 'string',
    description: 'aoi id',
  })
  @ApiBody({ type: AoiUpdateDto })
  @ApiOkResponse({ type: AoiDto })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Put('/:id')
  async update(
    @CurrentUser() user: IrisUserDto,
    @Param('id', ParseUUIDPipe) aoiId: string,
    @Body() updateDto: AoiUpdateDto,
  ): Promise<Aoi> {
    return await this.service.update(user, aoiId, updateDto);
  }

  @ApiOperation({ summary: 'Delete AOIs' })
  @ApiBody({ type: AoiDeleteDto })
  @ApiOkResponse({ type: [AoiDto] })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Delete('')
  async delete(
    @CurrentUser() user: IrisUserDto,
    @Body() deleteDto: AoiDeleteDto,
  ) {
    return await this.service.remove(user, deleteDto);
  }
}
