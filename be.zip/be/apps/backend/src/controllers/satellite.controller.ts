import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  ParseUUIDPipe,
  Post,
  Put,
} from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiBody,
  ApiCreatedResponse,
  ApiInternalServerErrorResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiParam,
  ApiTags,
} from '@nestjs/swagger';
import { UUIDV4 } from '../models/dto/uuidv4.dto';
import { SatelliteCreateDto } from '../models/dto/satellite/satellite-create.dto';
import { SatelliteUsecaseService } from '../usecases/satellite-usecase/satellite-usecase.service';
import { LoggerWrapper } from '@iris-lib/logger';
import { ErrorResponse } from '@iris-lib/filters';
import { SatelliteUpdateDto } from '../models/dto/satellite/satellite-update.dto';
import { Paginate, PaginateQuery } from 'nestjs-paginate';
import { PaginateQueryOptions } from '../helper/paginateHelper';
import { IrisAccessControlType } from '@iris-lib/constants/iris-access-control-type';
import { AccessControl } from '../decorators/access-control.decorator';
import { SatelliteDto } from '../models/dto/satellite/satellite.dto';

@ApiTags('satellite')
@AccessControl(IrisAccessControlType.Admin)
@Controller('satellite')
export class SatelliteController {
  private logger = new LoggerWrapper(SatelliteController.name);
  constructor(private readonly usecase: SatelliteUsecaseService) {}

  @ApiOperation({ summary: 'Register satellite' })
  @ApiBody({ type: SatelliteCreateDto })
  @ApiCreatedResponse({ type: SatelliteDto })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Post('')
  async create(@Body() dto: SatelliteCreateDto) {
    return await this.usecase.create(dto);
  }

  @ApiOperation({ summary: 'Update satellite' })
  @ApiParam({
    name: 'id',
    type: 'string',
    description: 'satellite id',
  })
  @ApiBody({ type: SatelliteUpdateDto })
  @ApiOkResponse({ type: SatelliteDto })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Put('/:id')
  async update(@Param() uuid: UUIDV4, @Body() dto: SatelliteUpdateDto) {
    return await this.usecase.update(uuid.id, dto);
  }

  @ApiOperation({ summary: 'Delete satellite' })
  @ApiParam({
    name: 'id',
    type: 'string',
    description: 'satellite id',
  })
  @ApiOkResponse({ type: SatelliteDto })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Delete('/:id')
  async delete(@Param('id', ParseUUIDPipe) id: string) {
    return await this.usecase.delete(id);
  }

  @ApiOperation({ summary: 'List satellites' })
  @PaginateQueryOptions(
    SatelliteDto,
    'name',
    'satId',
    'satelliteDevelopmentCode',
    'createdAt',
    'updatedAt',
  )
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Get('/search')
  async getMany(@Paginate() query: PaginateQuery) {
    return await this.usecase.search(query);
  }

  @ApiOperation({ summary: 'Get satellite' })
  @ApiParam({
    name: 'id',
    type: 'string',
    description: 'satellite id',
  })
  @ApiOkResponse({ type: SatelliteDto })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Get('/:id')
  async getOne(@Param() uuid: UUIDV4) {
    return await this.usecase.get(uuid.id);
  }
}
