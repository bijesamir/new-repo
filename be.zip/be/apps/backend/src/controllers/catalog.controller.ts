import {
  Body,
  Controller,
  Get,
  HttpCode,
  HttpStatus,
  Post,
  Query,
} from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiBody,
  ApiInternalServerErrorResponse,
  ApiOkResponse,
  ApiOperation,
  ApiProduces,
  ApiTags,
  ApiUnprocessableEntityResponse,
} from '@nestjs/swagger';
import { AccessControl } from '../decorators/access-control.decorator';
import { IrisAccessControlType } from '@iris-lib/constants/iris-access-control-type';
import { LoggerWrapper } from '@iris-lib/logger';
import { ErrorResponse } from '@iris-lib/filters';
import { FeatureCollectionDto } from '../models/dto/stac/feature-collection.dto';
import { CurrentUser } from '../decorators/current-user.decorator';
import { IrisUserDto } from '@iris-lib/models';
import {
  StacFullSearchDto,
  StacSimpleSearchDto,
} from '../models/dto/stac/stac-search.dto';
import { CatalogUsecaseService } from '../usecases/catalog-usecase/catalog-usecase.service';

@ApiTags('catalog')
@AccessControl(
  IrisAccessControlType.Admin,
  IrisAccessControlType.Internal,
  IrisAccessControlType.Archive,
)
@Controller('catalog')
export class CatalogController {
  private readonly logger = new LoggerWrapper(CatalogController.name);

  constructor(private readonly catalogUsecaseService: CatalogUsecaseService) {}

  @ApiOperation({ summary: 'Search STAC items with simple filtering' })
  @ApiProduces('application/geo+json', 'application/json')
  @ApiOkResponse({ type: FeatureCollectionDto })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiUnprocessableEntityResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Get('/search')
  async search(
    @CurrentUser() user: IrisUserDto,
    @Query() dto: StacSimpleSearchDto,
  ) {
    return await this.catalogUsecaseService.search(user, dto);
  }

  @ApiOperation({ summary: 'Search STAC items with full-featured filtering' })
  @ApiBody({ required: false, type: StacFullSearchDto })
  @ApiProduces('application/geo+json', 'application/json')
  @ApiOkResponse({ type: FeatureCollectionDto })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiUnprocessableEntityResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @HttpCode(HttpStatus.OK) // Overwrite 201
  @Post('/search')
  async searchFull(
    @CurrentUser() user: IrisUserDto,
    @Body() dto?: StacFullSearchDto,
  ) {
    return await this.catalogUsecaseService.search(user, dto);
  }
}
