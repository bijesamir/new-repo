import { Body, Controller, Delete, Get, Post, Put } from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiBody,
  ApiCreatedResponse,
  ApiInternalServerErrorResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
  ApiUnprocessableEntityResponse,
} from '@nestjs/swagger';
import { AccessControl } from '../decorators/access-control.decorator';
import { IrisAccessControlType } from '@iris-lib/constants/iris-access-control-type';
import { LoggerWrapper } from '@iris-lib/logger';
import { ErrorResponse } from '@iris-lib/filters';
import { CurrentUser } from '../decorators/current-user.decorator';
import { IrisUserDto } from '@iris-lib/models';
import { Serialize } from '@iris-lib/interceptors';
import { ArchiveCartUsecaseService } from '../usecases/archive-cart/archive-cart-usecase.service';
import { CartDto, CartWithFeatureDto } from '../models/dto/order/cart.dto';

@ApiTags('cart')
@AccessControl(
  IrisAccessControlType.Admin,
  IrisAccessControlType.Internal,
  IrisAccessControlType.Archive,
)
@Controller('cart')
export class ArchiveCartController {
  private readonly logger = new LoggerWrapper(ArchiveCartController.name);
  constructor(private readonly service: ArchiveCartUsecaseService) {}

  @ApiOperation({ summary: 'Register order to cart' })
  @ApiBody({ type: CartDto })
  @ApiCreatedResponse({ type: CartWithFeatureDto })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiUnprocessableEntityResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Serialize(CartWithFeatureDto)
  @Post('')
  async add(@CurrentUser() user: IrisUserDto, @Body() createDto: CartDto) {
    return await this.service.add(user, createDto);
  }

  @ApiOperation({ summary: 'overwrite orders in cart' })
  @ApiBody({ type: CartDto })
  @ApiOkResponse({ type: CartWithFeatureDto })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiUnprocessableEntityResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Serialize(CartWithFeatureDto)
  @Put('')
  async set(@CurrentUser() user: IrisUserDto, @Body() createDto: CartDto) {
    return await this.service.set(user, createDto);
  }

  @ApiOperation({ summary: 'delete order in cart' })
  @ApiOkResponse()
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Delete()
  async delete(@CurrentUser() user: IrisUserDto) {
    return await this.service.delete(user);
  }

  @ApiOperation({ summary: 'get cart orders' })
  @ApiOkResponse({ type: CartWithFeatureDto })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Serialize(CartWithFeatureDto)
  @Get('')
  async get(@CurrentUser() user: IrisUserDto): Promise<CartWithFeatureDto> {
    return await this.service.get(user);
  }
}
