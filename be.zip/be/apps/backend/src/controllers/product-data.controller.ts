import { IrisAccessControlType } from '@iris-lib/constants/iris-access-control-type';
import { ErrorResponse } from '@iris-lib/filters';
import { LoggerWrapper } from '@iris-lib/logger';
import { IrisUserDto } from '@iris-lib/models';
import { Controller, Delete, Get, Param, ParseUUIDPipe } from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiInternalServerErrorResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiParam,
  ApiTags,
} from '@nestjs/swagger';
import { Paginate, PaginateQuery } from 'nestjs-paginate';
import { AccessControl } from '../decorators/access-control.decorator';
import { CurrentUser } from '../decorators/current-user.decorator';
import { PaginateQueryOptions } from '../helper/paginateHelper';
import { ProductDataSearchFilter } from '../models/dto/product-data-search/product-data-search.dto';
import {
  ProductDataArchiveOrderDto,
  ProductDataExpandedDto,
  ProductDataWithVersionsDto,
} from '../models/dto/product-data/product-data.dto';
import { PaginateQueryValidationPipe } from '../pipes/paginate-query-validation.pipe';
import { ProductDataUsecaseService } from '../usecases/product-data/product-data-usecase.service';

@ApiTags('product-data')
@AccessControl(
  IrisAccessControlType.Admin,
  IrisAccessControlType.Internal,
  IrisAccessControlType.Collaborator,
  IrisAccessControlType.Tasking,
  IrisAccessControlType.Archive,
)
@Controller('product-data')
export class ProductDataController {
  private readonly logger = new LoggerWrapper(ProductDataController.name);

  constructor(
    private readonly productDataUsecaseService: ProductDataUsecaseService,
  ) {}

  @ApiOperation({ summary: 'List product-data' })
  @PaginateQueryOptions(
    ProductDataExpandedDto,
    'latest',
    'aois',
    'bbox',
    'orderCode',
    'uploadStartDateTime',
    'uploadEndDateTime',
    'productFormat',
    'resolutionMode',
    'imagingMode',
    'flightDirection',
    'lookingDirection',
    'acquisitionStartDateTime',
    'acquisitionEndDateTime',
    'offnadirAngleMin',
    'offnadirAngleMax',
  )
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Get('/search')
  async getMany(
    @CurrentUser() user: IrisUserDto,
    @Paginate(new PaginateQueryValidationPipe(ProductDataSearchFilter))
    query: PaginateQuery,
  ) {
    return await this.productDataUsecaseService.searchWithQuery(user, query);
  }

  @ApiOperation({ summary: 'List archive ordered product-data' })
  @PaginateQueryOptions(
    ProductDataArchiveOrderDto,
    'latest',
    'aois',
    'bbox',
    'itemId',
    'archiveRequestId',
    'uploadStartDateTime',
    'uploadEndDateTime',
    'productFormat',
    'resolutionMode',
    'imagingMode',
    'flightDirection',
    'lookingDirection',
    'acquisitionStartDateTime',
    'acquisitionEndDateTime',
    'centerStartDateTime',
    'centerEndDateTime',
    'offnadirAngleMin',
    'offnadirAngleMax',
  )
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @Get('/archive-order')
  async getManyArchive(
    @CurrentUser() user: IrisUserDto,
    @Paginate(new PaginateQueryValidationPipe(ProductDataSearchFilter))
    query: PaginateQuery,
  ) {
    return await this.productDataUsecaseService.searchArchiveOrder(user, query);
  }

  @ApiOperation({ summary: 'Delete product-data' })
  @ApiParam({
    name: 'id',
    type: 'string',
    description: 'product-data id',
  })
  @ApiOkResponse({ type: ProductDataWithVersionsDto })
  @ApiBadRequestResponse({ type: ErrorResponse })
  @ApiNotFoundResponse({ type: ErrorResponse })
  @ApiInternalServerErrorResponse({ type: ErrorResponse })
  @AccessControl(IrisAccessControlType.Admin)
  @Delete('/:id')
  async delete(
    @CurrentUser() user: IrisUserDto,
    @Param('id', ParseUUIDPipe) productDataId: string,
  ) {
    return this.productDataUsecaseService.removeWithVersion(
      user,
      productDataId,
    );
  }
}
