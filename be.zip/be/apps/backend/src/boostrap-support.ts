import { BadRequestException, ValidationPipe } from '@nestjs/common';
import { NestExpressApplication } from '@nestjs/platform-express';
import { AppModule } from './app.module';
import { LoggerService } from '@iris-lib/logger';
import { useContainer as useValidatorContainer } from 'class-validator';
import { getCustomValidationErrors } from '@iris-lib/models/errors';

export const decorateApp = async (app: NestExpressApplication) => {
  const logger = await app.get<LoggerService>(LoggerService);
  app.useLogger(logger);
  app.disable('x-powered-by');
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      transform: true,
      skipMissingProperties: false,
      forbidUnknownValues: true,
      transformOptions: {
        exposeDefaultValues: true,
        //enableImplicitConversion: true,
      },
      exceptionFactory(errors) {
        logger.debug(
          { message: 'Error content before processing', errors },
          'exceptionFactory',
        );
        const tmp = getCustomValidationErrors(errors);

        throw new BadRequestException(tmp);
      },
    }),
  );
  useValidatorContainer(app.select(AppModule), { fallbackOnErrors: true });
  return app;
};
