import { Inject, Module } from '@nestjs/common';
import { AppConfigModule } from './config/app-config.module';
import { AppConfigService } from './config/app-config.service';
import { AoiController } from './controllers/aoi.controller';
import { AoiUsecaseModule } from './usecases/aoi-usecase/aoi-usecase.module';

@Module({
  imports: [AoiUsecaseModule, AppConfigModule],
  controllers: [AoiController],
})
export class TaskingModule {
  constructor(@Inject('AppConfig') private readonly config: AppConfigService) {}
}
