import { Module } from '@nestjs/common';
import { TypeOrmModule, TypeOrmModuleOptions } from '@nestjs/typeorm';
import { AppController } from './app.controller';
import { AppConfigModule } from './config/app-config.module';
import { LoggerModule } from '@iris-lib/logger';
import { CacheManageModule } from './infra/cache-manage/cache-manage.module';
import { SatelliteUsecaseModule } from './usecases/satellite-usecase/satellite-usecase.module';
import { SatelliteController } from './controllers/satellite.controller';
import { RequestContextModule } from 'nestjs-request-context';
import { MissionPortalModule } from './infra/mission-portal/mission-portal.module';
import { MasterController } from './controllers/master.controller';
import { UserController } from './controllers/user.controller';
import { HealthModule } from './usecases/health/health.module';
import { ValidatorsModule } from './validators/validators.module';
import { DbConfigModule } from '@iris-lib/db/db-config.module';
import { DbConfigService } from '@iris-lib/db';
import { ProductDataController } from './controllers/product-data.controller';
import { ProductDataUsecaseModule } from './usecases/product-data/product-data-usecase.module';
import { ProductDataVersionController } from './controllers/product-data-version.controller';
import { ProductDataVersionUsecaseModule } from './usecases/product-data-version/product-data-version-usecase.module';
import { CitadelGrpcModule, CitadelHttpModule } from '@iris-lib/citadel';
import { ProductDataRequestController } from './controllers/product-data-request.controller';
import { ProductDataRequestUsecaseModule } from './usecases/product-data-request/product-data-request-usecase.module';
import { SlackNotificationModule } from '@iris-lib/slack';
import { DeliveryRequestUsecaseModule } from './usecases/delivery-request/delivery-request-usecase.module';
import { DeliveryRequestController } from './controllers/delivery-request.controller';
import { ReprocessingRequestUsecaseModule } from './usecases/reprocessing-request/reprocessing-request-usecase.module';
import { ReprocessingRequestController } from './controllers/reprocessing-request.controller';
import { ArchivePurchaseRequestController } from './controllers/archive-purchase-request.controller';
import { ArchivePurchaseRequestUsecaseModule } from './usecases/archive-purchase-request/archive-purchase-request-usecase.module';
import { ArchiveCartController } from './controllers/archive-cart.controller';
import { ArchiveCartUsecaseModule } from './usecases/archive-cart/archive-cart-usecase.module';

import { CandidateController } from './controllers/candidate.controller';
import { TaskingRequestController } from './controllers/tasking-request.controller';
import { TaskingInfoController } from './controllers/tasking-info.controller';
import { CandidateUsecaseModule } from './usecases/candidate-usecase/candidate-usecase.module';
import { TaskingRequestUsecaseModule } from './usecases/tasking-request-usecase/tasking-request-usecase.module';
import { TaskingInfoUsecaseModule } from './usecases/tasking-info-usecase/tasking-info-usecase.module';
import { TaskingBundleController } from './controllers/tasking-bundle.controller';
import { TaskingBundleUsecaseModule } from './usecases/tasking-bundle-usecase/tasking-bundle-usecase.module';
import { ObservableAreaController } from './controllers/observable-area.controller';
import { ObservableAreaModule } from './usecases/observable-area/observable-area.module';
import { ProductDataRelatedStatusController } from './controllers/product-data-related-status.controller';
import { ProductDataRelatedStatusModule } from './usecases/product-data-related-status/product-data-related-status.module';

@Module({
  imports: [
    RequestContextModule,
    AppConfigModule,
    DbConfigModule,
    LoggerModule,
    TypeOrmModule.forRootAsync({
      inject: ['DbConfig'],
      useFactory: async (configService: DbConfigService) => {
        return configService.get('db') as TypeOrmModuleOptions;
      },
    }),
    MissionPortalModule,
    CacheManageModule,
    ValidatorsModule,
    SatelliteUsecaseModule,
    CitadelGrpcModule,
    ProductDataRequestUsecaseModule,
    ProductDataUsecaseModule,
    ProductDataVersionUsecaseModule,
    ArchivePurchaseRequestUsecaseModule,
    ArchiveCartUsecaseModule,
    ReprocessingRequestUsecaseModule,
    DeliveryRequestUsecaseModule,
    CitadelHttpModule,
    HealthModule,
    SlackNotificationModule,

    CandidateUsecaseModule,
    ObservableAreaModule,
    ProductDataRelatedStatusModule,
    TaskingRequestUsecaseModule,
    TaskingInfoUsecaseModule,
    TaskingBundleUsecaseModule,
  ],
  controllers: [
    AppController,
    ProductDataRequestController,
    ProductDataController,
    ProductDataVersionController,
    ArchivePurchaseRequestController,
    ArchiveCartController,
    ReprocessingRequestController,
    DeliveryRequestController,
    SatelliteController,
    MasterController,
    UserController,

    CandidateController,
    ObservableAreaController,
    ProductDataRelatedStatusController,
    TaskingBundleController,
    TaskingInfoController,
    TaskingRequestController,
  ],
})
export class InternalModule {}
