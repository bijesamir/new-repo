import { Inject, Module } from '@nestjs/common';
import { AppConfigModule } from './config/app-config.module';
import { AppConfigService } from './config/app-config.service';
import { ArchiveCartUsecaseModule } from './usecases/archive-cart/archive-cart-usecase.module';
import { ArchiveOrderController } from './controllers/archive-order.controller';
import { ArchivePurchaseRequestUsecaseModule } from './usecases/archive-purchase-request/archive-purchase-request-usecase.module';
import { CatalogController } from './controllers/catalog.controller';
import { CatalogUsecaseModule } from './usecases/catalog-usecase/catalog-usecase.module';
import { SceneInfoUsecaseModule } from './usecases/scene-info/scene-info-usecase.module';

@Module({
  imports: [
    AppConfigModule,
    CatalogUsecaseModule,
    SceneInfoUsecaseModule,
    ArchiveCartUsecaseModule,
    ArchivePurchaseRequestUsecaseModule,
  ],
  controllers: [ArchiveOrderController, CatalogController],
})
export class ArchiveModule {
  constructor(@Inject('AppConfig') private readonly config: AppConfigService) {}
}
