import { Controller, Get, Options } from '@nestjs/common';
import { LoggerWrapper } from '@iris-lib/logger';
import { Public } from '@iris-lib/decorators';
import { ApiExcludeController } from '@nestjs/swagger';

@ApiExcludeController()
@Controller()
export class AppController {
  private logger = new LoggerWrapper(AppController.name);
  constructor() {}

  @Public()
  @Get()
  ok() {
    return 'ok';
  }

  @Options()
  options() {
    return 'option check';
  }
}
