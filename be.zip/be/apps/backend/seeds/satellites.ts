import {
  AllFlightDirectionValues,
  AllLookingDirectionValues,
  FlightDirection,
  ImagingMode,
  IrisUserRole,
  IrisUserRoleAllValues,
  IrisUserRoleInternalValues,
  LookingDirection,
  TaskingType,
} from '@iris-lib/constants';
import { Satellite } from '@iris-lib/db/entities';
import { DeepPartial } from 'typeorm';

export const satellites: Array<DeepPartial<Satellite>> = [
  {
    name: 'StriX-alpha',
    satId: 'ST0001',
    satelliteDevelopmentCode: 'dsx0101',
    isAvailable: false,
    visibleTo: IrisUserRoleInternalValues,
    parameters: [],
  },
  {
    name: 'StriX-beta',
    satId: 'ST0002',
    satelliteDevelopmentCode: 'dsx0102',
    isAvailable: false,
    visibleTo: [IrisUserRole.INTERNAL],
    parameters: [
      {
        imagingMode: ImagingMode.Stripmap,
        taskingType: [TaskingType.Regular],
        flightDirection: [FlightDirection.Descending],
        lookingDirection: [LookingDirection.Right],
        offnadirLowerLimit: 15,
        offnadirUpperLimit: 45,
      },
      {
        imagingMode: ImagingMode.Stripmap,
        taskingType: [TaskingType.Regular],
        flightDirection: [FlightDirection.Ascending],
        lookingDirection: AllLookingDirectionValues,
        offnadirLowerLimit: 15,
        offnadirUpperLimit: 45,
      },
    ],
  },
  {
    name: 'StriX-1',
    satId: 'ST0003',
    satelliteDevelopmentCode: 'dsx0201',
    isAvailable: true,
    visibleTo: IrisUserRoleAllValues,
    parameters: [
      {
        imagingMode: ImagingMode.Stripmap,
        taskingType: [TaskingType.Regular, TaskingType.Urgent],
        flightDirection: [FlightDirection.Descending],
        lookingDirection: AllLookingDirectionValues,
        offnadirLowerLimit: 15,
        offnadirUpperLimit: 45,
      },
    ],
  },
  {
    name: 'StriX-3',
    satId: 'ST0004',
    satelliteDevelopmentCode: 'dsx0202',
    isAvailable: true,
    visibleTo: [IrisUserRole.ADMINISTRATOR], // Before release, only admin can see this satellite
    parameters: [
      // Temporal value. Should be updated according to the actual capabilities of the satellite
      {
        imagingMode: ImagingMode.Stripmap,
        taskingType: [TaskingType.Regular, TaskingType.Urgent],
        flightDirection: AllFlightDirectionValues,
        lookingDirection: AllLookingDirectionValues,
        offnadirLowerLimit: 15,
        offnadirUpperLimit: 45,
      },
      {
        imagingMode: ImagingMode.SlidingSpotlight,
        taskingType: [TaskingType.Regular, TaskingType.Urgent],
        flightDirection: AllFlightDirectionValues,
        lookingDirection: AllLookingDirectionValues,
        offnadirLowerLimit: 15,
        offnadirUpperLimit: 45,
      },
      {
        imagingMode: ImagingMode.StaringSpotlight1,
        taskingType: [TaskingType.Regular, TaskingType.Urgent],
        flightDirection: AllFlightDirectionValues,
        lookingDirection: AllLookingDirectionValues,
        offnadirLowerLimit: 15,
        offnadirUpperLimit: 45,
      },
    ],
  },
];
