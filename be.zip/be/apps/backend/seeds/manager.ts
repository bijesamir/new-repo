import { NestFactory } from '@nestjs/core';
import { DataSource } from 'typeorm';
import {
  DbPrepareModule,
  cleanupFixturesByTargets,
  loadByTargets,
} from '@iris-lib/db';

const seeds = ['satellites'];

const main = async () => {
  const [doClean, targetData] =
    process.argv.length >= 3 ? process.argv.splice(2) : [];

  const app = await NestFactory.create(DbPrepareModule, {});
  const ds = app.get(DataSource);

  const target = !targetData || targetData === 'seed' ? seeds : [];
  if (doClean && doClean === 'cleanup') {
    await cleanupFixturesByTargets(ds, target);
  }
  await loadByTargets(ds, target);

  await ds.destroy();
  return;
};

main();
