import { DataSource } from 'typeorm';
import * as seeds from './index';

export async function reloadFixtures(ds: DataSource): Promise<void> {
  await cleanupFixtures(ds);
  await load(ds);
}

export async function load(ds: DataSource): Promise<void> {
  // テーブル一覧を取得しシーケンシャルにfixturesを登録する
  await Object.keys(seeds).reduce<Promise<any>>(
    async (prev, key) =>
      prev.then(() => {
        const tableName = key.charAt(0).toUpperCase() + key.slice(1);
        return ds.manager.insert(tableName, seeds[key]);
      }),
    Promise.resolve(),
  );
}

export async function loadByTargets(
  ds: DataSource,
  targets: string[] = new Array<string>(),
): Promise<void> {
  await Object.keys(seeds).reduce<Promise<any>>(
    async (prev, key) =>
      prev.then(async () => {
        if (targets.indexOf(key) >= 0) {
          const tableName = camel2Snake(key);
          const rtn = await ds.manager.query(
            `select count(id) from ${
              tableName === 'user' ? 'users' : tableName
            }`,
          );
          if (parseInt(rtn[0].count, 10) === 0) {
            // tslint:disable-next-line:no-console
            console.log(`insert: ${tableName}`);
            return await ds.manager.insert(
              tableName === 'user' ? 'users' : tableName,
              seeds[key],
            );
          } else {
            // tslint:disable-next-line:no-console
            console.log(`skip insert: ${tableName}`);
          }
        }
      }),
    Promise.resolve(),
  );
}

export async function cleanupFixturesByTargets(
  ds: DataSource,
  targets: string[] = new Array<string>(),
): Promise<void> {
  await Object.keys(seeds).reduce<Promise<any>>(
    async (prev, key) =>
      prev.then(async () => {
        if (targets.indexOf(key) >= 0) {
          const tableName = camel2Snake(key);
          return await ds.query(
            `TRUNCATE TABLE ${
              tableName === 'user' ? 'users' : tableName
            } RESTART IDENTITY CASCADE`,
          );
        } else {
          // tslint:disable-next-line:no-console
          console.log(`skip ${key}`);
        }
      }),
    Promise.resolve(),
  );
}

export async function cleanupByTargets(
  ds: DataSource,
  targets: string[] = new Array<string>(),
) {
  await targets.reduce(async (p, tableName) => {
    await p;
    return await ds.query(
      `TRUNCATE TABLE ${tableName} RESTART IDENTITY CASCADE`,
    );
  }, Promise.resolve());
}

export async function cleanupFixtures(ds: DataSource): Promise<void> {
  // テーブル一覧を取得し一括でTRUNCATEする
  const tables = Object.keys(seeds).map((key) => {
    const tableName = camel2Snake(key);
    return tableName === 'user' ? 'users' : tableName;
  });
  await ds.query(
    `TRUNCATE TABLE ${tables.join(', ')} RESTART IDENTITY CASCADE`,
  );
}

const camel2Snake = (camel) => {
  return camel.replace(/([A-Z])/g, (s) => '_' + s.charAt(0).toLowerCase());
};
