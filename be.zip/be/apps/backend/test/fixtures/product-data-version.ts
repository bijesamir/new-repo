import {
  FlightDirection,
  ImagingMode,
  LookingDirection,
  OrbitType,
  PolarizationType,
  ProductFormat,
  ResolutionMode,
  SystemContract,
  SystemOrganization,
  SystemUser,
} from '@iris-lib/constants';
import {
  getTestOrganizationIdForFixture,
  getTestContractIdForFixture,
  getTestAnotherOrganizationIdForFixture,
  getTestAnotherContractIdForFixture,
} from '@iris-lib/constants/test-support';
import { ProductData, ProductDataVersion } from '@iris-lib/db/entities';
import { OmitType } from '@nestjs/swagger';

import { DataSource, DeepPartial } from 'typeorm';

export class ProductDataVersionForTest extends OmitType(
  ProductDataVersion,
  [] as const,
) {}

export const fixtureProductDataVersions: Array<
  DeepPartial<ProductDataVersionForTest>
> = [
  {
    productData: { id: '0603e8a8-c8eb-4da0-838a-43d407dab2df' },
    id: '044ddb41-8c14-4b2f-b53c-d7a072106636',
    createdAt: '2023-03-01 01:01:01.000000+00',
    updatedAt: '2023-03-01 01:01:01.000000+00',
    latestEditorId: SystemUser.DPS_SYSTEM,
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    version: '00-PR-01-dps-20230201010101',
    sourceExpired: '2024-03-20 00:00:00.000000+00',
    bucket: 'gs://syns-daas-dev_iris-product-data-store',
    location:
      'fixtures/0603e8a8-c8eb-4da0-838a-43d407dab2df/044ddb41-8c14-4b2f-b53c-d7a072106636/STRIX_202302-10002_20220821T013544Z_SM_GRD_Geotiff.zip',
    quicklookBucket: 'gs://syns-daas-dev_iris-product-data-store',
    quicklookLocation:
      'fixtures/0603e8a8-c8eb-4da0-838a-43d407dab2df/044ddb41-8c14-4b2f-b53c-d7a072106636/STRIX_202302-10002_20220821T013544Z_SM_GRD_Geotiff_quicklook',
    quicklookContentType: 'image/jpeg',
    metadata: {
      product: {
        productSoftwareVersion: 'v007.000',
        productFormat: ProductFormat.GRD_GEOTIFF,
        dataProcessingSoftwareVersion: 'v0.10.0',
        orbitType: OrbitType.PR,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.normal,
      },
      geometry: {
        sceneCenterLocation: '-27.35446666895787 -66.67473904120934',
        sceneCornerLocations:
          '-27.300620979817765 -66.79206392164848 -27.44122412677884 -66.76265748962582 -27.408312358097973 -66.55741416077018 -27.267709211136896 -66.58682059279283 -27.300620979817765 -66.79206392164848',
      },
      observation: {
        sceneId: 'STRIXB-20230201T010101Z',
        sceneNo: 1,
        orderCode: '202302-10001',
        imagingMode: ImagingMode.SlidingSpotlight,
        satelliteId: 'ST0002',
        polarization: PolarizationType.VV,
        offnadirAngle: 35.36,
        flightDirection: FlightDirection.Ascending,
        lookingDirection: LookingDirection.Left,
        sceneEndDateTime: '2023-02-01T01:01:02.000Z',
        sceneStartDateTime: '2023-02-01T01:01:00.000Z',
        sceneCenterDateTime: '2023-02-01T01:01:01.000Z',
      },
    },
    center: {
      type: 'Point',
      coordinates: [-66.67473904120934, -27.35446666895787],
    },
    area: {
      type: 'Polygon',
      coordinates: [
        [
          [-66.79206392164848, -27.300620979817765],
          [-66.76265748962582, -27.44122412677884],
          [-66.55741416077018, -27.408312358097973],
          [-66.58682059279283, -27.267709211136896],
          [-66.79206392164848, -27.300620979817765],
        ],
      ],
    },
    bbox: [
      -66.79206392164848, -27.44122412677884, -66.55741416077018,
      -27.267709211136896,
    ],
    datetime: '2023-02-01T01:01:01.000Z',
  },
  {
    productData: { id: '0603e8a8-c8eb-4da0-838a-43d407dab2df' },
    id: '1aebd2bd-efdd-4d48-aeb9-0ebd04305581',
    createdAt: '2023-03-02 01:01:01.000000+00',
    updatedAt: '2023-03-02 01:01:01.000000+00',
    latestEditorId: SystemUser.DPS_SYSTEM,
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    version: '00-PR-01-dps-20230201010101-new',
    sourceExpired: '2024-03-21 00:00:00.000000+00',
    bucket: 'gs://syns-daas-dev_iris-product-data-store',
    location:
      'fixtures/0603e8a8-c8eb-4da0-838a-43d407dab2df/1aebd2bd-efdd-4d48-aeb9-0ebd04305581/STRIX_202302-10002_20220821T013544Z_SM_GRD_Geotiff.zip',
    quicklookBucket: 'gs://syns-daas-dev_iris-product-data-store',
    quicklookLocation:
      'fixtures/0603e8a8-c8eb-4da0-838a-43d407dab2df/1aebd2bd-efdd-4d48-aeb9-0ebd04305581/STRIX_202302-10002_20220821T013544Z_SM_GRD_Geotiff_quicklook',
    quicklookContentType: 'image/jpeg',
    metadata: {
      product: {
        productSoftwareVersion: 'v007.000',
        productFormat: ProductFormat.GRD_GEOTIFF,
        dataProcessingSoftwareVersion: 'v0.10.0',
        orbitType: OrbitType.PR,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.normal,
      },
      geometry: {
        sceneCenterLocation: '-27.35446666895787 -66.67473904120934',
        sceneCornerLocations:
          '-27.300620979817765 -66.79206392164848 -27.44122412677884 -66.76265748962582 -27.408312358097973 -66.55741416077018 -27.267709211136896 -66.58682059279283 -27.300620979817765 -66.79206392164848',
      },
      observation: {
        sceneId: 'STRIXB-20230201T010101Z',
        sceneNo: 1,
        orderCode: '202302-10001',
        imagingMode: ImagingMode.SlidingSpotlight,
        satelliteId: 'ST0002',
        polarization: PolarizationType.VV,
        offnadirAngle: 35.36,
        flightDirection: FlightDirection.Ascending,
        lookingDirection: LookingDirection.Left,
        sceneEndDateTime: '2023-02-01T01:01:02.000Z',
        sceneStartDateTime: '2023-02-01T01:01:00.000Z',
        sceneCenterDateTime: '2023-02-01T01:01:01.000Z',
      },
    },
    center: {
      type: 'Point',
      coordinates: [-66.67473904120934, -27.35446666895787],
    },
    area: {
      type: 'Polygon',
      coordinates: [
        [
          [-66.79206392164848, -27.300620979817765],
          [-66.76265748962582, -27.44122412677884],
          [-66.55741416077018, -27.408312358097973],
          [-66.58682059279283, -27.267709211136896],
          [-66.79206392164848, -27.300620979817765],
        ],
      ],
    },
    bbox: [
      -66.79206392164848, -27.44122412677884, -66.55741416077018,
      -27.267709211136896,
    ],
    datetime: '2023-02-01T01:01:01.000Z',
  },
  {
    productData: { id: '161a6d67-4eba-4bbc-84b6-a0f13ce2a37d' },
    id: '2fe11efa-8906-47e1-bdd7-c6774719e48f',
    createdAt: '2023-02-01 01:01:01.000000+00',
    updatedAt: '2023-02-01 01:01:01.000000+00',
    latestEditorId: SystemUser.DPS_SYSTEM,
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    version: '00-PR-00-dps-20230201010101',
    sourceExpired: '2024-02-21 00:00:00.000000+00',
    bucket: 'gs://syns-daas-dev_iris-product-data-store',
    location:
      'fixtures/161a6d67-4eba-4bbc-84b6-a0f13ce2a37d/2fe11efa-8906-47e1-bdd7-c6774719e48f/STRIX_202302-10001_20220821T013544Z_SM_SLC_SICD.zip',
    quicklookBucket: 'gs://syns-daas-dev_iris-product-data-store',
    quicklookLocation:
      'fixtures/161a6d67-4eba-4bbc-84b6-a0f13ce2a37d/2fe11efa-8906-47e1-bdd7-c6774719e48f/STRIX_202302-10001_20220821T013544Z_SM_SLC_SICD_quicklook',
    quicklookContentType: 'image/jpeg',
    metadata: {
      product: {
        productSoftwareVersion: 'v007.000',
        productFormat: ProductFormat.SLC_SICD,
        dataProcessingSoftwareVersion: 'v0.10.0',
        orbitType: OrbitType.PR,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.normal,
      },
      geometry: {
        sceneCenterLocation: '-27.35446666895787 -66.67473904120934',
        sceneCornerLocations:
          '-27.300620979817765 -66.79206392164848 -27.44122412677884 -66.76265748962582 -27.408312358097973 -66.55741416077018 -27.267709211136896 -66.58682059279283 -27.300620979817765 -66.79206392164848',
      },
      observation: {
        sceneId: 'STRIXB-20230201T010101Z',
        sceneNo: 1,
        orderCode: '202302-10001',
        imagingMode: ImagingMode.SlidingSpotlight,
        satelliteId: 'ST0002',
        polarization: PolarizationType.VV,
        offnadirAngle: 35.36,
        flightDirection: FlightDirection.Ascending,
        lookingDirection: LookingDirection.Left,
        sceneEndDateTime: '2023-02-01T01:01:02.000Z',
        sceneStartDateTime: '2023-02-01T01:01:00.000Z',
        sceneCenterDateTime: '2023-02-01T01:01:01.000Z',
      },
    },
    center: {
      type: 'Point',
      coordinates: [-66.67473904120934, -27.35446666895787],
    },
    area: {
      type: 'Polygon',
      coordinates: [
        [
          [-66.79206392164848, -27.300620979817765],
          [-66.76265748962582, -27.44122412677884],
          [-66.55741416077018, -27.408312358097973],
          [-66.58682059279283, -27.267709211136896],
          [-66.79206392164848, -27.300620979817765],
        ],
      ],
    },
    bbox: [
      -66.79206392164848, -27.44122412677884, -66.55741416077018,
      -27.267709211136896,
    ],
    datetime: '2023-02-01T01:01:01.000Z',
  },
  {
    productData: { id: '23e62f2a-17b0-40b8-9767-7d16d8233c01' },
    id: '383d20a9-8d1e-4706-921a-b1ebda87d2e3',
    createdAt: '2023-02-02 02:02:02.000000+00',
    updatedAt: '2023-02-02 02:02:02.000000+00',
    latestEditorId: SystemUser.DPS_SYSTEM,
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    version: '01-PR-00-dps-20230202020202',
    sourceExpired: '2024-02-22 00:00:00.000000+00',
    bucket: 'gs://syns-daas-dev_iris-product-data-store',
    location:
      'fixtures/23e62f2a-17b0-40b8-9767-7d16d8233c01/383d20a9-8d1e-4706-921a-b1ebda87d2e3/STRIX_202302-10001_20220821T013544Z_SM_GRD_Geotiff.zip',
    quicklookBucket: 'gs://syns-daas-dev_iris-product-data-store',
    quicklookLocation:
      'fixtures/23e62f2a-17b0-40b8-9767-7d16d8233c01/383d20a9-8d1e-4706-921a-b1ebda87d2e3/STRIX_202302-10001_20220821T013544Z_SM_GRD_Geotiff_quicklook',
    quicklookContentType: 'image/jpeg',
    metadata: {
      product: {
        productSoftwareVersion: 'v007.000',
        productFormat: ProductFormat.GRD_GEOTIFF,
        dataProcessingSoftwareVersion: 'v0.10.0',
        orbitType: OrbitType.OB,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.SR,
      },
      geometry: {
        sceneCenterLocation: '-26.35446666895787 -67.67473904120934',
        sceneCornerLocations:
          '-26.300620979817765 -67.79206392164848 -26.44122412677884 -67.76265748962582 -26.408312358097973 -67.55741416077018 -26.267709211136896 -67.58682059279283 -26.300620979817765 -67.79206392164848',
      },
      observation: {
        sceneId: 'STRIX1-20230202T020202Z',
        sceneNo: 0,
        orderCode: '202302-10002',
        imagingMode: ImagingMode.Stripmap,
        satelliteId: 'ST0003',
        polarization: PolarizationType.VV,
        offnadirAngle: 40.02,
        flightDirection: FlightDirection.Descending,
        lookingDirection: LookingDirection.Right,
        sceneEndDateTime: '2023-02-02T02:02:03.000Z',
        sceneStartDateTime: '2023-02-02T02:02:01.000Z',
        sceneCenterDateTime: '2023-02-02T02:02:02.000Z',
      },
    },
    center: {
      type: 'Point',
      coordinates: [-67.67473904120934, -26.35446666895787],
    },
    area: {
      type: 'Polygon',
      coordinates: [
        [
          [-67.79206392164848, -26.300620979817765],
          [-67.76265748962582, -26.44122412677884],
          [-67.55741416077018, -26.408312358097973],
          [-67.58682059279283, -26.267709211136896],
          [-67.79206392164848, -26.300620979817765],
        ],
      ],
    },
    bbox: [
      -67.79206392164848, -26.44122412677884, -67.55741416077018,
      -26.267709211136896,
    ],
    datetime: '2023-02-02T02:02:02.000Z',
  },
  {
    productData: { id: '337dbaca-3300-4628-98ee-c7e2d9bbf08b' },
    id: '42b89352-7420-4f02-b153-e9df7660d7bd',
    createdAt: '2023-02-02 02:03:03.000000+00',
    updatedAt: '2023-02-02 02:03:03.000000+00',
    latestEditorId: SystemUser.DPS_SYSTEM,
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    version: '01-PR-00-dps-20230202020303',
    sourceExpired: '2024-02-22 00:00:00.000000+00',
    bucket: 'gs://syns-daas-dev_iris-product-data-store',
    location:
      'fixtures/337dbaca-3300-4628-98ee-c7e2d9bbf08b/42b89352-7420-4f02-b153-e9df7660d7bd/STRIX_202302-10001_20220821T013544Z_SM_SLC_CEOS.zip',
    quicklookBucket: 'gs://syns-daas-dev_iris-product-data-store',
    quicklookLocation:
      'fixtures/337dbaca-3300-4628-98ee-c7e2d9bbf08b/42b89352-7420-4f02-b153-e9df7660d7bd/STRIX_202302-10001_20220821T013544Z_SM_SLC_CEOS_quicklook',
    quicklookContentType: 'image/png',
    metadata: {
      product: {
        productSoftwareVersion: 'v007.000',
        productFormat: ProductFormat.SLC_CEOS,
        dataProcessingSoftwareVersion: 'v0.10.0',
        orbitType: OrbitType.OB,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.normal,
      },
      geometry: {
        sceneCenterLocation: '-26.35446666895787 -67.67473904120934',
        sceneCornerLocations:
          '-26.300620979817765 -67.79206392164848 -26.44122412677884 -67.76265748962582 -26.408312358097973 -67.55741416077018 -26.267709211136896 -67.58682059279283 -26.300620979817765 -67.79206392164848',
      },
      observation: {
        sceneId: 'STRIX1-20230202T020202Z',
        sceneNo: 0,
        orderCode: '202302-10002',
        imagingMode: ImagingMode.Stripmap,
        satelliteId: 'ST0003',
        polarization: PolarizationType.VV,
        offnadirAngle: 40.02,
        flightDirection: FlightDirection.Descending,
        lookingDirection: LookingDirection.Right,
        sceneEndDateTime: '2023-02-02T02:02:03.000Z',
        sceneStartDateTime: '2023-02-02T02:02:01.000Z',
        sceneCenterDateTime: '2023-02-02T02:02:02.000Z',
      },
    },
    center: {
      type: 'Point',
      coordinates: [-67.67473904120934, -26.35446666895787],
    },
    area: {
      type: 'Polygon',
      coordinates: [
        [
          [-67.79206392164848, -26.300620979817765],
          [-67.76265748962582, -26.44122412677884],
          [-67.55741416077018, -26.408312358097973],
          [-67.58682059279283, -26.267709211136896],
          [-67.79206392164848, -26.300620979817765],
        ],
      ],
    },
    bbox: [
      -67.79206392164848, -26.44122412677884, -67.55741416077018,
      -26.267709211136896,
    ],
    datetime: '2023-02-02T02:02:02.000Z',
  },
  {
    productData: { id: '4d0e8288-cdf0-4359-a2c8-83e15a063dff' },
    id: '5051dbd0-c712-4c01-a4ff-baa2f5288b1f',
    createdAt: '2023-02-03 03:03:03.000000+00',
    updatedAt: '2023-02-03 03:03:03.000000+00',
    latestEditorId: SystemUser.DPS_SYSTEM,
    organizationId: getTestAnotherOrganizationIdForFixture(),
    contractId: getTestAnotherContractIdForFixture(),
    version: '02-PR-00-dps-20230203030303',
    sourceExpired: '2024-02-23 00:00:00.000000+00',
    bucket: 'gs://syns-daas-dev_iris-product-data-store',
    location:
      'fixtures/4d0e8288-cdf0-4359-a2c8-83e15a063dff/5051dbd0-c712-4c01-a4ff-baa2f5288b1f/STRIX_202302-10001_20220821T013544Z_SM_SLC_CEOS.zip',
    quicklookBucket: 'gs://syns-daas-dev_iris-product-data-store',
    quicklookLocation:
      'fixtures/4d0e8288-cdf0-4359-a2c8-83e15a063dff/5051dbd0-c712-4c01-a4ff-baa2f5288b1f/STRIX_202302-10001_20220821T013544Z_SM_SLC_CEOS_quicklook',
    quicklookContentType: 'image/png',
    metadata: {
      product: {
        productSoftwareVersion: 'v007.000',
        productFormat: ProductFormat.GRD_GEOTIFF,
        dataProcessingSoftwareVersion: 'v0.10.0',
        orbitType: OrbitType.OB,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.normal,
      },
      geometry: {
        sceneCenterLocation: '-30.35446666895787 -70.67473904120934',
        sceneCornerLocations:
          '-30.300620979817765 -70.79206392164848 -30.44122412677884 -70.76265748962582 -30.408312358097973 -70.55741416077018 -30.267709211136896 -70.58682059279283 -30.300620979817765 -70.79206392164848',
      },
      observation: {
        sceneId: 'STRIXB-20230203T030303Z',
        sceneNo: 2,
        orderCode: '202302-10003',
        imagingMode: ImagingMode.Stripmap,
        satelliteId: 'ST0002',
        polarization: PolarizationType.VV,
        offnadirAngle: 30.55,
        flightDirection: FlightDirection.Descending,
        lookingDirection: LookingDirection.Right,
        sceneEndDateTime: '2023-02-03T03:03:04.000Z',
        sceneStartDateTime: '2023-02-03T03:03:02.000Z',
        sceneCenterDateTime: '2023-02-03T03:03:03.000Z',
      },
    },
    center: {
      type: 'Point',
      coordinates: [-70.67473904120934, -30.35446666895787],
    },
    area: {
      type: 'Polygon',
      coordinates: [
        [
          [-70.79206392164848, -30.300620979817765],
          [-70.76265748962582, -30.44122412677884],
          [-70.55741416077018, -30.408312358097973],
          [-70.58682059279283, -30.267709211136896],
          [-70.79206392164848, -30.300620979817765],
        ],
      ],
    },
    bbox: [
      -70.79206392164848, -30.44122412677884, -70.55741416077018,
      -30.267709211136896,
    ],
    datetime: '2023-02-03T03:03:03.000Z',
  },
  // for product-data-related-status
  // No need to ask for accuracy of location etc. here
  {
    productData: { id: '323b047d-54f5-44e8-8d09-cb8e5859ab17' },
    id: '9d2f5f8c-2897-4b68-a04f-b77e1d157597',
    createdAt: '2023-03-01 01:01:01.000000+00',
    updatedAt: '2023-03-01 01:01:01.000000+00',
    latestEditorId: SystemUser.DPS_SYSTEM,
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    version: '00-PR-01-dps-20230201010101',
    sourceExpired: '2024-03-20 00:00:00.000000+00',
    bucket: 'gs://syns-daas-dev_iris-product-data-store',
    location:
      'fixtures/0603e8a8-c8eb-4da0-838a-43d407dab2df/044ddb41-8c14-4b2f-b53c-d7a072106636/STRIX_202302-10002_20220821T013544Z_SM_GRD_Geotiff.zip',
    quicklookBucket: 'gs://syns-daas-dev_iris-product-data-store',
    quicklookLocation:
      'fixtures/0603e8a8-c8eb-4da0-838a-43d407dab2df/044ddb41-8c14-4b2f-b53c-d7a072106636/STRIX_202302-10002_20220821T013544Z_SM_GRD_Geotiff_quicklook',
    quicklookContentType: 'image/jpeg',
    metadata: {
      product: {
        productSoftwareVersion: 'v007.000',
        productFormat: ProductFormat.GRD_GEOTIFF,
        dataProcessingSoftwareVersion: 'v0.10.0',
        orbitType: OrbitType.PR,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.normal,
      },
      geometry: {
        sceneCenterLocation: '15.35446666895787 44.67473904120934',
        sceneCornerLocations:
          '15.300620979817765 44.79206392164848 15.44122412677884 44.76265748962582 15.408312358097973 44.55741416077018 15.267709211136896 44.58682059279283 15.300620979817765 44.79206392164848',
      },
      observation: {
        sceneId: 'STRIXB-20230201T010101Z',
        sceneNo: 1,
        orderCode: '202302-10001',
        imagingMode: ImagingMode.SlidingSpotlight,
        satelliteId: 'ST0002',
        polarization: PolarizationType.VV,
        offnadirAngle: 35.36,
        flightDirection: FlightDirection.Ascending,
        lookingDirection: LookingDirection.Left,
        sceneEndDateTime: '2023-02-01T01:01:02.000Z',
        sceneStartDateTime: '2023-02-01T01:01:00.000Z',
        sceneCenterDateTime: '2023-02-01T01:01:01.000Z',
      },
    },
    center: {
      type: 'Point',
      coordinates: [44.67473904120934, 15.35446666895787],
    },
    area: {
      type: 'Polygon',
      coordinates: [
        [
          [44.79206392164848, 15.300620979817765],
          [44.76265748962582, 15.44122412677884],
          [44.55741416077018, 15.408312358097973],
          [44.58682059279283, 15.267709211136896],
          [44.79206392164848, 15.300620979817765],
        ],
      ],
    },
    bbox: [
      44.55741416077018, 15.267709211136896, 44.79206392164848,
      15.44122412677884,
    ],
    datetime: '2023-02-01T01:01:01.000Z',
  },
  {
    productData: { id: '323b047d-54f5-44e8-8d09-cb8e5859ab17' },
    id: '5e8f8a91-4cc4-41c0-9299-94a82313e2f0',
    createdAt: '2023-03-02 01:01:01.000000+00',
    updatedAt: '2023-03-02 01:01:01.000000+00',
    latestEditorId: SystemUser.DPS_SYSTEM,
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    version: '00-PR-01-dps-20230201010101-new',
    sourceExpired: '2024-03-21 00:00:00.000000+00',
    bucket: 'gs://syns-daas-dev_iris-product-data-store',
    location:
      'fixtures/0603e8a8-c8eb-4da0-838a-43d407dab2df/1aebd2bd-efdd-4d48-aeb9-0ebd04305581/STRIX_202302-10002_20220821T013544Z_SM_GRD_Geotiff.zip',
    quicklookBucket: 'gs://syns-daas-dev_iris-product-data-store',
    quicklookLocation:
      'fixtures/0603e8a8-c8eb-4da0-838a-43d407dab2df/1aebd2bd-efdd-4d48-aeb9-0ebd04305581/STRIX_202302-10002_20220821T013544Z_SM_GRD_Geotiff_quicklook',
    quicklookContentType: 'image/jpeg',
    metadata: {
      product: {
        productSoftwareVersion: 'v007.000',
        productFormat: ProductFormat.GRD_GEOTIFF,
        dataProcessingSoftwareVersion: 'v0.10.0',
        orbitType: OrbitType.PR,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.normal,
      },
      geometry: {
        sceneCenterLocation: '15.35446666895787 44.67473904120934',
        sceneCornerLocations:
          '15.300620979817765 44.79206392164848 15.44122412677884 44.76265748962582 15.408312358097973 44.55741416077018 15.267709211136896 44.58682059279283 15.300620979817765 44.79206392164848',
      },
      observation: {
        sceneId: 'STRIXB-20230201T010101Z',
        sceneNo: 1,
        orderCode: '202302-10001',
        imagingMode: ImagingMode.SlidingSpotlight,
        satelliteId: 'ST0002',
        polarization: PolarizationType.VV,
        offnadirAngle: 35.36,
        flightDirection: FlightDirection.Ascending,
        lookingDirection: LookingDirection.Left,
        sceneEndDateTime: '2023-02-01T01:01:02.000Z',
        sceneStartDateTime: '2023-02-01T01:01:00.000Z',
        sceneCenterDateTime: '2023-02-01T01:01:01.000Z',
      },
    },
    center: {
      type: 'Point',
      coordinates: [44.67473904120934, 15.35446666895787],
    },
    area: {
      type: 'Polygon',
      coordinates: [
        [
          [44.79206392164848, 15.300620979817765],
          [44.76265748962582, 15.44122412677884],
          [44.55741416077018, 15.408312358097973],
          [44.58682059279283, 15.267709211136896],
          [44.79206392164848, 15.300620979817765],
        ],
      ],
    },
    bbox: [
      44.55741416077018, 15.267709211136896, 44.79206392164848,
      15.44122412677884,
    ],
    datetime: '2023-02-01T01:01:01.000Z',
  },
  {
    productData: { id: 'c75c09bd-9f4b-41c8-a7a7-d48f8df8e44b' },
    id: '28ce9c86-fcf9-49f9-b467-e4a8bb9e8d41',
    createdAt: '2023-02-01 01:01:01.000000+00',
    updatedAt: '2023-02-01 01:01:01.000000+00',
    latestEditorId: SystemUser.DPS_SYSTEM,
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    version: '00-PR-00-dps-20230201010101',
    sourceExpired: '2024-02-21 00:00:00.000000+00',
    bucket: 'gs://syns-daas-dev_iris-product-data-store',
    location:
      'fixtures/161a6d67-4eba-4bbc-84b6-a0f13ce2a37d/2fe11efa-8906-47e1-bdd7-c6774719e48f/STRIX_202302-10001_20220821T013544Z_SM_SLC_SICD.zip',
    quicklookBucket: 'gs://syns-daas-dev_iris-product-data-store',
    quicklookLocation:
      'fixtures/161a6d67-4eba-4bbc-84b6-a0f13ce2a37d/2fe11efa-8906-47e1-bdd7-c6774719e48f/STRIX_202302-10001_20220821T013544Z_SM_SLC_SICD_quicklook',
    quicklookContentType: 'image/jpeg',
    metadata: {
      product: {
        productSoftwareVersion: 'v007.000',
        productFormat: ProductFormat.SLC_SICD,
        dataProcessingSoftwareVersion: 'v0.10.0',
        orbitType: OrbitType.PR,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.normal,
      },
      geometry: {
        sceneCenterLocation: '15.35446666895787 44.67473904120934',
        sceneCornerLocations:
          '15.300620979817765 44.79206392164848 15.44122412677884 44.76265748962582 15.408312358097973 44.55741416077018 15.267709211136896 44.58682059279283 15.300620979817765 44.79206392164848',
      },
      observation: {
        sceneId: 'STRIXB-20230201T010101Z',
        sceneNo: 1,
        orderCode: '202302-10001',
        imagingMode: ImagingMode.SlidingSpotlight,
        satelliteId: 'ST0002',
        polarization: PolarizationType.VV,
        offnadirAngle: 35.36,
        flightDirection: FlightDirection.Ascending,
        lookingDirection: LookingDirection.Left,
        sceneEndDateTime: '2023-02-01T01:01:02.000Z',
        sceneStartDateTime: '2023-02-01T01:01:00.000Z',
        sceneCenterDateTime: '2023-02-01T01:01:01.000Z',
      },
    },
    center: {
      type: 'Point',
      coordinates: [44.67473904120934, 15.35446666895787],
    },
    area: {
      type: 'Polygon',
      coordinates: [
        [
          [44.79206392164848, 15.300620979817765],
          [44.76265748962582, 15.44122412677884],
          [44.55741416077018, 15.408312358097973],
          [44.58682059279283, 15.267709211136896],
          [44.79206392164848, 15.300620979817765],
        ],
      ],
    },
    bbox: [
      44.55741416077018, 15.267709211136896, 44.79206392164848,
      15.44122412677884,
    ],
    datetime: '2023-02-01T01:01:01.000Z',
  },
  {
    productData: { id: '496c6c8a-4b10-4d1e-80ff-d41bc253ae46' },
    id: 'e8f348f8-ee26-4643-9dc6-b7550bb6924e',
    createdAt: '2022-12-31 01:01:01.100000+00',
    updatedAt: '2022-12-31 01:01:01.100000+00',
    latestEditorId: SystemUser.DPS_SYSTEM,
    organizationId: SystemOrganization.NO_ORGANIZATION,
    contractId: SystemContract.NO_CONTRACT,
    version: '00-PR-21-dps-20230401010101',
    sourceExpired: '2024-01-20 00:00:00.000000+00',
    bucket: 'gs://syns-daas-dev_iris-product-data-store',
    location:
      'fixtures/496c6c8a-4b10-4d1e-80ff-d41bc253ae46/e8f348f8-ee26-4643-9dc6-b7550bb6924e/STRIX_202302-10001_20220821T013544Z_SM_GRD_Geotiff.zip',
    quicklookBucket: 'gs://syns-daas-dev_iris-product-data-store',
    quicklookLocation:
      'fixtures/496c6c8a-4b10-4d1e-80ff-d41bc253ae46/e8f348f8-ee26-4643-9dc6-b7550bb6924e/STRIX_202302-10001_20220821T013544Z_SM_GRD_Geotiff_quicklook',
    quicklookContentType: 'image/jpeg',
    metadata: {
      product: {
        productSoftwareVersion: 'v007.000',
        productFormat: ProductFormat.GRD_GEOTIFF,
        dataProcessingSoftwareVersion: 'v0.10.0',
        orbitType: OrbitType.PR,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.normal,
      },
      geometry: {
        sceneCenterLocation: '15.35446666895787 44.67473904120934',
        sceneCornerLocations:
          '15.300620979817765 44.79206392164848 15.44122412677884 44.76265748962582 15.408312358097973 44.55741416077018 15.267709211136896 44.58682059279283 15.300620979817765 44.79206392164848',
      },
      observation: {
        sceneId: 'STRIX1-20230401T010101Z',
        sceneNo: 1,
        orderCode: '202302-10001',
        imagingMode: ImagingMode.Stripmap,
        satelliteId: 'ST0003',
        polarization: PolarizationType.VV,
        offnadirAngle: 40,
        flightDirection: FlightDirection.Descending,
        lookingDirection: LookingDirection.Left,
        sceneEndDateTime: '2022-12-31T01:01:02.000Z',
        sceneStartDateTime: '2022-12-31T01:01:00.000Z',
        sceneCenterDateTime: '2022-12-31T01:01:01.000Z',
      },
    },
    center: {
      type: 'Point',
      coordinates: [15.35446666895787, 44.67473904120934],
    },
    area: {
      type: 'Polygon',
      coordinates: [
        [
          [15.300620979817765, 44.79206392164848],
          [15.44122412677884, 44.76265748962582],
          [15.408312358097973, 44.55741416077018],
          [15.267709211136896, 44.58682059279283],
          [15.300620979817765, 44.79206392164848],
        ],
      ],
    },
    bbox: [
      15.267709211136896, 44.55741416077018, 15.44122412677884,
      44.79206392164848,
    ],
    datetime: '2022-12-31T01:01:01.000Z',
  },
  {
    productData: { id: '51bfb25f-7a74-4fba-b7a1-bec6a1707bbc' },
    id: '91b6a996-3582-466c-a527-4b26af9ab5cc',
    createdAt: '2022-12-31 01:01:01.200000+00',
    updatedAt: '2022-12-31 01:01:01.200000+00',
    latestEditorId: SystemUser.DPS_SYSTEM,
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    version: '00-PR-21-dps-20230401010101',
    sourceExpired: '2024-01-20 00:00:00.000000+00',
    bucket: 'gs://syns-daas-dev_iris-product-data-store',
    location:
      'fixtures/51bfb25f-7a74-4fba-b7a1-bec6a1707bbc/91b6a996-3582-466c-a527-4b26af9ab5cc/STRIX_202302-10001_20220821T013544Z_SM_SLC_SICD.zip',
    quicklookBucket: 'gs://syns-daas-dev_iris-product-data-store',
    quicklookLocation:
      'fixtures/51bfb25f-7a74-4fba-b7a1-bec6a1707bbc/91b6a996-3582-466c-a527-4b26af9ab5cc/STRIX_202302-10001_20220821T013544Z_SM_SLC_SICD_quicklook',
    quicklookContentType: 'image/jpeg',
    metadata: {
      product: {
        productSoftwareVersion: 'v007.000',
        productFormat: ProductFormat.SLC_SICD,
        dataProcessingSoftwareVersion: 'v0.10.0',
        orbitType: OrbitType.PR,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.normal,
      },
      geometry: {
        sceneCenterLocation: '15.35446666895787 44.67473904120934',
        sceneCornerLocations:
          '15.300620979817765 44.79206392164848 15.44122412677884 44.76265748962582 15.408312358097973 44.55741416077018 15.267709211136896 44.58682059279283 15.300620979817765 44.79206392164848',
      },
      observation: {
        sceneId: 'STRIX1-20230401T010101Z',
        sceneNo: 1,
        orderCode: '202302-10001',
        imagingMode: ImagingMode.Stripmap,
        satelliteId: 'ST0003',
        polarization: PolarizationType.VV,
        offnadirAngle: 40,
        flightDirection: FlightDirection.Descending,
        lookingDirection: LookingDirection.Left,
        sceneEndDateTime: '2022-12-31T01:01:02.000Z',
        sceneStartDateTime: '2022-12-31T01:01:00.000Z',
        sceneCenterDateTime: '2022-12-31T01:01:01.000Z',
      },
    },
    center: {
      type: 'Point',
      coordinates: [15.35446666895787, 44.67473904120934],
    },
    area: {
      type: 'Polygon',
      coordinates: [
        [
          [15.300620979817765, 44.79206392164848],
          [15.44122412677884, 44.76265748962582],
          [15.408312358097973, 44.55741416077018],
          [15.267709211136896, 44.58682059279283],
          [15.300620979817765, 44.79206392164848],
        ],
      ],
    },
    bbox: [
      15.267709211136896, 44.55741416077018, 15.44122412677884,
      44.79206392164848,
    ],
    datetime: '2022-12-31T01:01:01.000Z',
  },
  {
    productData: { id: '2365c2a9-0e20-4378-a3e3-de21fc45af3d' },
    id: 'e891a198-6661-44de-8b4f-148e24540dbe',
    createdAt: '2022-12-31 01:01:01.300000+00',
    updatedAt: '2022-12-31 01:01:01.300000+00',
    latestEditorId: SystemUser.DPS_SYSTEM,
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    version: '00-PR-21-dps-20230401010101',
    sourceExpired: '2024-01-20 00:00:00.000000+00',
    bucket: 'gs://syns-daas-dev_iris-product-data-store',
    location:
      'fixtures/2365c2a9-0e20-4378-a3e3-de21fc45af3d/e891a198-6661-44de-8b4f-148e24540dbe/STRIX_202302-10001_20220821T013544Z_SM_SLC_CEOS.zip',
    quicklookBucket: 'gs://syns-daas-dev_iris-product-data-store',
    quicklookLocation:
      'fixtures/2365c2a9-0e20-4378-a3e3-de21fc45af3d/e891a198-6661-44de-8b4f-148e24540dbe/STRIX_202302-10001_20220821T013544Z_SM_SLC_CEOS_quicklook',
    quicklookContentType: 'image/jpeg',
    metadata: {
      product: {
        productSoftwareVersion: 'v007.000',
        productFormat: ProductFormat.SLC_CEOS,
        dataProcessingSoftwareVersion: 'v0.10.0',
        orbitType: OrbitType.PR,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.normal,
      },
      geometry: {
        sceneCenterLocation: '15.35446666895787 44.67473904120934',
        sceneCornerLocations:
          '15.300620979817765 44.79206392164848 15.44122412677884 44.76265748962582 15.408312358097973 44.55741416077018 15.267709211136896 44.58682059279283 15.300620979817765 44.79206392164848',
      },
      observation: {
        sceneId: 'STRIX1-20230401T010101Z',
        sceneNo: 1,
        orderCode: '202302-10001',
        imagingMode: ImagingMode.Stripmap,
        satelliteId: 'ST0003',
        polarization: PolarizationType.VV,
        offnadirAngle: 40,
        flightDirection: FlightDirection.Descending,
        lookingDirection: LookingDirection.Left,
        sceneEndDateTime: '2022-12-31T01:01:02.000Z',
        sceneStartDateTime: '2022-12-31T01:01:00.000Z',
        sceneCenterDateTime: '2022-12-31T01:01:01.000Z',
      },
    },
    center: {
      type: 'Point',
      coordinates: [15.35446666895787, 44.67473904120934],
    },
    area: {
      type: 'Polygon',
      coordinates: [
        [
          [15.300620979817765, 44.79206392164848],
          [15.44122412677884, 44.76265748962582],
          [15.408312358097973, 44.55741416077018],
          [15.267709211136896, 44.58682059279283],
          [15.300620979817765, 44.79206392164848],
        ],
      ],
    },
    bbox: [
      15.267709211136896, 44.55741416077018, 15.44122412677884,
      44.79206392164848,
    ],
    datetime: '2022-12-31T01:01:01.000Z',
  },
  {
    productData: { id: 'ac48a143-e872-41b8-a361-93e5cb9732b0' },
    id: 'c4c769f7-fa74-4f49-a863-8789316e38d1',
    createdAt: '2022-12-31 01:01:01.400000+00',
    updatedAt: '2022-12-31 01:01:01.400000+00',
    latestEditorId: SystemUser.DPS_SYSTEM,
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    version: '00-PR-22-dps-20230401010101',
    sourceExpired: '2024-01-20 00:00:00.000000+00',
    bucket: 'gs://syns-daas-dev_iris-product-data-store',
    location:
      'fixtures/ac48a143-e872-41b8-a361-93e5cb9732b0/c4c769f7-fa74-4f49-a863-8789316e38d1/STRIX_202302-10001_20220821T013544Z_SM_SLC_SICD.zip',
    quicklookBucket: 'gs://syns-daas-dev_iris-product-data-store',
    quicklookLocation:
      'fixtures/ac48a143-e872-41b8-a361-93e5cb9732b0/c4c769f7-fa74-4f49-a863-8789316e38d1/STRIX_202302-10001_20220821T013544Z_SM_SLC_SICD_quicklook',
    quicklookContentType: 'image/jpeg',
    metadata: {
      product: {
        productSoftwareVersion: 'v007.000',
        productFormat: ProductFormat.SLC_SICD,
        dataProcessingSoftwareVersion: 'v0.10.0',
        orbitType: OrbitType.PR,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.normal,
      },
      geometry: {
        sceneCenterLocation: '15.35446666895787 44.67473904120934',
        sceneCornerLocations:
          '15.300620979817765 44.79206392164848 15.44122412677884 44.76265748962582 15.408312358097973 44.55741416077018 15.267709211136896 44.58682059279283 15.300620979817765 44.79206392164848',
      },
      observation: {
        sceneId: 'STRIX1-20230401T020202Z',
        sceneNo: 2,
        orderCode: '202302-10001',
        imagingMode: ImagingMode.Stripmap,
        satelliteId: 'ST0003',
        polarization: PolarizationType.VV,
        offnadirAngle: 40,
        flightDirection: FlightDirection.Descending,
        lookingDirection: LookingDirection.Left,
        sceneEndDateTime: '2022-12-31T02:02:03.000Z',
        sceneStartDateTime: '2022-12-31T02:02:01.000Z',
        sceneCenterDateTime: '2022-12-31T02:02:02.000Z',
      },
    },
    center: {
      type: 'Point',
      coordinates: [15.35446666895787, 44.67473904120934],
    },
    area: {
      type: 'Polygon',
      coordinates: [
        [
          [15.300620979817765, 44.79206392164848],
          [15.44122412677884, 44.76265748962582],
          [15.408312358097973, 44.55741416077018],
          [15.267709211136896, 44.58682059279283],
          [15.300620979817765, 44.79206392164848],
        ],
      ],
    },
    bbox: [
      15.267709211136896, 44.55741416077018, 15.44122412677884,
      44.79206392164848,
    ],
    datetime: '2022-12-31T02:02:02.000Z',
  },
  {
    productData: { id: '6ddfc361-60fc-403e-b424-eeb79f61b8ee' },
    id: 'ae649ec4-4007-4004-a832-ce4cab1b93c1',
    createdAt: '2022-12-31 01:01:01.500000+00',
    updatedAt: '2022-12-31 01:01:01.500000+00',
    latestEditorId: SystemUser.DPS_SYSTEM,
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    version: '00-PR-22-dps-20230401010101',
    sourceExpired: '2024-01-20 00:00:00.000000+00',
    bucket: 'gs://syns-daas-dev_iris-product-data-store',
    location:
      'fixtures/6ddfc361-60fc-403e-b424-eeb79f61b8ee/ae649ec4-4007-4004-a832-ce4cab1b93c1/STRIX_202302-10001_20220821T013544Z_SM_SLC_CEOS.zip',
    quicklookBucket: 'gs://syns-daas-dev_iris-product-data-store',
    quicklookLocation:
      'fixtures/6ddfc361-60fc-403e-b424-eeb79f61b8ee/ae649ec4-4007-4004-a832-ce4cab1b93c1/STRIX_202302-10001_20220821T013544Z_SM_SLC_CEOS_quicklook',
    quicklookContentType: 'image/jpeg',
    metadata: {
      product: {
        productSoftwareVersion: 'v007.000',
        productFormat: ProductFormat.SLC_CEOS,
        dataProcessingSoftwareVersion: 'v0.10.0',
        orbitType: OrbitType.PR,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.normal,
      },
      geometry: {
        sceneCenterLocation: '15.35446666895787 44.67473904120934',
        sceneCornerLocations:
          '15.300620979817765 44.79206392164848 15.44122412677884 44.76265748962582 15.408312358097973 44.55741416077018 15.267709211136896 44.58682059279283 15.300620979817765 44.79206392164848',
      },
      observation: {
        sceneId: 'STRIX1-20230401T020202Z',
        sceneNo: 2,
        orderCode: '202302-10001',
        imagingMode: ImagingMode.Stripmap,
        satelliteId: 'ST0003',
        polarization: PolarizationType.VV,
        offnadirAngle: 40,
        flightDirection: FlightDirection.Descending,
        lookingDirection: LookingDirection.Left,
        sceneEndDateTime: '2022-12-31T02:02:03.000Z',
        sceneStartDateTime: '2022-12-31T02:02:01.000Z',
        sceneCenterDateTime: '2022-12-31T02:02:02.000Z',
      },
    },
    center: {
      type: 'Point',
      coordinates: [15.35446666895787, 44.67473904120934],
    },
    area: {
      type: 'Polygon',
      coordinates: [
        [
          [15.300620979817765, 44.79206392164848],
          [15.44122412677884, 44.76265748962582],
          [15.408312358097973, 44.55741416077018],
          [15.267709211136896, 44.58682059279283],
          [15.300620979817765, 44.79206392164848],
        ],
      ],
    },
    bbox: [
      15.267709211136896, 44.55741416077018, 15.44122412677884,
      44.79206392164848,
    ],
    datetime: '2022-12-31T02:02:02.000Z',
  },
  {
    productData: { id: 'e5000001-9f4b-41c8-a7a7-d48f8df8e44b' },
    id: 'c0100001-fcf9-49f9-b467-e4a8bb9e8d41',
    createdAt: '2023-04-05 03:01:01.000000+00',
    updatedAt: '2023-04-05 03:01:01.000000+00',
    latestEditorId: SystemUser.DPS_SYSTEM,
    organizationId: getTestAnotherOrganizationIdForFixture(),
    contractId: getTestAnotherContractIdForFixture(),
    version: '00-PR-00-dps-20230201010101',
    sourceExpired: '2024-04-22 00:00:00.000000+00',
    bucket: 'gs://syns-daas-dev_iris-product-data-store',
    location:
      'fixtures/161a6d67-4eba-4bbc-84b6-a0f13ce2a37d/2fe11efa-8906-47e1-bdd7-c6774719e48f/STRIX_202302-10001_20220821T013544Z_SM_SLC_SICD.zip',
    quicklookBucket: 'gs://syns-daas-dev_iris-product-data-store',
    quicklookLocation:
      'fixtures/161a6d67-4eba-4bbc-84b6-a0f13ce2a37d/2fe11efa-8906-47e1-bdd7-c6774719e48f/STRIX_202302-10001_20220821T013544Z_SM_SLC_SICD_quicklook',
    quicklookContentType: 'image/jpeg',
    metadata: {
      product: {
        productSoftwareVersion: '0.13.1', //dps team sets dpsVersion to psVersion for SLC_SICD
        productFormat: ProductFormat.SLC_SICD,
        dataProcessingSoftwareVersion: '0.13.1',
        orbitType: OrbitType.PR,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.normal,
      },
      geometry: {
        sceneCenterLocation: '15.35446666895787 44.67473904120934',
        sceneCornerLocations:
          '15.300620979817765 44.79206392164848 15.44122412677884 44.76265748962582 15.408312358097973 44.55741416077018 15.267709211136896 44.58682059279283 15.300620979817765 44.79206392164848',
      },
      observation: {
        sceneId: 'STRIXB-20231201T010101Z',
        sceneNo: 2,
        orderCode: '202312-12001',
        imagingMode: ImagingMode.Stripmap,
        satelliteId: 'ST0002',
        polarization: PolarizationType.VV,
        offnadirAngle: 43.01,
        flightDirection: FlightDirection.Descending,
        lookingDirection: LookingDirection.Right,
        sceneEndDateTime: '2023-12-01T01:01:02.000Z',
        sceneStartDateTime: '2023-12-01T01:01:00.000Z',
        sceneCenterDateTime: '2023-12-01T01:01:01.000Z',
      },
    },
    center: {
      type: 'Point',
      coordinates: [44.67473904120934, 15.35446666895787],
    },
    area: {
      type: 'Polygon',
      coordinates: [
        [
          [44.79206392164848, 15.300620979817765],
          [44.76265748962582, 15.44122412677884],
          [44.55741416077018, 15.408312358097973],
          [44.58682059279283, 15.267709211136896],
          [44.79206392164848, 15.300620979817765],
        ],
      ],
    },
    bbox: [
      44.55741416077018, 15.267709211136896, 44.79206392164848,
      15.44122412677884,
    ],
    datetime: '2023-01-01T01:01:01.000Z',
  },
  {
    productData: { id: 'e5000001-9f4b-41c8-a7a7-d48f8df8e44b' },
    id: 'c0200001-fcf9-49f9-b467-e4a8bb9e8d41',
    createdAt: '2023-04-15 03:01:01.000000+00',
    updatedAt: '2023-04-15 03:01:01.000000+00',
    latestEditorId: SystemUser.DPS_SYSTEM,
    organizationId: SystemOrganization.NO_ORGANIZATION,
    contractId: SystemContract.NO_CONTRACT,
    version: '00-PR-00-dps-20230201010101',
    sourceExpired: '2024-04-22 00:00:00.000000+00',
    bucket: 'gs://syns-daas-dev_iris-product-data-store',
    location:
      'fixtures/161a6d67-4eba-4bbc-84b6-a0f13ce2a37d/2fe11efa-8906-47e1-bdd7-c6774719e48f/STRIX_202302-10001_20220821T013544Z_SM_SLC_SICD.zip',
    quicklookBucket: 'gs://syns-daas-dev_iris-product-data-store',
    quicklookLocation:
      'fixtures/161a6d67-4eba-4bbc-84b6-a0f13ce2a37d/2fe11efa-8906-47e1-bdd7-c6774719e48f/STRIX_202302-10001_20220821T013544Z_SM_SLC_SICD_quicklook',
    quicklookContentType: 'image/jpeg',
    metadata: {
      product: {
        productSoftwareVersion: '0.13.1', //dps team sets dpsVersion to psVersion for SLC_SICD
        productFormat: ProductFormat.SLC_SICD,
        dataProcessingSoftwareVersion: '0.13.1',
        orbitType: OrbitType.PR,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.normal,
      },
      geometry: {
        sceneCenterLocation: '15.35446666895787 44.67473904120934',
        sceneCornerLocations:
          '15.300620979817765 44.79206392164848 15.44122412677884 44.76265748962582 15.408312358097973 44.55741416077018 15.267709211136896 44.58682059279283 15.300620979817765 44.79206392164848',
      },
      observation: {
        sceneId: 'STRIXB-20231201T010101Z',
        sceneNo: 2,
        orderCode: '202312-12001',
        imagingMode: ImagingMode.Stripmap,
        satelliteId: 'ST0002',
        polarization: PolarizationType.VV,
        offnadirAngle: 43.01,
        flightDirection: FlightDirection.Descending,
        lookingDirection: LookingDirection.Right,
        sceneEndDateTime: '2023-12-01T01:01:02.000Z',
        sceneStartDateTime: '2023-12-01T01:01:00.000Z',
        sceneCenterDateTime: '2023-12-01T01:01:01.000Z',
      },
    },
    center: {
      type: 'Point',
      coordinates: [44.67473904120934, 15.35446666895787],
    },
    area: {
      type: 'Polygon',
      coordinates: [
        [
          [44.79206392164848, 15.300620979817765],
          [44.76265748962582, 15.44122412677884],
          [44.55741416077018, 15.408312358097973],
          [44.58682059279283, 15.267709211136896],
          [44.79206392164848, 15.300620979817765],
        ],
      ],
    },
    bbox: [
      44.55741416077018, 15.267709211136896, 44.79206392164848,
      15.44122412677884,
    ],
    datetime: '2023-01-01T01:01:01.000Z',
  },
  {
    productData: { id: 'e5000002-9f4b-41c8-a7a7-d48f8df8e44b' },
    id: 'c0100002-fcf9-49f9-b467-e4a8bb9e8d41',
    createdAt: '2023-04-04 02:01:01.000000+00',
    updatedAt: '2023-04-04 02:01:01.000000+00', //older than c0100001
    latestEditorId: SystemUser.DPS_SYSTEM,
    organizationId: getTestAnotherOrganizationIdForFixture(),
    contractId: getTestAnotherContractIdForFixture(),
    version: '00-PR-01-dps-20230201010101-new',
    sourceExpired: '2024-04-22 00:00:00.000000+00',
    bucket: 'gs://syns-daas-dev_iris-product-data-store',
    location:
      'fixtures/0603e8a8-c8eb-4da0-838a-43d407dab2df/1aebd2bd-efdd-4d48-aeb9-0ebd04305581/STRIX_202302-10002_20220821T013544Z_SM_GRD_Geotiff.zip',
    quicklookBucket: 'gs://syns-daas-dev_iris-product-data-store',
    quicklookLocation:
      'fixtures/0603e8a8-c8eb-4da0-838a-43d407dab2df/1aebd2bd-efdd-4d48-aeb9-0ebd04305581/STRIX_202302-10002_20220821T013544Z_SM_GRD_Geotiff_quicklook',
    quicklookContentType: 'image/jpeg',
    metadata: {
      product: {
        productSoftwareVersion: '011.000',
        productFormat: ProductFormat.GRD_GEOTIFF,
        dataProcessingSoftwareVersion: '0.13.1',
        orbitType: OrbitType.PR,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.normal,
      },
      geometry: {
        sceneCenterLocation: '15.35446666895787 44.67473904120934',
        sceneCornerLocations:
          '15.300620979817765 44.79206392164848 15.44122412677884 44.76265748962582 15.408312358097973 44.55741416077018 15.267709211136896 44.58682059279283 15.300620979817765 44.79206392164848',
      },
      observation: {
        sceneId: 'STRIXB-20231201T010101Z',
        sceneNo: 2,
        orderCode: '202312-12001',
        imagingMode: ImagingMode.Stripmap,
        satelliteId: 'ST0002',
        polarization: PolarizationType.VV,
        offnadirAngle: 43.01,
        flightDirection: FlightDirection.Descending,
        lookingDirection: LookingDirection.Right,
        sceneEndDateTime: '2023-12-01T01:01:02.000Z',
        sceneStartDateTime: '2023-12-01T01:01:00.000Z',
        sceneCenterDateTime: '2023-12-01T01:01:01.000Z',
      },
    },
    center: {
      type: 'Point',
      coordinates: [44.67473904120934, 15.35446666895787],
    },
    area: {
      type: 'Polygon',
      coordinates: [
        [
          [44.79206392164848, 15.300620979817765],
          [44.76265748962582, 15.44122412677884],
          [44.55741416077018, 15.408312358097973],
          [44.58682059279283, 15.267709211136896],
          [44.79206392164848, 15.300620979817765],
        ],
      ],
    },
    bbox: [
      44.55741416077018, 15.267709211136896, 44.79206392164848,
      15.44122412677884,
    ],
    datetime: '2023-01-01T01:01:01.000Z',
  },
  {
    productData: { id: 'e5000003-9f4b-41c8-a7a7-d48f8df8e44b' },
    id: 'c0100003-fcf9-49f9-b467-e4a8bb9e8d41',
    createdAt: '2023-04-04 02:00:01.000000+00',
    updatedAt: '2023-04-04 02:00:01.000000+00', //older than c0100002
    latestEditorId: SystemUser.DPS_SYSTEM,
    organizationId: getTestAnotherOrganizationIdForFixture(),
    contractId: getTestAnotherContractIdForFixture(),
    version: '01-PR-00-dps-20230202020202',
    sourceExpired: '2024-04-22 00:00:00.000000+00',
    bucket: 'gs://syns-daas-dev_iris-product-data-store',
    location:
      'fixtures/23e62f2a-17b0-40b8-9767-7d16d8233c01/383d20a9-8d1e-4706-921a-b1ebda87d2e3/STRIX_202302-10001_20220821T013544Z_SM_GRD_Geotiff.zip',
    quicklookBucket: 'gs://syns-daas-dev_iris-product-data-store',
    quicklookLocation:
      'fixtures/23e62f2a-17b0-40b8-9767-7d16d8233c01/383d20a9-8d1e-4706-921a-b1ebda87d2e3/STRIX_202302-10001_20220821T013544Z_SM_GRD_Geotiff_quicklook',
    quicklookContentType: 'image/jpeg',
    metadata: {
      product: {
        productSoftwareVersion: '011.000',
        productFormat: ProductFormat.GRD_GEOTIFF,
        dataProcessingSoftwareVersion: '0.13.1',
        orbitType: OrbitType.OB,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.SR,
      },
      geometry: {
        sceneCenterLocation: '-26.35446666895787 -67.67473904120934',
        sceneCornerLocations:
          '-26.300620979817765 -67.79206392164848 -26.44122412677884 -67.76265748962582 -26.408312358097973 -67.55741416077018 -26.267709211136896 -67.58682059279283 -26.300620979817765 -67.79206392164848',
      },
      observation: {
        sceneId: 'STRIXB-20231201T010101Z',
        sceneNo: 2,
        orderCode: '202312-12001',
        imagingMode: ImagingMode.Stripmap,
        satelliteId: 'ST0002',
        polarization: PolarizationType.VV,
        offnadirAngle: 43.01,
        flightDirection: FlightDirection.Descending,
        lookingDirection: LookingDirection.Right,
        sceneEndDateTime: '2023-12-01T01:01:02.000Z',
        sceneStartDateTime: '2023-12-01T01:01:00.000Z',
        sceneCenterDateTime: '2023-12-01T01:01:01.000Z',
      },
    },
    center: {
      type: 'Point',
      coordinates: [-67.67473904120934, -26.35446666895787],
    },
    area: {
      type: 'Polygon',
      coordinates: [
        [
          [-67.79206392164848, -26.300620979817765],
          [-67.76265748962582, -26.44122412677884],
          [-67.55741416077018, -26.408312358097973],
          [-67.58682059279283, -26.267709211136896],
          [-67.79206392164848, -26.300620979817765],
        ],
      ],
    },
    bbox: [
      -67.79206392164848, -26.44122412677884, -67.55741416077018,
      -26.267709211136896,
    ],
    datetime: '2023-01-02T02:02:02.000Z',
  },
  {
    productData: { id: 'e5000021-9f4b-41c8-a7a7-d48f8df8e44b' },
    id: 'c0100021-fcf9-49f9-b467-e4a8bb9e8d41',
    createdAt: '2023-04-05 01:05:01.000000+00',
    updatedAt: '2023-04-05 01:05:01.000000+00', //older than c0200001
    latestEditorId: SystemUser.DPS_SYSTEM,
    organizationId: getTestAnotherOrganizationIdForFixture(),
    contractId: getTestAnotherContractIdForFixture(),
    version: '00-PR-01-dps-20230201010101-new',
    sourceExpired: '2024-04-22 00:00:00.000000+00',
    bucket: 'gs://syns-daas-dev_iris-product-data-store',
    location:
      'fixtures/0603e8a8-c8eb-4da0-838a-43d407dab2df/1aebd2bd-efdd-4d48-aeb9-0ebd04305581/STRIX_202302-10002_20220821T013544Z_SM_GRD_Geotiff.zip',
    quicklookBucket: 'gs://syns-daas-dev_iris-product-data-store',
    quicklookLocation:
      'fixtures/0603e8a8-c8eb-4da0-838a-43d407dab2df/1aebd2bd-efdd-4d48-aeb9-0ebd04305581/STRIX_202302-10002_20220821T013544Z_SM_GRD_Geotiff_quicklook',
    quicklookContentType: 'image/jpeg',
    metadata: {
      product: {
        productSoftwareVersion: '011.000',
        productFormat: ProductFormat.GRD_GEOTIFF,
        dataProcessingSoftwareVersion: '0.13.1',
        orbitType: OrbitType.PR,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.normal,
      },
      geometry: {
        sceneCenterLocation: '15.35446666895787 44.67473904120934',
        sceneCornerLocations:
          '15.300620979817765 44.79206392164848 15.44122412677884 44.76265748962582 15.408312358097973 44.55741416077018 15.267709211136896 44.58682059279283 15.300620979817765 44.79206392164848',
      },
      observation: {
        sceneId: 'STRIXB-20231202T010101Z',
        sceneNo: 2,
        orderCode: '202312-12002',
        imagingMode: ImagingMode.Stripmap,
        satelliteId: 'ST0002',
        polarization: PolarizationType.VV,
        offnadirAngle: 43.01,
        flightDirection: FlightDirection.Descending,
        lookingDirection: LookingDirection.Right,
        sceneEndDateTime: '2023-12-02T01:02:02.000Z',
        sceneStartDateTime: '2023-12-02T01:02:00.000Z',
        sceneCenterDateTime: '2023-12-02T01:02:01.000Z',
      },
    },
    center: {
      type: 'Point',
      coordinates: [44.67473904120934, 15.35446666895787],
    },
    area: {
      type: 'Polygon',
      coordinates: [
        [
          [44.79206392164848, 15.300620979817765],
          [44.76265748962582, 15.44122412677884],
          [44.55741416077018, 15.408312358097973],
          [44.58682059279283, 15.267709211136896],
          [44.79206392164848, 15.300620979817765],
        ],
      ],
    },
    bbox: [
      44.55741416077018, 15.267709211136896, 44.79206392164848,
      15.44122412677884,
    ],
    datetime: '2023-01-01T01:01:01.000Z',
  },
  {
    productData: { id: '14b18ed8-f691-4913-1af8-4266054f251a' },
    id: '119d91f5-5c85-44bf-8196-bc26011e1b9f',
    createdAt: '2024-03-01 01:01:01.000000+00',
    updatedAt: '2024-03-01 01:01:01.000000+00',
    latestEditorId: SystemUser.DPS_SYSTEM,
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    version: '00-PR-01-dps-20230201010101',
    sourceExpired: '2024-03-20 00:00:00.000000+00',
    bucket: 'gs://syns-daas-dev_iris-product-data-store',
    location:
      'fixtures/14b18ed8-f691-4913-1af8-4266054f251a/119d91f5-5c85-44bf-8196-bc26011e1b9f/STRIX_202302-10002_20220821T013544Z_SM_ORT_Geotiff.zip',
    quicklookBucket: 'gs://syns-daas-dev_iris-product-data-store',
    quicklookLocation:
      'fixtures/14b18ed8-f691-4913-1af8-4266054f251a/119d91f5-5c85-44bf-8196-bc26011e1b9f/STRIX_202302-10002_20220821T013544Z_SM_ORT_Geotiff_quicklook',
    quicklookContentType: 'image/jpeg',
    metadata: {
      product: {
        productSoftwareVersion: 'v007.000',
        productFormat: ProductFormat.ORT_GEOTIFF,
        dataProcessingSoftwareVersion: 'v0.10.0',
        orbitType: OrbitType.PR,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.normal,
      },
      geometry: {
        sceneCenterLocation: '-27.35446666895787 -66.67473904120934',
        sceneCornerLocations:
          '-17.300620979817765 -56.79206392164848 -17.44122412677884 -56.76265748962582 -17.408312358097973 -56.55741416077018 -17.267709211136896 -56.58682059279283 -17.300620979817765 -56.79206392164848',
      },
      observation: {
        sceneId: 'STRIXB-20230201T010101Z',
        sceneNo: 1,
        orderCode: '202402-10001',
        imagingMode: ImagingMode.SlidingSpotlight,
        satelliteId: 'ST0002',
        polarization: PolarizationType.VV,
        offnadirAngle: 35.36,
        flightDirection: FlightDirection.Ascending,
        lookingDirection: LookingDirection.Left,
        sceneEndDateTime: '2024-02-01T01:01:02.000Z',
        sceneStartDateTime: '2024-02-01T01:01:00.000Z',
        sceneCenterDateTime: '2024-02-01T01:01:01.000Z',
      },
    },
    center: {
      type: 'Point',
      coordinates: [-56.67473904120934, -17.35446666895787],
    },
    area: {
      type: 'Polygon',
      coordinates: [
        [
          [-56.79206392164848, -17.300620979817765],
          [-56.76265748962582, -17.44122412677884],
          [-56.55741416077018, -17.408312358097973],
          [-56.58682059279283, -17.267709211136896],
          [-56.79206392164848, -17.300620979817765],
        ],
      ],
    },
    bbox: [
      -56.79206392164848, -17.44122412677884, -56.55741416077018,
      -17.267709211136896,
    ],
    datetime: '2023-02-01T01:01:01.000Z',
  },
];
export const fixtureProductDataVersionsArchive: Array<
  DeepPartial<ProductDataVersionForTest>
> = [
  {
    productData: { id: 'e5000031-9f4b-41c8-a7a7-d48f8df8e44b' },
    id: 'c0100031-fcf9-49f9-b467-e4a8bb9e8d41',
    createdAt: '2023-06-05 01:05:01.000000+00',
    updatedAt: '2023-06-05 01:05:01.000000+00', //within 1 year from test fake date
    latestEditorId: SystemUser.DPS_SYSTEM,
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    version: '00-PR-01-dps-20230201010101-new',
    sourceExpired: '2024-06-05 01:05:01.000000+00', //should be longer than apr.downloadExpired
    bucket: 'gs://syns-daas-dev_iris-product-data-store',
    location:
      'fixtures/0603e8a8-c8eb-4da0-838a-43d407dab2df/1aebd2bd-efdd-4d48-aeb9-0ebd04305581/STRIX_202302-10002_20220821T013544Z_SM_GRD_Geotiff.zip',
    quicklookBucket: 'gs://syns-daas-dev_iris-product-data-store',
    quicklookLocation:
      'fixtures/0603e8a8-c8eb-4da0-838a-43d407dab2df/1aebd2bd-efdd-4d48-aeb9-0ebd04305581/STRIX_202302-10002_20220821T013544Z_SM_GRD_Geotiff_quicklook',
    quicklookContentType: 'image/jpeg',
    metadata: {
      product: {
        productSoftwareVersion: '011.000',
        productFormat: ProductFormat.GRD_GEOTIFF,
        dataProcessingSoftwareVersion: '0.13.1',
        orbitType: OrbitType.PR,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.normal,
      },
      geometry: {
        sceneCenterLocation: '15.35446666895787 44.67473904120934',
        sceneCornerLocations:
          '15.0 45.0 15.44122412677884 44.76265748962582 15.408312358097973 44.55741416077018 15.267709211136896 44.58682059279283 15.0 45.0',
      },
      observation: {
        sceneId: 'STRIXB-20231202T010101Z',
        sceneNo: 1,
        orderCode: '202312-12003',
        imagingMode: ImagingMode.Stripmap,
        satelliteId: 'ST0002',
        polarization: PolarizationType.VV,
        offnadirAngle: 35.36,
        flightDirection: FlightDirection.Descending,
        lookingDirection: LookingDirection.Left,
        sceneEndDateTime: '2023-3-02T01:02:02.000Z',
        sceneStartDateTime: '2023-3-02T01:02:00.000Z',
        sceneCenterDateTime: '2023-3-02T01:02:01.000Z',
      },
    },
    center: {
      type: 'Point',
      coordinates: [44.67473904120934, 15.35446666895787],
    },
    area: {
      type: 'Polygon',
      coordinates: [
        [
          [45.0, 15.0],
          [44.76265748962582, 15.44122412677884],
          [44.55741416077018, 15.408312358097973],
          [44.58682059279283, 15.267709211136896],
          [45.0, 15.0],
        ],
      ],
    },
    bbox: [44.55741416077018, 15.0, 45.0, 15.44122412677884],
    datetime: '2023-03-02T01:01:01.000Z',
  },
  {
    productData: { id: 'e5000032-9f4b-41c8-a7a7-d48f8df8e44b' },
    id: 'c0100032-fcf9-49f9-b467-e4a8bb9e8d41',
    createdAt: '2023-06-06 01:05:01.000000+00',
    updatedAt: '2023-06-06 01:05:01.000000+00', //within 1 year and newer than c0100031 GRD to check default GRD to be used
    latestEditorId: SystemUser.DPS_SYSTEM,
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    version: '00-PR-01-dps-20230201010101-new',
    sourceExpired: '2024-06-06 01:05:01.000000+00', //should be longer than apr.downloadExpired,
    bucket: 'gs://syns-daas-dev_iris-product-data-store',
    location:
      'fixtures/0603e8a8-c8eb-4da0-838a-43d407dab2df/1aebd2bd-efdd-4d48-aeb9-0ebd04305581/STRIX_202302-10002_20220821T013544Z_SM_GRD_Geotiff.zip',
    quicklookBucket: 'gs://syns-daas-dev_iris-product-data-store',
    quicklookLocation:
      'fixtures/0603e8a8-c8eb-4da0-838a-43d407dab2df/1aebd2bd-efdd-4d48-aeb9-0ebd04305581/STRIX_202302-10002_20220821T013544Z_SM_GRD_Geotiff_quicklook',
    quicklookContentType: 'image/jpeg',
    metadata: {
      product: {
        productSoftwareVersion: '0.13.1', //dps team sets dpsVersion to psVersion for SLC_SICD
        productFormat: ProductFormat.SLC_SICD,
        dataProcessingSoftwareVersion: '0.13.1',
        orbitType: OrbitType.PR,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.normal,
      },
      geometry: {
        sceneCenterLocation: '15.35446666895787 44.67473904120934',
        sceneCornerLocations:
          '14.0 46.0 15.44122412677884 44.76265748962582 15.408312358097973 44.55741416077018 15.267709211136896 44.58682059279283 14.0 46.0',
      },
      observation: {
        sceneId: 'STRIXB-20231202T010101Z',
        sceneNo: 1,
        orderCode: '202312-12003',
        imagingMode: ImagingMode.Stripmap,
        satelliteId: 'ST0002',
        polarization: PolarizationType.VV,
        offnadirAngle: 35.36,
        flightDirection: FlightDirection.Descending,
        lookingDirection: LookingDirection.Left,
        sceneEndDateTime: '2023-3-04T01:02:02.000Z',
        sceneStartDateTime: '2023-3-04T01:02:00.000Z',
        sceneCenterDateTime: '2023-3-04T01:02:01.000Z',
      },
    },
    center: {
      type: 'Point',
      coordinates: [44.67473904120934, 15.35446666895787],
    },
    area: {
      type: 'Polygon',
      coordinates: [
        [
          [46.0, 14.0],
          [44.76265748962582, 15.44122412677884],
          [44.55741416077018, 15.408312358097973],
          [44.58682059279283, 15.267709211136896],
          [46.0, 14.0],
        ],
      ],
    },
    bbox: [44.55741416077018, 14.0, 46.0, 15.44122412677884],
    datetime: '2023-03-04T01:01:01.000Z',
  },
  {
    productData: { id: 'e5000022-9f4b-41c8-a7a7-d48f8df8e44b' },
    id: 'c0100022-fcf9-49f9-b467-e4a8bb9e8d41',
    createdAt: '2023-08-12 01:01:01.000000+00',
    updatedAt: '2023-08-12 01:01:01.000000+00', //within 1 year from fake time
    latestEditorId: SystemUser.DPS_SYSTEM,
    organizationId: getTestAnotherOrganizationIdForFixture(),
    contractId: getTestAnotherContractIdForFixture(),
    version: '00-PR-01-dps-20230201010101-new',
    sourceExpired: '2024-05-25 00:00:00.000000+00',
    bucket: 'gs://syns-daas-dev_iris-product-data-store',
    location:
      'fixtures/23e62f2a-17b0-40b8-9767-7d16d8233c01/383d20a9-8d1e-4706-921a-b1ebda87d2e3/STRIX_202302-10001_20220821T013544Z_SM_GRD_Geotiff.zip',
    quicklookBucket: 'gs://syns-daas-dev_iris-product-data-store',
    quicklookLocation:
      'fixtures/23e62f2a-17b0-40b8-9767-7d16d8233c01/383d20a9-8d1e-4706-921a-b1ebda87d2e3/STRIX_202302-10001_20220821T013544Z_SM_GRD_Geotiff_quicklook',
    quicklookContentType: 'image/jpeg',
    metadata: {
      product: {
        productSoftwareVersion: '011.000',
        productFormat: ProductFormat.GRD_GEOTIFF,
        dataProcessingSoftwareVersion: '0.13.1',
        orbitType: OrbitType.OB,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.SR,
      },
      geometry: {
        sceneCenterLocation: '-26.35446666895787 -67.67473904120934',
        sceneCornerLocations:
          '-26.300620979817765 -67.79206392164848 -26.44122412677884 -67.76265748962582 -26.408312358097973 -67.55741416077018 -26.267709211136896 -67.58682059279283 -26.300620979817765 -67.79206392164848',
      },
      observation: {
        sceneId: 'STRIXB-20231201T010101Z',
        sceneNo: 1,
        orderCode: '202312-12001',
        imagingMode: ImagingMode.Stripmap,
        satelliteId: 'ST0002',
        polarization: PolarizationType.VV,
        offnadirAngle: 35.36,
        flightDirection: FlightDirection.Descending,
        lookingDirection: LookingDirection.Left,
        sceneEndDateTime: '2023-05-01T01:01:02.000Z',
        sceneStartDateTime: '2023-05-01T01:01:00.000Z',
        sceneCenterDateTime: '2023-05-01T01:01:01.000Z',
      },
    },
    center: {
      type: 'Point',
      coordinates: [44.67473904120934, 15.35446666895787],
    },
    area: {
      type: 'Polygon',
      coordinates: [
        [
          [44.79206392164848, 15.300620979817765],
          [44.76265748962582, 15.44122412677884],
          [44.55741416077018, 15.408312358097973],
          [44.58682059279283, 15.267709211136896],
          [44.79206392164848, 15.300620979817765],
        ],
      ],
    },
    bbox: [
      44.55741416077018, 15.267709211136896, 44.79206392164848,
      15.44122412677884,
    ],
    datetime: '2023-05-01T01:01:01.000Z',
  },
  {
    productData: { id: 'e5000023-9f4b-41c8-a7a7-d48f8df8e44b' },
    id: 'c0100023-fcf9-49f9-b467-e4a8bb9e8d41',
    createdAt: '2023-08-06 01:01:01.000000+00',
    updatedAt: '2023-08-06 01:01:01.000000+00', //older than c0100022
    latestEditorId: SystemUser.DPS_SYSTEM,
    organizationId: getTestAnotherOrganizationIdForFixture(),
    contractId: getTestAnotherContractIdForFixture(),
    version: '00-PR-01-dps-20230201010101-new',
    sourceExpired: '2024-05-24 00:00:00.000000+00',
    bucket: 'gs://syns-daas-dev_iris-product-data-store',
    location:
      'fixtures/0603e8a8-c8eb-4da0-838a-43d407dab2df/1aebd2bd-efdd-4d48-aeb9-0ebd04305581/STRIX_202302-10002_20220821T013544Z_SM_GRD_Geotiff.zip',
    quicklookBucket: 'gs://syns-daas-dev_iris-product-data-store',
    quicklookLocation:
      'fixtures/0603e8a8-c8eb-4da0-838a-43d407dab2df/1aebd2bd-efdd-4d48-aeb9-0ebd04305581/STRIX_202302-10002_20220821T013544Z_SM_GRD_Geotiff_quicklook',
    quicklookContentType: 'image/jpeg',
    metadata: {
      product: {
        productSoftwareVersion: '011.000',
        productFormat: ProductFormat.GRD_GEOTIFF,
        dataProcessingSoftwareVersion: '0.13.1',
        orbitType: OrbitType.PR,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.normal,
      },
      geometry: {
        sceneCenterLocation: '15.35446666895787 44.67473904120934',
        sceneCornerLocations:
          '15.300620979817765 44.79206392164848 15.44122412677884 44.76265748962582 15.408312358097973 44.55741416077018 15.267709211136896 44.58682059279283 15.300620979817765 44.79206392164848',
      },
      observation: {
        sceneId: 'STRIXB-20231202T010101Z',
        sceneNo: 1,
        orderCode: '202312-12002',
        imagingMode: ImagingMode.Stripmap,
        satelliteId: 'ST0001',
        polarization: PolarizationType.VV,
        offnadirAngle: 44.36,
        flightDirection: FlightDirection.Ascending,
        lookingDirection: LookingDirection.Right,
        sceneEndDateTime: '2023-05-02T01:02:02.000Z',
        sceneStartDateTime: '2023-05-02T01:02:00.000Z',
        sceneCenterDateTime: '2023-05-02T01:02:01.000Z',
      },
    },
    center: {
      type: 'Point',
      coordinates: [44.67473904120934, 15.35446666895787],
    },
    area: {
      type: 'Polygon',
      coordinates: [
        [
          [44.79206392164848, 15.300620979817765],
          [44.76265748962582, 15.44122412677884],
          [44.55741416077018, 15.408312358097973],
          [44.58682059279283, 15.267709211136896],
          [44.79206392164848, 15.300620979817765],
        ],
      ],
    },
    bbox: [
      44.55741416077018, 15.267709211136896, 44.79206392164848,
      15.44122412677884,
    ],
    datetime: '2023-05-02T01:02:01.000Z',
  },
  {
    productData: { id: 'e5000041-9f4b-41c8-a7a7-d48f8df8e44b' },
    id: 'c0100025-fcf9-49f9-b467-e4a8bb9e8d41',
    createdAt: '2023-09-03 02:02:02.000000+00',
    updatedAt: '2023-09-03 02:02:02.000000+00',
    latestEditorId: 'dps-system',
    organizationId: SystemOrganization.NO_ORGANIZATION,
    contractId: SystemContract.NO_CONTRACT,
    version: '00-PR-01-dps-20230201010101-new',
    sourceExpired: '2024-04-22 00:00:00.000000+00',
    bucket: 'gs://syns-daas-dev_iris-product-data-store',
    location:
      'fixtures/0603e8a8-c8eb-4da0-838a-43d407dab2df/1aebd2bd-efdd-4d48-aeb9-0ebd04305581/STRIX_202302-10002_20220821T013544Z_SM_GRD_Geotiff.zip',
    quicklookBucket: 'gs://syns-daas-dev_iris-product-data-store',
    quicklookLocation:
      'fixtures/0603e8a8-c8eb-4da0-838a-43d407dab2df/1aebd2bd-efdd-4d48-aeb9-0ebd04305581/STRIX_202302-10002_20220821T013544Z_SM_GRD_Geotiff_quicklook',
    quicklookContentType: 'image/jpeg',
    metadata: {
      product: {
        productSoftwareVersion: '011.000',
        productFormat: ProductFormat.GRD_GEOTIFF,
        dataProcessingSoftwareVersion: '0.13.1',
        orbitType: OrbitType.PR,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.normal,
      },
      geometry: {
        sceneCenterLocation: '15.35446666895787 44.67473904120934',
        sceneCornerLocations:
          '15.300620979817765 44.79206392164848 15.44122412677884 44.76265748962582 15.408312358097973 44.55741416077018 15.267709211136896 44.58682059279283 15.300620979817765 44.79206392164848',
      },
      observation: {
        sceneId: 'STRIXB-20231201T010101Z',
        sceneNo: 3,
        orderCode: '202312-12001',
        imagingMode: ImagingMode.Stripmap,
        satelliteId: 'ST0002',
        polarization: PolarizationType.VV,
        offnadirAngle: 43.01,
        flightDirection: FlightDirection.Descending,
        lookingDirection: LookingDirection.Right,
        sceneEndDateTime: '2023-04-02T01:01:02.000Z',
        sceneStartDateTime: '2023-04-02T01:01:00.000Z',
        sceneCenterDateTime: '2023-04-02T01:01:01.000Z',
      },
    },
    center: {
      type: 'Point',
      coordinates: [44.67473904120934, 15.35446666895787],
    },
    area: {
      type: 'Polygon',
      coordinates: [
        [
          [44.79206392164848, 15.300620979817765],
          [44.76265748962582, 15.44122412677884],
          [44.55741416077018, 15.408312358097973],
          [44.58682059279283, 15.267709211136896],
          [44.79206392164848, 15.300620979817765],
        ],
      ],
    },
    bbox: [
      44.55741416077018, 15.267709211136896, 44.79206392164848,
      15.44122412677884,
    ],
    datetime: '2023-01-01T01:01:01.000Z',
  },
  {
    productData: { id: 'e5000046-9f4b-41c8-a7a7-d48f8df8e44b' },
    id: 'c0100026-fcf9-49f9-b467-e4a8bb9e8d41',
    createdAt: '2023-09-02 01:01:01.000000+00',
    updatedAt: '2023-09-02 01:01:01.000000+00', //about 6 months from fake time (older than c0100027)
    latestEditorId: SystemUser.DPS_SYSTEM,
    organizationId: getTestAnotherOrganizationIdForFixture(),
    contractId: getTestAnotherContractIdForFixture(),
    version: '00-PR-21-dps-20230401010101',
    sourceExpired: '2024-09-21 00:00:00.000000+00',
    bucket: 'gs://syns-daas-dev_iris-product-data-store',
    location:
      'fixtures/496c6c8a-4b10-4d1e-80ff-d41bc253ae46/e8f348f8-ee26-4643-9dc6-b7550bb6924e/STRIX_202302-10001_20220821T013544Z_SM_GRD_Geotiff.zip',
    quicklookBucket: 'gs://syns-daas-dev_iris-product-data-store',
    quicklookLocation:
      'fixtures/496c6c8a-4b10-4d1e-80ff-d41bc253ae46/e8f348f8-ee26-4643-9dc6-b7550bb6924e/STRIX_202302-10001_20220821T013544Z_SM_GRD_Geotiff_quicklook',
    quicklookContentType: 'image/jpeg',
    metadata: {
      product: {
        productSoftwareVersion: '011.000',
        productFormat: ProductFormat.GRD_GEOTIFF,
        dataProcessingSoftwareVersion: '0.13.1',
        orbitType: OrbitType.PR,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.normal,
      },
      geometry: {
        sceneCenterLocation: '15.35446666895787 44.67473904120934',
        sceneCornerLocations:
          '15.300620979817765 44.79206392164848 15.44122412677884 44.76265748962582 15.408312358097973 44.55741416077018 15.267709211136896 44.58682059279283 15.300620979817765 44.79206392164848',
      },
      observation: {
        sceneId: 'STRIX1-20230401T010101Z',
        sceneNo: 1,
        orderCode: '202302-10001',
        imagingMode: ImagingMode.Stripmap,
        satelliteId: 'ST0003',
        polarization: PolarizationType.VV,
        offnadirAngle: 40,
        flightDirection: FlightDirection.Descending,
        lookingDirection: LookingDirection.Left,
        sceneEndDateTime: '2023-09-01T01:01:02.000Z',
        sceneStartDateTime: '2023-09-01T01:01:00.000Z',
        sceneCenterDateTime: '2023-09-01T01:01:01.000Z',
      },
    },
    center: {
      type: 'Point',
      coordinates: [15.35446666895787, 44.67473904120934],
    },
    area: {
      type: 'Polygon',
      coordinates: [
        [
          [15.300620979817765, 44.79206392164848],
          [15.44122412677884, 44.76265748962582],
          [15.408312358097973, 44.55741416077018],
          [15.267709211136896, 44.58682059279283],
          [15.300620979817765, 44.79206392164848],
        ],
      ],
    },
    bbox: [
      15.267709211136896, 44.55741416077018, 15.44122412677884,
      44.79206392164848,
    ],
    datetime: '2022-12-31T01:01:01.000Z',
  },
  {
    productData: { id: 'e5000047-9f4b-41c8-a7a7-d48f8df8e44b' },
    id: 'c0100027-fcf9-49f9-b467-e4a8bb9e8d41',
    createdAt: '2023-09-02 01:14:01.000000+00',
    updatedAt: '2023-09-02 01:14:01.000000+00', // older than c0100025
    latestEditorId: SystemUser.DPS_SYSTEM,
    organizationId: getTestAnotherOrganizationIdForFixture(),
    contractId: getTestAnotherContractIdForFixture(),
    version: '00-PR-21-dps-20230401010101',
    sourceExpired: '2024-09-21 00:00:00.000000+00',
    bucket: 'gs://syns-daas-dev_iris-product-data-store',
    location:
      'fixtures/496c6c8a-4b10-4d1e-80ff-d41bc253ae46/e8f348f8-ee26-4643-9dc6-b7550bb6924e/STRIX_202302-10001_20220821T013544Z_SM_GRD_Geotiff.zip',
    quicklookBucket: 'gs://syns-daas-dev_iris-product-data-store',
    quicklookLocation:
      'fixtures/496c6c8a-4b10-4d1e-80ff-d41bc253ae46/e8f348f8-ee26-4643-9dc6-b7550bb6924e/STRIX_202302-10001_20220821T013544Z_SM_GRD_Geotiff_quicklook',
    quicklookContentType: 'image/jpeg',
    metadata: {
      product: {
        productSoftwareVersion: '011.000',
        productFormat: ProductFormat.GRD_GEOTIFF,
        dataProcessingSoftwareVersion: '0.13.1',
        orbitType: OrbitType.PR,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.normal,
      },
      geometry: {
        sceneCenterLocation: '15.35446666895787 44.67473904120934',
        sceneCornerLocations:
          '15.300620979817765 44.79206392164848 15.44122412677884 44.76265748962582 15.408312358097973 44.55741416077018 15.267709211136896 44.58682059279283 15.300620979817765 44.79206392164848',
      },
      observation: {
        sceneId: 'STRIX1-20230401T010101Z',
        sceneNo: 1,
        orderCode: '202302-10001',
        imagingMode: ImagingMode.Stripmap,
        satelliteId: 'ST0003',
        polarization: PolarizationType.VV,
        offnadirAngle: 40,
        flightDirection: FlightDirection.Descending,
        lookingDirection: LookingDirection.Left,
        sceneEndDateTime: '2023-09-01T01:03:02.000Z',
        sceneStartDateTime: '2023-09-01T01:03:00.000Z',
        sceneCenterDateTime: '2023-09-01T01:03:01.000Z',
      },
    },
    center: {
      type: 'Point',
      coordinates: [15.35446666895787, 44.67473904120934],
    },
    area: {
      type: 'Polygon',
      coordinates: [
        [
          [15.300620979817765, 44.79206392164848],
          [15.44122412677884, 44.76265748962582],
          [15.408312358097973, 44.55741416077018],
          [15.267709211136896, 44.58682059279283],
          [15.300620979817765, 44.79206392164848],
        ],
      ],
    },
    bbox: [
      15.267709211136896, 44.55741416077018, 15.44122412677884,
      44.79206392164848,
    ],
    datetime: '2022-12-31T01:01:01.000Z',
  },
  {
    productData: { id: 'e5000051-9f4b-41c8-a7a7-d48f8df8e44b' },
    id: 'c0100051-fcf9-49f9-b467-e4a8bb9e8d41',
    createdAt: '2023-02-01 01:15:01.000000+00',
    updatedAt: '2023-02-01 01:15:01.000000+00', // more than 1 year from test fake time
    latestEditorId: SystemUser.DPS_SYSTEM,
    organizationId: getTestAnotherOrganizationIdForFixture(),
    contractId: getTestAnotherContractIdForFixture(),
    version: '00-PR-21-dps-20230201010101',
    sourceExpired: '2024-02-21 00:00:00.000000+00',
    bucket: 'gs://syns-daas-dev_iris-product-data-store',
    location:
      'fixtures/496c6c8a-4b10-4d1e-80ff-d41bc253ae46/e8f348f8-ee26-4643-9dc6-b7550bb6924e/STRIX_202302-10001_20220821T013544Z_SM_GRD_Geotiff.zip',
    quicklookBucket: 'gs://syns-daas-dev_iris-product-data-store',
    quicklookLocation:
      'fixtures/496c6c8a-4b10-4d1e-80ff-d41bc253ae46/e8f348f8-ee26-4643-9dc6-b7550bb6924e/STRIX_202302-10001_20220821T013544Z_SM_GRD_Geotiff_quicklook',
    quicklookContentType: 'image/jpeg',
    metadata: {
      product: {
        productSoftwareVersion: '011.000',
        productFormat: ProductFormat.GRD_GEOTIFF,
        dataProcessingSoftwareVersion: '0.13.1',
        orbitType: OrbitType.PR,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.normal,
      },
      geometry: {
        sceneCenterLocation: '15.35446666895787 44.67473904120934',
        sceneCornerLocations:
          '15.300620979817765 44.79206392164848 15.44122412677884 44.76265748962582 15.408312358097973 44.55741416077018 15.267709211136896 44.58682059279283 15.300620979817765 44.79206392164848',
      },
      observation: {
        sceneId: 'STRIX1-20230201T010101Z',
        sceneNo: 1,
        orderCode: '202312-00001',
        imagingMode: ImagingMode.SlidingSpotlight,
        satelliteId: 'ST0003',
        polarization: PolarizationType.VV,
        offnadirAngle: 18,
        flightDirection: FlightDirection.Descending,
        lookingDirection: LookingDirection.Left,
        sceneEndDateTime: '2023-02-01T01:03:02.000Z',
        sceneStartDateTime: '2023-02-01T01:03:00.000Z',
        sceneCenterDateTime: '2023-02-01T01:03:01.000Z',
      },
    },
    center: {
      type: 'Point',
      coordinates: [15.35446666895787, 44.67473904120934],
    },
    area: {
      type: 'Polygon',
      coordinates: [
        [
          [15.300620979817765, 44.79206392164848],
          [15.44122412677884, 44.76265748962582],
          [15.408312358097973, 44.55741416077018],
          [15.267709211136896, 44.58682059279283],
          [15.300620979817765, 44.79206392164848],
        ],
      ],
    },
    bbox: [
      15.267709211136896, 44.55741416077018, 15.44122412677884,
      44.79206392164848,
    ],
    datetime: '2023-02-01T01:01:01.000Z',
  },
  {
    productData: { id: 'e5000052-9f4b-41c8-a7a7-d48f8df8e44b' },
    id: 'c0100052-fcf9-49f9-b467-e4a8bb9e8d41',
    createdAt: '2023-12-10 01:15:01.000000+00',
    updatedAt: '2023-12-10 01:15:01.000000+00',
    latestEditorId: SystemUser.DPS_SYSTEM,
    organizationId: getTestAnotherOrganizationIdForFixture(),
    contractId: getTestAnotherContractIdForFixture(),
    version: '00-PR-21-dps-20230201010101',
    sourceExpired: '2024-12-30 00:00:00.000000+00',
    bucket: 'gs://syns-daas-dev_iris-product-data-store',
    location:
      'fixtures/496c6c8a-4b10-4d1e-80ff-d41bc253ae46/e8f348f8-ee26-4643-9dc6-b7550bb6924e/STRIX_202302-10001_20241230T013500Z_SM_GRD_Geotiff.zip',
    quicklookBucket: 'gs://syns-daas-dev_iris-product-data-store',
    quicklookLocation:
      'fixtures/496c6c8a-4b10-4d1e-80ff-d41bc253ae46/e8f348f8-ee26-4643-9dc6-b7550bb6924e/STRIX_202302-10001_20220821T013544Z_SM_GRD_Geotiff_quicklook',
    quicklookContentType: 'image/jpeg',
    metadata: {
      product: {
        productSoftwareVersion: '011.000',
        productFormat: ProductFormat.GRD_GEOTIFF,
        dataProcessingSoftwareVersion: '0.13.1',
        orbitType: OrbitType.PR,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.normal,
      },
      geometry: {
        sceneCenterLocation: '15.35446666895787 44.67473904120934',
        sceneCornerLocations:
          '15.300620979817765 44.79206392164848 15.44122412677884 44.76265748962582 15.408312358097973 44.55741416077018 15.267709211136896 44.58682059279283 15.300620979817765 44.79206392164848',
      },
      observation: {
        sceneId: 'STRIX1-20231211T010101Z',
        sceneNo: 1,
        orderCode: '202312-00002',
        imagingMode: ImagingMode.Stripmap,
        satelliteId: 'ST0002',
        polarization: PolarizationType.VV,
        offnadirAngle: 40,
        flightDirection: FlightDirection.Descending,
        lookingDirection: LookingDirection.Left,
        sceneEndDateTime: '2023-12-01T11:03:02.000Z',
        sceneStartDateTime: '2023-12-11T01:03:00.000Z',
        sceneCenterDateTime: '2023-12-11T01:03:01.000Z',
      },
    },
    center: {
      type: 'Point',
      coordinates: [15.35446666895787, 44.67473904120934],
    },
    area: {
      type: 'Polygon',
      coordinates: [
        [
          [15.300620979817765, 44.79206392164848],
          [15.44122412677884, 44.76265748962582],
          [15.408312358097973, 44.55741416077018],
          [15.267709211136896, 44.58682059279283],
          [15.300620979817765, 44.79206392164848],
        ],
      ],
    },
    bbox: [
      15.267709211136896, 44.55741416077018, 15.44122412677884,
      44.79206392164848,
    ],
    datetime: '2023-12-11T01:01:01.000Z',
  },
  {
    //to test NO_REQUEST TaskingSummary
    productData: { id: 'e5000052-9f4b-41c8-a7a7-d48f8df8e44b' },
    id: 'c0200052-fcf9-49f9-b467-e4a8bb9e8d41',
    createdAt: '2023-12-12 01:15:01.000000+00',
    updatedAt: '2023-12-12 01:15:01.000000+00', //newer than c0100052
    latestEditorId: SystemUser.DPS_SYSTEM,
    organizationId: SystemOrganization.NO_ORGANIZATION,
    contractId: SystemContract.NO_CONTRACT,
    version: '00-PR-21-dps-20230201010101',
    sourceExpired: '2024-12-30 00:00:00.000000+00',
    bucket: 'gs://syns-daas-dev_iris-product-data-store',
    location:
      'fixtures/496c6c8a-4b10-4d1e-80ff-d41bc253ae46/e8f348f8-ee26-4643-9dc6-b7550bb6924e/STRIX_202302-10001_20241230T013400Z_SM_GRD_Geotiff.zip',
    quicklookBucket: 'gs://syns-daas-dev_iris-product-data-store',
    quicklookLocation:
      'fixtures/496c6c8a-4b10-4d1e-80ff-d41bc253ae46/e8f348f8-ee26-4643-9dc6-b7550bb6924e/STRIX_202302-10001_20220821T013544Z_SM_GRD_Geotiff_quicklook',
    quicklookContentType: 'image/jpeg',
    metadata: {
      product: {
        productSoftwareVersion: '011.000',
        productFormat: ProductFormat.GRD_GEOTIFF,
        dataProcessingSoftwareVersion: '0.13.1',
        orbitType: OrbitType.PR,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.normal,
      },
      geometry: {
        sceneCenterLocation: '15.35446666895787 44.67473904120934',
        sceneCornerLocations:
          '15.300620979817765 44.79206392164848 15.44122412677884 44.76265748962582 15.408312358097973 44.55741416077018 15.267709211136896 44.58682059279283 15.300620979817765 44.79206392164848',
      },
      observation: {
        sceneId: 'STRIX1-20231211T010101Z',
        sceneNo: 1,
        orderCode: '202312-00002',
        imagingMode: ImagingMode.Stripmap,
        satelliteId: 'ST0002',
        polarization: PolarizationType.VV,
        offnadirAngle: 40,
        flightDirection: FlightDirection.Descending,
        lookingDirection: LookingDirection.Left,
        sceneEndDateTime: '2023-12-01T11:03:02.000Z',
        sceneStartDateTime: '2023-12-11T01:03:00.000Z',
        sceneCenterDateTime: '2023-12-11T01:03:01.000Z',
      },
    },
    center: {
      type: 'Point',
      coordinates: [15.35446666895787, 44.67473904120934],
    },
    area: {
      type: 'Polygon',
      coordinates: [
        [
          [15.300620979817765, 44.79206392164848],
          [15.44122412677884, 44.76265748962582],
          [15.408312358097973, 44.55741416077018],
          [15.267709211136896, 44.58682059279283],
          [15.300620979817765, 44.79206392164848],
        ],
      ],
    },
    bbox: [
      15.267709211136896, 44.55741416077018, 15.44122412677884,
      44.79206392164848,
    ],
    datetime: '2023-12-11T01:01:01.000Z',
  },
  {
    //for pdv only NO_ORGANIZATION test
    productData: { id: 'e5000053-9f4b-41c8-a7a7-d48f8df8e44b' },
    id: 'c0200053-fcf9-49f9-b467-e4a8bb9e8d41',
    createdAt: '2023-04-19 01:15:01.000000+00',
    updatedAt: '2023-04-19 01:15:01.000000+00',
    latestEditorId: SystemUser.DPS_SYSTEM,
    organizationId: SystemOrganization.NO_ORGANIZATION,
    contractId: SystemContract.NO_CONTRACT,
    version: '00-PR-01-dps-20230201010101-new',
    sourceExpired: '2024-04-22 00:00:00.000000+00',
    bucket: 'gs://syns-daas-dev_iris-product-data-store',
    location:
      'fixtures/0603e8a8-c8eb-4da0-838a-43d407dab2df/1aebd2bd-efdd-4d48-aeb9-0ebd04305581/STRIX_202302-10002_20220821T013544Z_SM_GRD_Geotiff.zip',
    quicklookBucket: 'gs://syns-daas-dev_iris-product-data-store',
    quicklookLocation:
      'fixtures/0603e8a8-c8eb-4da0-838a-43d407dab2df/1aebd2bd-efdd-4d48-aeb9-0ebd04305581/STRIX_202302-10002_20220821T013544Z_SM_GRD_Geotiff_quicklook',
    quicklookContentType: 'image/jpeg',
    metadata: {
      product: {
        productSoftwareVersion: '011.000',
        productFormat: ProductFormat.GRD_GEOTIFF,
        dataProcessingSoftwareVersion: '0.13.1',
        orbitType: OrbitType.PR,
        focusSoftwareType: 'msar',
        focusSoftwareVersion: 'v702',
        resolutionMode: ResolutionMode.normal,
      },
      geometry: {
        sceneCenterLocation: '15.35446666895787 44.67473904120934',
        sceneCornerLocations:
          '15.300620979817765 44.79206392164848 15.44122412677884 44.76265748962582 15.408312358097973 44.55741416077018 15.267709211136896 44.58682059279283 15.300620979817765 44.79206392164848',
      },
      observation: {
        sceneId: 'STRIXB-20231201T010101Z',
        sceneNo: 2,
        orderCode: '202312-12001',
        imagingMode: ImagingMode.Stripmap,
        satelliteId: 'ST0002',
        polarization: PolarizationType.VV,
        offnadirAngle: 43.01,
        flightDirection: FlightDirection.Descending,
        lookingDirection: LookingDirection.Right,
        sceneEndDateTime: '2023-12-01T01:01:02.000Z',
        sceneStartDateTime: '2023-12-01T01:01:00.000Z',
        sceneCenterDateTime: '2023-12-01T01:01:01.000Z',
      },
    },
    center: {
      type: 'Point',
      coordinates: [44.67473904120934, 15.35446666895787],
    },
    area: {
      type: 'Polygon',
      coordinates: [
        [
          [44.79206392164848, 15.300620979817765],
          [44.76265748962582, 15.44122412677884],
          [44.55741416077018, 15.408312358097973],
          [44.58682059279283, 15.267709211136896],
          [44.79206392164848, 15.300620979817765],
        ],
      ],
    },
    bbox: [
      44.55741416077018, 15.267709211136896, 44.79206392164848,
      15.44122412677884,
    ],
    datetime: '2023-01-01T01:01:01.000Z',
  },
];

export const insertFixtureProductDataVersion = async (
  ds: DataSource,
  fixtures: Array<DeepPartial<ProductDataVersionForTest>>,
) => {
  return await ds.transaction(async (em) => {
    const targets = await fixtures.reduce(async (p, c) => {
      const r = await p;

      const productData = await em
        .getRepository(ProductData)
        .findOneOrFail({ where: { id: c.productData.id } });
      c.productData = productData;
      const tmp = em.getRepository(ProductDataVersion).create(c);
      r.push(tmp);
      return r;
    }, Promise.resolve(new Array<ProductDataVersion>()));

    return await em.getRepository(ProductDataVersion).insert(targets);
  });
};
