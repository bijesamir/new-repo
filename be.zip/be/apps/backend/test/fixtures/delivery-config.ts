import { ProductFormat, ResolutionMode } from '@iris-lib/constants';
import { DeliveryMethod } from '@iris-lib/constants/delivery-method';
import {
  getTestOrganizationIdForFixture,
  getTestUserIdForFixture,
} from '@iris-lib/constants/test-support';
import { DeliveryConfig } from '@iris-lib/db/entities';
import { ProductDetailsDto } from '@iris-lib/models';
import { plainToInstance } from 'class-transformer';
import { DeepPartial } from 'typeorm';

export const fixtureDeliveryConfigs: Array<DeepPartial<DeliveryConfig>> = [
  {
    method: DeliveryMethod.SFTP,
    jobName: 'test-001',
    organizationId: getTestOrganizationIdForFixture(),
    productDetails: [
      plainToInstance(ProductDetailsDto, {
        productFormat: ProductFormat.GRD_GEOTIFF,
        resolutionMode: ResolutionMode.normal,
      }),
      plainToInstance(ProductDetailsDto, {
        productFormat: ProductFormat.SLC_SICD,
        resolutionMode: ResolutionMode.normal,
      }),
      plainToInstance(ProductDetailsDto, {
        productFormat: ProductFormat.SLC_CEOS,
        resolutionMode: ResolutionMode.normal,
      }),
      plainToInstance(ProductDetailsDto, {
        productFormat: ProductFormat.GRD_GEOTIFF,
        resolutionMode: ResolutionMode.SR,
      }),
    ],
    config: `---
dest: /home/iris/share
options:
  - host: localhost
    username: iris
    port: 12223
    password: iris
  - host: iris-sftp-02
    username: iris
    port: 2222
    password: iris`,
    latestEditorId: getTestUserIdForFixture(),
    concurrency: 1,
  },
];
