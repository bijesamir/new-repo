import { ObservableArea } from '@iris-lib/db/entities';
import { DeepPartial } from 'typeorm';
import * as df from 'date-fns';

export const fixtureObservableArea: Array<DeepPartial<ObservableArea>> = [
  {
    satId: 'ST0003',
    date: df.parse('20230328_150000', 'yyyyMMdd_HHmmss', new Date()),
    polygon: {
      type: 'Polygon',
      coordinates: [
        [
          [-105.794171, -67.59254, 0],
          [-94.539307, -68.57315, 0],
          [-93.883764, -66.71727, 0],
          [-104.351972, -65.799645, 0],
          [-105.794171, -67.59254, 0],
        ],
      ],
    },
  },
  {
    satId: 'ST0003',
    date: df.parse('20230329_150000', 'yyyyMMdd_HHmmss', new Date()),
    polygon: {
      type: 'Polygon',
      coordinates: [
        [
          [-112.250215, -66.611957, 0],
          [-121.401844, -64.557515, 0],
          [-119.190092, -62.959596, 0],
          [-110.432081, -64.884794, 0],
          [-112.250215, -66.611957, 0],
        ],
      ],
    },
  },
  {
    satId: 'ST0002',
    date: df.parse('20230328_150000', 'yyyyMMdd_HHmmss', new Date()),
    polygon: {
      type: 'Polygon',
      coordinates: [
        [
          [-105.794171, -67.59254, 0],
          [-94.539307, -68.57315, 0],
          [-93.883764, -66.71727, 0],
          [-104.351972, -65.799645, 0],
          [-105.794171, -67.59254, 0],
        ],
      ],
    },
  },
  {
    satId: 'ST0002',
    date: df.parse('20230329_150000', 'yyyyMMdd_HHmmss', new Date()),
    polygon: {
      type: 'Polygon',
      coordinates: [
        [
          [-112.250215, -66.611957, 0],
          [-121.401844, -64.557515, 0],
          [-119.190092, -62.959596, 0],
          [-110.432081, -64.884794, 0],
          [-112.250215, -66.611957, 0],
        ],
      ],
    },
  },

  {
    satId: 'ST0001',
    date: df.parse('20230328_150000', 'yyyyMMdd_HHmmss', new Date()),
    polygon: {
      type: 'Polygon',
      coordinates: [
        [
          [-105.794171, -67.59254, 0],
          [-94.539307, -68.57315, 0],
          [-93.883764, -66.71727, 0],
          [-104.351972, -65.799645, 0],
          [-105.794171, -67.59254, 0],
        ],
      ],
    },
  },
  {
    satId: 'ST0001',
    date: df.parse('20230329_150000', 'yyyyMMdd_HHmmss', new Date()),
    polygon: {
      type: 'Polygon',
      coordinates: [
        [
          [-112.250215, -66.611957, 0],
          [-121.401844, -64.557515, 0],
          [-119.190092, -62.959596, 0],
          [-110.432081, -64.884794, 0],
          [-112.250215, -66.611957, 0],
        ],
      ],
    },
  },
];
