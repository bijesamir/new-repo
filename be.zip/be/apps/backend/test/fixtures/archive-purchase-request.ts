import {
  DataSourceType,
  OrderStatus,
  ProcessingStatus,
} from '@iris-lib/constants';
import {
  getTestAnotherContractIdForFixture,
  getTestAnotherOrganizationIdForFixture,
  getTestAnotherUserIdForFixture,
  getTestContractIdForFixture,
  getTestOrganizationIdForFixture,
  getTestThirdContractIdForFixture,
  getTestThirdUserIdForFixture,
  getTestThirdOrganizationIdForFixture,
  getTestUserIdForFixture,
} from '@iris-lib/constants/test-support';
import {
  ArchivePurchaseRequest,
  ArchivePurchasedItem,
  ArchivePurchasedProductData,
  ProductData,
} from '@iris-lib/db/entities';
import { OmitType } from '@nestjs/swagger';
import { DataSource, DeepPartial, In } from 'typeorm';
import { UUID } from 'crypto';
import { subDays } from 'date-fns';
import { DUMMY_ANOTHER_USER, DUMMY_USER } from '@iris-lib/guards';
import { plainToInstance } from 'class-transformer';
import { TEST_FAKE_TIME } from './tasking-info';

export class ArchivePurchaseForTest extends OmitType(
  ArchivePurchaseRequest,
  [] as const,
) {
  productDataIds: UUID[];
  // index of rr should be related to apr , undefined makes no relation
  //  this is for the test case apr already completed and then rr created case.
  targetReprocessingIndex?: number[];
}

const fixtureArchivePurchaseRequest: Array<
  DeepPartial<ArchivePurchaseForTest>
> = [
  {
    // To check Download expired minimum, requestid minimum
    id: 'a0100000-c8eb-4da0-838a-43d407dab2df',
    requestId: getTestContractIdForFixture() + '-202302-00001',
    createdAt: '2023-02-28 01:01:03.000000+00',
    updatedAt: '2023-02-28 01:01:03.000000+00',
    latestEditorId: 'system',
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    orderedUserId: DUMMY_USER.stringUserId(),
    status: OrderStatus.Completed,
    downloadExpired: '2023-03-13 01:01:03.000000+00',
    productDataIds: ['e5000032-9f4b-41c8-a7a7-d48f8df8e44b'],
  },
  {
    id: 'a0100001-c8eb-4da0-838a-43d407dab2df',
    requestId: getTestContractIdForFixture() + '-202303-00001',
    createdAt: '2023-03-01 01:01:03.000000+00',
    updatedAt: '2023-03-02 01:01:01.000000+00',
    latestEditorId: 'system',
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    orderedUserId: DUMMY_USER.stringUserId(),
    status: OrderStatus.Completed,
    downloadExpired: '2023-03-14 01:01:03.000000+00',
    productDataIds: [
      'e5000001-9f4b-41c8-a7a7-d48f8df8e44b',
      'e5000031-9f4b-41c8-a7a7-d48f8df8e44b',
    ],
  },
  {
    id: 'a0100002-c8eb-4da0-838a-43d407dab2df',
    requestId: getTestContractIdForFixture() + '-202303-00002',
    createdAt: '2023-03-01 01:01:01.000000+00',
    updatedAt: '2023-03-02 01:01:01.000000+00',
    latestEditorId: 'system',
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    orderedUserId: DUMMY_USER.stringUserId(),
    status: OrderStatus.Completed,
    downloadExpired: '2023-03-15 01:01:02.000000+00',
    productDataIds: [
      'e5000001-9f4b-41c8-a7a7-d48f8df8e44b',
      'e5000002-9f4b-41c8-a7a7-d48f8df8e44b',
    ],
  },
  {
    id: 'a0100003-c8eb-4da0-838a-43d407dab2df',
    requestId: getTestContractIdForFixture() + '-202311-00001',
    createdAt: '2023-11-01 01:01:02.000000+00',
    updatedAt: '2023-11-02 01:01:01.000000+00',
    latestEditorId: 'system',
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    orderedUserId: DUMMY_USER.stringUserId(),
    status: OrderStatus.Completed,
    downloadExpired: '2023-03-15 01:01:01.000000+00',
    productDataIds: [
      'e5000001-9f4b-41c8-a7a7-d48f8df8e44b',
      'e5000002-9f4b-41c8-a7a7-d48f8df8e44b',
      'e5000003-9f4b-41c8-a7a7-d48f8df8e44b',
    ],
  },
  {
    //to check downloadable order
    id: 'a0100021-c8eb-4da0-838a-43d407dab2df',
    requestId: getTestContractIdForFixture() + '-202311-00002',
    createdAt: '2023-11-11 01:01:01.000000+00',
    updatedAt: '2023-11-12 01:01:01.000000+00',
    latestEditorId: 'system',
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    orderedUserId: DUMMY_USER.stringUserId(),
    status: OrderStatus.Completed,
    downloadExpired: '2024-04-05 01:01:01.000000+00', //should be newer than test fake date
    productDataIds: ['e5000022-9f4b-41c8-a7a7-d48f8df8e44b'],
    targetReprocessingIndex: [0],
  },
  {
    id: 'a0100022-c8eb-4da0-838a-43d407dab2df',
    requestId: getTestContractIdForFixture() + '-202311-00003',
    createdAt: '2023-11-11 01:00:00.000000+00',
    updatedAt: '2023-11-12 01:02:02.000000+00',
    latestEditorId: 'system',
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    orderedUserId: DUMMY_USER.stringUserId(),
    status: OrderStatus.New,
    downloadExpired: '2023-11-25 01:00:00.000000+00',
    productDataIds: ['e5000024-9f4b-41c8-a7a7-d48f8df8e44b'],
    targetReprocessingIndex: [0],
  },
  {
    //to check download period valid, but pdv not ready test
    id: 'a0100023-c8eb-4da0-838a-43d407dab2df',
    requestId: getTestAnotherContractIdForFixture() + '-202310-00001',
    createdAt: '2023-10-11 01:00:00.000000+00',
    updatedAt: '2023-10-12 01:02:02.000000+00',
    latestEditorId: 'system',
    organizationId: getTestAnotherOrganizationIdForFixture(),
    contractId: getTestAnotherContractIdForFixture(),
    orderedUserId: DUMMY_ANOTHER_USER.stringUserId(),
    status: OrderStatus.New,
    downloadExpired: '2024-04-30 01:02:02.000000+00', //should be newer than test fake date
    productDataIds: ['e5000024-9f4b-41c8-a7a7-d48f8df8e44b'],
    targetReprocessingIndex: [0],
  },
  {
    //to check download period valid and pdvs ready
    id: 'a0100024-c8eb-4da0-838a-43d407dab2df',
    requestId: getTestAnotherContractIdForFixture() + '-202310-00002',
    createdAt: '2023-10-11 01:00:00.000000+00',
    updatedAt: '2023-10-12 01:03:03.000000+00',
    latestEditorId: 'system',
    organizationId: getTestAnotherOrganizationIdForFixture(),
    contractId: getTestAnotherContractIdForFixture(),
    orderedUserId: DUMMY_ANOTHER_USER.stringUserId(),
    status: OrderStatus.Completed,
    downloadExpired: '2024-04-30 01:02:02.000000+00', //should be newer than test fake date
    productDataIds: [
      'e5000031-9f4b-41c8-a7a7-d48f8df8e44b',
      'e5000032-9f4b-41c8-a7a7-d48f8df8e44b',
    ],
  },
  {
    //to check 1 item multi product and download period valid
    id: 'a0100031-c8eb-4da0-838a-43d407dab2df',
    requestId: getTestAnotherContractIdForFixture() + '-202310-00003',
    createdAt: '2023-10-11 01:01:00.000000+00',
    updatedAt: '2023-10-12 01:03:02.000000+00',
    latestEditorId: getTestAnotherUserIdForFixture(),
    organizationId: getTestAnotherOrganizationIdForFixture(),
    contractId: getTestAnotherContractIdForFixture(),
    orderedUserId: DUMMY_ANOTHER_USER.stringUserId(),
    status: OrderStatus.New,
    downloadExpired: '2024-04-30 01:02:02.000000+00', //should be newer than test fake date
    productDataIds: [
      'e5000042-9f4b-41c8-a7a7-d48f8df8e44b',
      'e5000043-9f4b-41c8-a7a7-d48f8df8e44b',
    ],
    targetReprocessingIndex: [0, 0],
  },
  {
    //to check multi item multi product and download period valid
    id: 'a0100032-c8eb-4da0-838a-43d407dab2df',
    requestId: getTestAnotherContractIdForFixture() + '-202310-00004',
    createdAt: '2023-10-11 01:02:00.000000+00',
    updatedAt: '2023-10-12 01:04:02.000000+00',
    latestEditorId: getTestAnotherUserIdForFixture(),
    organizationId: getTestAnotherOrganizationIdForFixture(),
    contractId: getTestAnotherContractIdForFixture(),
    orderedUserId: DUMMY_ANOTHER_USER.stringUserId(),
    status: OrderStatus.New,
    downloadExpired: '2024-04-30 01:02:02.000000+00', //should be newer than test fake date
    productDataIds: [
      'e5000044-9f4b-41c8-a7a7-d48f8df8e44b',
      'e5000045-9f4b-41c8-a7a7-d48f8df8e44b',
    ],
    targetReprocessingIndex: [0, 0],
  },
  {
    //to check multi item , one have pdr
    id: 'a0100033-c8eb-4da0-838a-43d407dab2df',
    requestId: getTestAnotherContractIdForFixture() + '-202310-00005',
    createdAt: '2023-10-14 01:02:00.000000+00',
    updatedAt: '2023-10-14 01:04:02.000000+00',
    latestEditorId: getTestAnotherUserIdForFixture(),
    organizationId: getTestAnotherOrganizationIdForFixture(),
    contractId: getTestAnotherContractIdForFixture(),
    orderedUserId: DUMMY_ANOTHER_USER.stringUserId(),
    status: OrderStatus.New,
    downloadExpired: '2024-04-30 01:02:02.000000+00', //should be newer than test fake date
    productDataIds: [
      'e5000001-9f4b-41c8-a7a7-d48f8df8e44b',
      'e5000043-9f4b-41c8-a7a7-d48f8df8e44b',
    ],
    targetReprocessingIndex: [0, 0],
  },
  {
    //to check basic order , one have pdr
    id: 'a0100034-c8eb-4da0-838a-43d407dab2df',
    requestId: getTestContractIdForFixture() + '-202310-00004',
    createdAt: '2023-10-14 01:02:00.000000+00',
    updatedAt: '2023-10-14 01:04:02.000000+00',
    latestEditorId: getTestUserIdForFixture(),
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    orderedUserId: DUMMY_USER.stringUserId(),
    status: OrderStatus.New,
    downloadExpired: '2024-04-30 01:02:02.000000+00', //should be newer than test fake date
    productDataIds: ['e5000002-9f4b-41c8-a7a7-d48f8df8e44b'],
    targetReprocessingIndex: [0],
  },
  {
    //to check multi organization order  one have pdr
    id: 'a0100035-c8eb-4da0-838a-43d407dab2df',
    requestId: getTestContractIdForFixture() + '-202310-00005',
    createdAt: '2023-10-13 01:02:00.000000+00',
    updatedAt: '2023-10-13 01:04:02.000000+00',
    latestEditorId: getTestUserIdForFixture(),
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    orderedUserId: DUMMY_USER.stringUserId(),
    status: OrderStatus.New,
    downloadExpired: '2023-10-27 01:02:02.000000+00',
    productDataIds: ['e5000046-9f4b-41c8-a7a7-d48f8df8e44b'],
    targetReprocessingIndex: [0],
  },
  {
    //to check multi organization order  one have pdr
    id: 'a0100036-c8eb-4da0-838a-43d407dab2df',
    requestId: getTestThirdContractIdForFixture() + '-202310-00001',
    createdAt: '2023-10-13 01:02:00.000000+00',
    updatedAt: '2023-10-13 01:04:02.000000+00',
    latestEditorId: getTestThirdUserIdForFixture(),
    organizationId: getTestThirdOrganizationIdForFixture(),
    contractId: getTestThirdContractIdForFixture(),
    orderedUserId: getTestThirdUserIdForFixture(),
    status: OrderStatus.New,
    downloadExpired: '2024-04-30 01:02:02.000000+00', //should be newer than test fake date
    productDataIds: ['e5000046-9f4b-41c8-a7a7-d48f8df8e44b'],
    targetReprocessingIndex: [0],
  },
  {
    //to check multi organization order one have pdr and multi PD
    id: 'a0100037-c8eb-4da0-838a-43d407dab2df',
    requestId: getTestContractIdForFixture() + '-202310-00006',
    createdAt: '2023-10-13 01:02:00.000000+00',
    updatedAt: '2023-10-13 01:04:02.000000+00',
    latestEditorId: getTestUserIdForFixture(),
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    orderedUserId: DUMMY_USER.stringUserId(),
    status: OrderStatus.New,
    downloadExpired: '2024-04-30 01:02:02.000000+00', //should be newer than test fake date
    productDataIds: [
      'e5000047-9f4b-41c8-a7a7-d48f8df8e44b',
      'e5000048-9f4b-41c8-a7a7-d48f8df8e44b',
    ],
    targetReprocessingIndex: [0, 0],
  },
  {
    //to check multi organization order  one have pdr
    id: 'a0100038-c8eb-4da0-838a-43d407dab2df',
    requestId: getTestThirdContractIdForFixture() + '-202310-00002',
    createdAt: '2023-10-13 01:02:00.000000+00',
    updatedAt: '2023-10-13 01:04:02.000000+00',
    latestEditorId: getTestThirdUserIdForFixture(),
    organizationId: getTestThirdOrganizationIdForFixture(),
    contractId: getTestThirdContractIdForFixture(),
    orderedUserId: getTestThirdUserIdForFixture(),
    status: OrderStatus.New,
    downloadExpired: '2023-10-27 01:02:02.000000+00',
    productDataIds: [
      'e5000047-9f4b-41c8-a7a7-d48f8df8e44b',
      'e5000048-9f4b-41c8-a7a7-d48f8df8e44b',
    ],
    targetReprocessingIndex: [0, 0],
  },
  {
    //to check  pdr and rr corner case for SR
    id: 'a0100039-c8eb-4da0-838a-43d407dab2df',
    requestId: getTestThirdContractIdForFixture() + '-202311-00001',
    createdAt: '2023-11-02 01:02:00.000000+00',
    updatedAt: '2023-11-02 01:02:02.000000+00',
    latestEditorId: getTestThirdUserIdForFixture(),
    organizationId: getTestThirdOrganizationIdForFixture(),
    contractId: getTestThirdContractIdForFixture(),
    orderedUserId: getTestThirdUserIdForFixture(),
    status: OrderStatus.New,
    downloadExpired: '2024-05-07 01:02:02.000000+00', //should be newer than test fake date
    productDataIds: ['e5000049-9f4b-41c8-a7a7-d48f8df8e44b'],
    targetReprocessingIndex: [0],
  },
  {
    //to check observation start old
    id: 'a0100041-c8eb-4da0-838a-43d407dab2df',
    requestId: getTestContractIdForFixture() + '-202312-00001',
    createdAt: '2023-12-14 01:02:00.000000+00',
    updatedAt: '2023-12-14 01:04:02.000000+00',
    latestEditorId: getTestUserIdForFixture(),
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    orderedUserId: DUMMY_USER.stringUserId(),
    status: OrderStatus.Completed,
    downloadExpired: '2024-04-30 01:02:02.000000+00', //should be newer than test fake date
    productDataIds: ['e5000051-9f4b-41c8-a7a7-d48f8df8e44b'],
    targetReprocessingIndex: [0],
  },
  {
    //to check observation start latest , latest created one becomes first,
    //   and download expired latest
    id: 'a0100042-c8eb-4da0-838a-43d407dab2df',
    requestId: getTestContractIdForFixture() + '-202312-00002',
    createdAt: '2023-12-15 01:02:00.000000+00',
    updatedAt: '2023-12-15 01:04:02.000000+00',
    latestEditorId: getTestUserIdForFixture(),
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    orderedUserId: DUMMY_USER.stringUserId(),
    status: OrderStatus.Completed,
    downloadExpired: '2024-04-30 01:02:02.000000+00', //should be newer than test fake date
    productDataIds: ['e5000052-9f4b-41c8-a7a7-d48f8df8e44b'],
    targetReprocessingIndex: [0],
  },
  {
    //to check offnadir and Desc order
    id: 'a0100043-c8eb-4da0-838a-43d407dab2df',
    requestId: getTestContractIdForFixture() + '-202306-00001',
    createdAt: '2023-06-01 01:01:01.000000+00',
    updatedAt: '2023-06-01 01:01:01.000000+00',
    latestEditorId: 'system',
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    orderedUserId: DUMMY_USER.stringUserId(),
    status: OrderStatus.Completed,
    downloadExpired: '2023-06-15 01:01:01.000000+00',
    productDataIds: ['e5000023-9f4b-41c8-a7a7-d48f8df8e44b'],
  },
  //to check multi rr 1/2
  {
    id: 'a0100044-c8eb-4da0-838a-43d407dab2df',
    requestId: getTestAnotherContractIdForFixture() + '-202312-00001',
    createdAt: '2023-12-01 01:01:02.000000+00',
    updatedAt: '2023-12-01 01:01:02.000000+00',
    latestEditorId: 'system',
    organizationId: getTestAnotherOrganizationIdForFixture(),
    contractId: getTestAnotherContractIdForFixture(),
    orderedUserId: DUMMY_ANOTHER_USER.stringUserId(),
    status: OrderStatus.Completed,
    downloadExpired: '2023-12-15 01:01:01.000000+00',
    productDataIds: ['e5000041-9f4b-41c8-a7a7-d48f8df8e44b'],
    targetReprocessingIndex: [0],
  },
  //to check multi rr 2/2
  {
    id: 'a0100045-c8eb-4da0-838a-43d407dab2df',
    requestId: getTestThirdContractIdForFixture() + '-202312-00001',
    createdAt: '2023-12-14 01:01:02.000000+00',
    updatedAt: '2023-12-14 01:01:02.000000+00',
    latestEditorId: 'system',
    organizationId: getTestThirdOrganizationIdForFixture(),
    contractId: getTestThirdContractIdForFixture(),
    orderedUserId: DUMMY_ANOTHER_USER.stringUserId(),
    status: OrderStatus.New,
    downloadExpired: '2023-12-28 01:01:01.000000+00',
    productDataIds: ['e5000041-9f4b-41c8-a7a7-d48f8df8e44b'],
    targetReprocessingIndex: [1],
  },
];

export const insertFixtureArchivePurchaseRequest = async (ds: DataSource) => {
  return await ds.transaction(async (em) => {
    const targets = await fixtureArchivePurchaseRequest.reduce(async (p, c) => {
      const r = await p;
      const tmp = em.getRepository(ArchivePurchaseRequest).create(c);
      if (c.productDataIds) {
        const pds = await em.getRepository(ProductData).find({
          where: { id: In(c.productDataIds) },
          relations: [
            'sceneInfo',
            'reprocessingRequests',
            'taskingInfo',
            'productDataVersions',
          ],
          order: { id: 'ASC', productDataVersions: { no: 'DESC' } },
        });
        tmp.archivePurchasedProductData = pds.map((pd) => {
          return plainToInstance(ArchivePurchasedProductData, {
            archivePurchaseRequest: tmp,
            productData: pd,
            productDataVersion:
              // fixtures use first productDataVersion
              tmp.status === OrderStatus.New && c.productDataIds.length === 1
                ? null
                : (pd.productDataVersions?.length >= 1 &&
                      tmp.status === OrderStatus.Completed) ||
                    (pd.reprocessingRequests.length >= 1 &&
                      pd.reprocessingRequests[0].status ===
                        ProcessingStatus.Completed)
                  ? pd.productDataVersions[0]
                  : null,
          });
        });
        tmp.reprocessingRequests = pds.reduce((p, pd, idx) => {
          if (c.targetReprocessingIndex) {
            p.push(pd.reprocessingRequests[c.targetReprocessingIndex[idx]]);
          }
          return p;
        }, []);
      }
      r.push(tmp);
      return r;
    }, Promise.resolve(new Array<ArchivePurchaseRequest>()));
    const aprs = await em.getRepository(ArchivePurchaseRequest).save(targets);
    let i = 1;
    const DAY_FRESH = subDays(TEST_FAKE_TIME, 30);
    const apItems = aprs.reduce((p, c) => {
      const existScene = {};
      for (const appd of c.archivePurchasedProductData) {
        if (existScene[c.id + appd.productData.sceneInfo.id]) {
          continue;
        }
        existScene[c.id + appd.productData.sceneInfo.id] = true;
        const apItem = em.getRepository(ArchivePurchasedItem).create();
        apItem.archivePurchaseRequest = c;
        apItem.sceneInfo = appd.productData.sceneInfo;
        apItem.registrationId = i++;
        apItem.dataSourceType =
          appd.productData.taskingInfo.observationStart < DAY_FRESH
            ? DataSourceType.ARCHIVE
            : DataSourceType.NEW;
        p.push(apItem);
      }
      return p;
    }, []);
    await em.getRepository(ArchivePurchasedItem).save(apItems);

    const apProductData = aprs.reduce((p, c) => {
      p.push(...c.archivePurchasedProductData);
      return p;
    }, []);
    await em.getRepository(ArchivePurchasedProductData).save(apProductData);

    return aprs;
  });
};
