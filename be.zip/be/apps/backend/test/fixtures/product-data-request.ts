import {
  FlightDirection,
  ProcessingStatus,
  ProductFormat,
  ResolutionMode,
  SystemContract,
  SystemOrganization,
} from '@iris-lib/constants';
import { ProductDataRequest, TaskingInfo } from '@iris-lib/db/entities';
import { DataSource, DeepPartial } from 'typeorm';

export const fixtureProductDataRequests: Array<
  DeepPartial<ProductDataRequest>
> = [
  {
    taskingInfo: { name: 'fixture-tasking_info-1' },
    flightDirection: FlightDirection.Ascending,
    productFormat: ProductFormat.GRD_GEOTIFF,
    resolutionMode: ResolutionMode.SR,
    sceneNo: 1,
    status: ProcessingStatus.New,
  },
  {
    taskingInfo: { name: 'fixture-tasking_info-1' },
    flightDirection: FlightDirection.Ascending,
    productFormat: ProductFormat.GRD_GEOTIFF,
    resolutionMode: ResolutionMode.SR,
    sceneNo: 2,
    status: ProcessingStatus.New,
  },
  {
    taskingInfo: { name: 'fixture-tasking_info-1' },
    flightDirection: FlightDirection.Ascending,
    productFormat: ProductFormat.SLC_SICD,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 1,
    status: ProcessingStatus.New,
  },
  {
    taskingInfo: { name: 'fixture-tasking_info-1' },
    flightDirection: FlightDirection.Ascending,
    productFormat: ProductFormat.SLC_SICD,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 2,
    status: ProcessingStatus.Failed,
  },
  {
    taskingInfo: { name: 'fixture-tasking_info-1' },
    flightDirection: FlightDirection.Ascending,
    productFormat: ProductFormat.SLC_CEOS,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 1,
    status: ProcessingStatus.New,
  },
  {
    taskingInfo: { name: 'fixture-tasking_info-1' },
    flightDirection: FlightDirection.Ascending,
    productFormat: ProductFormat.SLC_CEOS,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 2,
    status: ProcessingStatus.New,
  },
  {
    taskingInfo: { name: 'fixture-tasking_info-4' },
    flightDirection: FlightDirection.Ascending,
    productFormat: ProductFormat.GRD_GEOTIFF,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 1,
    status: ProcessingStatus.Completed,
  },
  {
    taskingInfo: { name: 'fixture-tasking_info-4' },
    flightDirection: FlightDirection.Ascending,
    productFormat: ProductFormat.SLC_SICD,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 2,
    status: ProcessingStatus.Completed,
  },
  {
    taskingInfo: { name: 'fixture-tasking_info-5' },
    flightDirection: FlightDirection.Descending,
    productFormat: ProductFormat.GRD_GEOTIFF,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 1,
    status: ProcessingStatus.New,
  },
  {
    taskingInfo: { name: 'fixture-tasking_info-5' },
    flightDirection: FlightDirection.Descending,
    productFormat: ProductFormat.GRD_GEOTIFF,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 2,
    status: ProcessingStatus.New,
  },
  {
    taskingInfo: { name: 'fixture-tasking_info-5' },
    flightDirection: FlightDirection.Descending,
    productFormat: ProductFormat.GRD_GEOTIFF,
    resolutionMode: ResolutionMode.SR,
    sceneNo: 1,
    status: ProcessingStatus.New,
  },
  {
    taskingInfo: { name: 'fixture-tasking_info-5' },
    flightDirection: FlightDirection.Descending,
    productFormat: ProductFormat.GRD_GEOTIFF,
    resolutionMode: ResolutionMode.SR,
    sceneNo: 2,
    status: ProcessingStatus.New,
  },
  {
    taskingInfo: { name: 'fixture-tasking_info-5' },
    flightDirection: FlightDirection.Descending,
    productFormat: ProductFormat.SLC_SICD,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 1,
    status: ProcessingStatus.New,
  },
  {
    taskingInfo: { name: 'fixture-tasking_info-5' },
    flightDirection: FlightDirection.Descending,
    productFormat: ProductFormat.SLC_SICD,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 2,
    status: ProcessingStatus.New,
  },
  {
    taskingInfo: { name: 'fixture-tasking_info-5' },
    flightDirection: FlightDirection.Descending,
    productFormat: ProductFormat.SLC_CEOS,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 1,
    status: ProcessingStatus.New,
  },
  {
    taskingInfo: { name: 'fixture-tasking_info-5' },
    flightDirection: FlightDirection.Descending,
    productFormat: ProductFormat.SLC_CEOS,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 2,
    status: ProcessingStatus.New,
  },
  {
    taskingInfo: { name: 'fixture-tasking_info-6' },
    flightDirection: FlightDirection.Descending,
    productFormat: ProductFormat.GRD_GEOTIFF,
    resolutionMode: ResolutionMode.SR,
    sceneNo: 0,
    status: ProcessingStatus.New,
  },
  {
    taskingInfo: { name: 'fixture-tasking_info-7' },
    flightDirection: FlightDirection.Descending,
    productFormat: ProductFormat.GRD_GEOTIFF,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 1,
    status: ProcessingStatus.Completed,
    organizationId: SystemOrganization.NO_ORGANIZATION,
    contractId: SystemContract.NO_CONTRACT,
  },
  {
    taskingInfo: { name: 'fixture-tasking_info-7' },
    flightDirection: FlightDirection.Descending,
    productFormat: ProductFormat.SLC_SICD,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 1,
    status: ProcessingStatus.Completed,
  },
  {
    taskingInfo: { name: 'fixture-tasking_info-7' },
    flightDirection: FlightDirection.Descending,
    productFormat: ProductFormat.SLC_CEOS,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 1,
    status: ProcessingStatus.Completed,
  },
  {
    taskingInfo: { name: 'fixture-tasking_info-7' },
    flightDirection: FlightDirection.Descending,
    productFormat: ProductFormat.GRD_GEOTIFF,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 2,
    status: ProcessingStatus.New,
    organizationId: SystemOrganization.NO_ORGANIZATION,
    contractId: SystemContract.NO_CONTRACT,
  },
  {
    taskingInfo: { name: 'fixture-tasking_info-7' },
    flightDirection: FlightDirection.Descending,
    productFormat: ProductFormat.SLC_SICD,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 2,
    status: ProcessingStatus.Completed,
  },
  {
    taskingInfo: { name: 'fixture-tasking_info-7' },
    flightDirection: FlightDirection.Descending,
    productFormat: ProductFormat.SLC_CEOS,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 2,
    status: ProcessingStatus.Completed,
  },
  {
    taskingInfo: { name: 'Afixture-tasking_info-11' },
    flightDirection: FlightDirection.Descending,
    productFormat: ProductFormat.SLC_SICD,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 2,
    status: ProcessingStatus.Completed,
  },
  {
    taskingInfo: { name: 'Afixture-tasking_info-11' },
    flightDirection: FlightDirection.Descending,
    productFormat: ProductFormat.GRD_GEOTIFF,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 2,
    status: ProcessingStatus.Completed,
  },
  {
    taskingInfo: { name: 'Afixture-tasking_info-11' },
    flightDirection: FlightDirection.Descending,
    productFormat: ProductFormat.GRD_GEOTIFF,
    resolutionMode: ResolutionMode.SR,
    sceneNo: 2,
    status: ProcessingStatus.New,
  },
  {
    taskingInfo: { name: 'Afixture-tasking_info-21' },
    flightDirection: FlightDirection.Descending,
    productFormat: ProductFormat.GRD_GEOTIFF,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 2,
    status: ProcessingStatus.New,
  },
  {
    taskingInfo: { name: 'fixture-tasking_info-22' },
    flightDirection: FlightDirection.Ascending,
    productFormat: ProductFormat.ORT_GEOTIFF,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 0,
    status: ProcessingStatus.Completed,
  },
  {
    taskingInfo: { name: 'fixture-tasking_info-23' },
    flightDirection: FlightDirection.Ascending,
    productFormat: ProductFormat.ORT_GEOTIFF,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 0,
    status: ProcessingStatus.New,
  },
];
export const fixtureProductDataRequestsArchive: Array<
  DeepPartial<ProductDataRequest>
> = [
  {
    taskingInfo: { name: 'Afixture-tasking_info-12' },
    flightDirection: FlightDirection.Descending,
    productFormat: ProductFormat.GRD_GEOTIFF,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 1,
    status: ProcessingStatus.Completed,
  },
  {
    taskingInfo: { name: 'Afixture-tasking_info-12' },
    flightDirection: FlightDirection.Descending,
    productFormat: ProductFormat.SLC_SICD,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 1,
    status: ProcessingStatus.Completed,
  },
  {
    taskingInfo: { name: 'Afixture-tasking_info-22' },
    flightDirection: FlightDirection.Descending,
    productFormat: ProductFormat.GRD_GEOTIFF,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 1,
    status: ProcessingStatus.New,
  },
  {
    taskingInfo: { name: 'Afixture-tasking_info-11' },
    flightDirection: FlightDirection.Descending,
    productFormat: ProductFormat.GRD_GEOTIFF,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 3,
    status: ProcessingStatus.Completed,
  },
  {
    taskingInfo: { name: 'Afixture-tasking_info-12' },
    flightDirection: FlightDirection.Descending,
    productFormat: ProductFormat.GRD_GEOTIFF,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 2,
    status: ProcessingStatus.Completed,
  },
  {
    taskingInfo: { name: 'Afixture-tasking_info-12' },
    flightDirection: FlightDirection.Descending,
    productFormat: ProductFormat.GRD_GEOTIFF,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 3,
    status: ProcessingStatus.Completed,
  },
  {
    taskingInfo: { name: 'Afixture-tasking_info-12' },
    flightDirection: FlightDirection.Descending,
    productFormat: ProductFormat.GRD_GEOTIFF,
    resolutionMode: ResolutionMode.SR,
    sceneNo: 2,
    status: ProcessingStatus.New,
  },
  {
    taskingInfo: { name: 'Afixture-tasking_info-01' },
    flightDirection: FlightDirection.Descending,
    productFormat: ProductFormat.GRD_GEOTIFF,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 1,
    status: ProcessingStatus.Completed,
  },
  {
    taskingInfo: { name: 'Afixture-tasking_info-31' },
    flightDirection: FlightDirection.Descending,
    productFormat: ProductFormat.GRD_GEOTIFF,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 1,
    status: ProcessingStatus.Completed,
  },
  {
    //for pdv only NO_ORGANIZATION test
    taskingInfo: { name: 'Afixture-tasking_info-32' },
    flightDirection: FlightDirection.Descending,
    productFormat: ProductFormat.GRD_GEOTIFF,
    resolutionMode: ResolutionMode.normal,
    sceneNo: 0,
    status: ProcessingStatus.Completed,
  },
];

export const insertFixtureProductDataRequest = async (
  ds: DataSource,
  fixtures: Array<DeepPartial<ProductDataRequest>>,
) => {
  return await ds.transaction(async (em) => {
    const targets = await fixtures.reduce(async (p, c) => {
      const r = await p;

      const taskingInfo = await em.getRepository(TaskingInfo).findOneOrFail({
        where: { name: c.taskingInfo.name },
        relations: { satellite: true },
      });
      c.taskingInfoId = taskingInfo.id;
      c.taskingInfo = taskingInfo;
      c.latestEditorId = taskingInfo.latestEditorId;
      c.organizationId = c.organizationId ?? taskingInfo.organizationId;
      c.contractId = c.contractId ?? taskingInfo.contractId;
      const tmp = em.getRepository(ProductDataRequest).create(c);
      r.push(tmp);
      return r;
    }, Promise.resolve(new Array<ProductDataRequest>()));

    return await em.getRepository(ProductDataRequest).insert(targets);
  });
};
