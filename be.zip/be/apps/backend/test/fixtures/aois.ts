import { Aoi } from '@iris-lib/db/entities';
import {
  getTestAnotherOrganizationIdForFixture,
  getTestAnotherUserIdForFixture,
  getTestOrganizationIdForFixture,
  getTestUserIdForFixture,
} from '@iris-lib/constants/test-support';
import { DeepPartial } from 'typeorm';

export const fixtureAois: Array<DeepPartial<Aoi>> = [
  {
    name: 'fixture-aoi-common-1',
    center: {
      coordinates: [136.22293925676638, 36.07057488390686],
      type: 'Point',
    },
    altitude: 4000,
    latestEditorId: getTestUserIdForFixture(),
    organizationId: getTestOrganizationIdForFixture(),
  },
  {
    name: 'fixture-aoi-common-2',
    center: {
      coordinates: [139.23559122231075, 37.352067492922515],
      type: 'Point',
    },
    altitude: 100,
    latestEditorId: getTestUserIdForFixture(),
    organizationId: getTestOrganizationIdForFixture(),
  },
  {
    name: 'fixture-aoi-common-3',
    center: {
      coordinates: [139.15345766053883, 35.251022585347826],
      type: 'Point',
    },
    altitude: 100,
    latestEditorId: getTestAnotherUserIdForFixture(), // other user
    organizationId: getTestAnotherOrganizationIdForFixture(), // other organization
  },
  {
    name: 'fixture-aoi-used-101',
    center: {
      coordinates: [136.22293925676638, 36.07057488390686],
      type: 'Point',
    },
    altitude: 4000,
    latestEditorId: getTestUserIdForFixture(),
    organizationId: getTestOrganizationIdForFixture(),
  },
  {
    name: 'fixture-aoi-used-102',
    center: {
      coordinates: [136.22293925676638, 36.07057488390686],
      type: 'Point',
    },
    altitude: 4000,
    latestEditorId: getTestUserIdForFixture(),
    organizationId: getTestOrganizationIdForFixture(),
  },
  {
    name: 'fixture-aoi-used-103',
    center: {
      coordinates: [136.22293925676638, 36.07057488390686],
      type: 'Point',
    },
    altitude: 4000,
    latestEditorId: getTestUserIdForFixture(),
    organizationId: getTestOrganizationIdForFixture(),
  },
  {
    name: 'Afixture-aoi-used-101',
    center: {
      coordinates: [136.22293925676638, 36.07057488390686],
      type: 'Point',
    },
    altitude: 4000,
    latestEditorId: getTestAnotherUserIdForFixture(),
    organizationId: getTestAnotherOrganizationIdForFixture(),
  },
];
