import { addDays, addSeconds, subDays } from 'date-fns';

import {
  CatalogDelayKind,
  FlightDirection,
  ImagingMode,
  LookingDirection,
  PolarizationType,
  ProductFormat,
  ResolutionMode,
  TaskingStatus,
  TaskingStatusDetail,
  TaskingType,
} from '@iris-lib/constants';
import {
  Aoi,
  Satellite,
  TaskingInfo,
  TaskingRequest,
} from '@iris-lib/db/entities';
import {
  getTestAnotherContractIdForFixture,
  getTestAnotherOrganizationIdForFixture,
  getTestAnotherUserIdForFixture,
  getTestContractIdForFixture,
  getTestOrganizationIdForFixture,
  getTestUserIdForFixture,
} from '@iris-lib/constants/test-support';
import { DataSource, DeepPartial, In } from 'typeorm';
import { associateTaskingRequestWithAois } from '.';

//this baseDate affect to product data publication_start.
export const TEST_FAKE_TIME = new Date('2024-03-01T01:00:00.000Z');
const baseDate = subDays(TEST_FAKE_TIME, 180);

export const fixtureTaskingInfos: Array<DeepPartial<TaskingInfo>> = [
  {
    name: 'fixture-tasking_info-1',
    createdAt: '2023-02-28 01:01:01.000000+00',
    updatedAt: '2023-03-01 01:01:01.000000+00',
    taskingRequest: {
      name: 'fixture-tasking_request-1',
      aois: [{ name: 'fixture-aoi-used-101' }],
    },
    scsOrderId: '9974ea33-526e-4249-81ef-d992d7b0c32a',
    scsOrderCode: '202302-10001',
    taskingType: TaskingType.Regular,
    status: TaskingStatus.ObservationCompleted,
    center: {
      coordinates: [136.22293925676638, 36.07057488390686],
      type: 'Point',
    },
    altitude: 4000,
    observationArea: {
      coordinates: [
        [
          [139.56431812672935, 35.81470688094848, 0],
          [139.56431812672935, 35.548685800882055, 0],
          [139.8503864048817, 35.548685800882055, 0],
          [139.8503864048817, 35.81470688094848, 0],
          [139.56431812672935, 35.81470688094848, 0],
        ],
      ],
      type: 'Polygon',
    },
    priority: 100000,
    imagingMode: ImagingMode.Stripmap,
    lookingDirection: LookingDirection.Left,
    flightDirection: FlightDirection.Ascending,
    offnadirAngle: 30,
    catalogDelayKind: CatalogDelayKind.NO_DELAY,
    observationStart: baseDate,
    observationEnd: addSeconds(baseDate, 2 * 8),
    satellite: {
      name: 'StriX-beta',
    },
    latestEditorId: getTestUserIdForFixture(),
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    statusDetail: TaskingStatusDetail.None,
    productDetails: [
      {
        productFormat: ProductFormat.GRD_GEOTIFF,
        resolutionMode: ResolutionMode.SR,
      },
      {
        productFormat: ProductFormat.SLC_SICD,
        resolutionMode: ResolutionMode.normal,
      },
      {
        productFormat: ProductFormat.SLC_CEOS,
        resolutionMode: ResolutionMode.normal,
      },
    ],
    polarization: PolarizationType.VV,
    downloadExpired: '2023-03-15 01:01:01.000000+00',
    scenes: 2,
    paymentId: 999990,
  },
  {
    name: 'fixture-tasking_info-2',
    createdAt: '2023-02-01 02:02:02.000000+00',
    updatedAt: '2023-02-01 02:02:02.000000+00',
    taskingRequest: {
      name: 'fixture-tasking_request-3',
      aois: [
        { name: 'fixture-aoi-used-101' },
        { name: 'fixture-aoi-used-102' },
      ],
    },
    scsOrderId: '5a056da6-c87b-4b5d-b7cd-71c7477055be',
    scsOrderCode: '202302-10002',
    taskingType: TaskingType.Regular,
    status: TaskingStatus.ObservationCompleted,
    center: {
      coordinates: [136.22293925676638, 36.07057488390686],
      type: 'Point',
    },
    altitude: 4000,
    observationArea: {
      coordinates: [
        [
          [139.56431812672935, 35.81470688094848, 0],
          [139.56431812672935, 35.548685800882055, 0],
          [139.8503864048817, 35.548685800882055, 0],
          [139.8503864048817, 35.81470688094848, 0],
          [139.56431812672935, 35.81470688094848, 0],
        ],
      ],
      type: 'Polygon',
    },
    priority: 100000,
    imagingMode: ImagingMode.Stripmap,
    lookingDirection: LookingDirection.Left,
    flightDirection: FlightDirection.Ascending,
    offnadirAngle: 30,
    catalogDelayKind: CatalogDelayKind.NO_DELAY,
    observationStart: addSeconds(baseDate, 120),
    observationEnd: addSeconds(baseDate, 120 + 1 * 8),
    satellite: {
      name: 'StriX-1',
    },
    latestEditorId: getTestUserIdForFixture(),
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    statusDetail: TaskingStatusDetail.None,
    productDetails: [
      {
        productFormat: ProductFormat.GRD_GEOTIFF,
        resolutionMode: ResolutionMode.normal,
      },
      {
        productFormat: ProductFormat.GRD_GEOTIFF,
        resolutionMode: ResolutionMode.SR,
      },
      {
        productFormat: ProductFormat.SLC_SICD,
        resolutionMode: ResolutionMode.normal,
      },
      {
        productFormat: ProductFormat.SLC_CEOS,
        resolutionMode: ResolutionMode.normal,
      },
      {
        productFormat: ProductFormat.ORT_GEOTIFF,
        resolutionMode: ResolutionMode.normal,
      },
    ],
    polarization: PolarizationType.VV,
    downloadExpired: '2023-02-15 02:02:02.000000+00',
    scenes: 1,
    paymentId: 999991,
  },
  {
    name: 'fixture-tasking_info-3',
    createdAt: '2023-02-02 03:03:03.000000+00',
    updatedAt: '2023-02-02 03:03:03.000000+00',
    taskingRequest: {
      name: 'fixture-tasking_request-2',
      aois: [{ name: 'fixture-aoi-common-3' }],
    },
    scsOrderId: 'b6a08673-ed41-43d2-acd1-5559be077431',
    scsOrderCode: '202302-10003',
    taskingType: TaskingType.Regular,
    status: TaskingStatus.ObservationCompleted,
    center: {
      coordinates: [136.22293925676638, 36.07057488390686],
      type: 'Point',
    },
    altitude: 4000,
    observationArea: {
      coordinates: [
        [
          [139.56431812672935, 35.81470688094848, 0],
          [139.56431812672935, 35.548685800882055, 0],
          [139.8503864048817, 35.548685800882055, 0],
          [139.8503864048817, 35.81470688094848, 0],
          [139.56431812672935, 35.81470688094848, 0],
        ],
      ],
      type: 'Polygon',
    },
    priority: 100000,
    imagingMode: ImagingMode.Stripmap,
    lookingDirection: LookingDirection.Right,
    flightDirection: FlightDirection.Descending,
    offnadirAngle: 30,
    catalogDelayKind: CatalogDelayKind.PERMANENT,
    observationStart: baseDate,
    observationEnd: addSeconds(baseDate, 2 * 8),
    satellite: {
      name: 'StriX-beta',
    },
    latestEditorId: getTestAnotherUserIdForFixture(),
    organizationId: getTestAnotherOrganizationIdForFixture(),
    contractId: getTestAnotherContractIdForFixture(),
    statusDetail: TaskingStatusDetail.None,
    productDetails: [
      {
        productFormat: ProductFormat.GRD_GEOTIFF,
        resolutionMode: ResolutionMode.normal,
      },
      {
        productFormat: ProductFormat.GRD_GEOTIFF,
        resolutionMode: ResolutionMode.SR,
      },
      {
        productFormat: ProductFormat.SLC_SICD,
        resolutionMode: ResolutionMode.normal,
      },
      {
        productFormat: ProductFormat.SLC_CEOS,
        resolutionMode: ResolutionMode.normal,
      },
      {
        productFormat: ProductFormat.ORT_GEOTIFF,
        resolutionMode: ResolutionMode.normal,
      },
    ],
    polarization: PolarizationType.VV,
    downloadExpired: '2023-02-16 03:03:03.000000+00',
    scenes: 2,
    paymentId: 999992,
  },
  {
    name: 'fixture-tasking_info-4',
    createdAt: '2023-02-28 01:01:01.000000+00',
    updatedAt: '2023-03-03 01:01:01.000000+00',
    taskingRequest: {
      name: 'fixture-tasking_request-4',
      aois: [{ name: 'fixture-aoi-used-101' }],
    },
    scsOrderId: '7b0651e2-16ed-4a08-858a-83ca01d6fd84',
    scsOrderCode: '202302-11001',
    taskingType: TaskingType.Urgent,
    status: TaskingStatus.ObservationCompleted,
    center: {
      coordinates: [136.22293925676638, 36.07057488390686],
      type: 'Point',
    },
    altitude: 4000,
    observationArea: {
      coordinates: [
        [
          [139.56431812672935, 35.81470688094848, 0],
          [139.56431812672935, 35.548685800882055, 0],
          [139.8503864048817, 35.548685800882055, 0],
          [139.8503864048817, 35.81470688094848, 0],
          [139.56431812672935, 35.81470688094848, 0],
        ],
      ],
      type: 'Polygon',
    },
    priority: 100000,
    imagingMode: ImagingMode.Stripmap,
    lookingDirection: LookingDirection.Right,
    flightDirection: FlightDirection.Descending,
    offnadirAngle: 30,
    catalogDelayKind: CatalogDelayKind.PERMANENT,
    observationStart: addSeconds(baseDate, 180),
    observationEnd: addSeconds(baseDate, 180 + 2 * 8),
    satellite: {
      name: 'StriX-beta',
    },
    latestEditorId: getTestAnotherUserIdForFixture(),
    organizationId: getTestAnotherOrganizationIdForFixture(),
    contractId: getTestAnotherContractIdForFixture(),
    statusDetail: TaskingStatusDetail.None,
    productDetails: [
      {
        productFormat: ProductFormat.GRD_GEOTIFF,
        resolutionMode: ResolutionMode.normal,
      },
      {
        productFormat: ProductFormat.SLC_SICD,
        resolutionMode: ResolutionMode.normal,
      },
      {
        productFormat: ProductFormat.SLC_CEOS,
        resolutionMode: ResolutionMode.normal,
      },
    ],
    polarization: PolarizationType.VV,
    downloadExpired: '2023-03-17 01:01:01.000000+00',
    scenes: 2,
    paymentId: 999992,
  },
  {
    name: 'fixture-tasking_info-5',
    createdAt: '2023-02-28 01:01:01.000000+00',
    updatedAt: '2023-03-03 01:01:01.000000+00',
    taskingRequest: {
      name: 'fixture-tasking_request-5',
      aois: [{ name: 'fixture-aoi-used-102' }],
    },
    scsOrderId: 'a05570c3-9256-4752-9638-6166eee30d95',
    scsOrderCode: '202302-11002',
    taskingType: TaskingType.Urgent,
    status: TaskingStatus.PreOrder,
    center: {
      coordinates: [136.22293925676638, 36.07057488390686],
      type: 'Point',
    },
    altitude: 4000,
    observationArea: {
      coordinates: [
        [
          [139.56431812672935, 35.81470688094848, 0],
          [139.56431812672935, 35.548685800882055, 0],
          [139.8503864048817, 35.548685800882055, 0],
          [139.8503864048817, 35.81470688094848, 0],
          [139.56431812672935, 35.81470688094848, 0],
        ],
      ],
      type: 'Polygon',
    },
    priority: 100000,
    imagingMode: ImagingMode.Stripmap,
    lookingDirection: LookingDirection.Right,
    flightDirection: FlightDirection.Descending,
    offnadirAngle: 30,
    catalogDelayKind: CatalogDelayKind.PERMANENT,
    observationStart: addSeconds(baseDate, 240),
    observationEnd: addSeconds(baseDate, 240 + 2 * 8),
    satellite: {
      name: 'StriX-beta',
    },
    latestEditorId: getTestAnotherUserIdForFixture(),
    organizationId: getTestAnotherOrganizationIdForFixture(),
    contractId: getTestAnotherContractIdForFixture(),
    statusDetail: TaskingStatusDetail.None,
    productDetails: [
      {
        productFormat: ProductFormat.GRD_GEOTIFF,
        resolutionMode: ResolutionMode.normal,
      },
      {
        productFormat: ProductFormat.GRD_GEOTIFF,
        resolutionMode: ResolutionMode.SR,
      },
      {
        productFormat: ProductFormat.SLC_SICD,
        resolutionMode: ResolutionMode.normal,
      },
      {
        productFormat: ProductFormat.SLC_CEOS,
        resolutionMode: ResolutionMode.normal,
      },
    ],
    polarization: PolarizationType.VV,
    downloadExpired: '2024-04-03 01:01:01.000000+00',
    scenes: 2,
    paymentId: 999992,
  },
  {
    name: 'fixture-tasking_info-6',
    createdAt: '2023-02-28 01:01:01.000000+00',
    updatedAt: '2023-03-04 01:01:01.000000+00',
    taskingRequest: {
      name: 'fixture-tasking_request-6',
      aois: [{ name: 'fixture-aoi-used-101' }],
    },
    scsOrderId: '2e616f2f-e31e-440f-a1a3-a22451a53914',
    scsOrderCode: '202302-12001',
    taskingType: TaskingType.Urgent,
    status: TaskingStatus.PreOrder,
    center: {
      coordinates: [136.22293925676638, 36.07057488390686],
      type: 'Point',
    },
    altitude: 4000,
    observationArea: {
      coordinates: [
        [
          [139.56431812672935, 35.81470688094848, 0],
          [139.56431812672935, 35.548685800882055, 0],
          [139.8503864048817, 35.548685800882055, 0],
          [139.8503864048817, 35.81470688094848, 0],
          [139.56431812672935, 35.81470688094848, 0],
        ],
      ],
      type: 'Polygon',
    },
    priority: 100000,
    imagingMode: ImagingMode.Stripmap,
    lookingDirection: LookingDirection.Left,
    flightDirection: FlightDirection.Descending,
    offnadirAngle: 40,
    catalogDelayKind: CatalogDelayKind.NO_DELAY,
    observationStart: addSeconds(baseDate, 300),
    observationEnd: addSeconds(baseDate, 300 + 2 * 8),
    satellite: {
      name: 'StriX-1',
    },
    latestEditorId: getTestUserIdForFixture(),
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    statusDetail: TaskingStatusDetail.None,
    productDetails: [
      {
        productFormat: ProductFormat.GRD_GEOTIFF,
        resolutionMode: ResolutionMode.SR,
      },
    ],
    polarization: PolarizationType.VV,
    downloadExpired: '2024-04-03 01:01:01.000000+00',
    scenes: 1,
    paymentId: 999990,
  },
  {
    name: 'fixture-tasking_info-7',
    createdAt: '2022-12-30 01:01:01.100000+00',
    updatedAt: '2022-12-30 01:01:01.100000+00',
    taskingRequest: {
      name: 'fixture-tasking_request-7',
      aois: [{ name: 'fixture-aoi-used-101' }],
    },
    scsOrderId: '7a24f60a-f517-4c03-9952-f4222262e253',
    scsOrderCode: '202307-12007',
    taskingType: TaskingType.Regular,
    status: TaskingStatus.ObservationCompleted,
    center: {
      coordinates: [136.22293925676638, 36.07057488390686],
      type: 'Point',
    },
    altitude: 4000,
    observationArea: {
      coordinates: [
        [
          [139.56431812672935, 35.81470688094848, 0],
          [139.56431812672935, 35.548685800882055, 0],
          [139.8503864048817, 35.548685800882055, 0],
          [139.8503864048817, 35.81470688094848, 0],
          [139.56431812672935, 35.81470688094848, 0],
        ],
      ],
      type: 'Polygon',
    },
    priority: 100000,
    imagingMode: ImagingMode.Stripmap,
    lookingDirection: LookingDirection.Left,
    flightDirection: FlightDirection.Descending,
    offnadirAngle: 40,
    catalogDelayKind: CatalogDelayKind.NO_DELAY,
    observationStart: addSeconds(baseDate, 300),
    observationEnd: addSeconds(baseDate, 300 + 2 * 8),
    satellite: {
      name: 'StriX-1',
    },
    latestEditorId: getTestUserIdForFixture(),
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    statusDetail: TaskingStatusDetail.None,
    productDetails: [
      {
        productFormat: ProductFormat.SLC_SICD,
        resolutionMode: ResolutionMode.normal,
      },
      {
        productFormat: ProductFormat.SLC_CEOS,
        resolutionMode: ResolutionMode.normal,
      },
    ],
    polarization: PolarizationType.VV,
    downloadExpired: '2023-01-13 01:01:01.100000+00',
    scenes: 2,
    paymentId: 999990,
  },
  {
    name: 'fixture-tasking_info-8',
    createdAt: '2022-12-30 01:01:01.500000+00',
    updatedAt: '2022-12-30 01:01:01.500000+00',
    taskingRequest: {
      name: 'fixture-tasking_request-8',
      aois: [{ name: 'fixture-aoi-used-101' }],
    },
    scsOrderId: '9d4909a2-9468-4ea9-b5c0-c2338f406921',
    scsOrderCode: '202308-13008',
    taskingType: TaskingType.Regular,
    status: TaskingStatus.OrderFixed,
    center: {
      coordinates: [136.22293925676638, 36.07057488390686],
      type: 'Point',
    },
    altitude: 4000,
    observationArea: {
      coordinates: [
        [
          [139.56431812672935, 35.81470688094848, 0],
          [139.56431812672935, 35.548685800882055, 0],
          [139.8503864048817, 35.548685800882055, 0],
          [139.8503864048817, 35.81470688094848, 0],
          [139.56431812672935, 35.81470688094848, 0],
        ],
      ],
      type: 'Polygon',
    },
    priority: 100000,
    imagingMode: ImagingMode.Stripmap,
    lookingDirection: LookingDirection.Left,
    flightDirection: FlightDirection.Descending,
    offnadirAngle: 40,
    catalogDelayKind: CatalogDelayKind.NO_DELAY,
    observationStart: addSeconds(baseDate, 300),
    observationEnd: addSeconds(baseDate, 300 + 2 * 8),
    satellite: {
      name: 'StriX-1',
    },
    latestEditorId: getTestAnotherUserIdForFixture(),
    organizationId: getTestAnotherOrganizationIdForFixture(),
    contractId: getTestAnotherContractIdForFixture(),
    statusDetail: TaskingStatusDetail.None,
    productDetails: [
      {
        productFormat: ProductFormat.SLC_SICD,
        resolutionMode: ResolutionMode.normal,
      },
      {
        productFormat: ProductFormat.SLC_CEOS,
        resolutionMode: ResolutionMode.normal,
      },
    ],
    polarization: PolarizationType.VV,
    downloadExpired: null,
    scenes: 2,
    paymentId: 999990,
  },
  {
    name: 'fixture-tasking_info-12',
    createdAt: '2024-05-16 01:01:01.000000+00',
    updatedAt: '2024-05-16 01:01:01.000000+00',
    taskingRequest: {
      name: 'fixture-tasking_request-9',
      aois: [{ name: 'fixture-aoi-used-103' }],
    },
    scsOrderId: '91269ac3-aba5-4021-a1a1-e9cf7b0f6bca',
    scsOrderCode: '202405-00001',
    taskingType: TaskingType.Regular,
    status: TaskingStatus.PreOrder,
    center: {
      coordinates: [136.22293925676638, 36.07057488390686],
      type: 'Point',
    },
    altitude: 4000,
    observationArea: {
      coordinates: [
        [
          [139.56431812672935, 35.81470688094848, 0],
          [139.56431812672935, 35.548685800882055, 0],
          [139.8503864048817, 35.548685800882055, 0],
          [139.8503864048817, 35.81470688094848, 0],
          [139.56431812672935, 35.81470688094848, 0],
        ],
      ],
      type: 'Polygon',
    },
    priority: 100000,
    imagingMode: ImagingMode.Stripmap,
    lookingDirection: LookingDirection.Left,
    flightDirection: FlightDirection.Descending,
    offnadirAngle: 40,
    catalogDelayKind: CatalogDelayKind.NO_DELAY,
    observationStart: addDays(baseDate, 182), // should be after 'TEST_FAKE_TIME'
    observationEnd: addSeconds(addDays(baseDate, 182), 2 * 8),
    satellite: {
      name: 'StriX-1',
    },
    latestEditorId: getTestUserIdForFixture(),
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    statusDetail: TaskingStatusDetail.None,
    productDetails: [
      {
        productFormat: ProductFormat.GRD_GEOTIFF,
        resolutionMode: ResolutionMode.SR,
      },
    ],
    polarization: PolarizationType.VV,
    downloadExpired: addDays(baseDate, 196), // should be after 'this.observationStart'
    scenes: 2,
    paymentId: 999990,
  },
  {
    name: 'Afixture-tasking_info-11',
    createdAt: '2023-04-02 03:03:03.000000+00',
    updatedAt: '2023-04-04 03:01:01.000000+00',
    taskingRequest: {
      name: 'Afixture-tasking_request-11',
      aois: [{ name: 'Afixture-aoi-used-101' }],
    },
    scsOrderId: 'ac000001-e31e-440f-a1a3-a22451a53914',
    scsOrderCode: '202312-12001',
    taskingType: TaskingType.Urgent,
    status: TaskingStatus.ObservationCompleted,
    center: {
      coordinates: [136.22293925676638, 36.07057488390686],
      type: 'Point',
    },
    altitude: 4000,
    observationArea: {
      coordinates: [
        [
          [139.56431812672935, 35.81470688094848, 0],
          [139.56431812672935, 35.548685800882055, 0],
          [139.8503864048817, 35.548685800882055, 0],
          [139.8503864048817, 35.81470688094848, 0],
          [139.56431812672935, 35.81470688094848, 0],
        ],
      ],
      type: 'Polygon',
    },
    priority: 100000,
    imagingMode: ImagingMode.Stripmap,
    lookingDirection: LookingDirection.Left,
    flightDirection: FlightDirection.Descending,
    offnadirAngle: 40,
    catalogDelayKind: CatalogDelayKind.NO_DELAY,
    observationStart: addSeconds(baseDate, 360),
    observationEnd: addSeconds(baseDate, 360 + 2 * 8),
    satellite: {
      name: 'StriX-1',
    },
    latestEditorId: getTestAnotherUserIdForFixture(),
    organizationId: getTestAnotherOrganizationIdForFixture(),
    contractId: getTestAnotherContractIdForFixture(),
    statusDetail: TaskingStatusDetail.None,
    productDetails: [
      {
        productFormat: ProductFormat.SLC_SICD,
        resolutionMode: ResolutionMode.normal,
      },
      {
        productFormat: ProductFormat.GRD_GEOTIFF,
        resolutionMode: ResolutionMode.normal,
      },
      {
        productFormat: ProductFormat.GRD_GEOTIFF,
        resolutionMode: ResolutionMode.SR,
      },
    ],
    polarization: PolarizationType.VV,
    downloadExpired: '2023-04-18 03:01:01.000000+00',
    scenes: 6,
    paymentId: 999990,
  },
  {
    name: 'Afixture-tasking_info-21',
    createdAt: '2023-03-31 01:01:01.000000+00',
    updatedAt: '2023-04-04 01:05:01.000000+00',
    taskingRequest: {
      name: 'Afixture-tasking_request-21',
      aois: [{ name: 'Afixture-aoi-used-101' }],
    },
    scsOrderId: 'ac000002-e31e-440f-a1a3-a22451a53914',
    scsOrderCode: '202312-12002',
    taskingType: TaskingType.Regular,
    status: TaskingStatus.ObservationCompleted,
    center: {
      coordinates: [136.22293925676638, 36.07057488390686],
      type: 'Point',
    },
    altitude: 4000,
    observationArea: {
      coordinates: [
        [
          [139.56431812672935, 35.81470688094848, 0],
          [139.56431812672935, 35.548685800882055, 0],
          [139.8503864048817, 35.548685800882055, 0],
          [139.8503864048817, 35.81470688094848, 0],
          [139.56431812672935, 35.81470688094848, 0],
        ],
      ],
      type: 'Polygon',
    },
    priority: 100000,
    imagingMode: ImagingMode.Stripmap,
    lookingDirection: LookingDirection.Left,
    flightDirection: FlightDirection.Descending,
    offnadirAngle: 40,
    catalogDelayKind: CatalogDelayKind.NO_DELAY,
    observationStart: addSeconds(baseDate, 420),
    observationEnd: addSeconds(baseDate, 420 + 2 * 8),
    satellite: {
      name: 'StriX-1',
    },
    latestEditorId: getTestAnotherUserIdForFixture(),
    organizationId: getTestAnotherOrganizationIdForFixture(),
    contractId: getTestAnotherContractIdForFixture(),
    statusDetail: TaskingStatusDetail.None,
    productDetails: [
      {
        productFormat: ProductFormat.GRD_GEOTIFF,
        resolutionMode: ResolutionMode.normal,
      },
    ],
    polarization: PolarizationType.VV,
    downloadExpired: '2024-04-18 01:05:01.000000+00',
    scenes: 6,
    paymentId: 999990,
  },
  {
    name: 'fixture-tasking_info-22',
    createdAt: '2024-02-28 01:01:01.000000+00',
    updatedAt: '2024-03-01 01:01:01.000000+00',
    taskingRequest: {
      name: 'fixture-tasking_request-22',
      aois: [{ name: 'fixture-aoi-used-101' }],
    },
    scsOrderId: 'c46f3c6d-01b3-4f53-bc74-368ea4a5a6e8',
    scsOrderCode: '202402-10001',
    taskingType: TaskingType.Regular,
    status: TaskingStatus.ObservationCompleted,
    center: {
      coordinates: [136.22293925676638, 36.07057488390686],
      type: 'Point',
    },
    altitude: 4000,
    observationArea: {
      coordinates: [
        [
          [139.56431812672935, 35.81470688094848, 0],
          [139.56431812672935, 35.548685800882055, 0],
          [139.8503864048817, 35.548685800882055, 0],
          [139.8503864048817, 35.81470688094848, 0],
          [139.56431812672935, 35.81470688094848, 0],
        ],
      ],
      type: 'Polygon',
    },
    priority: 100000,
    imagingMode: ImagingMode.Stripmap,
    lookingDirection: LookingDirection.Left,
    flightDirection: FlightDirection.Ascending,
    offnadirAngle: 30,
    catalogDelayKind: CatalogDelayKind.NO_DELAY,
    observationStart: baseDate,
    observationEnd: addSeconds(baseDate, 2 * 8),
    satellite: {
      name: 'StriX-beta',
    },
    latestEditorId: getTestUserIdForFixture(),
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    statusDetail: TaskingStatusDetail.None,
    productDetails: [
      {
        productFormat: ProductFormat.ORT_GEOTIFF,
        resolutionMode: ResolutionMode.normal,
      },
    ],
    polarization: PolarizationType.VV,
    downloadExpired: '2023-03-15 01:01:01.000000+00',
    scenes: 1,
    paymentId: 999990,
  },
  {
    name: 'fixture-tasking_info-23',
    createdAt: '2024-02-28 01:01:01.000000+00',
    updatedAt: '2024-03-01 01:01:01.000000+00',
    taskingRequest: {
      name: 'fixture-tasking_request-23',
      aois: [{ name: 'fixture-aoi-used-102' }],
    },
    scsOrderId: '9958ddf5-60aa-4e7a-b334-dbfc40cfa06d',
    scsOrderCode: '202402-10002',
    taskingType: TaskingType.Regular,
    status: TaskingStatus.ObservationCompleted,
    center: {
      coordinates: [136.22293925676638, 36.07057488390686],
      type: 'Point',
    },
    altitude: 4000,
    observationArea: {
      coordinates: [
        [
          [139.56431812672935, 35.81470688094848, 0],
          [139.56431812672935, 35.548685800882055, 0],
          [139.8503864048817, 35.548685800882055, 0],
          [139.8503864048817, 35.81470688094848, 0],
          [139.56431812672935, 35.81470688094848, 0],
        ],
      ],
      type: 'Polygon',
    },
    priority: 100000,
    imagingMode: ImagingMode.Stripmap,
    lookingDirection: LookingDirection.Left,
    flightDirection: FlightDirection.Ascending,
    offnadirAngle: 30,
    catalogDelayKind: CatalogDelayKind.NO_DELAY,
    observationStart: baseDate,
    observationEnd: addSeconds(baseDate, 2 * 8),
    satellite: {
      name: 'StriX-beta',
    },
    latestEditorId: getTestUserIdForFixture(),
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestAnotherContractIdForFixture(),
    statusDetail: TaskingStatusDetail.None,
    productDetails: [
      {
        productFormat: ProductFormat.ORT_GEOTIFF,
        resolutionMode: ResolutionMode.normal,
      },
    ],
    polarization: PolarizationType.VV,
    downloadExpired: '2023-03-15 01:01:01.000000+00',
    scenes: 1,
    paymentId: 999990,
  },
];

export const fixtureTaskingInfosArchive: Array<DeepPartial<TaskingInfo>> = [
  {
    name: 'Afixture-tasking_info-12',
    createdAt: '2023-01-02 01:01:01.000000+00',
    updatedAt: '2023-01-05 01:01:01.000000+00',
    taskingRequest: {
      name: 'Afixture-tasking_request-12',
      aois: [{ name: 'Afixture-aoi-used-101' }],
    },
    scsOrderId: 'ac000003-e31e-440f-a1a3-a22451a53914',
    scsOrderCode: '202312-12003',
    taskingType: TaskingType.Regular,
    status: TaskingStatus.ObservationCompleted,
    center: {
      coordinates: [136.22293925676638, 36.07057488390686],
      type: 'Point',
    },
    altitude: 4000,
    observationArea: {
      coordinates: [
        [
          [139.56431812672935, 35.81470688094848, 0],
          [139.56431812672935, 35.548685800882055, 0],
          [139.8503864048817, 35.548685800882055, 0],
          [139.8503864048817, 35.81470688094848, 0],
          [139.56431812672935, 35.81470688094848, 0],
        ],
      ],
      type: 'Polygon',
    },
    priority: 100000,
    imagingMode: ImagingMode.Stripmap,
    lookingDirection: LookingDirection.Left,
    flightDirection: FlightDirection.Descending,
    offnadirAngle: 40,
    catalogDelayKind: CatalogDelayKind.NO_DELAY,
    observationStart: addSeconds(baseDate, 480),
    observationEnd: addSeconds(baseDate, 480 + 2 * 8),
    satellite: {
      name: 'StriX-1',
    },
    latestEditorId: getTestUserIdForFixture(),
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    statusDetail: TaskingStatusDetail.None,
    productDetails: [
      {
        productFormat: ProductFormat.GRD_GEOTIFF,
        resolutionMode: ResolutionMode.normal,
      },
      {
        productFormat: ProductFormat.SLC_SICD,
        resolutionMode: ResolutionMode.normal,
      },
    ],
    polarization: PolarizationType.VV,
    downloadExpired: '2024-03-20 01:01:01.000000+00',
    scenes: 6,
    paymentId: 999990,
  },

  {
    name: 'Afixture-tasking_info-22',
    createdAt: '2023-07-31 04:01:01.000000+00',
    updatedAt: '2023-08-05 01:01:01.000000+00',
    taskingRequest: {
      name: 'Afixture-tasking_request-22',
      aois: [{ name: 'Afixture-aoi-used-101' }],
    },
    scsOrderId: 'ac000004-e31e-440f-a1a3-a22451a53914',
    scsOrderCode: '202312-12004',
    taskingType: TaskingType.Regular,
    status: TaskingStatus.ObservationCompleted,
    center: {
      coordinates: [136.22293925676638, 36.07057488390686],
      type: 'Point',
    },
    altitude: 4000,
    observationArea: {
      coordinates: [
        [
          [139.56431812672935, 35.81470688094848, 0],
          [139.56431812672935, 35.548685800882055, 0],
          [139.8503864048817, 35.548685800882055, 0],
          [139.8503864048817, 35.81470688094848, 0],
          [139.56431812672935, 35.81470688094848, 0],
        ],
      ],
      type: 'Polygon',
    },
    priority: 100000,
    imagingMode: ImagingMode.Stripmap,
    lookingDirection: LookingDirection.Right,
    flightDirection: FlightDirection.Ascending,
    offnadirAngle: 44,
    catalogDelayKind: CatalogDelayKind.NO_DELAY,
    observationStart: new Date(2023, 4, 2, 1, 2, 1),
    observationEnd: new Date(2023, 4, 2, 1, 4, 1),
    satellite: {
      name: 'StriX-alpha',
    },
    latestEditorId: getTestAnotherUserIdForFixture(),
    organizationId: getTestAnotherOrganizationIdForFixture(),
    contractId: getTestAnotherContractIdForFixture(),
    statusDetail: TaskingStatusDetail.None,
    productDetails: [
      {
        productFormat: ProductFormat.GRD_GEOTIFF,
        resolutionMode: ResolutionMode.normal,
      },
    ],
    polarization: PolarizationType.VV,
    downloadExpired: '2023-08-19 01:01:01.000000+00',
    scenes: 1,
    paymentId: 999990,
  },
  {
    //for old observation time test offnadir min, item_id asc (strix-1_min)
    name: 'Afixture-tasking_info-01',
    createdAt: '2023-01-31 01:15:01.000000+00',
    updatedAt: '2023-01-31 01:15:01.000000+00',
    taskingRequest: {
      name: 'Afixture-tasking_request-01',
      aois: [{ name: 'Afixture-aoi-used-101' }],
    },
    scsOrderId: 'ac000005-e31e-440f-a1a3-a22451a53914',
    scsOrderCode: '202302-00001',
    taskingType: TaskingType.Regular,
    status: TaskingStatus.ObservationCompleted,
    center: {
      coordinates: [136.22293925676638, 36.07057488390686],
      type: 'Point',
    },
    altitude: 4000,
    observationArea: {
      coordinates: [
        [
          [139.56431812672935, 35.81470688094848, 0],
          [139.56431812672935, 35.548685800882055, 0],
          [139.8503864048817, 35.548685800882055, 0],
          [139.8503864048817, 35.81470688094848, 0],
          [139.56431812672935, 35.81470688094848, 0],
        ],
      ],
      type: 'Polygon',
    },
    priority: 100000,
    imagingMode: ImagingMode.SlidingSpotlight,
    lookingDirection: LookingDirection.Left,
    flightDirection: FlightDirection.Descending,
    offnadirAngle: 18,
    catalogDelayKind: CatalogDelayKind.NO_DELAY,
    observationStart: new Date(2023, 2, 1, 1, 1, 1),
    observationEnd: new Date(2023, 2, 1, 1, 1, 10),
    satellite: {
      name: 'StriX-1',
    },
    latestEditorId: getTestAnotherUserIdForFixture(),
    organizationId: getTestAnotherOrganizationIdForFixture(),
    contractId: getTestAnotherContractIdForFixture(),
    statusDetail: TaskingStatusDetail.None,
    productDetails: [
      {
        productFormat: ProductFormat.GRD_GEOTIFF,
        resolutionMode: ResolutionMode.normal,
      },
    ],
    polarization: PolarizationType.VV,
    downloadExpired: '2023-02-14 01:15:01.000000+00',
    scenes: 1,
    paymentId: 999990,
  },
  {
    //for latest observation time test, item_id Desc (beta)
    name: 'Afixture-tasking_info-31',
    createdAt: '2023-12-09 01:15:01.000000+00',
    updatedAt: '2023-12-09 01:15:01.000000+00',
    taskingRequest: {
      name: 'Afixture-tasking_request-31',
      aois: [{ name: 'Afixture-aoi-used-101' }],
    },
    scsOrderId: 'ac000006-e31e-440f-a1a3-a22451a53914',
    scsOrderCode: '202312-00006',
    taskingType: TaskingType.Regular,
    status: TaskingStatus.ObservationCompleted,
    center: {
      coordinates: [136.22293925676638, 36.07057488390686],
      type: 'Point',
    },
    altitude: 4000,
    observationArea: {
      coordinates: [
        [
          [139.56431812672935, 35.81470688094848, 0],
          [139.56431812672935, 35.548685800882055, 0],
          [139.8503864048817, 35.548685800882055, 0],
          [139.8503864048817, 35.81470688094848, 0],
          [139.56431812672935, 35.81470688094848, 0],
        ],
      ],
      type: 'Polygon',
    },
    priority: 100000,
    imagingMode: ImagingMode.Stripmap,
    lookingDirection: LookingDirection.Left,
    flightDirection: FlightDirection.Descending,
    offnadirAngle: 40,
    catalogDelayKind: CatalogDelayKind.NO_DELAY,
    observationStart: addSeconds(baseDate, 1200),
    observationEnd: addSeconds(baseDate, 1200 + 2 * 8),
    satellite: {
      name: 'StriX-beta',
    },
    latestEditorId: getTestAnotherUserIdForFixture(),
    organizationId: getTestAnotherOrganizationIdForFixture(),
    contractId: getTestAnotherContractIdForFixture(),
    statusDetail: TaskingStatusDetail.None,
    productDetails: [
      {
        productFormat: ProductFormat.GRD_GEOTIFF,
        resolutionMode: ResolutionMode.normal,
      },
    ],
    polarization: PolarizationType.VV,
    downloadExpired: '2024-12-23 01:15:01.000000+00',
    scenes: 1,
    paymentId: 999990,
  },
  {
    //for pdv only NO_ORGANIZATION test
    name: 'Afixture-tasking_info-32',
    createdAt: '2023-03-09 01:15:01.000000+00',
    updatedAt: '2023-03-09 01:15:01.000000+00',
    taskingRequest: {
      name: 'Afixture-tasking_request-32',
      aois: [{ name: 'Afixture-aoi-used-101' }],
    },
    scsOrderId: 'ac000007-e31e-440f-a1a3-a22451a53914',
    scsOrderCode: '202303-00002',
    taskingType: TaskingType.Regular,
    status: TaskingStatus.ObservationCompleted,
    center: {
      coordinates: [136.22293925676638, 36.07057488390686],
      type: 'Point',
    },
    altitude: 4000,
    observationArea: {
      coordinates: [
        [
          [139.56431812672935, 35.81470688094848, 0],
          [139.56431812672935, 35.548685800882055, 0],
          [139.8503864048817, 35.548685800882055, 0],
          [139.8503864048817, 35.81470688094848, 0],
          [139.56431812672935, 35.81470688094848, 0],
        ],
      ],
      type: 'Polygon',
    },
    priority: 100000,
    imagingMode: ImagingMode.Stripmap,
    lookingDirection: LookingDirection.Left,
    flightDirection: FlightDirection.Descending,
    offnadirAngle: 40,
    catalogDelayKind: CatalogDelayKind.NO_DELAY,
    observationStart: addSeconds(baseDate, 1200),
    observationEnd: addSeconds(baseDate, 1200 + 2 * 8),
    satellite: {
      name: 'StriX-beta',
    },
    latestEditorId: getTestAnotherUserIdForFixture(),
    organizationId: getTestAnotherOrganizationIdForFixture(),
    contractId: getTestAnotherContractIdForFixture(),
    statusDetail: TaskingStatusDetail.None,
    productDetails: [
      {
        productFormat: ProductFormat.GRD_GEOTIFF,
        resolutionMode: ResolutionMode.normal,
      },
    ],
    polarization: PolarizationType.VV,
    downloadExpired: '2023-12-23 01:15:01.000000+00',
    scenes: 1,
    paymentId: 999990,
  },
];

export const insertFixtureTaskingInfo = async (
  ds: DataSource,
  fixtures: Array<DeepPartial<TaskingInfo>>,
) => {
  return await ds.transaction(async (em) => {
    //to re-use fixture data on test setup, teadown
    // deep copy original data (some field is deleted in reduce.)
    const copy = structuredClone(fixtures);
    const targets = await copy.reduce(async (p, c) => {
      const r = await p;
      const sat = await em
        .getRepository(Satellite)
        .findOneOrFail({ where: { name: c.satellite.name } });

      const aois = await em.getRepository(Aoi).find({
        where: { name: In(c.taskingRequest.aois.map((x) => x.name)) },
      });
      const tr = await em
        .getRepository(TaskingRequest)
        .findOneOrFail({ where: { name: c.taskingRequest.name } });

      await associateTaskingRequestWithAois(ds, tr, aois);
      c.satId = sat.satId;
      delete c.satellite;
      c.taskingRequestId = tr.id;
      delete c.taskingRequest;
      const a = em.getRepository(TaskingInfo).create(c);
      r.push(a);
      return r;
    }, Promise.resolve(new Array<TaskingInfo>()));

    return await em.getRepository(TaskingInfo).insert(targets);
  });
};
