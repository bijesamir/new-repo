import {
  DeliveryRequestSource,
  DeliveryRequestStatus,
  DeliveryRequestStatusDetail,
  getTestContractIdForFixture,
  getTestOrganizationIdForFixture,
  getTestUserIdForFixture,
} from '@iris-lib/constants';
import { DeliveryRequest } from '@iris-lib/db/entities';
import { DeepPartial } from 'typeorm';

export const fixtureDeliveryRequests: Array<DeepPartial<DeliveryRequest>> = [
  {
    productDataVersionId: '9d2f5f8c-2897-4b68-a04f-b77e1d157597',
    status: DeliveryRequestStatus.Failed,
    statusDetail: DeliveryRequestStatusDetail.None,
    latestEditorId: getTestUserIdForFixture(),
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    source: DeliveryRequestSource.Observation,
  },

  {
    productDataVersionId: '5e8f8a91-4cc4-41c0-9299-94a82313e2f0',
    status: DeliveryRequestStatus.Completed,
    statusDetail: DeliveryRequestStatusDetail.None,
    latestEditorId: getTestUserIdForFixture(),
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    source: DeliveryRequestSource.Observation,
  },

  {
    productDataVersionId: '28ce9c86-fcf9-49f9-b467-e4a8bb9e8d41',
    status: DeliveryRequestStatus.Completed,
    statusDetail: DeliveryRequestStatusDetail.None,
    latestEditorId: getTestUserIdForFixture(),
    organizationId: getTestOrganizationIdForFixture(),
    contractId: getTestContractIdForFixture(),
    source: DeliveryRequestSource.Observation,
  },
];
