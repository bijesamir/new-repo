import {
  Aoi,
  ArchivePurchaseRequest,
  DeliveryConfig,
  DeliveryRequest,
  ObservableArea,
  ProductData,
  ProductDataRequest,
  ProductDataVersion,
  ReprocessingRequest,
  Satellite,
  SceneInfo,
  TaskingInfo,
  TaskingRequest,
} from '@iris-lib/db/entities';
import { DataSource, In, Like } from 'typeorm';
import { satellites } from '../../seeds';
import { fixtureAois } from './aois';

import { fixtureTaskingRequest } from './tasking-request';

import {
  FlightDirection,
  ImagingMode,
  LookingDirection,
  PolarizationType,
  ProductFormat,
  ResolutionMode,
} from '@iris-lib/constants';
import { plainToInstance } from 'class-transformer';
import {
  ScsCandidateDto,
  ScsCandidateDtoDecorator,
} from '../../src/models/dto/mission-portal/scs-candidate.dto';
import { insertFixtureArchivePurchaseRequest } from './archive-purchase-request';
import { fixtureDeliveryConfigs } from './delivery-config';
import { fixtureDeliveryRequests } from './delivery-request';
import { fixtureObservableArea } from './observable-area';
import {
  fixtureProductData,
  fixtureProductDataForArchive,
  insertFixtureProductData,
} from './product-data';
import {
  fixtureProductDataRequests,
  fixtureProductDataRequestsArchive,
  insertFixtureProductDataRequest,
} from './product-data-request';
import {
  fixtureProductDataVersions,
  fixtureProductDataVersionsArchive,
  insertFixtureProductDataVersion,
} from './product-data-version';
import { insertFixtureSceneInfo } from './scene-info';
import {
  fixtureTaskingInfos,
  fixtureTaskingInfosArchive,
  insertFixtureTaskingInfo,
} from './tasking-info';

// fixture has test group you can execute like followings
// `npm run testdata:setup` or `npm run testdata:setup all`  execute all
// `npm run testdata:setup basic`  only execute
// `npm run testdata:setup fixture` means run without seed:true
export const allFixtures = {
  aoi: {
    data: fixtureAois,
    entity: Aoi,
    basic: true,
  },
  taskingRequest: {
    data: fixtureTaskingRequest,
    entity: TaskingRequest,
    basic: true,
  },
  satellite: {
    data: satellites,
    entity: Satellite,
    seed: true,
    basic: true,
  },
  taskingInfo: {
    entity: TaskingInfo,
    custom: true,
    data: fixtureTaskingInfos,
    m: insertFixtureTaskingInfo,
    basic: true,
  },
  taskingInfoArchive: {
    entity: TaskingInfo,
    custom: true,
    data: fixtureTaskingInfosArchive,
    m: insertFixtureTaskingInfo,
    archive: true,
  },
  observableArea: {
    entity: ObservableArea,
    data: fixtureObservableArea,
    basic: true,
  },
  deliveryConfig: {
    entity: DeliveryConfig,
    data: fixtureDeliveryConfigs,
    basic: true,
  },
  productDataRequest: {
    entity: ProductDataRequest,
    custom: true,
    data: fixtureProductDataRequests,
    m: insertFixtureProductDataRequest,
    basic: true,
  },
  productDataRequestArchive: {
    entity: ProductDataRequest,
    custom: true,
    data: fixtureProductDataRequestsArchive,
    m: insertFixtureProductDataRequest,
    archive: true,
  },
  productData: {
    entity: ProductData,
    custom: true,
    data: fixtureProductData,
    m: insertFixtureProductData,
    basic: true,
  },
  productDataArchive: {
    entity: ProductData,
    custom: true,
    data: fixtureProductDataForArchive,
    m: insertFixtureProductData,
    archive: true,
  },
  productDataVersion: {
    entity: ProductDataVersion,
    custom: true,
    data: fixtureProductDataVersions,
    m: insertFixtureProductDataVersion,
    basic: true,
  },
  productDataVersionArchive: {
    entity: ProductDataVersion,
    custom: true,
    data: fixtureProductDataVersionsArchive,
    m: insertFixtureProductDataVersion,
    archive: true,
  },
  sceneInfo: {
    entity: SceneInfo,
    custom: true,
    data: null,
    m: insertFixtureSceneInfo,
    basic: true,
  },
  deliveryRequest: {
    entity: DeliveryRequest,
    data: fixtureDeliveryRequests,
    basic: true,
  },
  archivePurchaseRequest: {
    entity: ArchivePurchaseRequest,
    custom: true,
    data: null,
    m: insertFixtureArchivePurchaseRequest,
    archive: true,
  },
};

export const loadFixtureAoi = async (ds: DataSource) => {
  return await ds.manager
    .getRepository(Aoi)
    .find({ where: { name: Like('fixture%') } });
};

export const loadFixtureTaskingRequest = async (
  ds: DataSource,
  prefix?: string | null,
) => {
  return await ds.manager
    .getRepository(TaskingRequest)
    .find({ where: { name: Like(prefix ? prefix : 'fixture-%') } });
};

export const loadFixtureTaskingInfo = async (ds: DataSource) => {
  return await ds.manager
    .getRepository(TaskingInfo)
    .createQueryBuilder('taskingInfo')
    .where(
      'taskingInfo.name LIKE :pattern1 OR taskingInfo.name LIKE :pattern2',
      { pattern1: 'fixture%', pattern2: 'Afixture-tasking_info-3%' },
    )
    .getMany();
};

export const loadFixtureProductDataRequest = async (ds: DataSource) => {
  // fixture-tasking_info-1 has fixtureProductDataRequests
  return await ds.manager
    .getRepository(ProductDataRequest)
    .find({ where: { scsOrderId: '9974ea33-526e-4249-81ef-d992d7b0c32a' } });
};

export const loadFixtureProductData = async (ds: DataSource) => {
  try {
    return await ds.manager
      .getRepository(ProductData)
      .createQueryBuilder('pd')
      .leftJoinAndSelect('pd.productDataVersions', 'pd_productDataVersions')
      .leftJoinAndSelect('pd.taskingInfo', 'pd_taskingInfo')
      .leftJoinAndSelect('pd_taskingInfo.taskingRequest', 'tr')
      .leftJoinAndSelect('tr.aois', 'tr_aois')
      .select()
      .where({
        id: In([
          '0603e8a8-c8eb-4da0-838a-43d407dab2df',
          '161a6d67-4eba-4bbc-84b6-a0f13ce2a37d',
          '23e62f2a-17b0-40b8-9767-7d16d8233c01',
          '337dbaca-3300-4628-98ee-c7e2d9bbf08b',
          '4d0e8288-cdf0-4359-a2c8-83e15a063dff',
        ]),
      })
      .orderBy({
        'pd.updatedAt': 'DESC',
        'pd_productDataVersions.updatedAt': 'DESC',
      })
      .getMany();
  } catch (e) {
    console.log(e);
  }
};

export const loadFixtureProductDataForArchive = async (ds: DataSource) => {
  try {
    return await ds.manager
      .getRepository(ProductData)
      .createQueryBuilder('pd')
      .leftJoinAndSelect('pd.productDataVersions', 'pd_productDataVersions')
      .leftJoinAndSelect('pd.taskingInfo', 'pd_taskingInfo')
      .leftJoinAndSelect('pd_taskingInfo.taskingRequest', 'tr')
      .leftJoinAndSelect('tr.aois', 'tr_aois')
      .leftJoinAndSelect(
        'pd.archivePurchasedProductData',
        'pd_archivePurchasedProductData',
      )
      .leftJoinAndSelect(
        'pd_archivePurchasedProductData.archivePurchaseRequest',
        'apr',
      )
      .select()
      .where({
        id: In([
          'e5000031-9f4b-41c8-a7a7-d48f8df8e44b',
          'e5000032-9f4b-41c8-a7a7-d48f8df8e44b',
          'e5000023-9f4b-41c8-a7a7-d48f8df8e44b',
          'e5000024-9f4b-41c8-a7a7-d48f8df8e44b',
          'e5000041-9f4b-41c8-a7a7-d48f8df8e44b',
          'e5000044-9f4b-41c8-a7a7-d48f8df8e44b',
          'e5000045-9f4b-41c8-a7a7-d48f8df8e44b',
          'e5000046-9f4b-41c8-a7a7-d48f8df8e44b',
          'e5000051-9f4b-41c8-a7a7-d48f8df8e44b',
          'e5000052-9f4b-41c8-a7a7-d48f8df8e44b',
          'e5000053-9f4b-41c8-a7a7-d48f8df8e44b',
        ]),
      })
      .orderBy({
        'pd.updatedAt': 'DESC',
        'pd_productDataVersions.updatedAt': 'DESC',
        'apr.updatedAt': 'DESC',
      })
      .getMany();
  } catch (e) {
    console.log(e);
  }
};

export const loadFixtureProductSceneData = async (ds: DataSource) => {
  try {
    return await ds.manager
      .getRepository(ProductData)
      .createQueryBuilder('pd')
      .innerJoinAndSelect('pd.sceneInfo', 'pd_sceneInfo')
      .leftJoinAndSelect('pd.productDataVersions', 'pd_productDataVersions')
      .leftJoinAndSelect('pd.taskingInfo', 'pd_taskingInfo')
      .leftJoinAndSelect('pd_taskingInfo.taskingRequest', 'tr')
      .leftJoinAndSelect('tr.aois', 'tr_aois')
      .select()
      .orderBy({
        'pd.updatedAt': 'DESC',
        'pd_productDataVersions.updatedAt': 'DESC',
      })
      .getMany();
  } catch (e) {
    console.log(e);
  }
};

export const loadFixtureProductDataWithSceneInfo = async (ds: DataSource) => {
  const now = new Date();
  return await ds.manager
    .getRepository(ProductData)
    .createQueryBuilder('pd')
    .innerJoinAndSelect(
      'pd.productDataVersions',
      'pdv',
      `pdv.no = (SELECT MAX(no) from product_data_versions WHERE product_datum_id=pd.id AND deleted_at IS NULL)`,
    )
    .innerJoinAndSelect('pd.taskingInfo', 'ti')
    .innerJoinAndSelect('pd.sceneInfo', 'si')
    .leftJoinAndSelect('ti.satellite', 'sat')
    .select()
    .andWhere('pd.publicationStart <= :now', { now })
    .andWhere('pd.productFormat = :productFormat', {
      productFormat: ProductFormat.GRD_GEOTIFF,
    })
    .andWhere('pd.resolutionMode = :resolutionMode', {
      resolutionMode: ResolutionMode.normal,
    })
    .addOrderBy('pdv.datetime', 'DESC')
    .addOrderBy('si.itemId', 'DESC')
    .addOrderBy('pd.collection', 'DESC')
    .getMany();
};

export const loadFixtureProductDataVersion = async (ds: DataSource) => {
  return await ds.manager
    .getRepository(ProductDataVersion)
    .createQueryBuilder('pdv')
    .innerJoinAndSelect('pdv.productData', 'pd')
    .select()
    .where({
      id: In([
        '044ddb41-8c14-4b2f-b53c-d7a072106636',
        '1aebd2bd-efdd-4d48-aeb9-0ebd04305581',
        '2fe11efa-8906-47e1-bdd7-c6774719e48f',
        '383d20a9-8d1e-4706-921a-b1ebda87d2e3',
        '42b89352-7420-4f02-b153-e9df7660d7bd',
        '5051dbd0-c712-4c01-a4ff-baa2f5288b1f',
        '119d91f5-5c85-44bf-8196-bc26011e1b9f',
      ]),
    })
    .orderBy({
      'pdv.updatedAt': 'DESC',
    })
    .getMany();
};

export const loadFixtureReprocessingRequest = async (ds: DataSource) => {
  return await ds.manager.getRepository(ReprocessingRequest).find({
    where: { productData: { id: 'e5000024-9f4b-41c8-a7a7-d48f8df8e44b' } },
  });
};

export const associateTaskingRequestWithAois = async (
  ds: DataSource,
  tr: TaskingRequest,
  aois: Aoi[],
) => {
  if (aois.length < 1) {
    throw new Error('aois is empty array.');
  }
  return await ds
    .createQueryBuilder()
    .relation(TaskingRequest, 'aois')
    .of(tr)
    .add(aois.map((x) => x.id));
};

export const rawCandidates: ScsCandidateDto[] = (() => {
  const tmp = [
    {
      conflictConditions: null,
      observationArea: {
        obsArea: [
          {
            altitude: 0,
            latitude: 35.887980133234485,
            longitude: 139.35855625270173,
          },
          {
            altitude: 0,
            latitude: 35.92828577702214,
            longitude: 139.63021528298995,
          },
          {
            altitude: 0,
            latitude: 35.248947584277836,
            longitude: 139.77946112317204,
          },
          {
            altitude: 0,
            latitude: 35.20864194049018,
            longitude: 139.50780209288382,
          },
        ],
        obsCenterPosition: {
          altitude: 0,
          latitude: 35.568214,
          longitude: 139.567492,
        },
      },
      observationTiming: {
        obsEndTime: 162128034,
        obsEndTimeUTC: '2023-02-20T11:33:54.000Z',
        obsStartTime: 162128024,
        obsStartTimeUTC: '2023-02-20T11:33:44.000Z',
        orbitParams: {
          imagingMode: ImagingMode.Stripmap,
          offNadir: 30.95969587786137,
          pathDirection: FlightDirection.Descending,
          polarization: PolarizationType.VV,
          sightDirection: LookingDirection.Right,
        },
      },
      priority: 111110,
      requestName: '',
      satelliteInfo: {
        satId: 'ST0003',
        satName: 'Strix-1',
        satelliteLat: 34.93699904113231,
        satelliteLon: 135.8276605673017,
      },
    },
    {
      conflictConditions: null,
      observationArea: {
        obsArea: [
          {
            altitude: 0,
            latitude: 35.89169672708796,
            longitude: 139.3676706062742,
          },
          {
            altitude: 0,
            latitude: 35.92687087784716,
            longitude: 139.6407183049771,
          },
          {
            altitude: 0,
            latitude: 35.24521190638712,
            longitude: 139.7707728728203,
          },
          {
            altitude: 0,
            latitude: 35.21003775562792,
            longitude: 139.4977251741174,
          },
        ],
        obsCenterPosition: {
          altitude: 0,
          latitude: 35.568214,
          longitude: 139.567492,
        },
      },
      observationTiming: {
        obsEndTime: 162129789,
        obsEndTimeUTC: '2023-02-20T12:03:09.000Z',
        obsStartTime: 162129779,
        obsStartTimeUTC: '2023-02-20T12:02:59.000Z',
        orbitParams: {
          imagingMode: ImagingMode.Stripmap,
          offNadir: 43.846938286675794,
          pathDirection: FlightDirection.Ascending,
          polarization: PolarizationType.VV,
          sightDirection: LookingDirection.Right,
        },
      },
      priority: 111110,
      requestName: '',
      satelliteInfo: {
        satId: 'ST0002',
        satName: 'Strix-b',
        satelliteLat: 34.597417628869486,
        satelliteLon: 133.38809577272977,
      },
    },
    {
      conflictConditions: null,
      observationArea: {
        obsArea: [
          {
            altitude: 0,
            latitude: 35.88173319576977,
            longitude: 139.3356796024286,
          },
          {
            altitude: 0,
            latitude: 35.20365444351528,
            longitude: 139.52787923697525,
          },
          {
            altitude: 0,
            latitude: 35.25427865818154,
            longitude: 139.79668212128104,
          },
          {
            altitude: 0,
            latitude: 35.932357410436026,
            longitude: 139.60448248673438,
          },
        ],
        obsCenterPosition: {
          altitude: 0,
          latitude: 35.568214,
          longitude: 139.567492,
        },
      },
      observationTiming: {
        obsEndTime: 162174261,
        obsEndTimeUTC: '2023-02-21T00:24:21.000Z',
        obsStartTime: 162174251,
        obsStartTimeUTC: '2023-02-21T00:24:11.000Z',
        orbitParams: {
          imagingMode: ImagingMode.Stripmap,
          offNadir: 19.996760150123418,
          pathDirection: FlightDirection.Ascending,
          polarization: PolarizationType.VV,
          sightDirection: LookingDirection.Left,
        },
      },
      priority: 111110,
      requestName: '',
      satelliteInfo: {
        satId: 'ST0001',
        satName: 'Strix-a',
        satelliteLat: 35.879249549737274,
        satelliteLon: 141.35105268278335,
      },
    },
  ];
  return tmp.reduce((p, c) => {
    const a = plainToInstance(ScsCandidateDto, c);
    p.push(a);
    return p;
  }, new Array<ScsCandidateDto>());
})();

export const displayCandidates =
  ScsCandidateDtoDecorator.plainToInstance(rawCandidates);
