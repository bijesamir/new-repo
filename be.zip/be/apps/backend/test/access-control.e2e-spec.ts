import { ExecutionContext, INestApplication, Logger } from '@nestjs/common';
import { ExpressAdapter } from '@nestjs/platform-express';
import { Test } from '@nestjs/testing';
import { AppModule } from '../src/app.module';
import { decorateApp } from '../src/boostrap-support';
import { IrisAuthGuard } from '../src/guards/iris-auth.guard';
import {
  DUMMY_CONTRACTS,
  DUMMY_CONTRACTS_FOR_GENERAL_DATA_CUSTOMER,
  DUMMY_USER,
} from '@iris-lib/guards';
import { IrisRequest } from '@iris-lib/middlewares';
import * as request from 'supertest';
import { IrisUserRole } from '@iris-lib/constants';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { RedisCache } from 'cache-manager-ioredis-yet';
import Redis, { Cluster } from 'ioredis';

const mockForTaskingCustomer = () => {
  return jest.fn((context: ExecutionContext) => {
    const user = structuredClone(DUMMY_USER);
    user.roleTypes = [IrisUserRole.CUSTOMER];
    const contracts = structuredClone(DUMMY_CONTRACTS);
    contracts.forEach((x) => {
      x.availableTasking = true;
      x.availableArchivePurchase = false;
    });
    const req = context.switchToHttp().getRequest();
    const irisRequest = req as IrisRequest;
    irisRequest.currentUser = user;
    irisRequest.currentContracts = contracts;
    return Promise.resolve(true);
  });
};

const mockForGeneralDataTaskingCustomer = () => {
  return jest.fn((context: ExecutionContext) => {
    const user = structuredClone(DUMMY_USER);
    user.roleTypes = [IrisUserRole.CUSTOMER];
    const contracts = structuredClone(
      DUMMY_CONTRACTS_FOR_GENERAL_DATA_CUSTOMER,
    );
    contracts.forEach((x) => {
      x.availableTasking = true;
      x.availableArchivePurchase = false;
    });
    const req = context.switchToHttp().getRequest();
    const irisRequest = req as IrisRequest;
    irisRequest.currentUser = user;
    irisRequest.currentContracts = contracts;
    return Promise.resolve(true);
  });
};

const mockForArchiveCustomer = () => {
  return jest.fn((context: ExecutionContext) => {
    const user = structuredClone(DUMMY_USER);
    user.roleTypes = [IrisUserRole.CUSTOMER];
    const contracts = structuredClone(DUMMY_CONTRACTS);
    contracts.forEach((x) => {
      x.availableTasking = false;
      x.availableArchivePurchase = true;
    });
    const req = context.switchToHttp().getRequest();
    const irisRequest = req as IrisRequest;
    irisRequest.currentUser = user;
    irisRequest.currentContracts = contracts;
    return Promise.resolve(true);
  });
};

const mockForInternalUser = () => {
  return jest.fn((context: ExecutionContext) => {
    const user = structuredClone(DUMMY_USER);
    user.roleTypes = [IrisUserRole.INTERNAL];
    const contracts = structuredClone(DUMMY_CONTRACTS);
    contracts.forEach((x) => {
      x.availableTasking = true;
      x.availableArchivePurchase = true;
    });
    const req = context.switchToHttp().getRequest();
    const irisRequest = req as IrisRequest;
    irisRequest.currentUser = user;
    irisRequest.currentContracts = contracts;
    return Promise.resolve(true);
  });
};

const mockForAdminUser = () => {
  return jest.fn((context: ExecutionContext) => {
    const user = structuredClone(DUMMY_USER);
    user.roleTypes = [IrisUserRole.ADMINISTRATOR];
    const req = context.switchToHttp().getRequest();
    const irisRequest = req as IrisRequest;
    irisRequest.currentUser = user;
    irisRequest.currentContracts = [];
    return Promise.resolve(true);
  });
};

const mockForCollaboratorUser = () => {
  return jest.fn((context: ExecutionContext) => {
    const user = structuredClone(DUMMY_USER);
    user.roleTypes = [IrisUserRole.COLLABORATOR];
    const req = context.switchToHttp().getRequest();
    const irisRequest = req as IrisRequest;
    irisRequest.currentUser = user;
    irisRequest.currentContracts = [];
    return Promise.resolve(true);
  });
};

describe('AccessControl (e2e)', () => {
  let app: INestApplication;
  let cacheManager: Redis | Cluster;
  let httpServer: ExpressAdapter;

  const mockGuard = {
    canActivate: jest.fn(),
  };

  beforeAll(async () => {
    const m = Test.createTestingModule({
      imports: [AppModule], // I think this is the simplest and best.
    })
      .overrideProvider(IrisAuthGuard)
      .useValue(mockGuard);

    const tm = await m.compile();
    tm.useLogger(new Logger());
    app = await decorateApp(
      tm.createNestApplication({ forceCloseConnections: true }),
    );
    await app.init();
    cacheManager = (app.get(CACHE_MANAGER) as RedisCache).store.client;
    httpServer = app.getHttpServer();
  });

  afterAll(async () => {
    await cacheManager.flushdb();
    await cacheManager.quit();
    await app.close();
  });

  afterEach(async () => {
    mockGuard.canActivate = jest.fn();
  });

  it('/satellite/search: (admin only) userRole: CUSTOMER, contract: tasking => status 403', async () => {
    mockGuard.canActivate = mockForTaskingCustomer();
    const res: request.Response = await request
      .default(httpServer)
      .get('/satellite/search')
      .set('Content-Type', 'application/json')
      .query({})
      .send();
    expect(res.status).toEqual(403);

    expect(mockGuard.canActivate).toBeCalledTimes(1);
  });

  it('/product-data/UUID: (admin only) userRole: CUSTOMER, contract: archive => status 403', async () => {
    mockGuard.canActivate = mockForArchiveCustomer();
    const res: request.Response = await request
      .default(httpServer)
      .delete('/product-data/411a3630-9867-4b11-ab0c-7feeee9a4a07')
      .set('Content-Type', 'application/json')
      .send();
    expect(res.status).toEqual(403);

    expect(mockGuard.canActivate).toBeCalledTimes(1);
  });

  it('/satellite/search: (admin only) userRole: CUSTOMER, contract: archive => status 403', async () => {
    mockGuard.canActivate = mockForArchiveCustomer();
    const res: request.Response = await request
      .default(httpServer)
      .get('/satellite/search')
      .set('Content-Type', 'application/json')
      .query({})
      .send();
    expect(res.status).toEqual(403);

    expect(mockGuard.canActivate).toBeCalledTimes(1);
  });

  it('/aoi/search: userRole: CUSTOMER, contract: archive => status 403', async () => {
    mockGuard.canActivate = mockForArchiveCustomer();
    const res: request.Response = await request
      .default(httpServer)
      .get('/aoi/search')
      .set('Content-Type', 'application/json')
      .query({})
      .send();
    expect(res.status).toEqual(403);

    expect(mockGuard.canActivate).toBeCalledTimes(1);
  });

  it('/tasking-bundle: userRole: CUSTOMER, contract: archive => status 403', async () => {
    mockGuard.canActivate = mockForArchiveCustomer();
    const res: request.Response = await request
      .default(httpServer)
      .post('/tasking-bundle')
      .set('Content-Type', 'application/json')
      .send({});
    expect(res.status).toEqual(403);

    expect(mockGuard.canActivate).toBeCalledTimes(1);
  });

  it('/tasking-bundle/urgent: userRole: CUSTOMER, contract: archive => status 403', async () => {
    mockGuard.canActivate = mockForArchiveCustomer();
    const res: request.Response = await request
      .default(httpServer)
      .post('/tasking-bundle/urgent')
      .set('Content-Type', 'application/json')
      .send({});
    expect(res.status).toEqual(403);

    expect(mockGuard.canActivate).toBeCalledTimes(1);
  });

  it('/tasking-info userRole: CUSTOMER, contract: archive => status 403', async () => {
    mockGuard.canActivate = mockForArchiveCustomer();
    const res: request.Response = await request
      .default(httpServer)
      .post('/tasking-info')
      .set('Content-Type', 'application/json')
      .send({});
    expect(res.status).toEqual(403);

    expect(mockGuard.canActivate).toBeCalledTimes(1);
  });

  it('/tasking-info/search userRole: CUSTOMER, contract: archive => status 403', async () => {
    mockGuard.canActivate = mockForArchiveCustomer();
    const res: request.Response = await request
      .default(httpServer)
      .get('/tasking-info/search')
      .set('Content-Type', 'application/json')
      .send({});
    expect(res.status).toEqual(403);

    expect(mockGuard.canActivate).toBeCalledTimes(1);
  });

  it('/tasking-request/search userRole: CUSTOMER, contract: archive => status 403', async () => {
    mockGuard.canActivate = mockForArchiveCustomer();
    const res: request.Response = await request
      .default(httpServer)
      .get('/tasking-request/search')
      .set('Content-Type', 'application/json')
      .send({});
    expect(res.status).toEqual(403);

    expect(mockGuard.canActivate).toBeCalledTimes(1);
  });

  it('/candidate/search userRole: CUSTOMER, contract: archive => status 403', async () => {
    mockGuard.canActivate = mockForArchiveCustomer();
    const res: request.Response = await request
      .default(httpServer)
      .post('/candidate/search')
      .set('Content-Type', 'application/json')
      .send({});
    expect(res.status).toEqual(403);

    expect(mockGuard.canActivate).toBeCalledTimes(1);
  });

  it('/candidate/search userRole: CUSTOMER, contract: tasking for general data customer => status 403', async () => {
    mockGuard.canActivate = mockForGeneralDataTaskingCustomer();
    const res: request.Response = await request
      .default(httpServer)
      .post('/candidate/search')
      .set('Content-Type', 'application/json')
      .send({});
    expect(res.status).toEqual(403);

    expect(mockGuard.canActivate).toBeCalledTimes(1);
  });

  it('/candidate/search/urgent userRole: CUSTOMER, contract: archive => status 403', async () => {
    mockGuard.canActivate = mockForArchiveCustomer();
    const res: request.Response = await request
      .default(httpServer)
      .post('/candidate/search/urgent')
      .set('Content-Type', 'application/json')
      .send({});
    expect(res.status).toEqual(403);

    expect(mockGuard.canActivate).toBeCalledTimes(1);
  });

  it('/product-data/UUID: (admin only) userRole: INTERNAL, contract: archive,tasking => status 403', async () => {
    mockGuard.canActivate = mockForInternalUser();
    const res: request.Response = await request
      .default(httpServer)
      .delete('/product-data/411a3630-9867-4b11-ab0c-7feeee9a4a07')
      .set('Content-Type', 'application/json')
      .send();
    expect(res.status).toEqual(403);

    expect(mockGuard.canActivate).toBeCalledTimes(1);
  });

  it('/satellite/search: (admin only) userRole: INTERNAL, contract: archive,tasking => status 403', async () => {
    mockGuard.canActivate = mockForInternalUser();
    const res: request.Response = await request
      .default(httpServer)
      .get('/satellite/search')
      .set('Content-Type', 'application/json')
      .query({})
      .send();
    expect(res.status).toEqual(403);

    expect(mockGuard.canActivate).toBeCalledTimes(1);
  });

  it('/product-data/UUID: (admin only) userRole: ADMINISTRATOR, contract: no => status 403', async () => {
    mockGuard.canActivate = mockForAdminUser();
    const res: request.Response = await request
      .default(httpServer)
      .delete('/product-data/411a3630-9867-4b11-ab0c-7feeee9a4a07')
      .set('Content-Type', 'application/json')
      .send();
    expect(res.status).toEqual(404); // not found

    expect(mockGuard.canActivate).toBeCalledTimes(1);
  });

  it('/satellite/search: (admin only) userRole: ADMINISTRATOR, contract: no => status 403', async () => {
    mockGuard.canActivate = mockForAdminUser();
    const res: request.Response = await request
      .default(httpServer)
      .get('/satellite/search')
      .set('Content-Type', 'application/json')
      .query({})
      .send();
    expect(res.status).toEqual(200);

    expect(mockGuard.canActivate).toBeCalledTimes(1);
  });

  it('/aoi/search: userRole: COLLABORATOR, => status 200', async () => {
    mockGuard.canActivate = mockForCollaboratorUser();
    const res: request.Response = await request
      .default(httpServer)
      .get('/aoi/search')
      .set('Content-Type', 'application/json')
      .query({})
      .send();
    expect(res.status).toEqual(200);

    expect(mockGuard.canActivate).toBeCalledTimes(1);
  });

  it('/candidate/search: userRole: COLLABORATOR, => status 403', async () => {
    mockGuard.canActivate = mockForCollaboratorUser();
    const res: request.Response = await request
      .default(httpServer)
      .post('/candidate/search')
      .set('Content-Type', 'application/json')
      .send();
    expect(res.status).toEqual(403);

    expect(mockGuard.canActivate).toBeCalledTimes(1);
  });

  it('/master/satellites: userRole: COLLABORATOR, => status 403', async () => {
    mockGuard.canActivate = mockForCollaboratorUser();
    const res: request.Response = await request
      .default(httpServer)
      .get('/master/satellites')
      .set('Content-Type', 'application/json')
      .query({})
      .send();
    expect(res.status).toEqual(403);

    expect(mockGuard.canActivate).toBeCalledTimes(1);
  });

  it('/observable-area/search: userRole: COLLABORATOR, => status 403', async () => {
    mockGuard.canActivate = mockForCollaboratorUser();
    const res: request.Response = await request
      .default(httpServer)
      .post('/observable-area/search')
      .set('Content-Type', 'application/json')
      .send();
    expect(res.status).toEqual(403);

    expect(mockGuard.canActivate).toBeCalledTimes(1);
  });

  it('/satellite/search: userRole: COLLABORATOR => status 403', async () => {
    mockGuard.canActivate = mockForCollaboratorUser();
    const res: request.Response = await request
      .default(httpServer)
      .get('/satellite/search')
      .set('Content-Type', 'application/json')
      .query({})
      .send();
    expect(res.status).toEqual(403);

    expect(mockGuard.canActivate).toBeCalledTimes(1);
  });

  it('/tasking-bundle: userRole: COLLABORATOR => status 403', async () => {
    mockGuard.canActivate = mockForCollaboratorUser();
    const res: request.Response = await request
      .default(httpServer)
      .post('/tasking-bundle')
      .set('Content-Type', 'application/json')
      .send();
    expect(res.status).toEqual(403);

    expect(mockGuard.canActivate).toBeCalledTimes(1);
  });

  it('/tasking-info POST: userRole: COLLABORATOR => status 403', async () => {
    mockGuard.canActivate = mockForCollaboratorUser();
    const res: request.Response = await request
      .default(httpServer)
      .post('/tasking-info')
      .set('Content-Type', 'application/json')
      .send();
    expect(res.status).toEqual(403);

    expect(mockGuard.canActivate).toBeCalledTimes(1);
  });

  it('/tasking-request POST: userRole: COLLABORATOR => status 403', async () => {
    mockGuard.canActivate = mockForCollaboratorUser();
    const res: request.Response = await request
      .default(httpServer)
      .post('/tasking-request')
      .set('Content-Type', 'application/json')
      .send();
    expect(res.status).toEqual(403);

    expect(mockGuard.canActivate).toBeCalledTimes(1);
  });
});
