import Redis, { Cluster } from 'ioredis';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { RedisCache } from 'cache-manager-ioredis-yet';
import { INestApplication } from '@nestjs/common';
import { DataSource } from 'typeorm';
import { ExpressAdapter } from '@nestjs/platform-express';
import { ProductData } from '@iris-lib/db/entities';
import { createAppForE2ETest } from './utils';
import { CitadelGrpcService } from '@iris-lib/citadel';
import { loadFixtureProductSceneData } from './fixtures';
import * as request from 'supertest';
import { plainToInstance } from 'class-transformer';
import { CartWithFeatureDto } from '../src/models/dto/order/cart.dto';
import {
  DUMMY_ANOTHER_CONTRACTS,
  DUMMY_ANOTHER_USER,
  DUMMY_CONTRACTS,
  DUMMY_USER,
  DummyAuthGuard,
} from '@iris-lib/guards';
import {
  FlightDirection,
  FlightDirectionParamName,
  ImagingMode,
  ImagingModeParamName,
  LookingDirection,
  LookingDirectionParamName,
} from '@iris-lib/constants';
const baseUrl = '/cart';

describe('ArchiveRequestController', () => {
  let app: INestApplication;
  let dataSource: DataSource;
  let cacheManager: Redis | Cluster;
  let httpServer: ExpressAdapter;

  let fixtureProductData: ProductData[];
  let requestItems: string[];
  let multiUserItems: string[];

  const mockCitadelGrpcService = {
    emitTaskResult: jest.fn(),
  };

  beforeAll(async () => {
    app = await createAppForE2ETest((tm) => {
      tm.overrideProvider(CitadelGrpcService).useValue(mockCitadelGrpcService);
    });
    await app.init();
    dataSource = app.get(DataSource);
    cacheManager = (app.get(CACHE_MANAGER) as RedisCache).store.client;
    httpServer = app.getHttpServer();
    fixtureProductData = await loadFixtureProductSceneData(dataSource);
    requestItems = fixtureProductData
      .filter((a) =>
        [
          'e5000001-9f4b-41c8-a7a7-d48f8df8e44b',
          'e5000002-9f4b-41c8-a7a7-d48f8df8e44b',
          'e5000003-9f4b-41c8-a7a7-d48f8df8e44b',
        ].some((b) => b === a.id),
      )
      .map((x) => {
        return x.sceneInfo.itemId;
      });
    multiUserItems = fixtureProductData
      .filter((a) => a.id === 'e5000021-9f4b-41c8-a7a7-d48f8df8e44b')
      .map((x) => {
        return x.sceneInfo.itemId;
      });
  });

  afterAll(async () => {
    await httpServer.close();
    //await new Promise((r) => setTimeout(r, 1500));
    await cacheManager.flushdb();
    await cacheManager.quit();
    await dataSource.destroy();
    await app.close();
  });

  beforeEach(async () => {
    DummyAuthGuard.setDummy(DUMMY_USER, DUMMY_CONTRACTS);
  });

  it(`${baseUrl} (POST): Successful Add to cart`, async () => {
    const body = {
      itemIds: [requestItems[0]],
    };
    const res: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(201);
    const cart = plainToInstance(CartWithFeatureDto, res.body);
    expect(cart.items[0].itemId).toEqual(requestItems[0]);
  });

  it(`${baseUrl} (POST): Successful Add to cart sameId, another format`, async () => {
    const body = {
      itemIds: [requestItems[1]],
    };
    const res: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(201);
    const cart = plainToInstance(CartWithFeatureDto, res.body);
    expect(cart.items.length).toEqual(1);
    expect(cart.items[0].itemId).toEqual(requestItems[0]);
  });
  it(`${baseUrl} (POST): cannot add an already existing product`, async () => {
    const body = {
      itemIds: [requestItems[1], requestItems[2]],
    };
    let res: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(201);
    let cart = plainToInstance(CartWithFeatureDto, res.body);
    expect(cart.items.length).toEqual(1);
    expect(cart.items[0].itemId).toEqual(requestItems[0]);
    res = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(201);
    cart = plainToInstance(CartWithFeatureDto, res.body);
    expect(cart.items.length).toEqual(1);
  });
  it(`${baseUrl} (GET): Successful get cart info`, async () => {
    const res: request.Response = await request
      .default(httpServer)
      .get(baseUrl);
    expect(res.status).toEqual(200);
    const cart = plainToInstance(CartWithFeatureDto, res.body);
    expect(cart.items.length).toEqual(1);
    expect(cart.items[0].itemId).toEqual(requestItems[0]);
  });
  it(`${baseUrl} (GET): Another user cannot get other's cart info`, async () => {
    DummyAuthGuard.setDummy(DUMMY_ANOTHER_USER, DUMMY_ANOTHER_CONTRACTS);
    const res: request.Response = await request
      .default(httpServer)
      .get(baseUrl);
    expect(res.status).toEqual(200);
    const cart = plainToInstance(CartWithFeatureDto, res.body);
    expect(cart.items.length).toEqual(0);
  });
  it(`${baseUrl} (PUT): Delete(Overwrite) item`, async () => {
    //clear at first
    await request.default(httpServer).delete(baseUrl);

    //1st add
    const body1 = {
      itemIds: [requestItems[1], requestItems[2]],
    };
    const res1: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body1);
    expect(res1.status).toEqual(201);
    const cart1 = plainToInstance(CartWithFeatureDto, res1.body);
    expect(cart1.items).toHaveLength(1);

    // overwrite
    const body = {
      itemIds: [requestItems[2]],
    };
    const res: request.Response = await request
      .default(httpServer)
      .put(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(200);
    const cart = plainToInstance(CartWithFeatureDto, res.body);
    expect(cart.items).toHaveLength(1);
  });
  it(`${baseUrl} (DELETE): clear items`, async () => {
    const res: request.Response = await request
      .default(httpServer)
      .delete(baseUrl);
    expect(res.status).toEqual(200);
    const cart = plainToInstance(CartWithFeatureDto, res.body);
    expect(cart.items.length).toEqual(0);
  });
  it(`${baseUrl} (POST): duplicated item  merged to 1`, async () => {
    const body = {
      itemIds: [requestItems[0], requestItems[0]],
    };
    const res: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(201);
    const cart = plainToInstance(CartWithFeatureDto, res.body);
    expect(cart.items.length).toEqual(1);
  });
  it(`${baseUrl} (POST): multi items`, async () => {
    const body = {
      itemIds: [requestItems[0], multiUserItems[0]],
    };
    const res: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(201);
    const cart = plainToInstance(CartWithFeatureDto, res.body);
    expect(cart.items.length).toEqual(2);
  });
  it(`${baseUrl} (POST & GET): meta data `, async () => {
    //clear at first
    await request.default(httpServer).delete(baseUrl);
    const target = fixtureProductData.find(
      (a) => a.id === 'e5000001-9f4b-41c8-a7a7-d48f8df8e44b',
    );
    const body = {
      itemIds: [target.sceneInfo.itemId],
    };
    let res: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(201);
    let cart = plainToInstance(CartWithFeatureDto, res.body);
    expect(cart.items.length).toEqual(1);
    expect(cart.items[0].feature).toBeDefined();
    expect(cart.items[0].feature.properties['syns:imaging_mode']).toEqual(
      ImagingMode.Stripmap,
    );
    expect(cart.items[0].feature.properties['syns:flight_direction']).toEqual(
      FlightDirection.Descending,
    );
    expect(cart.items[0].feature.properties['syns:looking_direction']).toEqual(
      LookingDirection.Right,
    );
    expect(cart.items[0].feature.properties['syns:imaging_mode_param']).toEqual(
      ImagingModeParamName.Stripmap,
    );
    expect(
      cart.items[0].feature.properties['syns:flight_direction_param'],
    ).toEqual(FlightDirectionParamName.Descending);
    expect(
      cart.items[0].feature.properties['syns:looking_direction_param'],
    ).toEqual(LookingDirectionParamName.Right);
    expect(
      cart.items[0].feature.properties['syns:offnadir_angle'],
    ).toBeDefined();

    res = await request.default(httpServer).get(baseUrl);
    expect(res.status).toEqual(200);
    cart = plainToInstance(CartWithFeatureDto, res.body);
    expect(cart.items.length).toEqual(1);
    expect(cart.items[0].feature).toBeDefined();
    expect(cart.items[0].feature.properties['syns:imaging_mode']).toEqual(
      ImagingMode.Stripmap,
    );
    expect(cart.items[0].feature.properties['syns:flight_direction']).toEqual(
      FlightDirection.Descending,
    );
    expect(cart.items[0].feature.properties['syns:looking_direction']).toEqual(
      LookingDirection.Right,
    );
    expect(cart.items[0].feature.properties['syns:imaging_mode_param']).toEqual(
      ImagingModeParamName.Stripmap,
    );
    expect(
      cart.items[0].feature.properties['syns:flight_direction_param'],
    ).toEqual(FlightDirectionParamName.Descending);
    expect(
      cart.items[0].feature.properties['syns:looking_direction_param'],
    ).toEqual(LookingDirectionParamName.Right);
    expect(
      cart.items[0].feature.properties['syns:offnadir_angle'],
    ).toBeDefined();
  });
  it(`${baseUrl} (POST): max cart test`, async () => {
    //clear at first
    await request.default(httpServer).delete(baseUrl);
    const items = [];
    for (let i = 0; i < 100; i++) {
      items.push(requestItems[0]);
    }
    const body = {
      itemIds: items,
    };
    const res: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(201);
    const cart = plainToInstance(CartWithFeatureDto, res.body);
    expect(cart.items.length).toEqual(1);
  });
  it(`${baseUrl} (POST): max over fail request only test`, async () => {
    //clear at first
    await request.default(httpServer).delete(baseUrl);
    const items = [];
    for (let i = 0; i < 101; i++) {
      items.push('test' + i);
    }
    const body = {
      itemIds: items,
    };
    const res: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(422);
  });
  it(`${baseUrl} (PUT): max over fail`, async () => {
    //clear at first
    await request.default(httpServer).delete(baseUrl);
    const items = [];
    for (let i = 0; i < 101; i++) {
      items.push('test' + i);
    }
    const body = {
      itemIds: items,
    };
    const res: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(422);
  });
});
