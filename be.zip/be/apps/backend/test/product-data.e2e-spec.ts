import {
  FlightDirection,
  ImagingMode,
  LookingDirection,
  ProductFormat,
  ResolutionMode,
} from '@iris-lib/constants';
import {
  ArchivePurchaseRequest,
  ProductData,
  ProductDataVersion,
} from '@iris-lib/db/entities';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { INestApplication } from '@nestjs/common';
import { ExpressAdapter } from '@nestjs/platform-express';
import { RedisCache } from 'cache-manager-ioredis-yet';
import { plainToInstance } from 'class-transformer';
import Redis, { Cluster } from 'ioredis';
import { Paginated } from 'nestjs-paginate';
import { Readable } from 'stream';
import * as request from 'supertest';
import { DataSource } from 'typeorm';
import {
  DUMMY_ANOTHER_CONTRACTS,
  DUMMY_ANOTHER_USER,
  DUMMY_CONTRACTS,
  DUMMY_USER,
  DummyAuthGuard,
} from '@iris-lib/guards';
import { GcsServiceService } from '../src/infra/gcs-service/gcs-service.service';
import { ProductDataArchiveOrderDto } from '../src/models/dto/product-data/product-data.dto';
import { loadFixtureProductData } from './fixtures';
import { createAppForE2ETest } from './utils';
import { GcPubsubServiceService } from '../src/infra/gc-pubsub-service/gc-pubsub-service.service';
import { TEST_FAKE_TIME } from './fixtures/tasking-info';

const baseUrl = '/product-data';
const thumbnailUrl = '/product-data-version';

describe('ProductDataController', () => {
  let app: INestApplication;
  let dataSource: DataSource;
  let cacheManager: Redis | Cluster;
  let httpServer: ExpressAdapter;
  let fixtureProductData: ProductData[];

  const mockGcsService = {
    generateV4ReadSignedUrl: jest.fn(),
    createReadStream: jest.fn(),
    checkFileExists: jest.fn(),
  };
  const mockGcPubsubService = {
    publishDownloadProductDataEvent: jest.fn(() => {
      return;
    }),
    emitDownloadProductDataEvent: jest.fn(() => {
      return;
    }),
  };

  beforeAll(async () => {
    jest.useFakeTimers({
      advanceTimers: true,
      now: TEST_FAKE_TIME,
    });
    app = await createAppForE2ETest((tm) => {
      tm.overrideProvider(GcsServiceService).useValue(mockGcsService);
      tm.overrideProvider(GcPubsubServiceService).useValue(mockGcPubsubService);
    });
    await app.init();
    dataSource = app.get(DataSource);
    cacheManager = (app.get(CACHE_MANAGER) as RedisCache).store.client;
    httpServer = app.getHttpServer();
    fixtureProductData = await loadFixtureProductData(dataSource);
  });
  beforeEach(async () => {
    DummyAuthGuard.setDummy(DUMMY_USER, DUMMY_CONTRACTS);
  });

  afterAll(async () => {
    await httpServer.close();
    await cacheManager.flushdb();
    await cacheManager.quit();
    await dataSource.destroy();
    await app.close();

    jest.useRealTimers();
  });

  describe('Search', () => {
    it(`${baseUrl}/search (GET): all`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({})
        .send();

      expect(res.status).toEqual(200);

      const result = res.body as Paginated<ProductData>;
      expect(result.data).toHaveLength(13);
      expect(result.data[0].productDataVersions).toHaveLength(1);
      expect(result.data[1].productDataVersions).toHaveLength(1);
      expect(result.data[2].productDataVersions).toHaveLength(2);
      expect(result.data[3].productDataVersions).toHaveLength(2);
      expect(result.data[4].productDataVersions).toHaveLength(1);
      expect(result.data[5].productDataVersions).toHaveLength(1);
      expect(result.data[6].productDataVersions).toHaveLength(1);
      expect(result.data[7].productDataVersions).toHaveLength(1);
      expect(result.data[8].productDataVersions).toHaveLength(1);
      expect(result.data[9].productDataVersions).toHaveLength(1);
      expect(result.data[10].productDataVersions).toHaveLength(1);
      expect(result.data[11].productDataVersions).toHaveLength(1);
      expect(result.data[12].productDataVersions).toHaveLength(1);

      // sorted by updatedAt
      expect(result.data[0].id).toEqual('14b18ed8-f691-4913-1af8-4266054f251a');
      expect(result.data[1].id).toEqual('c75c09bd-9f4b-41c8-a7a7-d48f8df8e44b');
      expect(result.data[2].id).toEqual('323b047d-54f5-44e8-8d09-cb8e5859ab17');
      expect(result.data[3].id).toEqual('0603e8a8-c8eb-4da0-838a-43d407dab2df');
      expect(result.data[4].id).toEqual('337dbaca-3300-4628-98ee-c7e2d9bbf08b');
      expect(result.data[5].id).toEqual('23e62f2a-17b0-40b8-9767-7d16d8233c01');
      expect(result.data[6].id).toEqual('161a6d67-4eba-4bbc-84b6-a0f13ce2a37d');
      expect(result.data[7].id).toEqual('e5000032-9f4b-41c8-a7a7-d48f8df8e44b');
      expect(result.data[8].id).toEqual('e5000031-9f4b-41c8-a7a7-d48f8df8e44b');
      // fixture-tasking_info-7 includes GRD_GEOTIFF not requested by user (not included in response)
      expect(result.data[9].id).toEqual('6ddfc361-60fc-403e-b424-eeb79f61b8ee');
      expect(result.data[10].id).toEqual(
        'ac48a143-e872-41b8-a361-93e5cb9732b0',
      );
      expect(result.data[11].id).toEqual(
        '2365c2a9-0e20-4378-a3e3-de21fc45af3d',
      );
      expect(result.data[12].id).toEqual(
        '51bfb25f-7a74-4fba-b7a1-bec6a1707bbc',
      );
    });

    it(`${baseUrl}/search (GET): sortBy updatedAt ASC`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          sortBy: 'updatedAt:ASC',
        })
        .send();

      expect(res.status).toEqual(200);

      const result = res.body as Paginated<ProductData>;
      expect(result.data).toHaveLength(13);
      expect(result.data[11].productDataVersions).toHaveLength(1);
      expect(result.data[10].productDataVersions).toHaveLength(2);
      expect(result.data[9].productDataVersions).toHaveLength(2);
      expect(result.data[8].productDataVersions).toHaveLength(1);
      expect(result.data[7].productDataVersions).toHaveLength(1);
      expect(result.data[6].productDataVersions).toHaveLength(1);
      expect(result.data[5].productDataVersions).toHaveLength(1);
      expect(result.data[4].productDataVersions).toHaveLength(1);
      expect(result.data[3].productDataVersions).toHaveLength(1);
      expect(result.data[2].productDataVersions).toHaveLength(1);
      expect(result.data[1].productDataVersions).toHaveLength(1);
      expect(result.data[0].productDataVersions).toHaveLength(1);

      // sorted by updatedAt ASC
      expect(result.data[11].id).toEqual(
        'c75c09bd-9f4b-41c8-a7a7-d48f8df8e44b',
      );
      expect(result.data[10].id).toEqual(
        '323b047d-54f5-44e8-8d09-cb8e5859ab17',
      );
      expect(result.data[9].id).toEqual('0603e8a8-c8eb-4da0-838a-43d407dab2df');
      expect(result.data[8].id).toEqual('337dbaca-3300-4628-98ee-c7e2d9bbf08b');
      expect(result.data[7].id).toEqual('23e62f2a-17b0-40b8-9767-7d16d8233c01');
      expect(result.data[6].id).toEqual('161a6d67-4eba-4bbc-84b6-a0f13ce2a37d');
      expect(result.data[5].id).toEqual('e5000032-9f4b-41c8-a7a7-d48f8df8e44b');
      expect(result.data[4].id).toEqual('e5000031-9f4b-41c8-a7a7-d48f8df8e44b');
      expect(result.data[3].id).toEqual('6ddfc361-60fc-403e-b424-eeb79f61b8ee');
      expect(result.data[2].id).toEqual('ac48a143-e872-41b8-a361-93e5cb9732b0');
      expect(result.data[1].id).toEqual('2365c2a9-0e20-4378-a3e3-de21fc45af3d');
      expect(result.data[0].id).toEqual('51bfb25f-7a74-4fba-b7a1-bec6a1707bbc');
    });

    it.each([
      ['taskingInfo.satId:DESC', 200, 13, /^6ddfc361.*/, 'ST0003'],
      ['taskingInfo.satId:ASC', 200, 13, /^0603e8a8.*/, 'ST0002'],
      ['taskingInfo.flightDirection:DESC', 200, 13, /^e5000031.*/, 2],
      ['taskingInfo.flightDirection:ASC', 200, 13, /^0603e8a8.*/, 1],
      ['taskingInfo.imagingMode:DESC', 200, 13, /^0603e8a8.*/, 1],
      ['taskingInfo.imagingMode:ASC', 200, 13, /^0603e8a8.*/, 1],
      ['taskingInfo.lookingDirection:DESC', 200, 13, /^c75c09bd.*/, 2],
      ['taskingInfo.lookingDirection:ASC', 200, 13, /^0603e8a8.*/, 1],
      [
        'taskingInfo.name:DESC',
        200,
        13,
        /^ac48a143.*/,
        'fixture-tasking_info-7',
      ],
      [
        'taskingInfo.name:ASC',
        200,
        13,
        /^e5000031.*/,
        'Afixture-tasking_info-12',
      ],
      ['taskingInfo.offnadirAngle:DESC', 200, 13, /^6ddfc361.*/, 40],
      ['taskingInfo.offnadirAngle:ASC', 200, 13, /^0603e8a8.*/, 30],
      ['taskingInfo.observationStart:DESC', 200, 13, /^e5000031.*/, undefined],
      ['taskingInfo.observationStart:ASC', 200, 13, /^0603e8a8.*/, undefined],
      ['productDataVersions.createdAt:DESC', 200, 13, /^e5000031.*/, undefined],
      ['productDataVersions.createdAt:ASC', 200, 13, /^0603e8a8.*/, undefined],
    ])(
      `${baseUrl}/search (GET) sortBy %s`,
      async (key, expStatus, expCount, expId, expValue) => {
        const query = { sortBy: key };
        const res: request.Response = await request
          .default(httpServer)
          .get(`${baseUrl}/search`)
          .set('Content-Type', 'application/json')
          .query(query)
          .send();
        expect(res.status).toEqual(expStatus);
        const result = res.body as Paginated<ProductData>;
        expect(result.data).toHaveLength(expCount);
        const keys = key.split(':')[0].split('.');
        if (expValue) {
          expect(result.data[0].taskingInfo[keys[1]]).toEqual(expValue);
        }
        // id order is unstable so cannot check
        //if (expCount) {
        //  expect(result.data[0].id).toMatch(expId);
        //}
      },
    );

    it(`${baseUrl}/search (GET): limit (page 1)`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          limit: 3,
          page: 1,
        })
        .send();

      expect(res.status).toEqual(200);

      const result = res.body as Paginated<ProductData>;
      expect(result.data).toHaveLength(3);

      // sorted by updatedAt
      expect(result.data[0].id).toEqual('14b18ed8-f691-4913-1af8-4266054f251a');
      expect(result.data[1].id).toEqual('c75c09bd-9f4b-41c8-a7a7-d48f8df8e44b');
      expect(result.data[2].id).toEqual('323b047d-54f5-44e8-8d09-cb8e5859ab17');
    });

    it(`${baseUrl}/search (GET): limit (page 2)`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          limit: 3,
          page: 2,
        })
        .send();

      expect(res.status).toEqual(200);

      const result = res.body as Paginated<ProductData>;
      expect(result.data).toHaveLength(3);

      // sorted by updatedAt
      expect(result.data[0].id).toEqual('0603e8a8-c8eb-4da0-838a-43d407dab2df');
      expect(result.data[1].id).toEqual('337dbaca-3300-4628-98ee-c7e2d9bbf08b');
      expect(result.data[2].id).toEqual('23e62f2a-17b0-40b8-9767-7d16d8233c01');
    });

    it(`${baseUrl}/search (GET): filter by latest`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.latest': true,
        })
        .send();

      expect(res.status).toEqual(200);

      const result = res.body as Paginated<ProductData>;
      expect(result.data).toHaveLength(13);
      expect(result.data[0].productDataVersions).toHaveLength(1);
      expect(result.data[1].productDataVersions).toHaveLength(1);
      expect(result.data[2].productDataVersions).toHaveLength(1);
      expect(result.data[3].productDataVersions).toHaveLength(1);
      expect(result.data[4].productDataVersions).toHaveLength(1);
      expect(result.data[5].productDataVersions).toHaveLength(1);
      expect(result.data[6].productDataVersions).toHaveLength(1);
      expect(result.data[7].productDataVersions).toHaveLength(1);
      expect(result.data[8].productDataVersions).toHaveLength(1);
      expect(result.data[9].productDataVersions).toHaveLength(1);
      expect(result.data[10].productDataVersions).toHaveLength(1);
      expect(result.data[11].productDataVersions).toHaveLength(1);

      // sorted by updatedAt
      expect(result.data[0].id).toEqual('14b18ed8-f691-4913-1af8-4266054f251a');
      expect(result.data[1].id).toEqual('c75c09bd-9f4b-41c8-a7a7-d48f8df8e44b');
      expect(result.data[2].id).toEqual('323b047d-54f5-44e8-8d09-cb8e5859ab17');
      expect(result.data[3].id).toEqual('0603e8a8-c8eb-4da0-838a-43d407dab2df');
      expect(result.data[4].id).toEqual('337dbaca-3300-4628-98ee-c7e2d9bbf08b');
      expect(result.data[5].id).toEqual('23e62f2a-17b0-40b8-9767-7d16d8233c01');
      expect(result.data[6].id).toEqual('161a6d67-4eba-4bbc-84b6-a0f13ce2a37d');
      expect(result.data[7].id).toEqual('e5000032-9f4b-41c8-a7a7-d48f8df8e44b');
      expect(result.data[8].id).toEqual('e5000031-9f4b-41c8-a7a7-d48f8df8e44b');
      expect(result.data[9].id).toEqual('6ddfc361-60fc-403e-b424-eeb79f61b8ee');
      expect(result.data[10].id).toEqual(
        'ac48a143-e872-41b8-a361-93e5cb9732b0',
      );
      expect(result.data[11].id).toEqual(
        '2365c2a9-0e20-4378-a3e3-de21fc45af3d',
      );
      expect(result.data[12].id).toEqual(
        '51bfb25f-7a74-4fba-b7a1-bec6a1707bbc',
      );
    });

    it(`${baseUrl}/search (GET): filter by latest invalid string`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.latest': 'invalid',
        })
        .send();

      expect(res.status).toEqual(400);
    });

    it(`${baseUrl}/search (GET): filter by aois (1)`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.aois': 'fixture-aoi-used-101,fixture-aoi-used-102',
        })
        .send();

      expect(res.status).toEqual(200);

      const result = res.body as Paginated<ProductData>;
      expect(result.data).toHaveLength(11);

      // sorted by updatedAt
      expect(result.data[0].id).toEqual('14b18ed8-f691-4913-1af8-4266054f251a');
      expect(result.data[1].id).toEqual('c75c09bd-9f4b-41c8-a7a7-d48f8df8e44b');
      expect(result.data[2].id).toEqual('323b047d-54f5-44e8-8d09-cb8e5859ab17');
      expect(result.data[3].id).toEqual('0603e8a8-c8eb-4da0-838a-43d407dab2df');
      expect(result.data[4].id).toEqual('337dbaca-3300-4628-98ee-c7e2d9bbf08b');
      expect(result.data[5].id).toEqual('23e62f2a-17b0-40b8-9767-7d16d8233c01');
      expect(result.data[6].id).toEqual('161a6d67-4eba-4bbc-84b6-a0f13ce2a37d');
      expect(result.data[7].id).toEqual('6ddfc361-60fc-403e-b424-eeb79f61b8ee');
      expect(result.data[8].id).toEqual('ac48a143-e872-41b8-a361-93e5cb9732b0');
      expect(result.data[9].id).toEqual('2365c2a9-0e20-4378-a3e3-de21fc45af3d');
      expect(result.data[10].id).toEqual(
        '51bfb25f-7a74-4fba-b7a1-bec6a1707bbc',
      );
    });

    it(`${baseUrl}/search (GET): filter by aois invalid empty`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.aois': '',
        })
        .send();
      expect(res.status).toEqual(400);
    });

    it(`${baseUrl}/search (GET): filter by aois (2)`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.aois': 'fixture-aoi-used-102',
        })
        .send();

      expect(res.status).toEqual(200);

      const result = res.body as Paginated<ProductData>;
      expect(result.data).toHaveLength(2);

      // sorted by updatedAt
      expect(result.data[0].id).toEqual('337dbaca-3300-4628-98ee-c7e2d9bbf08b');
      expect(result.data[1].id).toEqual('23e62f2a-17b0-40b8-9767-7d16d8233c01');
    });

    it(`${baseUrl}/search (GET): filter by bbox (1)`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.bbox': '-67,-27.5,-66.5,-27',
        })
        .send();

      expect(res.status).toEqual(200);

      const result = res.body as Paginated<ProductData>;
      expect(result.data).toHaveLength(2);

      // sorted by updatedAt
      expect(result.data[0].id).toEqual('0603e8a8-c8eb-4da0-838a-43d407dab2df');
      expect(result.data[1].id).toEqual('161a6d67-4eba-4bbc-84b6-a0f13ce2a37d');
    });

    it(`${baseUrl}/search (GET): filter by bbox invalid format`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.bbox': '-67,-27.5,-66.5',
        })
        .send();

      expect(res.status).toEqual(400);
    });

    it(`${baseUrl}/search (GET): filter by bbox invalid type`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.bbox': -1,
        })
        .send();

      expect(res.status).toEqual(400);
    });

    it(`${baseUrl}/search (GET): filter by bbox (2)`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.bbox': '44,15,45,16',
        })
        .send();

      expect(res.status).toEqual(200);

      const result = res.body as Paginated<ProductData>;
      expect(result.data).toHaveLength(4);

      // sorted by updatedAt
      expect(result.data[0].id).toEqual('c75c09bd-9f4b-41c8-a7a7-d48f8df8e44b');
      expect(result.data[1].id).toEqual('323b047d-54f5-44e8-8d09-cb8e5859ab17');
    });

    it(`${baseUrl}/search (GET): filter by orderCode`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.orderCode': '202302-10001',
        })
        .send();

      expect(res.status).toEqual(200);

      const result = res.body as Paginated<ProductData>;
      expect(result.data).toHaveLength(2);

      // sorted by updatedAt
      expect(result.data[0].id).toEqual('0603e8a8-c8eb-4da0-838a-43d407dab2df');
      expect(result.data[1].id).toEqual('161a6d67-4eba-4bbc-84b6-a0f13ce2a37d');
    });

    it(`${baseUrl}/search (GET): filter by orderCode not exist`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.orderCode': '202302-90001',
        })
        .send();

      expect(res.status).toEqual(200);
      const result = res.body as Paginated<ProductData>;
      expect(result.data).toHaveLength(0);
    });

    it(`${baseUrl}/search (GET): filter by uploadStartDateTime & uploadEndDateTime`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.uploadStartDateTime': '2023-02-02',
          'filter.uploadEndDateTime': '2023-02-04T00:00:00.000Z',
        })
        .send();

      expect(res.status).toEqual(200);

      const result = res.body as Paginated<ProductData>;
      expect(result.data).toHaveLength(2);

      // sorted by updatedAt
      expect(result.data[0].id).toEqual('337dbaca-3300-4628-98ee-c7e2d9bbf08b');
      expect(result.data[1].id).toEqual('23e62f2a-17b0-40b8-9767-7d16d8233c01');
    });

    it(`${baseUrl}/search (GET): filter by uploadStartDateTime & uploadEndDateTime very long range`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.uploadStartDateTime': '1900-01-01',
          'filter.uploadEndDateTime': '2223-10-04T00:00:00.000Z',
        })
        .send();

      expect(res.status).toEqual(200);
      const result = res.body as Paginated<ProductData>;
      expect(result.data).toHaveLength(13);
    });

    it(`${baseUrl}/search (GET): filter by uploadStartDateTime & uploadEndDateTime invalid date format`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.uploadStartDateTime': '2020-01-01',
          'filter.uploadEndDateTime': '2023-100-04T00:00:00.000Z',
        })
        .send();
      expect(res.status).toEqual(400);
    });

    it(`${baseUrl}/search (GET): filter by productFormat`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.productFormat': ProductFormat.GRD_GEOTIFF,
        })
        .send();

      expect(res.status).toEqual(200);

      const result = res.body as Paginated<ProductData>;
      expect(result.data).toHaveLength(4);

      // sorted by updatedAt
      expect(result.data[0].id).toEqual('323b047d-54f5-44e8-8d09-cb8e5859ab17');
      expect(result.data[1].id).toEqual('0603e8a8-c8eb-4da0-838a-43d407dab2df');
      expect(result.data[2].id).toEqual('23e62f2a-17b0-40b8-9767-7d16d8233c01');
    });

    it(`${baseUrl}/search (GET): filter by productFormat invalid value`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.productFormat': 999,
        })
        .send();

      expect(res.status).toEqual(400);
    });
    it(`${baseUrl}/search (GET): filter by productFormat invalid type`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.productFormat': 'invalid',
        })
        .send();

      expect(res.status).toEqual(400);
    });

    it(`${baseUrl}/search (GET): filter by resolutionMode`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.resolutionMode': ResolutionMode.SR,
        })
        .send();

      expect(res.status).toEqual(200);

      const result = res.body as Paginated<ProductData>;
      expect(result.data).toHaveLength(1);

      // sorted by updatedAt
      expect(result.data[0].id).toEqual('23e62f2a-17b0-40b8-9767-7d16d8233c01');
    });

    it(`${baseUrl}/search (GET): filter by resolutionMode invalid value`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.resolutionMode': 999,
        })
        .send();

      expect(res.status).toEqual(400);
    });

    it(`${baseUrl}/search (GET): filter by resolutionMode invalid type`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.resolutionMode': 'invalid',
        })
        .send();

      expect(res.status).toEqual(400);
    });

    it(`${baseUrl}/search (GET): filter by imagingMode`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.imagingMode': ImagingMode.SlidingSpotlight,
        })
        .send();

      expect(res.status).toEqual(200);

      const result = res.body as Paginated<ProductData>;
      expect(result.data).toHaveLength(5);

      // sorted by updatedAt
      expect(result.data[0].id).toEqual('14b18ed8-f691-4913-1af8-4266054f251a');
      expect(result.data[1].id).toEqual('c75c09bd-9f4b-41c8-a7a7-d48f8df8e44b');
      expect(result.data[2].id).toEqual('323b047d-54f5-44e8-8d09-cb8e5859ab17');
      expect(result.data[3].id).toEqual('0603e8a8-c8eb-4da0-838a-43d407dab2df');
      expect(result.data[4].id).toEqual('161a6d67-4eba-4bbc-84b6-a0f13ce2a37d');
    });

    it(`${baseUrl}/search (GET): filter by imagingMode invalid value`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.imagingMode': 999,
        })
        .send();
      expect(res.status).toEqual(400);
    });

    it(`${baseUrl}/search (GET): filter by imagingMode invalid type`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.imagingMode': 'invalid',
        })
        .send();
      expect(res.status).toEqual(400);
    });
    it(`${baseUrl}/search (GET): filter by flightDirection`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.flightDirection': FlightDirection.Descending,
        })
        .send();

      expect(res.status).toEqual(200);

      const result = res.body as Paginated<ProductData>;
      expect(result.data).toHaveLength(8);

      // sorted by updatedAt
      expect(result.data[0].id).toEqual('337dbaca-3300-4628-98ee-c7e2d9bbf08b');
      expect(result.data[1].id).toEqual('23e62f2a-17b0-40b8-9767-7d16d8233c01');
      expect(result.data[2].id).toEqual('e5000032-9f4b-41c8-a7a7-d48f8df8e44b');
      expect(result.data[3].id).toEqual('e5000031-9f4b-41c8-a7a7-d48f8df8e44b');
      expect(result.data[4].id).toEqual('6ddfc361-60fc-403e-b424-eeb79f61b8ee');
      expect(result.data[5].id).toEqual('ac48a143-e872-41b8-a361-93e5cb9732b0');
      expect(result.data[6].id).toEqual('2365c2a9-0e20-4378-a3e3-de21fc45af3d');
      expect(result.data[7].id).toEqual('51bfb25f-7a74-4fba-b7a1-bec6a1707bbc');
    });

    it(`${baseUrl}/search (GET): filter by flightDirection invalid value`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.flightDirection': 999,
        })
        .send();
      expect(res.status).toEqual(400);
    });

    it(`${baseUrl}/search (GET): filter by flightDirection invalid type`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.flightDirection': 'invalid',
        })
        .send();
      expect(res.status).toEqual(400);
    });

    it(`${baseUrl}/search (GET): filter by lookingDirection`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.lookingDirection': LookingDirection.Left,
        })
        .send();

      expect(res.status).toEqual(200);

      const result = res.body as Paginated<ProductData>;
      expect(result.data).toHaveLength(11);

      // sorted by updatedAt
      expect(result.data[0].id).toEqual('14b18ed8-f691-4913-1af8-4266054f251a');
      expect(result.data[1].id).toEqual('c75c09bd-9f4b-41c8-a7a7-d48f8df8e44b');
      expect(result.data[2].id).toEqual('323b047d-54f5-44e8-8d09-cb8e5859ab17');
      expect(result.data[3].id).toEqual('0603e8a8-c8eb-4da0-838a-43d407dab2df');
      expect(result.data[4].id).toEqual('161a6d67-4eba-4bbc-84b6-a0f13ce2a37d');
      expect(result.data[5].id).toEqual('e5000032-9f4b-41c8-a7a7-d48f8df8e44b');
      expect(result.data[6].id).toEqual('e5000031-9f4b-41c8-a7a7-d48f8df8e44b');
      expect(result.data[7].id).toEqual('6ddfc361-60fc-403e-b424-eeb79f61b8ee');
      expect(result.data[8].id).toEqual('ac48a143-e872-41b8-a361-93e5cb9732b0');
      expect(result.data[9].id).toEqual('2365c2a9-0e20-4378-a3e3-de21fc45af3d');
      expect(result.data[10].id).toEqual(
        '51bfb25f-7a74-4fba-b7a1-bec6a1707bbc',
      );
    });

    it(`${baseUrl}/search (GET): filter by lookingDirection invalid value`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.lookingDirection': 999,
        })
        .send();

      expect(res.status).toEqual(400);
    });

    it(`${baseUrl}/search (GET): filter by lookingDirection invalid type`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.lookingDirection': 'invalid',
        })
        .send();

      expect(res.status).toEqual(400);
    });

    it(`${baseUrl}/search (GET): filter by acquisitionStartDateTime & acquisitionEndDateTime`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.acquisitionStartDateTime': '2023-02-01',
          'filter.acquisitionEndDateTime': '2023-02-02T00:00:00.000Z',
        })
        .send();

      expect(res.status).toEqual(200);

      const result = res.body as Paginated<ProductData>;
      expect(result.data).toHaveLength(4);

      // sorted by updatedAt
      expect(result.data[0].id).toEqual('c75c09bd-9f4b-41c8-a7a7-d48f8df8e44b');
      expect(result.data[1].id).toEqual('323b047d-54f5-44e8-8d09-cb8e5859ab17');
      expect(result.data[2].id).toEqual('0603e8a8-c8eb-4da0-838a-43d407dab2df');
      expect(result.data[3].id).toEqual('161a6d67-4eba-4bbc-84b6-a0f13ce2a37d');
    });
    /*TBD 31st Feb still causes 500
    it(`${baseUrl}/search (GET): filter by acquisitionStartDateTime & acquisitionEndDateTime invalid date format`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.acquisitionStartDateTime': '2023-02-01',
          'filter.acquisitionEndDateTime': '2023-02-31T00:00:00.000Z',
        })
        .send();
      expect(res.status).toEqual(400);
    });
    */
    it(`${baseUrl}/search (GET): filter by acquisitionStartDateTime & acquisitionEndDateTime invalid type`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.acquisitionStartDateTime': -1,
          'filter.acquisitionEndDateTime': 0,
        })
        .send();

      expect(res.status).toEqual(400);
    });

    it(`${baseUrl}/search (GET): filter by offnadirAngleMin & offnadirAngleMax`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.offnadirAngleMin': 30,
          'filter.offnadirAngleMax': 40,
        })
        .send();

      expect(res.status).toEqual(200);

      const result = res.body as Paginated<ProductData>;
      expect(result.data).toHaveLength(11);

      // sorted by updatedAt
      expect(result.data[0].id).toEqual('14b18ed8-f691-4913-1af8-4266054f251a');
      expect(result.data[1].id).toEqual('c75c09bd-9f4b-41c8-a7a7-d48f8df8e44b');
      expect(result.data[2].id).toEqual('323b047d-54f5-44e8-8d09-cb8e5859ab17');
      expect(result.data[3].id).toEqual('0603e8a8-c8eb-4da0-838a-43d407dab2df');
      expect(result.data[4].id).toEqual('161a6d67-4eba-4bbc-84b6-a0f13ce2a37d');
      expect(result.data[5].id).toEqual('e5000032-9f4b-41c8-a7a7-d48f8df8e44b');
      expect(result.data[6].id).toEqual('e5000031-9f4b-41c8-a7a7-d48f8df8e44b');
      expect(result.data[7].id).toEqual('6ddfc361-60fc-403e-b424-eeb79f61b8ee');
      expect(result.data[8].id).toEqual('ac48a143-e872-41b8-a361-93e5cb9732b0');
      expect(result.data[9].id).toEqual('2365c2a9-0e20-4378-a3e3-de21fc45af3d');
      expect(result.data[10].id).toEqual(
        '51bfb25f-7a74-4fba-b7a1-bec6a1707bbc',
      );
    });

    it(`${baseUrl}/search (GET): filter by offnadirAngleMin & offnadirAngleMax minus value`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.offnadirAngleMin': -2,
          'filter.offnadirAngleMax': 15,
        })
        .send();

      expect(res.status).toEqual(200);
    });

    it(`${baseUrl}/search (GET): filter by offnadirAngleMin & offnadirAngleMax invalid order`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.offnadirAngleMin': '45',
          'filter.offnadirAngleMax': '0',
        })
        .send();

      expect(res.status).toEqual(400);
    });

    it(`${baseUrl}/search (GET): filter by productFormat & imagingMode`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.productFormat': ProductFormat.SLC_SICD,
          'filter.imagingMode': ImagingMode.SlidingSpotlight,
        })
        .send();

      expect(res.status).toEqual(200);

      const result = res.body as Paginated<ProductData>;
      expect(result.data).toHaveLength(2);

      // sorted by updatedAt
      expect(result.data[0].id).toEqual('c75c09bd-9f4b-41c8-a7a7-d48f8df8e44b');
      expect(result.data[1].id).toEqual('161a6d67-4eba-4bbc-84b6-a0f13ce2a37d');
    });

    it(`${baseUrl}/search (GET): filter by productFormat & imagingMode invalid value 1`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.productFormat': 999,
          'filter.imagingMode': ImagingMode.SlidingSpotlight,
        })
        .send();

      expect(res.status).toEqual(400);
    });

    it(`${baseUrl}/search (GET): filter by productFormat & imagingMode invalid value 2`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.productFormat': 999,
          'filter.imagingMode': 999,
        })
        .send();

      expect(res.status).toEqual(400);
    });

    it(`${baseUrl}/search (GET): filter by productFormat & imagingMode invalid type 1`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.productFormat': 'ProductFormat.SLC_SICD',
          'filter.imagingMode': ImagingMode.SlidingSpotlight,
        })
        .send();

      expect(res.status).toEqual(400);
    });

    it(`${baseUrl}/search (GET): pdv SystemOrganization should be filtered out`, async () => {
      DummyAuthGuard.setDummy(DUMMY_ANOTHER_USER, DUMMY_ANOTHER_CONTRACTS);
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.orderCode': '202312-12001',
          'filter.latest': true,
        })
        .send();

      expect(res.status).toEqual(200);

      const result = res.body as Paginated<ProductData>;
      expect(result.data).toHaveLength(3);

      // sorted by updatedAt
      expect(result.data[0].id).toMatch(/^e5000001/);
      expect(result.data[0].productDataVersions[0].id).toMatch(/^c0100001/);
    });
  });

  describe('Delete', () => {
    afterEach(async () => {
      //save(fixtureProductData[0]) makes error for reference tasking_info_id,
      // so using update method insted.
      const t = fixtureProductData.find(
        (pd) => pd.id === '0603e8a8-c8eb-4da0-838a-43d407dab2df',
      );
      await dataSource.getRepository(ProductData).update(t.id, {
        latestEditorId: t.latestEditorId,
        updatedAt: t.updatedAt,
        deletedAt: null,
      });
      await dataSource
        .getRepository(ProductDataVersion)
        .save(t.productDataVersions);
    });

    it(`${baseUrl}/:id (DELETE): Successful soft deletion`, async () => {
      const target = fixtureProductData.find(
        (pd) => pd.id === '0603e8a8-c8eb-4da0-838a-43d407dab2df',
      );

      const res: request.Response = await request
        .default(httpServer)
        .delete(`${baseUrl}/${target.id}`)
        .set('Content-Type', 'application/json');

      expect(res.status).toEqual(200);
      const result = res.body as ProductData;

      expect(result.deletedAt).not.toBeNull();

      const checkProductData1 = await dataSource
        .getRepository(ProductData)
        .findOne({ where: { id: target.id } });
      expect(checkProductData1).toBeNull();

      const checkProductData2 = await dataSource
        .getRepository(ProductData)
        .findOne({ where: { id: target.id }, withDeleted: true });
      expect(checkProductData2).not.toBeNull();
      expect(checkProductData2.deletedAt).not.toBeNull();

      const checkProductDataVersion1 = await dataSource
        .getRepository(ProductDataVersion)
        .find({ where: { productDatumId: target.id } });
      expect(checkProductDataVersion1).toHaveLength(0);

      const checkProductDataVersion2 = await dataSource
        .getRepository(ProductDataVersion)
        .find({ where: { productDatumId: target.id }, withDeleted: true });
      expect(checkProductDataVersion2).toHaveLength(2);
      expect(checkProductDataVersion2[0]).not.toBeNull();
      expect(checkProductDataVersion2[1]).not.toBeNull();
      expect(checkProductDataVersion2[0].deletedAt).not.toBeNull();
      expect(checkProductDataVersion2[1].deletedAt).not.toBeNull();
    });
  });

  describe(`ArchiveServiceProductData`, () => {
    const fixtureArchiveProductCount = 9;
    beforeEach(async () => {
      DummyAuthGuard.setDummy(DUMMY_USER, DUMMY_CONTRACTS);
      const url =
        'https://storage.googleapis.com/syns-daas-dev_iris-product-data-store/path/to/archive?X-Goog-Algorithm=GOOG4-RSA-SHA256&X-Goog-Credential=xxx&X-Goog-Date=20230522T010630Z&X-Goog-Expires=yyy&X-Goog-SignedHeaders=host&X-Goog-Signature=zzz';

      mockGcsService.generateV4ReadSignedUrl = jest.fn(() => {
        return Promise.resolve([url]);
      });
      mockGcsService.checkFileExists = jest.fn(() => {
        return [true];
      });
      mockGcsService.createReadStream = jest.fn(
        (_bucket: string, name: string) => {
          const readable = new Readable();
          readable.push(`write: ${name}`);
          readable.push(null);

          return readable;
        },
      );
    });
    //test expectation:
    // productData includes 1 latest product data version and 1 latest archive purchase request
    //   but if request has query filter, filter first, and then select latest archive purchase request
    it(`${baseUrl}/archive-order (GET)`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/archive-order`)
        .set('Content-Type', 'application/json')
        .send();
      expect(res.status).toEqual(200);
      const result = res.body as Paginated<ProductDataArchiveOrderDto>;
      expect(result.data).toHaveLength(fixtureArchiveProductCount);
      expect(result.data[0].id).toEqual('e5000052-9f4b-41c8-a7a7-d48f8df8e44b');
      expect(
        result.data[0].archivePurchasedProductData[0].archivePurchaseRequest
          .requestId,
      ).toEqual('1000001-202312-00002');
    });

    it(`${baseUrl}/archive-order (GET) by another user`, async () => {
      DummyAuthGuard.setDummy(DUMMY_ANOTHER_USER, DUMMY_ANOTHER_CONTRACTS);
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/archive-order`)
        .set('Content-Type', 'application/json')
        .send();
      expect(res.status).toEqual(200);
      const result = res.body as Paginated<ProductDataArchiveOrderDto>;
      expect(result.data).toHaveLength(3);
      expect(result.data[0].id).toEqual('e5000041-9f4b-41c8-a7a7-d48f8df8e44b');
      expect(result.data[1].id).toEqual('e5000032-9f4b-41c8-a7a7-d48f8df8e44b');
      expect(result.data[2].id).toEqual('e5000031-9f4b-41c8-a7a7-d48f8df8e44b');
    });

    it.each([
      [
        'latest',
        true,
        200,
        fixtureArchiveProductCount,
        /^e5000052.*/,
        /12-00002$/,
      ],
      [
        'latest',
        false,
        200,
        fixtureArchiveProductCount,
        /^e5000052.*/,
        /12-00002$/,
      ],
      [
        'itemId',
        'StriX-1_20231202_010201_SM',
        200,
        1,
        /^e5000022.*/,
        /11-00002$/,
      ],
      [
        'itemId',
        'StriX-1_20231202_010201_SM,StriX-1_20230302_010201_SM',
        200,
        3,
        /^e5000022.*/,
        /11-00002$/,
      ],
      [
        'archiveRequestId',
        '1000001-202311-00001',
        200,
        3,
        /^e5000001.*/,
        /11-00001$/,
      ],
      [
        'archiveRequestId',
        '1000001-202303-00001',
        200,
        2,
        /^e5000001.*/,
        /03-00001$/,
      ],
      [
        'archiveRequestId',
        '1000001-202311-00001,1000001-202303-00001',
        200,
        4,
        /^e5000001.*/,
        /11-00001$/,
      ],
      [
        'archiveRequestId',
        '1000001-202311-00099',
        200,
        0,
        /^invalid.*/,
        /invalid$/,
      ],
      [
        'imagingMode',
        ImagingMode.SlidingSpotlight,
        200,
        1,
        /^e5000051.*/,
        /12-00001$/,
      ],
    ])(
      `${baseUrl}/archive-order (GET) filter %s`,
      async (key, filter, expStatus, expCount, expId, expReqNo) => {
        const query = {};
        query[`filter.${key}`] = filter;
        const res: request.Response = await request
          .default(httpServer)
          .get(`${baseUrl}/archive-order`)
          .set('Content-Type', 'application/json')
          .query(query)
          .send();
        expect(res.status).toEqual(expStatus);
        const result = res.body as Paginated<ProductDataArchiveOrderDto>;
        expect(result.data).toHaveLength(expCount);
        if (expCount) {
          expect(result.data[0].id).toMatch(expId);
          expect(
            result.data[0].archivePurchasedProductData[0].archivePurchaseRequest
              .requestId,
          ).toMatch(expReqNo);
        }
      },
    );

    it(`${baseUrl}/archive-order (GET) filter centerTime`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/archive-order`)
        .query({
          'filter.centerStartDateTime': '2023-03-01',
          'filter.centerEndDateTime': '2023-03-03T00:00:00.000Z',
        })
        .set('Content-Type', 'application/json')
        .send();

      expect(res.status).toEqual(200);
      const result = res.body as Paginated<ProductDataArchiveOrderDto>;
      expect(result.data).toHaveLength(1);
      expect(result.data[0].id).toEqual('e5000031-9f4b-41c8-a7a7-d48f8df8e44b');
    });

    it.each([
      [
        'updatedAt:ASC',
        200,
        fixtureArchiveProductCount,
        /^e5000031.*/,
        /03-00001$/,
      ],
      [
        'sceneInfo.itemId:ASC',
        200,
        fixtureArchiveProductCount,
        /^e5000051.*/,
        /12-00001$/,
      ],
      [
        'sceneInfo.itemId:DESC',
        200,
        fixtureArchiveProductCount,
        /^e5000052.*/,
        /12-00002$/,
      ],
      [
        'archivePurchasedProductData.archivePurchaseRequest.requestId:ASC',
        200,
        fixtureArchiveProductCount,
        /^e5000032.*/,
        /02-00001$/,
      ],
      [
        'archivePurchasedProductData.archivePurchaseRequest.requestId:DESC',
        200,
        fixtureArchiveProductCount,
        /^e5000052.*/,
        /12-00002$/,
      ],
      [
        'archivePurchasedProductData.archivePurchaseRequest.downloadExpired:ASC',
        200,
        fixtureArchiveProductCount,
        /^e5000032.*/,
        /02-00001$/,
      ],
      [
        'archivePurchasedProductData.archivePurchaseRequest.downloadExpired:DESC',
        200,
        fixtureArchiveProductCount,
        /^e5000052.*/,
        /12-00002$/,
      ],
      [
        'taskingInfo.satId:ASC',
        200,
        fixtureArchiveProductCount,
        /^e5000023.*/,
        /06-00001$/,
      ],
      [
        'taskingInfo.flightDirection:ASC',
        200,
        fixtureArchiveProductCount,
        /^e5000023.*/,
        /06-00001$/,
      ],
      [
        'taskingInfo.imagingMode:DESC',
        200,
        fixtureArchiveProductCount,
        /^e5000051.*/,
        /12-00001$/,
      ],
      [
        'taskingInfo.lookingDirection:DESC',
        200,
        fixtureArchiveProductCount,
        /^e5000023.*/,
        /06-00001$/,
      ],
      [
        'taskingInfo.name:DESC',
        200,
        fixtureArchiveProductCount,
        /^e5000052.*/,
        /12-00002$/,
      ],
      [
        'taskingInfo.name:ASC',
        200,
        fixtureArchiveProductCount,
        /^e5000051.*/,
        /12-00001$/,
      ],
      [
        'taskingInfo.offnadirAngle:DESC',
        200,
        fixtureArchiveProductCount,
        /^e5000023.*/,
        /06-00001$/,
      ],
      [
        'taskingInfo.offnadirAngle:ASC',
        200,
        fixtureArchiveProductCount,
        /^e5000051.*/,
        /12-00001$/,
      ],
      [
        'taskingInfo.observationStart:DESC',
        200,
        fixtureArchiveProductCount,
        /^e5000052.*/,
        /12-00002$/,
      ],
      [
        'taskingInfo.observationStart:ASC',
        200,
        fixtureArchiveProductCount,
        /^e5000051.*/,
        /12-00001$/,
      ],
      [
        'productDataVersions.createdAt:DESC',
        200,
        fixtureArchiveProductCount,
        /^e5000052.*/,
        /12-00002$/,
      ],
      [
        'productDataVersions.createdAt:ASC',
        200,
        fixtureArchiveProductCount,
        /^e5000051.*/,
        /12-00001$/,
      ],
    ])(
      `${baseUrl}/archive-order (GET) sortBy %s`,
      async (key, expStatus, expCount, expId, expReqNo) => {
        const query = { sortBy: key };
        const res: request.Response = await request
          .default(httpServer)
          .get(`${baseUrl}/archive-order`)
          .set('Content-Type', 'application/json')
          .query(query)
          .send();
        expect(res.status).toEqual(expStatus);
        const result = res.body as Paginated<ProductDataArchiveOrderDto>;
        expect(result.data).toHaveLength(expCount);
        if (expCount) {
          expect(result.data[0].id).toMatch(expId);
          expect(
            result.data[0].archivePurchasedProductData[0].archivePurchaseRequest
              .requestId,
          ).toMatch(expReqNo);
        }
      },
    );

    it(`${baseUrl}/archive-order (GET): page 1`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/archive-order`)
        .set('Content-Type', 'application/json')
        .query({
          limit: 3,
          page: 1,
        })
        .send();
      expect(res.status).toEqual(200);
      const result = res.body as Paginated<ProductDataArchiveOrderDto>;
      expect(result.data).toHaveLength(3);
      expect(result.data[0].id).toEqual('e5000052-9f4b-41c8-a7a7-d48f8df8e44b');
    });

    it(`${baseUrl}/archive-order (GET): page 2`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/archive-order`)
        .set('Content-Type', 'application/json')
        .query({
          limit: 4,
          page: 2,
        })
        .send();
      expect(res.status).toEqual(200);
      const result = res.body as Paginated<ProductDataArchiveOrderDto>;
      expect(result.data).toHaveLength(4); //To be update with fixture data
    });

    // if productData has pdv and within download period, user can download it (thubnail is always ok)
    it(`${baseUrl}/archive-order (Scenario) GET and Download success (pd.org not equal archive.org)`, async () => {
      jest.useFakeTimers({
        advanceTimers: true,
        now: TEST_FAKE_TIME,
      });

      let res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/archive-order`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.archiveRequestId': '1000001-202311-00002',
        })
        .send();

      expect(res.status).toEqual(200);
      expect(res.body.data).toHaveLength(1);
      const result = plainToInstance(
        ProductDataArchiveOrderDto,
        res.body.data[0],
      );
      expect(result.archivePurchasedProductData).toHaveLength(1);
      //check test data condition
      expect(result.organizationId).not.toEqual(
        result.archivePurchasedProductData[0].archivePurchaseRequest
          .organizationId,
      );

      //within download period and have pdv
      expect(
        result.archivePurchasedProductData[0].archivePurchaseRequest.downloadExpired.getTime(),
      ).toBeGreaterThan(new Date().getTime());
      expect(result.productDataVersions).toHaveLength(1);

      //thumbnail should be OK
      res = await request
        .default(httpServer)
        .get(`${thumbnailUrl}/${result.productDataVersions[0].id}/quicklook`)
        .send();
      expect(res.status).toEqual(200);

      //download should be OK
      res = await request
        .default(httpServer)
        .get(`${baseUrl}-version/${result.productDataVersions[0].id}/download`)
        .send();
      expect(res.status).toEqual(302);
    });

    // if productData has pdv and over download period, user cannot download it(thumbnail is always ok)
    it(`${baseUrl}/archive-order (Scenario) GET and Download Fail by over dl period (pd.org not equal archive.org)`, async () => {
      let res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/archive-order`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.archiveRequestId': '1000001-202311-00001',
        })
        .send();

      expect(res.status).toEqual(200);
      expect(res.body.data).toHaveLength(3);
      const result = plainToInstance(
        ProductDataArchiveOrderDto,
        res.body.data[0],
      );
      expect(result.archivePurchasedProductData).toHaveLength(1);
      //check test data condition
      expect(result.organizationId).not.toEqual(
        result.archivePurchasedProductData[0].archivePurchaseRequest
          .organizationId,
      );

      //download period overed and there is pdv
      expect(
        result.archivePurchasedProductData[0].archivePurchaseRequest.downloadExpired.getTime(),
      ).toBeLessThan(new Date().getTime());
      expect(result.productDataVersions).toHaveLength(1);

      //thumbnail should be OK
      res = await request
        .default(httpServer)
        .get(`${thumbnailUrl}/${result.productDataVersions[0].id}/quicklook`)
        .send();
      expect(res.status).toEqual(200);

      res = await request
        .default(httpServer)
        .get(`${baseUrl}-version/${result.productDataVersions[0].id}/download`)
        .send();
      expect(res.status).toEqual(404);
    });

    // if productData has not pdv user cannot download it
    it(`${baseUrl}/archive-order (Scenario) GET and Download Fail by not exist pdv (pd.org not equal archive.org)`, async () => {
      const archiveRequestId = '1000002-202310-00001';
      DummyAuthGuard.setDummy(DUMMY_ANOTHER_USER, DUMMY_ANOTHER_CONTRACTS);
      let res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/archive-order`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.archiveRequestId': archiveRequestId,
        })
        .send();

      expect(res.status).toEqual(200);
      expect(res.body.data).toHaveLength(0);

      const result = await dataSource
        .getRepository(ArchivePurchaseRequest)
        .findOne({
          where: { requestId: archiveRequestId },
          relations: ['archivePurchasedProductData'],
        });

      res = await request
        .default(httpServer)
        .get(
          `${baseUrl}-version/${result.archivePurchasedProductData[0].productDataVersionId}/download`,
        )
        .send();
      expect(res.status).toEqual(400);
    });
    // (TBD add test case after product expired supported)
    //if productData has pdv but old one user cannot download it
  });
});
