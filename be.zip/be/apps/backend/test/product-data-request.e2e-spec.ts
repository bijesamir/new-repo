import { INestApplication } from '@nestjs/common';
import { ExpressAdapter } from '@nestjs/platform-express';
import { DataSource } from 'typeorm';
import { createAppForE2ETest } from './utils';
import { ProductDataRequestUpdateStatusDto } from '../src/models/dto/product-data-request/product-data-request-update-status.dto';
import {
  ProcessingStatus,
  getProductFormatLabel,
  getResolutionModeLabel,
} from '@iris-lib/constants';
import * as request from 'supertest';
import { ProductDataRequest } from '@iris-lib/db/entities';
import { loadFixtureProductDataRequest } from './fixtures';
import {
  SlackMessage,
  SlackNotificationService,
  SlackProductDataRequestStatusMessage,
} from '@iris-lib/slack';
import Redis, { Cluster } from 'ioredis';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { RedisCache } from 'cache-manager-ioredis-yet';

const baseUrl = '/product-data-request';

describe('ProductDataRequestController', () => {
  let app: INestApplication;
  let dataSource: DataSource;
  let cacheManager: Redis | Cluster;
  let httpServer: ExpressAdapter;

  let fixtureProductDataRequests: ProductDataRequest[];
  let testForUpdateOperation: ProductDataRequest;

  const mockSlackNotificationService = {
    send: jest.fn(),
  };

  beforeAll(async () => {
    app = await createAppForE2ETest((tm) => {
      tm.overrideProvider(SlackNotificationService).useValue(
        mockSlackNotificationService,
      );
    });
    await app.init();
    dataSource = app.get(DataSource);
    cacheManager = (app.get(CACHE_MANAGER) as RedisCache).store.client;
    httpServer = app.getHttpServer();
    fixtureProductDataRequests =
      await loadFixtureProductDataRequest(dataSource);
    testForUpdateOperation = fixtureProductDataRequests.find((pdr) => {
      return pdr.status === ProcessingStatus.New;
    });
  });

  beforeEach(() => {
    mockSlackNotificationService.send = jest.fn((message: SlackMessage) => {
      return Promise.resolve(message.shouldNotify);
    });
  });

  afterAll(async () => {
    await cacheManager.flushdb();
    await cacheManager.quit();
    await dataSource.destroy();
    await app.close();
  });

  afterEach(async () => {
    await dataSource.getRepository(ProductDataRequest).update(
      { id: testForUpdateOperation.id },
      {
        status: ProcessingStatus.New,
        latestEditorId: testForUpdateOperation.latestEditorId,
      },
    );
  });

  it(`ok ${baseUrl}/update-status (PUT) from new to completed`, async () => {
    const body: ProductDataRequestUpdateStatusDto = {
      ids: [testForUpdateOperation.id],
      status: ProcessingStatus.Completed,
    };

    const res: request.Response = await request
      .default(httpServer)
      .put(`${baseUrl}/update-status`)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(200);

    const result = await dataSource.getRepository(ProductDataRequest).findOne({
      where: { id: testForUpdateOperation.id },
      relations: { taskingInfo: { taskingRequest: { aois: true } } },
    });
    expect(result.status).toEqual(ProcessingStatus.Completed);

    expect(mockSlackNotificationService.send).toHaveBeenCalledTimes(1);
    expect(mockSlackNotificationService.send).toHaveBeenNthCalledWith(
      1,
      new SlackProductDataRequestStatusMessage({
        aoiName: result.taskingInfo.taskingRequest.aois[0].name,
        status: ProcessingStatus.Completed,
        orderCode: result.taskingInfo.scsOrderCode,
        sceneNo: result.sceneNo,
        productFormat: getProductFormatLabel(result.productFormat),
        resolutionMode: getResolutionModeLabel(result.resolutionMode),
      }),
    );
    // ProcessingStatus.Completed should be notified to Slack
    await expect(
      mockSlackNotificationService.send.mock.results[0].value,
    ).resolves.toEqual(true);
  });

  it(`ok ${baseUrl}/update-status (PUT) from new to failed`, async () => {
    const body: ProductDataRequestUpdateStatusDto = {
      ids: [testForUpdateOperation.id],
      status: ProcessingStatus.Failed,
    };

    const res: request.Response = await request
      .default(httpServer)
      .put(`${baseUrl}/update-status`)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(200);

    const result = await dataSource.getRepository(ProductDataRequest).findOne({
      where: { id: testForUpdateOperation.id },
      relations: { taskingInfo: { taskingRequest: { aois: true } } },
    });
    expect(result.status).toEqual(ProcessingStatus.Failed);

    expect(mockSlackNotificationService.send).toHaveBeenCalledTimes(1);
    expect(mockSlackNotificationService.send).toHaveBeenNthCalledWith(
      1,
      new SlackProductDataRequestStatusMessage({
        aoiName: result.taskingInfo.taskingRequest.aois[0].name,
        status: ProcessingStatus.Failed,
        orderCode: result.taskingInfo.scsOrderCode,
        sceneNo: result.sceneNo,
        productFormat: getProductFormatLabel(result.productFormat),
        resolutionMode: getResolutionModeLabel(result.resolutionMode),
      }),
    );
    // ProcessingStatus.Failed should NOT be notified to Slack
    await expect(
      mockSlackNotificationService.send.mock.results[0].value,
    ).resolves.toEqual(false);
  });

  it(`ng ${baseUrl}/update-status`, async () => {
    const body: ProductDataRequestUpdateStatusDto = {
      ids: [testForUpdateOperation.id],
      status: 'unknown',
    };

    const res: request.Response = await request
      .default(httpServer)
      .put(`${baseUrl}/update-status `)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(400);
  });
});
