import { INestApplication } from '@nestjs/common';
import { DataSource, In } from 'typeorm';
import { createAppForE2ETest } from './utils';

import {
  ArchivePurchaseRequest,
  ArchivePurchasedItem,
  ProductData,
  ProductDataVersion,
  ReprocessingRequest,
} from '@iris-lib/db/entities';
import * as request from 'supertest';

import { plainToInstance } from 'class-transformer';
import {
  OrderDto,
  OrdersDto,
  ProductDataInfo,
} from '../src/models/dto/order/order.dto';
import {
  ArchiveOrderNotificationTemplates,
  DeliveryTimeKind,
  DownloadableStatus,
  ImagingMode,
  NotificationParam,
  OrderStatus,
  DataSourceType,
  ProductFormat,
  ResolutionMode,
  TEST_ANOTHER_CONTRACT_ID,
  TEST_ANOTHER_ORGANIZATION_ID,
  TEST_CONTRACT_ID,
  TEST_ORGANIZATION_ID,
  TaskingPriorityKind,
  TaskingType,
  generateNotificationContents,
  NotificationParamItem,
  ArchiveProductDataNotificationTemplates,
  AppConstants,
} from '@iris-lib/constants';
import { Cluster, Redis } from 'ioredis';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { RedisCache } from 'cache-manager-ioredis-yet';
import {
  DUMMY_ANOTHER_CONTRACTS,
  DUMMY_ANOTHER_USER,
  DUMMY_CONTRACTS,
  DUMMY_USER,
  DummyAuthGuard,
} from '@iris-lib/guards';
import {
  OrderCreateDto,
  OrderCreateReplyDto,
  OrderItem,
} from '../src/models/dto/order/order-create.dto';
import { Paginated } from 'nestjs-paginate';
import { ReprocessingRequestDto } from '../src/models/dto/reprocessing-request/reprocessing-request.dto';
import { ExpressAdapter } from '@nestjs/platform-express';
import { addDays, sub } from 'date-fns';
import { Item } from '../src/models/dto/stac/feature-collection.dto';
import {
  getProductLabel,
  getProductName,
} from '@iris-lib/utils/product-name-helper';
import { loadFixtureProductSceneData } from './fixtures';
import { CitadelGrpcService } from '@iris-lib/citadel';
import {
  CheckQuotaDto,
  EmitRequestDto,
  PaymentReplyDto,
  PaymentsDto,
  ProcessingSuccessResult,
  VerifyItemDto,
} from '@iris-lib/models/payment';
import {
  PaymentTaskStatus,
  fromOrderStatusToPaymentTaskStatus,
} from '@iris-lib/constants/payment-task-status';
import { CartWithFeatureDto } from '../src/models/dto/order/cart.dto';
import { StacSortby } from '../src/models/dto/stac/stac-search.dto';
import { basename } from 'path';
import { ProcessingVersionUsecaseService } from '../src/usecases/processing-version/processing-version-usecase.service';
import { ProductDataArchiveOrderDto } from '../src/models/dto/product-data/product-data.dto';
import { TEST_FAKE_TIME } from './fixtures/tasking-info';

const baseUrl = '/orders';
const productDataUrl = '/product-data';
const cartUrl = '/cart';

class CitadelRelatedDataForTest {
  taskingId: string;
  paymentId: number;
}

describe('ArchivePurchaseRequestController', () => {
  let app: INestApplication;
  let dataSource: DataSource;
  let cacheManager: Redis | Cluster;
  let httpServer: ExpressAdapter;

  let fixtureProductData: ProductData[];
  const fixtureCount = 12; //TO Be updated with fixture APR org count

  let requestItems: OrderItem[];
  let notExistItems: OrderItem[];
  let reproCompletedItems: OrderItem[];
  let multiUserItems: OrderItem[];
  const usedPDIds = new Array<string>();
  const afterDeleteAprs = new Array<OrderDto>();
  const afterDeletePDs = new Array<ProductData>();
  const afterDeleteRRs = new Array<ReprocessingRequestDto>();

  const mockCitadelGrpcService = {
    verifyQuota: jest.fn(),
    checkQuota: jest.fn(),
    reserveTask: jest.fn(),
    emitTaskResult: jest.fn(),
  };
  const mockProcessingVersion = {
    getLatestProcessingVersion: jest.fn(),
  };
  let storedCitadelRelatedData: CitadelRelatedDataForTest[] =
    new Array<CitadelRelatedDataForTest>();

  beforeAll(async () => {
    jest.useFakeTimers({
      advanceTimers: true,
      now: TEST_FAKE_TIME,
    });

    app = await createAppForE2ETest((tm) => {
      tm.overrideProvider(CitadelGrpcService).useValue(mockCitadelGrpcService);
      tm.overrideProvider(ProcessingVersionUsecaseService).useValue(
        mockProcessingVersion,
      );
    });
    await app.init();
    dataSource = app.get(DataSource);
    httpServer = app.getHttpServer();
    cacheManager = (app.get(CACHE_MANAGER) as RedisCache).store.client;
    fixtureProductData = await loadFixtureProductSceneData(dataSource);
    requestItems = fixtureProductData
      .filter((a) =>
        [
          'e5000001-9f4b-41c8-a7a7-d48f8df8e44b',
          'e5000021-9f4b-41c8-a7a7-d48f8df8e44b',
          'e5000023-9f4b-41c8-a7a7-d48f8df8e44b',
          'e5000051-9f4b-41c8-a7a7-d48f8df8e44b',
        ].some((b) => b === a.id),
      )
      .map((x) => {
        return {
          itemId: x.sceneInfo.itemId,
          productDetails: [
            {
              productFormat: x.productFormat,
              resolutionMode: x.resolutionMode,
            },
          ],
        };
      });
    notExistItems = fixtureProductData
      .filter((a) => a.id === 'e5000031-9f4b-41c8-a7a7-d48f8df8e44b')
      .map((x) => {
        return {
          itemId: x.sceneInfo.itemId,
          productDetails: [
            {
              productFormat: ProductFormat.SLC_CEOS,
              resolutionMode: ResolutionMode.normal,
            },
          ],
        };
      });
    reproCompletedItems = fixtureProductData
      .filter((a) => a.id === 'e5000022-9f4b-41c8-a7a7-d48f8df8e44b')
      .map((x) => {
        return {
          itemId: x.sceneInfo.itemId,
          productDetails: [
            {
              productFormat: x.productFormat,
              resolutionMode: x.resolutionMode,
            },
          ],
        };
      });
    multiUserItems = fixtureProductData
      .filter((a) => a.id === 'e5000021-9f4b-41c8-a7a7-d48f8df8e44b')
      .map((x) => {
        return {
          itemId: x.sceneInfo.itemId,
          productDetails: [
            {
              productFormat: x.productFormat,
              resolutionMode: x.resolutionMode,
            },
          ],
          task: x.taskingInfo.name,
        };
      });
  });

  beforeEach(async () => {
    DummyAuthGuard.setDummy(DUMMY_USER, DUMMY_CONTRACTS);
    await prepareTest();
  });
  async function prepareTest() {
    // prepare mock of Citadel
    mockCitadelGrpcService.verifyQuota = jest.fn(
      (contractId: number, checkList: CheckQuotaDto[]) => {
        const tmp = plainToInstance(PaymentsDto, {
          totalConsumptionCredit: 100,
          remainingCredit: 99999,
          results: [],
          verifyResults: checkList.map((x, idx) => {
            const taskCheck = storedCitadelRelatedData.find(
              (y) => y.taskingId == x.id,
            );
            if (taskCheck) {
              throw new Error(`taskingId ${x.id} is already registered`);
            }
            const tmp = plainToInstance(CitadelRelatedDataForTest, {
              taskingId: x.id,
              paymentId: 999000 + idx,
            } as CitadelRelatedDataForTest);
            storedCitadelRelatedData.push(tmp);
            return plainToInstance(VerifyItemDto, {
              taskId: '',
              itemId: tmp.taskingId,
              consumptionCredit: 100,
              dataSourceType: DataSourceType.ARCHIVE,
              imagingMode: ImagingMode.Stripmap,
              numberOfLicense: 1,
              options: [],
            } as VerifyItemDto);
          }),
        } as PaymentsDto);
        return Promise.resolve(tmp);
      },
    );
    mockCitadelGrpcService.checkQuota = jest.fn(
      (contractId: number, checkList: CheckQuotaDto[]) => {
        return Promise.resolve(
          checkList.map((x, idx) => {
            const taskCheck = storedCitadelRelatedData.find(
              (y) => y.taskingId == x.id,
            );
            if (taskCheck) {
              throw new Error(`taskingId ${x.id} is already registered`);
            }
            const tmp = plainToInstance(CitadelRelatedDataForTest, {
              taskingId: x.id,
              paymentId: 999000 + idx,
            } as CitadelRelatedDataForTest);
            storedCitadelRelatedData.push(tmp);
            return plainToInstance(PaymentReplyDto, {
              registrationId: tmp.paymentId,
              taskId: tmp.taskingId,
              status: PaymentTaskStatus.TEMPORAL,
              consumptionCredit: 0,
            } as PaymentReplyDto);
          }),
        );
      },
    );
    mockCitadelGrpcService.reserveTask = jest.fn(
      (registrationIds: string[]) => {
        const tmp = plainToInstance(PaymentsDto, {
          totalConsumptionCredit: 0,
          remainingCredit: 0,
          results: registrationIds.map((x) => {
            return plainToInstance(PaymentReplyDto, {
              registrationId: storedCitadelRelatedData.find(
                (y) => y.taskingId == x,
              ).paymentId,
              taskId: x,
              status: PaymentTaskStatus.RESERVED,
              consumptionCredit: 0,
            } as PaymentReplyDto);
          }),
          verifyResults: registrationIds.map((x) => {
            return plainToInstance(VerifyItemDto, {
              taskId: x,
              consumptionCredit: 0,
              dataSourceType: DataSourceType.ARCHIVE,
              imagingMode: ImagingMode.Stripmap,
              numberOfLicense: 1,
              options: [],
            } as VerifyItemDto);
          }),
        } as PaymentsDto);

        return Promise.resolve(tmp);
      },
    );

    mockCitadelGrpcService.emitTaskResult = jest.fn(
      (emitRequests: EmitRequestDto[]) => {
        return Promise.resolve(
          emitRequests.map((x) => {
            return plainToInstance(PaymentReplyDto, {
              registrationId: storedCitadelRelatedData.find(
                (y) => y.taskingId === x.registrationId,
              ).paymentId,
              taskId: x.registrationId,
              status: PaymentTaskStatus.EXCEPTIONAL,
              consumptionCredit: 0,
            } as PaymentReplyDto);
          }),
        );
      },
    );
    mockProcessingVersion.getLatestProcessingVersion = jest.fn(() => {
      return Promise.resolve({
        dataProcessingSoftwareVersion: '0.13.1',
        productSoftwareVersion: '011.000',
      });
    });
  }

  afterEach(async () => {
    storedCitadelRelatedData = [];
  });

  afterAll(async () => {
    await httpServer.close();
    if (afterDeleteAprs.length) {
      await dataSource.manager.getRepository(ArchivePurchasedItem).delete({
        archivePurchaseRequest: In(afterDeleteAprs.map((x) => x.id)),
      });
      await dataSource.manager
        .getRepository(ArchivePurchaseRequest)
        .delete(afterDeleteAprs.map((x) => x.id));
    }
    if (afterDeleteRRs.length) {
      await dataSource.manager
        .getRepository(ReprocessingRequest)
        .delete(afterDeleteRRs.map((x) => x.id));
    }
    if (afterDeletePDs.length) {
      await dataSource.manager
        .getRepository(ProductData)
        .delete(afterDeletePDs.map((x) => x.id));
    }
    await cacheManager.flushdb();
    await cacheManager.quit();
    await dataSource.destroy();
    //await new Promise((r) => setTimeout(r, 500));

    jest.useRealTimers();
  });

  const checkExistingOrder = async (itemId = undefined) => {
    const resGet = await request
      .default(httpServer)
      .post(baseUrl + '/search')
      .set('Content-Type', 'application/json')
      .send({
        page: 1,
        limit: 100,
      });
    expect(resGet.status).toEqual(200);
    const resultGet = plainToInstance(OrdersDto, resGet.body);
    const existingOrder = itemId
      ? resultGet.data.filter(
          (x) => x.items.filter((y) => y.id === itemId)[0] !== undefined,
        )
      : resultGet.data;
    return existingOrder;
  };

  const checkReprocessingRequest = async (itemId = undefined) => {
    const resGet = await request
      .default(httpServer)
      .get('/reprocessing')
      .query({ limit: 100 })
      .set('Content-Type', 'application/json');
    expect(resGet.status).toEqual(200);
    const resultGet = plainToInstance(
      Paginated<ReprocessingRequestDto>,
      resGet.body,
    );
    const requests = itemId
      ? resultGet.data.filter((x) => x.productData.sceneInfo.itemId === itemId)
      : resultGet.data;
    return requests;
  };

  const getOrder = async (id) => {
    const resGet: request.Response = await request
      .default(httpServer)
      .get(`${baseUrl}/${id}`)
      .set('Content-Type', 'application/json');
    expect(resGet.status).toEqual(200);
    return plainToInstance(OrderDto, resGet.body);
  };

  it(`${baseUrl}/search (POST): Successful already ordered data`, async () => {
    const resGet: request.Response = await request
      .default(httpServer)
      .post(`${baseUrl}/search`)
      .set('Content-Type', 'application/json')
      .send({ limit: 20 });
    expect(resGet.status).toEqual(200);
    const resultGet = plainToInstance(OrdersDto, resGet.body);
    expect(resultGet.data).toHaveLength(fixtureCount);

    // latest created item should be first
    expect(resultGet.data[0].id).toEqual(
      'a0100042-c8eb-4da0-838a-43d407dab2df',
    );
    // this dummy data should have valid downloadExpired,
    //  and valid items property and asset
    expect(resultGet.data[0].orderedUserId).toEqual(DUMMY_USER.stringUserId());
    expect(resultGet.data[0].status).toEqual(OrderStatus.Completed);
    expect(resultGet.data[0].downloadExpired.getTime()).toBeGreaterThan(
      new Date().getTime(),
    );
    expect(resultGet.data[0].downloadableStatus).toEqual(
      DownloadableStatus.Ready,
    );
    let item = plainToInstance(Item, resultGet.data[0].items[0]);
    expect(item.properties['syns:imaging_mode']).toBeDefined();
    expect(item.properties['syns:flight_direction']).toBeDefined();
    expect(item.properties['syns:looking_direction']).toBeDefined();
    expect(item.properties['syns:offnadir_angle']).toBeDefined();

    let infos = item.properties['syns:product_data_info'] as ProductDataInfo[];
    expect(infos).toHaveLength(1);
    expect(
      infos.some(
        (x) =>
          x.product_name ===
            getProductName(ProductFormat.GRD_GEOTIFF, ResolutionMode.normal) &&
          x.product_label ===
            getProductLabel(ProductFormat.GRD_GEOTIFF, ResolutionMode.normal) &&
          x.downloadable === true,
      ),
    ).toBeTruthy();

    expect(item.assets).toBeDefined();
    expect(item.assets).toHaveProperty('thumbnail');
    expect(item.assets).toHaveProperty(
      getProductName(ProductFormat.GRD_GEOTIFF, ResolutionMode.normal),
    );
    const data0 = await getOrder(resultGet.data[0].id);
    expect(data0.items[0].assets).toHaveProperty(
      getProductName(ProductFormat.GRD_GEOTIFF, ResolutionMode.normal),
    );

    // 2nd latest created item should be 2nd
    expect(resultGet.data[1].id).toEqual(
      'a0100041-c8eb-4da0-838a-43d407dab2df',
    );
    // this dummy data should have reprocessing.new SLC_CEOS and expired downloadExpired
    expect(resultGet.data[3].id).toEqual(
      'a0100022-c8eb-4da0-838a-43d407dab2df',
    );
    expect(resultGet.data[3].orderedUserId).toEqual(DUMMY_USER.stringUserId());
    expect(resultGet.data[3].status).toEqual(OrderStatus.New);
    expect(resultGet.data[3].downloadExpired.getTime()).toBeLessThan(
      new Date().getTime(),
    );
    expect(resultGet.data[3].downloadableStatus).toEqual(
      DownloadableStatus.NotReady,
    );

    item = plainToInstance(Item, resultGet.data[3].items[0]);
    expect(item.properties['syns:imaging_mode']).toBeDefined();
    expect(item.properties['syns:flight_direction']).toBeDefined();
    expect(item.properties['syns:looking_direction']).toBeDefined();
    expect(item.properties['syns:offnadir_angle']).toBeDefined();
    expect(item.assets).toBeDefined();
    expect(item.assets).toHaveProperty('thumbnail');
    infos = item.properties['syns:product_data_info'] as ProductDataInfo[];
    expect(infos).toHaveLength(1);
    expect(
      infos.some(
        (x) =>
          x.product_name ===
            getProductName(ProductFormat.SLC_CEOS, ResolutionMode.normal) &&
          x.product_label ===
            getProductLabel(ProductFormat.SLC_CEOS, ResolutionMode.normal) &&
          x.downloadable === false,
      ),
    ).toBeTruthy();
    const data3 = await getOrder(resultGet.data[3].id);
    //still reprocessing so not in asset.
    expect(item.assets).not.toHaveProperty(
      getProductName(ProductFormat.SLC_CEOS, ResolutionMode.normal),
    );
    expect(data3.items[0].assets).not.toHaveProperty(
      getProductName(ProductFormat.SLC_CEOS, ResolutionMode.normal),
    );
  });

  it.each([
    [
      'Single Item Single product no repro ',
      'a0100021-c8eb-4da0-838a-43d407dab2df',
      ProductFormat.GRD_GEOTIFF,
      ResolutionMode.SR,
      DownloadableStatus.Ready,
      1,
      1,
    ],
    [
      'Single Item Multi product no repro ',
      'a0100002-c8eb-4da0-838a-43d407dab2df',
      ProductFormat.SLC_SICD,
      ResolutionMode.normal,
      DownloadableStatus.Expired,
      1,
      2,
    ],
    [
      'Multi item Single product no repro ',
      'a0100001-c8eb-4da0-838a-43d407dab2df',
      ProductFormat.SLC_SICD,
      ResolutionMode.normal,
      DownloadableStatus.Expired,
      2,
      1,
    ],
    [
      'Single item Single product repro New ',
      'a0100023-c8eb-4da0-838a-43d407dab2df',
      ProductFormat.SLC_CEOS,
      ResolutionMode.normal,
      DownloadableStatus.NotReady,
      1,
      1,
    ],
    [
      'Single item Single product Multi repro completed ',
      'a0100044-c8eb-4da0-838a-43d407dab2df',
      ProductFormat.GRD_GEOTIFF,
      ResolutionMode.normal,
      DownloadableStatus.Expired,
      1,
      1,
    ],
    [
      'Single item Single product Multi repro new ',
      'a0100045-c8eb-4da0-838a-43d407dab2df',
      ProductFormat.GRD_GEOTIFF,
      ResolutionMode.normal,
      DownloadableStatus.NotReady,
      1,
      1,
    ],
  ])(
    `${baseUrl}/:id (GET): %s Successful`,
    async (
      _,
      fixture_id,
      format,
      resolution,
      expDL,
      expItemLen,
      expProductLen,
    ) => {
      const resGet: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/${fixture_id}`)
        .set('Content-Type', 'application/json');
      expect(resGet.status).toEqual(200);
      const resultGet = plainToInstance(OrderDto, resGet.body);
      //latest created item should be first
      expect(resultGet.id).toEqual(fixture_id);
      expect(resultGet.items).toHaveLength(expItemLen);
      expect(resultGet.downloadableStatus).toEqual(expDL);

      const item = plainToInstance(Item, resultGet.items[0]);
      const infos = item.properties[
        'syns:product_data_info'
      ] as ProductDataInfo[];
      expect(infos).toHaveLength(expProductLen);
      expect(
        infos.some(
          (x) =>
            x.product_name === getProductName(format, resolution) &&
            x.product_label === getProductLabel(format, resolution) &&
            x.downloadable ===
              (expDL == DownloadableStatus.Ready ? true : false),
        ),
      ).toBeTruthy();
      expect(item.assets).toHaveProperty('thumbnail');
      const product_name = getProductName(format, resolution);
      if (expDL == DownloadableStatus.Ready) {
        expect(item.assets).toHaveProperty(product_name);
        expect(item.assets[product_name].href).toMatch(
          new RegExp(
            `${process.env.IRIS_API_URL}/v${AppConstants.DEFAULT_VERSION}/product-data-version/.*/download`,
          ),
        );
      }
    },
  );

  it(`${baseUrl}/:id (GET): Fail invalid id `, async () => {
    const FIXTURE_INVALID = 'a0900021-c8eb-4da0-838a-43d407dab2df';
    const resGet: request.Response = await request
      .default(httpServer)
      .get(`${baseUrl}/${FIXTURE_INVALID}`)
      .set('Content-Type', 'application/json');
    expect(resGet.status).toEqual(404);
  });

  const OTHER_ORG = TEST_ANOTHER_ORGANIZATION_ID;
  const OTHER_CONTRACT = TEST_ANOTHER_CONTRACT_ID;
  it.each([
    ['requestId', { eq: '1000001-202303-00001' }, 200, 1, /^a0100001.*/],
    ['requestId', { startsWith: '1000001-202302' }, 200, 1, /^a0100000.*/],
    ['requestId', { eq: 'xxx-202303-00001' }, 200, 0, /^invalid/],
    ['status', { eq: OrderStatus.New }, 200, 4, /^a0100022.*/],
    [
      'organizationId',
      { eq: TEST_ORGANIZATION_ID },
      200,
      fixtureCount,
      /^a0100042.*/,
    ],
    ['organizationId', { eq: OTHER_ORG }, 200, 0, /^a0100024.*/],
    ['organizationId', { eq: -100 }, 200, 0, /^invalid*/],
    ['contractId', { eq: TEST_CONTRACT_ID }, 200, fixtureCount, /^a0100042.*/],
    ['contractId', { eq: OTHER_CONTRACT }, 200, 0, /^a0100024.*/],
    ['contractId', { eq: -100 }, 200, 0, /^invalid*/],
    ['invalidKey', { eq: 'invalid' }, 400, 0, /^invalid/],
  ])(
    `${baseUrl}/search (POST): query by %s`,
    async (key, filter, expStatus, expCount, expId) => {
      const query = {
        [key]: filter,
      };
      const body = { limit: 20, query };
      const res: request.Response = await request
        .default(httpServer)
        .post(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .send(body);
      expect(res.status).toEqual(expStatus);
      if (expStatus !== 200) return;

      const result = plainToInstance(OrdersDto, res.body);
      expect(result.context).toEqual(
        expect.objectContaining({
          matched: expCount,
          returned: expCount,
          limit: 20,
        }),
      );
      if (expCount) {
        expect(result.data[0].id).toMatch(expId);
      }
      expect(result.links).toHaveLength(1);
      expect(result.links).toEqual(
        expect.arrayContaining([
          { rel: 'root', href: process.env.IRIS_API_URL },
        ]),
      );
    },
  );

  it.each([
    ['+requestId', 200, fixtureCount, /^a0100000.*/],
    ['-status,requestId', 200, fixtureCount, /^a0100034.*/],
    ['+organizationId,+requestId', 200, fixtureCount, /^a0100000.*/],
    ['+contractId,+requestId', 200, fixtureCount, /^a0100000.*/],
    ['+createdAt', 200, fixtureCount, /^a0100000.*/],
    ['+orderedUserId,+requestId', 200, fixtureCount, /^a0100000.*/],
    ['+downloadExpired', 200, fixtureCount, /^a0100000.*/],
    ['+invalid', 400, 0, ''],
  ])(
    `${baseUrl}/search (POST): sort by %s`,
    async (query, expStatus, expCount, expId) => {
      const body = {
        limit: 20,
        sortby: query.split(',').map((x) => {
          if (x.startsWith('-'))
            return { field: x.substring(1), direction: 'desc' } as StacSortby;
          if (x.startsWith('+'))
            return { field: x.substring(1), direction: 'asc' } as StacSortby;
          return { field: x, direction: 'asc' } as StacSortby;
        }),
      };
      const res: request.Response = await request
        .default(httpServer)
        .post(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .send(body);
      expect(res.status).toEqual(expStatus);
      if (expStatus !== 200) return;

      const result = plainToInstance(OrdersDto, res.body);
      expect(result.context).toEqual(
        expect.objectContaining({
          matched: expCount,
          returned: expCount,
          limit: 20,
        }),
      );
      if (expCount) {
        expect(result.data[0].id).toMatch(expId);
      }
      expect(result.links).toHaveLength(1);
      expect(result.links).toEqual(
        expect.arrayContaining([
          { rel: 'root', href: process.env.IRIS_API_URL },
        ]),
      );
    },
  );
  it.each([
    ['No one purchased', /^0603e8a8/, false],
    ['Other org purchased', /^e5000041/, false],
    ['ContractOrg purchased', /^e5000003/, true],
  ])(
    `${baseUrl}/review (POST): review order which is %s`,
    async (_, fixture, prevOrdered) => {
      const target = fixtureProductData.find((x) => x.id.match(fixture));
      const targetItem = {
        itemId: target.sceneInfo.itemId,
        productDetails: [
          {
            productFormat: target.productFormat,
            resolutionMode: target.resolutionMode,
          },
        ],
      };
      const body = {
        items: [targetItem],
        contractId: TEST_CONTRACT_ID,
      } as OrderCreateDto;
      const response: request.Response = await request
        .default(httpServer)
        .post(baseUrl + '/review')
        .set('Content-Type', 'application/json')
        .send(body);
      expect(response.status).toEqual(200);
      const expTotal = 100;
      const expVerify = 'ok';
      const expDataType = 1;
      expect(response.body).toMatchObject({
        totalConsumptionCredit: expTotal,
        remainingCredit: expect.any(Number),
        verifyStatus: expect.stringMatching(expVerify),
        verifyResults: expect.arrayContaining([
          expect.objectContaining({
            taskId: expect.any(String),
            consumptionCredit: expect.any(Number),
            dataSourceType: expDataType,
            imagingMode: expect.any(Number),
            numberOfLicense: expect.any(Number),
            options: expect.any(Array),
            itemId: targetItem.itemId,
            previouslyOrdered: prevOrdered,
          }),
        ]),
      });
    },
  );

  it(`${baseUrl} (POST): PD exists, PDV inside reprocessing cutoff`, async () => {
    const beforeRepro = await checkReprocessingRequest();
    const target = fixtureProductData.find((x) => x.id.match(/^e5000003/));
    const targetItem = {
      itemId: target.sceneInfo.itemId,
      productDetails: [
        {
          productFormat: target.productFormat,
          resolutionMode: target.resolutionMode,
        },
      ],
    };
    const body = {
      items: [targetItem],
      contractId: TEST_CONTRACT_ID,
    } as OrderCreateDto;
    const resCreate: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(resCreate.status).toEqual(201);
    const result = plainToInstance(OrderDto, resCreate.body);
    afterDeleteAprs.push(result);

    expect(mockCitadelGrpcService.checkQuota).toHaveBeenNthCalledWith(
      1,
      TEST_CONTRACT_ID,
      [
        {
          id: storedCitadelRelatedData[0].taskingId,
          dataSourceType: DataSourceType.ARCHIVE,
          imagingMode: ImagingMode.Stripmap,
          taskingType: TaskingType.Regular,
          scene: 1,
          productDetails: targetItem.productDetails,
          deliveryTimeKind: DeliveryTimeKind.STANDARD,
          taskPriorityKind: TaskingPriorityKind.STANDARD,
        } as CheckQuotaDto,
      ],
    );

    expect(mockCitadelGrpcService.reserveTask).toHaveBeenNthCalledWith(
      1,
      storedCitadelRelatedData.map((x) => x.taskingId),
      await generateNotificationContents(
        OrderStatus.New,
        plainToInstance(NotificationParam, {
          env: process.env.NODE_ENV,
          reqNo: result.requestId,
          orderUrl: `${process.env.IRIS_WEBPAGE_URL}/archive-order-review/${result.id}`,
          items: [
            plainToInstance(NotificationParamItem, {
              itemId: targetItem.itemId,
              imagingMode: ImagingMode.Stripmap,
              dataSourceType: DataSourceType.ARCHIVE,
              files: [
                {
                  productLabel: getProductLabel(
                    target.productFormat,
                    target.resolutionMode,
                  ),
                },
              ],
            } as NotificationParamItem),
          ],
        }),
        ArchiveOrderNotificationTemplates,
      ),
    );

    expect(result.id).not.toBeFalsy();
    expect(result.organizationId).toEqual(TEST_ORGANIZATION_ID);
    expect(result.contractId).toEqual(body.contractId);
    expect(result.orderedUserId).toEqual(DUMMY_USER.stringUserId());
    expect(result.requestId).toMatch(/00001$/);
    expect(result.status).toEqual(OrderStatus.Completed);
    expect(result.downloadableStatus).toEqual(DownloadableStatus.Ready);
    const apr = await dataSource.manager
      .getRepository(ArchivePurchaseRequest)
      .findOneOrFail({
        where: { id: result.id },
        relations: {
          archivePurchasedItems: true,
          archivePurchasedProductData: { productDataVersion: true },
        },
      });
    expect(mockCitadelGrpcService.emitTaskResult).toHaveBeenNthCalledWith(
      1,
      [
        plainToInstance(EmitRequestDto, {
          registrationId: apr.archivePurchasedItems[0].id,
          isRushDelivery: false,
          status: fromOrderStatusToPaymentTaskStatus(OrderStatus.Completed),
          processingSuccessList: [
            plainToInstance(ProcessingSuccessResult, {
              productDataVersionId:
                apr.archivePurchasedProductData[0].productDataVersionId,
              productFormat: ProductFormat.GRD_GEOTIFF,
              resolutionMode: ResolutionMode.SR,
            }),
          ],
        } as EmitRequestDto),
      ],
      await generateNotificationContents(
        OrderStatus.Completed,
        plainToInstance(NotificationParam, {
          env: process.env.NODE_ENV,
          reqNo: result.requestId,
          orderUrl: `${process.env.IRIS_WEBPAGE_URL}/archive-order-review/${result.id}`,
          items: [
            plainToInstance(NotificationParam, {
              itemId: targetItem.itemId,
              imagingMode: ImagingMode.Stripmap,
              dataSourceType: DataSourceType.ARCHIVE,
              expiredAt: result.downloadExpired,
              files: [
                {
                  filename: basename(
                    apr.archivePurchasedProductData[0].productDataVersion
                      .location,
                  ),
                  productLabel: getProductLabel(
                    target.productFormat,
                    target.resolutionMode,
                  ),
                  link: `${process.env.IRIS_API_URL}/v${AppConstants.DEFAULT_VERSION}/product-data-version/${apr.archivePurchasedProductData[0].productDataVersionId}/download`,
                },
              ],
            } as NotificationParamItem),
          ],
        }),
        ArchiveProductDataNotificationTemplates,
      ),
    );
    const afterRepro = await checkReprocessingRequest();
    expect(afterRepro).toHaveLength(beforeRepro.length);
  });

  it(`${baseUrl} (POST): PD exists & RR exists, PDV inside reprocessing cutoff`, async () => {
    const beforeRepro = await checkReprocessingRequest();
    const target = fixtureProductData.find((x) => x.id.match(/^e5000001/));
    const targetItem = {
      itemId: target.sceneInfo.itemId,
      productDetails: [
        {
          productFormat: target.productFormat,
          resolutionMode: target.resolutionMode,
        },
      ],
    };
    const body = {
      items: [targetItem],
      contractId: TEST_CONTRACT_ID,
    } as OrderCreateDto;
    // if already has reprocessing, not create new reprocessing request eve if version changed
    mockProcessingVersion.getLatestProcessingVersion = jest.fn(() => {
      return Promise.resolve({
        dataProcessingSoftwareVersion: '99',
        productSoftwareVersion: '99',
      });
    });
    const resCreate: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(resCreate.status).toEqual(201);
    const result = plainToInstance(OrderDto, resCreate.body);
    afterDeleteAprs.push(result);

    expect(mockCitadelGrpcService.checkQuota).toHaveBeenNthCalledWith(
      1,
      TEST_CONTRACT_ID,
      [
        {
          id: storedCitadelRelatedData[0].taskingId,
          dataSourceType: DataSourceType.ARCHIVE,
          imagingMode: ImagingMode.Stripmap,
          taskingType: TaskingType.Regular,
          scene: 1,
          productDetails: targetItem.productDetails,
          deliveryTimeKind: DeliveryTimeKind.STANDARD,
          taskPriorityKind: TaskingPriorityKind.STANDARD,
        } as CheckQuotaDto,
      ],
    );

    expect(mockCitadelGrpcService.reserveTask).toHaveBeenNthCalledWith(
      1,
      storedCitadelRelatedData.map((x) => x.taskingId),
      await generateNotificationContents(
        OrderStatus.New,
        plainToInstance(NotificationParam, {
          env: process.env.NODE_ENV,
          reqNo: result.requestId,
          orderUrl: `${process.env.IRIS_WEBPAGE_URL}/archive-order-review/${result.id}`,
          items: [
            plainToInstance(NotificationParamItem, {
              itemId: targetItem.itemId,
              imagingMode: ImagingMode.Stripmap,
              dataSourceType: DataSourceType.ARCHIVE,
              files: [
                {
                  productLabel: getProductLabel(
                    target.productFormat,
                    target.resolutionMode,
                  ),
                },
              ],
            } as NotificationParamItem),
          ],
        }),
        ArchiveOrderNotificationTemplates,
      ),
    );

    expect(result.id).not.toBeFalsy();
    expect(result.organizationId).toEqual(TEST_ORGANIZATION_ID);
    expect(result.contractId).toEqual(body.contractId);
    expect(result.orderedUserId).toEqual(DUMMY_USER.stringUserId());
    expect(result.requestId).toMatch(/00002$/);
    expect(result.status).toEqual(OrderStatus.New);
    expect(result.downloadableStatus).toEqual(DownloadableStatus.NotReady);
    expect(mockCitadelGrpcService.emitTaskResult).toHaveBeenCalledTimes(0);
    const afterRepro = await checkReprocessingRequest();
    expect(afterRepro).toHaveLength(beforeRepro.length);
  });

  it(`${baseUrl} (POST): PD exists & RR exists, PDV inside reprocessing cutoff (2)`, async () => {
    const beforeOrder = await checkExistingOrder();
    const body = {
      items: [requestItems[1]],
      contractId: TEST_CONTRACT_ID,
    };
    const resCreate: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(resCreate.status).toEqual(201);
    const result = plainToInstance(OrderDto, resCreate.body);
    afterDeleteAprs.push(result);
    expect(result.id).not.toBeFalsy();
    expect(result.organizationId).toEqual(TEST_ORGANIZATION_ID);
    expect(result.contractId).toEqual(body.contractId);
    expect(result.requestId).toMatch(/00003$/);
    const afterOrder = await checkExistingOrder();
    expect(afterOrder.length).toEqual(beforeOrder.length + 1);
    //latest order should be first by default order
    expect(afterOrder[0].status).toEqual(OrderStatus.New);
  });

  it(`${baseUrl} (POST): PD exists, PDV outside reprocessing cutoff, create new RR`, async () => {
    const beforeOrder = await checkExistingOrder();
    const beforeRepro = await checkReprocessingRequest();
    const body = {
      items: [requestItems[3]],
      contractId: TEST_CONTRACT_ID,
    };

    const resCreate: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(resCreate.status).toEqual(201);
    const result = plainToInstance(OrderDto, resCreate.body);
    afterDeleteAprs.push(result);

    expect(result.id).not.toBeFalsy();
    expect(result.organizationId).toEqual(TEST_ORGANIZATION_ID);
    expect(result.contractId).toEqual(body.contractId);
    expect(result.requestId).toMatch(/00004$/);

    const afterOrder = await checkExistingOrder();
    expect(afterOrder.length).toEqual(beforeOrder.length + 1);
    // latest order should be first by default order
    expect(afterOrder[0].id).toEqual(result.id);
    expect(afterOrder[0].status).toEqual(OrderStatus.New);
    expect(afterOrder[0].items).toHaveLength(1);
    const item = plainToInstance(Item, afterOrder[0].items[0]);
    const infos = item.properties[
      'syns:product_data_info'
    ] as ProductDataInfo[];
    expect(infos).toHaveLength(1);
    expect(
      infos.some(
        (x) =>
          x.product_name ===
            getProductName(ProductFormat.GRD_GEOTIFF, ResolutionMode.normal) &&
          x.product_label ===
            getProductLabel(ProductFormat.GRD_GEOTIFF, ResolutionMode.normal) &&
          x.downloadable === false,
      ),
    ).toBeTruthy();
    expect(item.assets).toHaveProperty('thumbnail');
    const data = await getOrder(result.id);
    //still reprocessing so not in asset.
    expect(item.assets).not.toHaveProperty(
      getProductName(ProductFormat.GRD_GEOTIFF, ResolutionMode.normal),
    );
    expect(data.items[0].assets).not.toHaveProperty(
      getProductName(ProductFormat.GRD_GEOTIFF, ResolutionMode.normal),
    );

    const afterRepro = await checkReprocessingRequest();
    expect(afterRepro).toHaveLength(beforeRepro.length + 1);
    afterDeleteRRs.push(afterRepro[0]);
  });

  it(`${baseUrl} (POST): PD not exists, create new PD & new RR`, async () => {
    const beforeOrder = await checkExistingOrder(notExistItems[0].itemId);
    const beforeRepro = await checkReprocessingRequest();
    const body = {
      items: [notExistItems[0]],
      contractId: TEST_CONTRACT_ID,
    };
    const resCreate: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(resCreate.status).toEqual(201);
    const result = plainToInstance(OrderDto, resCreate.body);
    afterDeleteAprs.push(result);

    expect(result.id).not.toBeFalsy();
    expect(result.organizationId).toEqual(TEST_ORGANIZATION_ID);
    expect(result.contractId).toEqual(body.contractId);
    //expect(result.requestId).toMatch(/00003$/);

    //get order and itemId related order should added
    const afterOrder = await checkExistingOrder(notExistItems[0].itemId);
    expect(afterOrder).toHaveLength(beforeOrder.length + 1);
    //latest order should be first by default order
    expect(afterOrder[0].orderedUserId).toEqual(DUMMY_USER.stringUserId());
    expect(afterOrder[0].status).toEqual(OrderStatus.New);
    expect(afterOrder[0].items).toHaveLength(1);
    const item = plainToInstance(Item, afterOrder[0].items[0]);
    const infos = item.properties[
      'syns:product_data_info'
    ] as ProductDataInfo[];
    expect(infos).toHaveLength(1);
    expect(
      infos.some(
        (x) =>
          x.product_name ===
            getProductName(ProductFormat.SLC_CEOS, ResolutionMode.normal) &&
          x.product_label ===
            getProductLabel(ProductFormat.SLC_CEOS, ResolutionMode.normal) &&
          x.downloadable === false,
      ),
    ).toBeTruthy();
    expect(item.assets).toHaveProperty('thumbnail');
    const data = await getOrder(result.id);
    //still reprocessing so not in asset.
    expect(item.assets).not.toHaveProperty(
      getProductName(ProductFormat.SLC_CEOS, ResolutionMode.normal),
    );
    expect(data.items[0].assets).not.toHaveProperty(
      getProductName(ProductFormat.SLC_CEOS, ResolutionMode.normal),
    );

    const afterRepro = await checkReprocessingRequest();
    expect(afterRepro).toHaveLength(beforeRepro.length + 1);
    afterDeleteRRs.push(afterRepro[0]);
    afterDeletePDs.push(afterRepro[0].productData);
  });

  it(`${baseUrl} (POST): Other user order same product, then PD & RR are not created`, async () => {
    const beforeOrder = await checkExistingOrder(notExistItems[0].itemId);
    const beforeRepro = await checkReprocessingRequest();
    const body = {
      items: [notExistItems[0]],
      contractId: TEST_CONTRACT_ID,
    };
    const resCreate: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(resCreate.status).toEqual(201);
    const result = plainToInstance(OrderDto, resCreate.body);
    afterDeleteAprs.push(result);

    //get order and itemId related order should added
    const afterOrder = await checkExistingOrder(notExistItems[0].itemId);
    expect(afterOrder.length).toEqual(beforeOrder.length + 1);
    //latest order should be first by default order
    expect(afterOrder[0].status).toEqual(OrderStatus.New);
    expect(afterOrder[0].orderedUserId).toEqual(DUMMY_USER.stringUserId());

    const afterRepro = await checkReprocessingRequest();
    expect(afterRepro.length).toEqual(beforeRepro.length);
    expect(afterRepro[0].archivePurchaseRequests.map((x) => x.id)).toEqual(
      expect.arrayContaining([result.id]),
    );
  });

  it(`${baseUrl} (POST): RR already exists, then PD, RR & relation not created`, async () => {
    const beforePdv = fixtureProductData.find(
      (pd) => pd.id === 'e5000022-9f4b-41c8-a7a7-d48f8df8e44b',
    ).productDataVersions[0];
    await dataSource.manager
      .getRepository(ProductDataVersion)
      .update(beforePdv.id, {
        createdAt: sub(new Date(), { days: 1 }),
      });

    const targetItem = reproCompletedItems[0];
    const beforeOrder = await checkExistingOrder();
    const beforeRepro = await checkReprocessingRequest();
    const body = {
      items: [targetItem],
      contractId: TEST_CONTRACT_ID,
    };
    const resCreate: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(resCreate.status).toEqual(201);
    const result = plainToInstance(OrderDto, resCreate.body);
    afterDeleteAprs.push(result);

    //get order and itemId related order should added
    const afterOrder = await checkExistingOrder();
    expect(afterOrder.length).toEqual(beforeOrder.length + 1);
    //latest order should be first by default order
    expect(afterOrder[0].status).toEqual(OrderStatus.Completed);
    expect(afterOrder[0].orderedUserId).toEqual(DUMMY_USER.stringUserId());
    expect(afterOrder[0].downloadableStatus).toEqual(DownloadableStatus.Ready);
    expect(afterOrder[0].items).toHaveLength(1);
    expect(afterOrder[0].items[0].assets).toHaveProperty('thumbnail');
    expect(afterOrder[0].items[0].assets).toMatchObject({
      'SR-GRD_Geotiff': {
        href: expect.any(String),
        title: expect.any(String),
      },
    });
    const data = await getOrder(result.id);
    expect(data.items[0].assets).toMatchObject({
      'SR-GRD_Geotiff': {
        href: expect.any(String),
        title: expect.any(String),
      },
    });

    const afterRepro = await checkReprocessingRequest();
    expect(afterRepro.length).toEqual(beforeRepro.length);
    expect(afterRepro[0].archivePurchaseRequests.map((x) => x.id)).not.toEqual(
      expect.arrayContaining([result.id]),
    );

    const apr = await dataSource.manager
      .getRepository(ArchivePurchaseRequest)
      .findOneOrFail({
        where: { id: result.id },
        relations: {
          archivePurchasedItems: true,
          archivePurchasedProductData: {
            productData: true,
            productDataVersion: true,
          },
        },
      });
    const target = apr.archivePurchasedProductData[0].productData;

    //check notification sent
    expect(mockCitadelGrpcService.emitTaskResult).toHaveBeenNthCalledWith(
      1,
      [
        plainToInstance(EmitRequestDto, {
          registrationId: apr.archivePurchasedItems[0].id,
          isRushDelivery: false,
          status: fromOrderStatusToPaymentTaskStatus(OrderStatus.Completed),
          processingSuccessList: [
            plainToInstance(ProcessingSuccessResult, {
              productDataVersionId:
                apr.archivePurchasedProductData[0].productDataVersionId,
              productFormat: ProductFormat.GRD_GEOTIFF,
              resolutionMode: ResolutionMode.SR,
            }),
          ],
        } as EmitRequestDto),
      ],
      await generateNotificationContents(
        OrderStatus.Completed,
        plainToInstance(NotificationParam, {
          env: process.env.NODE_ENV,
          reqNo: result.requestId,
          orderUrl: `${process.env.IRIS_WEBPAGE_URL}/archive-order-review/${result.id}`,
          items: [
            plainToInstance(NotificationParam, {
              itemId: targetItem.itemId,
              imagingMode: ImagingMode.Stripmap,
              dataSourceType: DataSourceType.ARCHIVE,
              expiredAt: result.downloadExpired,
              files: [
                {
                  filename: basename(
                    apr.archivePurchasedProductData[0].productDataVersion
                      .location,
                  ),
                  productLabel: getProductLabel(
                    target.productFormat,
                    target.resolutionMode,
                  ),
                  link: `${process.env.IRIS_API_URL}/v${AppConstants.DEFAULT_VERSION}/product-data-version/${apr.archivePurchasedProductData[0].productDataVersionId}/download`,
                },
              ],
            } as NotificationParamItem),
          ],
        }),
        ArchiveProductDataNotificationTemplates,
      ),
    );

    await dataSource.manager
      .getRepository(ProductDataVersion)
      .update(beforePdv.id, {
        createdAt: beforePdv.createdAt,
      });
  });
  it(`${baseUrl} (POST): Re-use Multi PD should call emitTask multi times`, async () => {
    const beforeOrder = await checkExistingOrder();
    const beforeRepro = await checkReprocessingRequest();
    const body = {
      items: [
        {
          itemId: reproCompletedItems[0].itemId,
          productDetails: [
            {
              productFormat: ProductFormat.GRD_GEOTIFF,
              resolutionMode: ResolutionMode.normal,
            },
            {
              productFormat: ProductFormat.GRD_GEOTIFF,
              resolutionMode: ResolutionMode.SR,
            },
          ],
        },
      ],
      contractId: TEST_CONTRACT_ID,
    };
    const resCreate: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(resCreate.status).toEqual(201);
    const result = plainToInstance(OrderDto, resCreate.body);
    afterDeleteAprs.push(result);

    //get order and itemId related order should added
    const afterOrder = await checkExistingOrder();
    expect(afterOrder.length).toEqual(beforeOrder.length + 1);
    //latest order should be first by default order
    expect(afterOrder[0].status).toEqual(OrderStatus.Completed);
    expect(afterOrder[0].orderedUserId).toEqual(DUMMY_USER.stringUserId());
    expect(afterOrder[0].downloadableStatus).toEqual(DownloadableStatus.Ready);
    expect(afterOrder[0].items).toHaveLength(1);
    expect(afterOrder[0].items[0].assets).toHaveProperty('thumbnail');
    expect(afterOrder[0].items[0].assets).toMatchObject({
      GRD_Geotiff: {
        href: expect.any(String),
        title: expect.any(String),
      },
      'SR-GRD_Geotiff': {
        href: expect.any(String),
        title: expect.any(String),
      },
    });
    const data = await getOrder(result.id);
    expect(data.items[0].assets).toMatchObject({
      GRD_Geotiff: {
        href: expect.any(String),
        title: expect.any(String),
      },
      'SR-GRD_Geotiff': {
        href: expect.any(String),
        title: expect.any(String),
      },
    });

    const afterRepro = await checkReprocessingRequest();
    expect(afterRepro.length).toEqual(beforeRepro.length);

    //check notification sent
    expect(mockCitadelGrpcService.emitTaskResult).toHaveBeenCalledTimes(2);
  });

  it.each([
    ['both version', '0.14.1', '012.000', /^e5000022/],
    //['dpsVersion', '0.14.1', '011.000', /^e5000051/], e5000051 already reprocessed with another test
    ['psVersion', '0.13.1', '012.000', /^e5000052/],
  ])(
    `${baseUrl} (POST): Already reprocessed order, if %s changed,then  RR Relation Created`,
    async (_, dpsVersion, psVersion, targetId) => {
      //latest Processing version update
      mockProcessingVersion.getLatestProcessingVersion = jest.fn(() => {
        return Promise.resolve({
          dataProcessingSoftwareVersion: dpsVersion,
          productSoftwareVersion: psVersion,
        });
      });

      const target = fixtureProductData.find((x) => x.id.match(targetId));
      const beforeOrder = await checkExistingOrder();
      const beforeRepro = await checkReprocessingRequest();
      const body = {
        items: [
          {
            itemId: target.sceneInfo.itemId,
            productDetails: [
              {
                productFormat: target.productFormat,
                resolutionMode: target.resolutionMode,
              },
            ],
          },
        ],
        contractId: TEST_CONTRACT_ID,
      };
      const resCreate: request.Response = await request
        .default(httpServer)
        .post(baseUrl)
        .set('Content-Type', 'application/json')
        .send(body);
      expect(resCreate.status).toEqual(201);
      const result = plainToInstance(OrderDto, resCreate.body);
      afterDeleteAprs.push(result);

      const afterRepro = await checkReprocessingRequest();
      expect(afterRepro).toHaveLength(beforeRepro.length + 1);
      expect(afterRepro[0].archivePurchaseRequests.map((x) => x.id)).toEqual(
        expect.arrayContaining([result.id]),
      );
      afterDeleteRRs.push(afterRepro[0]);

      //get order and itemId related order should added
      const afterOrder = await checkExistingOrder();
      expect(afterOrder).toHaveLength(beforeOrder.length + 1);

      //latest order should be first by default order
      expect(afterOrder[0].status).toEqual(OrderStatus.New);
      expect(afterOrder[0].orderedUserId).toEqual(DUMMY_USER.stringUserId());
      expect(afterOrder[0].downloadableStatus).toEqual(
        DownloadableStatus.NotReady,
      );
      expect(afterOrder[0].items).toHaveLength(1);
      const infos = afterOrder[0].items[0].properties[
        'syns:product_data_info'
      ] as ProductDataInfo[];
      expect(infos).toHaveLength(1);
      expect(
        infos.some(
          (x) =>
            x.product_name ===
              getProductName(target.productFormat, target.resolutionMode) &&
            x.product_label ===
              getProductLabel(target.productFormat, target.resolutionMode) &&
            x.downloadable === false,
        ),
      ).toBeTruthy();
      expect(afterOrder[0].items[0].assets).toHaveProperty('thumbnail');
      const name = getProductName(target.productFormat, target.resolutionMode);
      const data = await getOrder(result.id);
      // still reprocessing so not in asset.
      expect(afterOrder[0].items[0].assets).not.toMatchObject({
        [name]: {
          href: expect.any(String),
          title: expect.any(String),
        },
      });
      expect(data.items[0].assets).not.toMatchObject({
        [name]: {
          href: expect.any(String),
          title: expect.any(String),
        },
      });

      expect(mockCitadelGrpcService.emitTaskResult).toHaveBeenCalledTimes(0);
      const query = {};
      query[`filter.archiveRequestId`] = afterOrder[0].requestId;
      const res: request.Response = await request
        .default(httpServer)
        .get(`${productDataUrl}/archive-order`)
        .set('Content-Type', 'application/json')
        .query(query)
        .send();
      expect(res.status).toEqual(200);
      const resultPD = res.body as Paginated<ProductDataArchiveOrderDto>;
      expect(resultPD.data).toHaveLength(0);
    },
  );

  it(`${baseUrl} (POST): success with another contract`, async () => {
    DummyAuthGuard.setDummy(DUMMY_ANOTHER_USER, DUMMY_ANOTHER_CONTRACTS);
    const usedPDId = fixtureProductData.map((x) => x.id);
    usedPDIds.push(...usedPDId);

    const body = {
      items: requestItems.slice(0, 2),
      contractId: TEST_ANOTHER_CONTRACT_ID,
    };
    const resCreate: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(resCreate.status).toEqual(201);
    const result = plainToInstance(OrderDto, resCreate.body);
    afterDeleteAprs.push(result);
    expect(result.id).not.toBeFalsy();
    expect(result.organizationId).toEqual(TEST_ANOTHER_ORGANIZATION_ID);
    expect(result.orderedUserId).toEqual(DUMMY_ANOTHER_USER.stringUserId());
    expect(result.requestId).toMatch(/00001$/);
  });

  it(`${baseUrl} (POST): NG with Another Organization`, async () => {
    DummyAuthGuard.setDummy(DUMMY_ANOTHER_USER, DUMMY_ANOTHER_CONTRACTS);

    const body = {
      items: requestItems.slice(0, 2),
      contractId: TEST_CONTRACT_ID,
    };
    const resCreate: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(resCreate.status).toEqual(400);
  });

  it(`${baseUrl} (GET): Successful check relation created OK`, async () => {
    const resGet: request.Response = await request
      .default(httpServer)
      .post(baseUrl + '/search')
      .set('Content-Type', 'application/json')
      .send();
    expect(resGet.status).toEqual(200);
    const resultGet = plainToInstance(OrdersDto, resGet.body);
    expect(resultGet.data.length).toBeGreaterThan(0);
    expect(resultGet.data[0].orderedUserId).toEqual(DUMMY_USER.stringUserId());
    expect(resultGet.data[0].items.length).toBeGreaterThan(0);
    const item = plainToInstance(Item, resultGet.data[0].items[0]);
    expect(item.properties['syns:imaging_mode']).toBeDefined();
    expect(item.properties['syns:flight_direction']).toBeDefined();
    expect(item.properties['syns:looking_direction']).toBeDefined();
    expect(item.properties['syns:offnadir_angle']).toBeDefined();
    expect(item.assets).toBeDefined();
    expect(item.assets).toHaveProperty('thumbnail');

    const order = plainToInstance(OrderDto, resultGet.data[0]);
    expect(order.downloadExpired.getTime()).toBeDefined();
    expect(order.downloadExpired.getTime()).toBeGreaterThan(
      addDays(new Date(), 13).getTime(),
    );
    expect(order.downloadExpired.getTime()).toBeLessThan(
      addDays(new Date(), 14).getTime(),
    );
  });

  it(`${baseUrl}/search (POST): check pagination`, async () => {
    let resGet: request.Response = await request
      .default(httpServer)
      .post(baseUrl + '/search')
      .set('Content-Type', 'application/json')
      .send({
        page: 2,
        limit: 1,
      });
    expect(resGet.status).toEqual(200);
    let resultGet = plainToInstance(OrdersDto, resGet.body);
    expect(resultGet.data.length).toBe(1);

    resGet = await request
      .default(httpServer)
      .post(baseUrl + '/search')
      .set('Content-Type', 'application/json')
      .send({
        page: 1,
        limit: 3,
      });
    expect(resGet.status).toEqual(200);
    resultGet = plainToInstance(OrdersDto, resGet.body);
    expect(resultGet.data.length).toBe(3);
  });

  it(`${baseUrl}/search (POST): check multi product per scene`, async () => {
    const resGet: request.Response = await request
      .default(httpServer)
      .post(baseUrl + '/search')
      .set('Content-Type', 'application/json')
      .send({
        limit: 100,
      });
    expect(resGet.status).toEqual(200);
    const resultGet = plainToInstance(OrdersDto, resGet.body);
    const order = resultGet.data.find(
      (a) => a.id === 'a0100003-c8eb-4da0-838a-43d407dab2df',
    ); //multi product
    expect(order.items.length).toBe(1);
    expect(order.orderedUserId).toEqual(DUMMY_USER.stringUserId());
    expect(order.items[0].properties['syns:product_data_info']).toHaveLength(3);
    expect(order.items[0].assets).toHaveProperty('thumbnail');
    expect(Object.keys(order.items[0].assets)).toHaveLength(1);
    const data = await getOrder(order.id);
    expect(Object.keys(data.items[0].assets)).toHaveLength(1);
  });

  it(`${baseUrl} (Scenario): user A cannot see User B created product`, async () => {
    DummyAuthGuard.setDummy(DUMMY_ANOTHER_USER, DUMMY_ANOTHER_CONTRACTS);
    //first User A has  sceneA1 related product count
    let res, result, task1_pd;
    res = await request
      .default(httpServer)
      .get(`${productDataUrl}/search`)
      .set('Content-Type', 'application/json')
      .send();

    expect(res.status).toEqual(200);
    result = res.body as Paginated<ProductData>;
    task1_pd = result.data.filter(
      (x) => x.taskingInfo.name === 'Afixture-tasking_info-21',
    );
    expect(task1_pd).toHaveLength(1);

    // UserB ordered not existing format for SceneA
    DummyAuthGuard.setDummy(DUMMY_USER, DUMMY_CONTRACTS);
    const body = {
      items: [
        {
          itemId: multiUserItems[0].itemId,
          productDetails: [
            {
              productFormat: ProductFormat.SLC_SICD,
              resolutionMode: ResolutionMode.normal,
            },
          ],
        },
      ],
      contractId: TEST_CONTRACT_ID,
    };
    //SLC_SICD has same dps and ps version.
    mockProcessingVersion.getLatestProcessingVersion = jest.fn(() => {
      return Promise.resolve({
        dataProcessingSoftwareVersion: '0.13.1',
        productSoftwareVersion: '0.13.1',
      });
    });

    const resCreate: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(resCreate.status).toEqual(201);
    result = plainToInstance(OrderDto, resCreate.body);
    expect(result.orderedUserId).toEqual(DUMMY_USER.stringUserId());
    afterDeleteAprs.push(result);

    // User A cannot see new Product
    DummyAuthGuard.setDummy(DUMMY_ANOTHER_USER, DUMMY_ANOTHER_CONTRACTS);
    res = await request
      .default(httpServer)
      .get(`${productDataUrl}/search`)
      .set('Content-Type', 'application/json')
      .send();

    expect(res.status).toEqual(200);
    result = res.body as Paginated<ProductData>;
    task1_pd = result.data.filter(
      (x) => x.taskingInfo.name === 'Afixture-tasking_info-21',
    );
    expect(task1_pd).toHaveLength(1);
  });

  it(`${baseUrl} (Scenario): it should return GRD information as default`, async () => {
    DummyAuthGuard.setDummy(DUMMY_ANOTHER_USER, DUMMY_ANOTHER_CONTRACTS);
    const beforeOrder = await checkExistingOrder();
    const beforeRepro = await checkReprocessingRequest();
    // use SLC_SICD product id, but sceneInfo should use GRD product data
    const PRODUCT_GRD = 'e5000031-9f4b-41c8-a7a7-d48f8df8e44b';
    const PRODUCT_SLC = 'e5000032-9f4b-41c8-a7a7-d48f8df8e44b';
    const grd = fixtureProductData.find((a) => a.id === PRODUCT_GRD);
    const slc = fixtureProductData.find((a) => a.id === PRODUCT_SLC);

    //product has same itemId
    expect(slc.sceneInfo.itemId).toEqual(grd.sceneInfo.itemId);

    //first User B order sceneA1 related product
    const body = {
      items: [
        {
          itemId: slc.sceneInfo.itemId,
          productDetails: [
            {
              productFormat: ProductFormat.SLC_SICD,
              resolutionMode: ResolutionMode.normal,
            },
          ],
        },
      ],
      contractId: TEST_ANOTHER_CONTRACT_ID,
    };
    //SLC_SICD has same dps and ps version.
    mockProcessingVersion.getLatestProcessingVersion = jest.fn(() => {
      return Promise.resolve({
        dataProcessingSoftwareVersion: '0.13.1',
        productSoftwareVersion: '0.13.1',
      });
    });
    const resCreate: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(resCreate.status).toEqual(201);
    const result = plainToInstance(OrderDto, resCreate.body);
    afterDeleteAprs.push(result);

    // then check order list
    const afterOrder = await checkExistingOrder();
    expect(afterOrder.length).toEqual(beforeOrder.length + 1);
    //latest order should be first by default order
    // it shows GRD based information as ordered item
    expect(afterOrder[0].items.length).toEqual(1);
    expect(afterOrder[0].items[0].bbox).toEqual(
      grd.productDataVersions[0].bbox,
    );
    expect(afterOrder[0].items[0].bbox).not.toEqual(
      slc.productDataVersions[0].bbox,
    );

    const afterRepro = await checkReprocessingRequest();
    expect(afterRepro).toHaveLength(beforeRepro.length);
    //this test not create reprocessing, so don't push to afterDeleteRRs
  });

  it(`${baseUrl} (Scenario): user can get only ordered product`, async () => {
    const beforeRepro = await checkReprocessingRequest();
    // original, only GRD_Geotiff product exist
    const target = fixtureProductData.find(
      (x) => x.id === 'e5000023-9f4b-41c8-a7a7-d48f8df8e44b',
    );

    // UserA ordered SLC_Ceos
    DummyAuthGuard.setDummy(DUMMY_ANOTHER_USER, DUMMY_ANOTHER_CONTRACTS);

    let body = {
      items: [
        {
          itemId: target.sceneInfo.itemId,
          productDetails: [
            {
              productFormat: ProductFormat.SLC_CEOS,
              resolutionMode: ResolutionMode.normal,
            },
          ],
        },
      ],
      contractId: TEST_ANOTHER_CONTRACT_ID,
    };
    let resCreate: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(resCreate.status).toEqual(201);
    let result = plainToInstance(OrderDto, resCreate.body);
    afterDeleteAprs.push(result);
    expect(result.orderedUserId).toEqual(DUMMY_ANOTHER_USER.stringUserId());

    const afterRepro = await checkReprocessingRequest();
    expect(afterRepro).toHaveLength(beforeRepro.length + 1);
    afterDeleteRRs.push(afterRepro[0]);
    afterDeletePDs.push(afterRepro[0].productData);

    // UserB ordered SR-GRD
    DummyAuthGuard.setDummy(DUMMY_USER, DUMMY_CONTRACTS);
    body = {
      items: [
        {
          itemId: target.sceneInfo.itemId,
          productDetails: [
            {
              productFormat: ProductFormat.GRD_GEOTIFF,
              resolutionMode: ResolutionMode.SR,
            },
          ],
        },
      ],
      contractId: TEST_CONTRACT_ID,
    };
    resCreate = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(resCreate.status).toEqual(201);
    result = plainToInstance(OrderDto, resCreate.body);
    afterDeleteAprs.push(result);
    expect(result.orderedUserId).toEqual(DUMMY_USER.stringUserId());

    // UserB don't get SLC_Ceos asset and product-data
    DummyAuthGuard.setDummy(DUMMY_USER, DUMMY_CONTRACTS);
    let orders = await checkExistingOrder();
    expect(orders[0].orderedUserId).toEqual(DUMMY_USER.stringUserId());
    expect(orders[0].items).toHaveLength(1);
    let item = plainToInstance(Item, orders[0].items[0]);
    expect(item.properties['syns:product_data_info']).toHaveLength(1);
    let infos = item.properties['syns:product_data_info'] as ProductDataInfo[];
    expect(infos).toHaveLength(1);
    expect(
      infos.some(
        (x) =>
          x.product_name ===
            getProductName(ProductFormat.GRD_GEOTIFF, ResolutionMode.SR) &&
          x.product_label ===
            getProductLabel(ProductFormat.GRD_GEOTIFF, ResolutionMode.SR) &&
          x.downloadable === false,
      ),
    ).toBeTruthy();
    expect(item.assets).toHaveProperty('thumbnail');
    const data = await getOrder(orders[0].id);
    // still reprocessing so, no assert url
    expect(item.assets).not.toHaveProperty(
      getProductName(ProductFormat.GRD_GEOTIFF, ResolutionMode.SR),
    );
    expect(data.items[0].assets).not.toHaveProperty(
      getProductName(ProductFormat.GRD_GEOTIFF, ResolutionMode.SR),
    );

    expect(
      infos.some(
        (x) =>
          x.product_name ===
            getProductName(ProductFormat.SLC_CEOS, ResolutionMode.normal) &&
          x.product_label ===
            getProductLabel(ProductFormat.SLC_CEOS, ResolutionMode.normal) &&
          x.downloadable === false,
      ),
    ).toBeFalsy();
    expect(item.assets).not.toHaveProperty(
      getProductName(ProductFormat.SLC_CEOS, ResolutionMode.normal),
    );
    expect(data.items[0].assets).not.toHaveProperty(
      getProductName(ProductFormat.SLC_CEOS, ResolutionMode.normal),
    );

    // UserA don't get SR-GRD asset and product-data
    DummyAuthGuard.setDummy(DUMMY_ANOTHER_USER, DUMMY_ANOTHER_CONTRACTS);
    orders = await checkExistingOrder();
    expect(orders[0].orderedUserId).toEqual(DUMMY_ANOTHER_USER.stringUserId());
    expect(orders[0].items).toHaveLength(1);
    item = plainToInstance(Item, orders[0].items[0]);
    infos = item.properties['syns:product_data_info'] as ProductDataInfo[];
    expect(infos).toHaveLength(1);
    expect(
      infos.some(
        (x) =>
          x.product_name ===
            getProductName(ProductFormat.GRD_GEOTIFF, ResolutionMode.SR) &&
          x.product_label ===
            getProductLabel(ProductFormat.GRD_GEOTIFF, ResolutionMode.SR) &&
          x.downloadable === false,
      ),
    ).toBeFalsy();
    expect(item.assets).toHaveProperty('thumbnail');
    expect(item.assets).not.toHaveProperty(
      getProductName(ProductFormat.GRD_GEOTIFF, ResolutionMode.SR),
    );
    const data2 = await getOrder(orders[0].id);
    expect(data2.items[0].assets).not.toHaveProperty(
      getProductName(ProductFormat.GRD_GEOTIFF, ResolutionMode.SR),
    );

    expect(
      infos.some(
        (x) =>
          x.product_name ===
            getProductName(ProductFormat.SLC_CEOS, ResolutionMode.normal) &&
          x.product_label ===
            getProductLabel(ProductFormat.SLC_CEOS, ResolutionMode.normal) &&
          x.downloadable === false,
      ),
    ).toBeTruthy();
    // still reprocessing so, no assert url
    expect(item.assets).not.toHaveProperty(
      getProductName(ProductFormat.SLC_CEOS, ResolutionMode.normal),
    );
    expect(data2.items[0].assets).not.toHaveProperty(
      getProductName(ProductFormat.SLC_CEOS, ResolutionMode.normal),
    );
  });

  it(`${baseUrl} (Scenario): check downloadable status partial`, async () => {
    DummyAuthGuard.setDummy(DUMMY_ANOTHER_USER, DUMMY_ANOTHER_CONTRACTS);
    // use SLC_SICD product id, but sceneInfo should use GRD product data
    const PRODUCT_READY = 'e5000022-9f4b-41c8-a7a7-d48f8df8e44b';
    const PRODUCT_NEW = 'e5000024-9f4b-41c8-a7a7-d48f8df8e44b';
    const ready = fixtureProductData.find((a) => a.id === PRODUCT_READY);
    const preparing = fixtureProductData.find((a) => a.id === PRODUCT_NEW);

    //this fixture product has same itemId
    expect(ready.sceneInfo.itemId).toEqual(preparing.sceneInfo.itemId);
    const body = {
      items: [
        {
          itemId: ready.sceneInfo.itemId,
          productDetails: [
            //ready
            {
              productFormat: ProductFormat.GRD_GEOTIFF,
              resolutionMode: ResolutionMode.SR,
            },
            //new
            {
              productFormat: ProductFormat.SLC_CEOS,
              resolutionMode: ResolutionMode.normal,
            },
          ],
        },
      ],
      contractId: TEST_ANOTHER_CONTRACT_ID,
    };
    const resCreate: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(resCreate.status).toEqual(201);
    const result = plainToInstance(OrderDto, resCreate.body);
    afterDeleteAprs.push(result);
    const orders = await checkExistingOrder();
    expect(orders[0].orderedUserId).toEqual(DUMMY_ANOTHER_USER.stringUserId());
    expect(orders[0].items).toHaveLength(1);
    expect(orders[0].downloadableStatus).toEqual(DownloadableStatus.NotReady);
  });

  it(`${baseUrl} (Scenario): ArchivePurchasedItem record should be set registrationId and credit`, async () => {
    DummyAuthGuard.setDummy(DUMMY_ANOTHER_USER, DUMMY_ANOTHER_CONTRACTS);
    const PRODUCT_GRD = 'e5000031-9f4b-41c8-a7a7-d48f8df8e44b';
    const grd = fixtureProductData.find((a) => a.id === PRODUCT_GRD);
    const body = {
      items: [
        {
          itemId: grd.sceneInfo.itemId,
          productDetails: [
            {
              productFormat: ProductFormat.SLC_SICD,
              resolutionMode: ResolutionMode.normal,
            },
          ],
        },
      ],
      contractId: TEST_ANOTHER_CONTRACT_ID,
    };
    //SLC_SICD has same dps and ps version.
    mockProcessingVersion.getLatestProcessingVersion = jest.fn(() => {
      return Promise.resolve({
        dataProcessingSoftwareVersion: '0.13.1',
        productSoftwareVersion: '0.13.1',
      });
    });
    const resCreate: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(resCreate.status).toEqual(201);
    const result = plainToInstance(OrderCreateReplyDto, resCreate.body);
    afterDeleteAprs.push(result);
    const apItems = await dataSource.manager
      .getRepository(ArchivePurchasedItem)
      .find({
        where: { archivePurchaseRequest: { id: result.id } },
        relations: ['archivePurchaseRequest'],
      });
    expect(apItems).toHaveLength(1);
    expect(apItems[0].registrationId).toEqual(
      result.payment.results[0].registrationId,
    );
    expect(apItems[0].consumptionCredit).toEqual(
      result.payment.results[0].consumptionCredit,
    );
  });

  it(`${baseUrl} (Scenario): cart should be deleted after order`, async () => {
    DummyAuthGuard.setDummy(DUMMY_USER, DUMMY_CONTRACTS);
    const PRODUCT_GRD = 'e5000031-9f4b-41c8-a7a7-d48f8df8e44b';
    const grd = fixtureProductData.find((a) => a.id === PRODUCT_GRD);

    let res: request.Response = await request
      .default(httpServer)
      .post(cartUrl)
      .set('Content-Type', 'application/json')
      .send({ itemIds: [grd.sceneInfo.itemId] });
    expect(res.status).toEqual(201);
    let cart = plainToInstance(CartWithFeatureDto, res.body);
    expect(cart.items.length).toEqual(1);

    res = await request.default(httpServer).get(cartUrl);
    expect(res.status).toEqual(200);
    cart = plainToInstance(CartWithFeatureDto, res.body);
    expect(cart.items.length).toEqual(1);

    const body = {
      items: [
        {
          itemId: grd.sceneInfo.itemId,
          productDetails: [
            {
              productFormat: ProductFormat.SLC_SICD,
              resolutionMode: ResolutionMode.normal,
            },
          ],
        },
      ],
      contractId: TEST_CONTRACT_ID,
    };
    //SLC_SICD has same dps and ps version.
    mockProcessingVersion.getLatestProcessingVersion = jest.fn(() => {
      return Promise.resolve({
        dataProcessingSoftwareVersion: '0.13.1',
        productSoftwareVersion: '0.13.1',
      });
    });
    const resCreate: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(resCreate.status).toEqual(201);
    const result = plainToInstance(OrderCreateReplyDto, resCreate.body);
    afterDeleteAprs.push(result);

    res = await request.default(httpServer).get(cartUrl);
    expect(res.status).toEqual(200);
    cart = plainToInstance(CartWithFeatureDto, res.body);
    expect(cart.items.length).toEqual(0);
  });
});
