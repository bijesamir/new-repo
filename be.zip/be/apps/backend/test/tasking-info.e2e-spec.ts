/* eslint-disable @typescript-eslint/no-unused-vars */
import { INestApplication, InternalServerErrorException } from '@nestjs/common';
import { DataSource } from 'typeorm';
import {
  TaskingInfoListDtoForTest,
  TaskingRequestInputDataForTest,
  createAppForE2ETest,
  mockDataScsOrderResponseDto,
} from './utils';
import {
  loadFixtureAoi,
  loadFixtureTaskingInfo,
  loadFixtureTaskingRequest,
} from './fixtures';
import {
  TEST_ANOTHER_ORGANIZATION_ID,
  TEST_ORGANIZATION_ID,
  getTestContractIdForFixture,
} from '@iris-lib/constants/test-support';
import { Aoi, TaskingInfo, TaskingRequest } from '@iris-lib/db/entities';
import * as request from 'supertest';
import { TaskingInfoCreateDto } from '../src/models/dto/tasking-info/tasking-info-create.dto';
import { displayCandidates } from './fixtures';
import { ExpressAdapter } from '@nestjs/platform-express';

import { plainToInstance } from 'class-transformer';
import { MissionPortalService } from '../src/infra/mission-portal/mission-portal.service';
import {
  ScsOrderRequestDto,
  ScsOrderResponseDto,
} from '../src/models/dto/mission-portal/scs-order.dto';
import {
  ScsCommonResponseDto,
  ScsUpdateStatusRequestDto,
} from '../src/models/dto/mission-portal/scs-update-status.dto';

import {
  ImagingMode,
  NotificationContents,
  NotificationParam,
  NotificationParamItem,
  ProductFormat,
  ResolutionMode,
  ScsOrderStatus,
  TaskingStatus,
  TaskingStatusDetail,
  TaskingType,
  UnrecordedTaskingStatus,
  generateNotificationContents,
  getDetermineDeadlineBaseDate,
  getUrgentDeadlineTime,
  toScsOrderStatus,
} from '@iris-lib/constants';
import { ScsCandidateForViewDto } from '../src/models/dto/mission-portal/scs-candidate.dto';
import { Paginated } from 'nestjs-paginate';
import {
  TaskingInfoUpdateStatusDto,
  TaskingInfoUpdateStatusResultDtoDecorator,
} from '../src/models/dto/tasking-info/tasking-info-update-status.dto';
import { AxiosError } from 'axios';
import { TaskingInfoUpdateAltitudeDto } from '../src/models/dto/tasking-info/tasking-info-update-altitude.dto';
import { TaskingInfoUsecaseService } from '../src/usecases/tasking-info-usecase/tasking-info-usecase.service';

import {
  CheckQuotaDto,
  EmitRequestDto,
  PaymentReplyDto,
  PaymentsDto,
  VerifyItemDto,
} from '@iris-lib/models/payment';
import {
  PaymentTaskStatus,
  fromTaskingOperationStatusToPaymentTaskStatus,
} from '@iris-lib/constants/payment-task-status';
import { ScsRegistrationAvailabilityCheckRequestDto } from '../src/models/dto/mission-portal/scs-registration-availability-check.dto';
import { DataSourceType } from '@iris-lib/constants/data-source-type';
import { add } from 'date-fns';
import { ScsUpdateAltitudeDto } from '../src/models/dto/mission-portal/scs-update-alititude.dto';
import { CitadelGrpcService } from '@iris-lib/citadel';
import { DeliveryTimeKind } from '@iris-lib/constants/delivery-time-kind';
import { TaskingPriorityKind } from '@iris-lib/constants/tasking-priority-kind';
import { ProductDetailsDto } from '@iris-lib/models';
import {
  SlackChannel,
  SlackMessage,
  SlackNotificationService,
  SlackTaskingInfoStatusMessage,
} from '@iris-lib/slack';
import { TaskingInfoWithTaskingRequestDto } from '../src/models/dto/tasking-info/tasking-info.dto';
import Redis, { Cluster } from 'ioredis';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { RedisCache } from 'cache-manager-ioredis-yet';
import {
  DUMMY_ANOTHER_CONTRACTS,
  DUMMY_ANOTHER_USER,
  DUMMY_CONTRACTS,
  DUMMY_USER,
  DummyAuthGuard,
} from '@iris-lib/guards';

const baseUrl = '/tasking-info';

class AssociatedTaskingRequest {
  taskingRequest: TaskingRequest;
  aois: Aoi[];
}

const linkAoisToTaskingRequest = async (
  ds: DataSource,
  linkTarget: AssociatedTaskingRequest,
) => {
  await ds
    .createQueryBuilder()
    .relation(TaskingRequest, 'aois')
    .of(linkTarget.taskingRequest)
    .add(linkTarget.aois);
  return linkTarget;
};

class CitadelRelatedDataForTest {
  taskingId: string;
  paymentId: number;
}

describe('TaskingInfoController', () => {
  let app: INestApplication;
  let dataSource: DataSource;
  let cacheManager: Redis | Cluster;
  let httpServer: ExpressAdapter;
  let fixtureAois: Aoi[];
  let fixtureTaskingRequests: TaskingRequest[];
  let fixtureTaskingInfos: TaskingInfo[];
  let testForUpdateOperation: TaskingInfo;

  const createdTaskingInfos = new Array<TaskingInfo>();

  const defaultProductDetails = [
    plainToInstance(ProductDetailsDto, {
      productFormat: ProductFormat.GRD_GEOTIFF,
      resolutionMode: ResolutionMode.normal,
    }),
    plainToInstance(ProductDetailsDto, {
      productFormat: ProductFormat.SLC_SICD,
      resolutionMode: ResolutionMode.normal,
    }),
    plainToInstance(ProductDetailsDto, {
      productFormat: ProductFormat.SLC_CEOS,
      resolutionMode: ResolutionMode.normal,
    }),
  ];

  const mockMissionPortalService = {
    registrationAvailabilityCheck: jest.fn(),
    register: jest.fn(),
    updateStatusByOrderId: jest.fn(),
    updateAltitude: jest.fn(),
    getEmailForRegistraion: jest.fn(() => 'test@test.com'),
  };

  const mockCitadelGrpcService = {
    checkQuota: jest.fn(),
    reserveTask: jest.fn(),
    emitTaskResult: jest.fn(),
  };

  const mockSlackNotificationService = {
    send: jest.fn(),
  };

  const taskMgmtUrl = `${process.env.IRIS_WEBPAGE_URL ?? 'NONE'}/tasks`;

  beforeAll(async () => {
    app = await createAppForE2ETest((tm) => {
      tm.overrideProvider(MissionPortalService).useValue(
        mockMissionPortalService,
      );
      tm.overrideProvider(SlackNotificationService).useValue(
        mockSlackNotificationService,
      );
      tm.overrideProvider(CitadelGrpcService).useValue(mockCitadelGrpcService);
    });
    await app.init();
    dataSource = app.get(DataSource);
    cacheManager = (app.get(CACHE_MANAGER) as RedisCache).store.client;
    httpServer = app.getHttpServer();
    fixtureAois = await loadFixtureAoi(dataSource);
    fixtureTaskingRequests = await loadFixtureTaskingRequest(dataSource);
    fixtureTaskingInfos = await loadFixtureTaskingInfo(dataSource);
    testForUpdateOperation = fixtureTaskingInfos.filter(
      (x) =>
        x.organizationId == TEST_ORGANIZATION_ID &&
        x.status === TaskingStatus.PreOrder,
    )[0];
  });

  beforeEach(async () => {
    DummyAuthGuard.setDummy(DUMMY_USER, DUMMY_CONTRACTS);
  });

  afterAll(async () => {
    if (createdTaskingInfos.length > 0) {
      await dataSource.manager
        .getRepository(TaskingInfo)
        .delete(createdTaskingInfos.map((x) => x.id));
    }
    await dataSource.destroy();
    await cacheManager.flushdb();
    await cacheManager.quit();
    await app.close();
  });

  describe('all endpoint', () => {
    const associatedData = new Array<AssociatedTaskingRequest>();
    let storedCitadelRelatedData: CitadelRelatedDataForTest[] =
      new Array<CitadelRelatedDataForTest>();
    afterEach(async () => {
      mockMissionPortalService.registrationAvailabilityCheck = jest.fn();
      mockMissionPortalService.register = jest.fn();
      mockMissionPortalService.updateStatusByOrderId = jest.fn();
      mockMissionPortalService.updateAltitude = jest.fn();
      mockCitadelGrpcService.checkQuota = jest.fn();
      mockCitadelGrpcService.reserveTask = jest.fn();
      mockCitadelGrpcService.emitTaskResult = jest.fn();
      mockSlackNotificationService.send = jest.fn();
      storedCitadelRelatedData = [];
    });
    afterAll(async () => {
      associatedData.reduce(async (p, c) => {
        await p;
        await dataSource
          .createQueryBuilder()
          .relation(TaskingRequest, 'aois')
          .of(c.taskingRequest)
          .remove(c.aois.map((x) => x.id));
      }, Promise.resolve());
    });

    it(`${baseUrl} (POST): Fail registration (caused by taskingType)`, async () => {
      const { targetTaskingRequest, selectedCandidate } = await prepareTest();

      const body: TaskingInfoCreateDto = plainToInstance(TaskingInfoCreateDto, {
        name: 'tasking-info-001',
        contractId: getTestContractIdForFixture(),
        taskingRequestId: targetTaskingRequest.id,
        selectedCandidates: [selectedCandidate],
        organizationId: targetTaskingRequest.organizationId,
      });
      // end preparation

      // execute test
      const res: request.Response = await request
        .default(httpServer)
        .post(baseUrl)
        .set('Content-Type', 'application/json')
        .send(body);
      expect(res.status).toEqual(400);
      expect(res.body.message[0].name).toEqual('taskingType');

      async function prepareTest() {
        const tmp = new AssociatedTaskingRequest();
        tmp.taskingRequest = fixtureTaskingRequests.find(
          (x) =>
            x.organizationId == TEST_ORGANIZATION_ID &&
            x.name.startsWith('fixture-tasking_request-1'),
        );
        tmp.aois = [
          fixtureAois.find(
            (x) =>
              x.organizationId == TEST_ORGANIZATION_ID &&
              x.name.startsWith('fixture-aoi-common-1'),
          ),
        ];
        // Link aoi to tasking request
        await linkAoisToTaskingRequest(dataSource, tmp);
        associatedData.push(tmp);

        const selectedCandidate = plainToInstance(
          ScsCandidateForViewDto,
          structuredClone(displayCandidates[0]),
        );

        // adjust observationTiming
        selectedCandidate.observationTiming.obsStartTimeUTC = add(
          getUrgentDeadlineTime(
            new Date(),
            getDetermineDeadlineBaseDate(new Date()),
          ),
          { days: 1 },
        );
        selectedCandidate.observationTiming.obsEndTimeUTC = add(
          selectedCandidate.observationTiming.obsStartTimeUTC,
          { seconds: 10 },
        );
        selectedCandidate.taskingType = TaskingType.Urgent;

        return { targetTaskingRequest: tmp.taskingRequest, selectedCandidate };
      }
    });

    it(`${baseUrl} (POST): Fail registration (caused by non-visible satellite)`, async () => {
      const { targetTaskingRequest, selectedCandidate } = await prepareTest();

      const body: TaskingInfoCreateDto = plainToInstance(TaskingInfoCreateDto, {
        name: 'tasking-info-001',
        contractId: getTestContractIdForFixture(),
        taskingRequestId: targetTaskingRequest.id,
        selectedCandidates: [selectedCandidate],
        organizationId: targetTaskingRequest.organizationId,
      });
      // end preparation

      // execute test
      const res: request.Response = await request
        .default(httpServer)
        .post(baseUrl)
        .set('Content-Type', 'application/json')
        .send(body);
      expect(res.status).toEqual(400);
      expect(res.body.message[0].name).toEqual('satId');

      async function prepareTest() {
        const tmp = new AssociatedTaskingRequest();
        tmp.taskingRequest = fixtureTaskingRequests.find(
          (x) =>
            x.organizationId == TEST_ORGANIZATION_ID &&
            x.name.startsWith('fixture-tasking_request-1'),
        );
        tmp.aois = [
          fixtureAois.find(
            (x) =>
              x.organizationId == TEST_ORGANIZATION_ID &&
              x.name.startsWith('fixture-aoi-common-1'),
          ),
        ];
        // skip linking aoi to tasking request (already done in previous case)
        // await linkAoisToTaskingRequest(dataSource, tmp);
        // associatedData.push(tmp);

        // ST0002 is a non-visible satellite to IrisUserRole.ADMINISTRATOR
        const selectedCandidate = plainToInstance(
          ScsCandidateForViewDto,
          structuredClone(displayCandidates[1]),
        );
        // adjust observationTiming
        selectedCandidate.observationTiming.obsStartTimeUTC = add(
          getUrgentDeadlineTime(
            new Date(),
            getDetermineDeadlineBaseDate(new Date()),
          ),
          { days: 1 },
        );
        selectedCandidate.observationTiming.obsEndTimeUTC = add(
          selectedCandidate.observationTiming.obsStartTimeUTC,
          { seconds: 10 },
        );
        selectedCandidate.taskingType = TaskingType.Regular;

        return { targetTaskingRequest: tmp.taskingRequest, selectedCandidate };
      }
    });

    it(`${baseUrl} (POST): Successful registration`, async () => {
      const {
        targetTaskingRequest,
        selectedCandidate,
        orderId,
        orderCode,
        contract,
      } = await prepareTest();

      const body: TaskingInfoCreateDto = plainToInstance(TaskingInfoCreateDto, {
        name: 'tasking-info-001',
        taskingRequestId: targetTaskingRequest.id,
        selectedCandidates: [selectedCandidate],
        contractId: contract.contractId,
        organizationId: targetTaskingRequest.organizationId,
      });
      const res: request.Response = await request
        .default(httpServer)
        .post(baseUrl)
        .set('Content-Type', 'application/json')
        .send(body);
      expect(res.status).toEqual(201);

      const result = plainToInstance(TaskingInfoListDtoForTest, {
        items: res.body,
      });
      createdTaskingInfos.push(...result.items);
      expect(result.items.length).toEqual(1);
      expect(result.items[0].status).toEqual(TaskingStatus.Ordered);
      expect(result.items[0].scsOrderId).toEqual(orderId);
      expect(result.items[0].scsOrderCode).toEqual(orderCode);
      expect(result.items[0].paymentId).toEqual(
        storedCitadelRelatedData[0].paymentId,
      );
      expect(result.items[0].catalogDelayKind).toEqual(
        contract.catalogDelayKind,
      );
      const found = await dataSource
        .getRepository(TaskingInfo)
        .findOneOrFail({ where: { id: result.items[0].id } });
      expect(result.items[0].updatedAt).toEqual(found.updatedAt);
      expect(result.items[0].status).toEqual(found.status);
      expect(result.items[0].scsOrderId).toEqual(found.scsOrderId);
      expect(result.items[0].scsOrderCode).toEqual(found.scsOrderCode);
      expect(result.items[0].paymentId).toEqual(found.paymentId);
      expect(result.items[0].catalogDelayKind).toEqual(found.catalogDelayKind);

      expect(
        mockMissionPortalService.registrationAvailabilityCheck,
      ).toHaveBeenNthCalledWith(1, [
        plainToInstance(ScsRegistrationAvailabilityCheckRequestDto, {
          searchIndex: 1,
          satelliteInfo: selectedCandidate.satelliteInfo,
          observationTiming: selectedCandidate.observationTiming,
        } as ScsRegistrationAvailabilityCheckRequestDto),
      ]);

      expect(mockMissionPortalService.register).toHaveBeenNthCalledWith(1, [
        {
          title: body.name,
          email: mockMissionPortalService.getEmailForRegistraion(),
          customerOrgID: targetTaskingRequest.organizationId.toString(),
          basePriority: targetTaskingRequest.priority,
          centerPosition:
            selectedCandidate.observationArea.obsCenterPosition.getScsPointDto(),
          imagingMode:
            selectedCandidate.observationTiming.orbitParams.imagingMode,
          polarization: targetTaskingRequest.polarization,
          startOBCTime: selectedCandidate.observationTiming.obsStartTime,
          endOBCTime: selectedCandidate.observationTiming.obsEndTime,
          pathDirection:
            selectedCandidate.observationTiming.orbitParams.pathDirection,
          sightDirection:
            selectedCandidate.observationTiming.orbitParams.sightDirection,
          offnadirAngle:
            selectedCandidate.observationTiming.orbitParams.offNadir,
          satId: selectedCandidate.satelliteInfo.satId,
        } as ScsOrderRequestDto,
      ]);
      expect(
        mockMissionPortalService.updateStatusByOrderId,
      ).toHaveBeenNthCalledWith(1, [
        {
          orderId,
          orderStatus: toScsOrderStatus(TaskingStatus.Ordered),
        } as ScsUpdateStatusRequestDto,
      ]);

      expect(mockCitadelGrpcService.checkQuota).toHaveBeenNthCalledWith(
        1,
        found.contractId,
        [
          {
            id: storedCitadelRelatedData[0].taskingId,
            dataSourceType: DataSourceType.NEW,
            imagingMode: found.imagingMode,
            taskingType: found.taskingType,
            scene: found.scenes,
            productDetails: found.productDetails,
            deliveryTimeKind: DeliveryTimeKind.RUSH,
            taskPriorityKind: TaskingPriorityKind.HIGH,
          } as CheckQuotaDto,
        ],
      );

      expect(mockCitadelGrpcService.reserveTask).toHaveBeenNthCalledWith(
        1,
        storedCitadelRelatedData.map((x) => x.taskingId),
        await generateNotificationContents(
          TaskingStatus.Ordered,
          plainToInstance(NotificationParam, {
            env: process.env.NODE_ENV,
            taskMgmtLink: taskMgmtUrl,
            items: result.items.map((x) =>
              plainToInstance(NotificationParamItem, {
                scsOrderCode: x.scsOrderCode,
                obsStart: x.observationStart,
                aoiName: x.name,
                satellite: x.satellite.name,
                imagingMode: x.imagingMode,
                flightDirection: x.flightDirection,
                lookingDirection: x.lookingDirection,
                offnadirAngle: x.offnadirAngle,
                taskingType: x.taskingType,
              } as NotificationParamItem),
            ),
          } as NotificationParam),
        ),
      );

      expect(mockSlackNotificationService.send).toHaveBeenCalledTimes(1);
      expect(mockSlackNotificationService.send).toHaveBeenNthCalledWith(
        1,
        new SlackTaskingInfoStatusMessage(
          {
            name: found.name,
            status: TaskingStatus.Ordered,
            orderCode: found.scsOrderCode,
            observationStart: found.observationStart,
          },
          { channel: SlackChannel.DEFAULT },
        ),
      );
      // TaskingStatus.Ordered should be notified to Slack
      await expect(
        mockSlackNotificationService.send.mock.results[0].value,
      ).resolves.toEqual(true);

      async function prepareTest() {
        const tmp = new AssociatedTaskingRequest();
        tmp.taskingRequest = fixtureTaskingRequests.find(
          (x) =>
            x.organizationId == TEST_ORGANIZATION_ID &&
            x.name.startsWith('fixture-tasking_request-1'),
        );
        tmp.aois = [
          fixtureAois.find(
            (x) =>
              x.organizationId == TEST_ORGANIZATION_ID &&
              x.name.startsWith('fixture-aoi-common-2'),
          ),
        ];
        // Link aoi to tasking request
        await linkAoisToTaskingRequest(dataSource, tmp);
        associatedData.push(tmp);

        const selectedCandidate = plainToInstance(
          ScsCandidateForViewDto,
          structuredClone(displayCandidates[0]),
        );
        // adjust observationTiming
        selectedCandidate.observationTiming.obsStartTimeUTC = add(
          getUrgentDeadlineTime(
            new Date(),
            getDetermineDeadlineBaseDate(new Date()),
          ),
          { days: 1 },
        );
        selectedCandidate.observationTiming.obsEndTimeUTC = add(
          selectedCandidate.observationTiming.obsStartTimeUTC,
          { seconds: 10 },
        );
        selectedCandidate.taskingType = TaskingType.Regular;

        const orderId = 'ec93b142-0f44-4f5d-8055-1bdf4268700e';
        const orderCode = '202302-00001';

        // prepare mock of MissionPortalService.registrationAvailabilityCheck
        mockMissionPortalService.registrationAvailabilityCheck = jest.fn(() => {
          return Promise.resolve(true);
        });

        // prepare mock of MissionPortalService.register
        mockMissionPortalService.register = jest.fn(() => {
          return Promise.resolve([
            mockDataScsOrderResponseDto(
              orderId,
              orderCode,
              ScsOrderStatus.PreRegistration,
              plainToInstance(
                TaskingRequestInputDataForTest,
                tmp.taskingRequest,
              ),
              selectedCandidate,
            ),
          ] as ScsOrderResponseDto[]);
        });

        // prepare mock of MissionPortalService.updateStatusByOrderId
        mockMissionPortalService.updateStatusByOrderId = jest.fn(() => {
          return Promise.resolve({
            result: true,
            errorMessage: null,
          } as ScsCommonResponseDto);
        });

        // prepare mock of Citadel
        mockCitadelGrpcService.checkQuota = jest.fn(
          (contractId: number, checkList: CheckQuotaDto[]) => {
            return Promise.resolve(
              checkList.map((x, idx) => {
                const tmp = plainToInstance(CitadelRelatedDataForTest, {
                  taskingId: x.id,
                  paymentId: 999000 + idx,
                } as CitadelRelatedDataForTest);
                storedCitadelRelatedData.push(tmp);
                return plainToInstance(PaymentReplyDto, {
                  registrationId: tmp.paymentId,
                  taskId: tmp.taskingId,
                  status: PaymentTaskStatus.TEMPORAL,
                  consumptionCredit: 0,
                } as PaymentReplyDto);
              }),
            );
          },
        );
        mockCitadelGrpcService.reserveTask = jest.fn(
          (registrationIds: string[]) => {
            const tmp = plainToInstance(PaymentsDto, {
              totalConsumptionCredit: 0,
              remainingCredit: 0,
              results: registrationIds.map((x) => {
                return plainToInstance(PaymentReplyDto, {
                  registrationId: storedCitadelRelatedData.find(
                    (y) => y.taskingId == x,
                  ).paymentId,
                  taskId: x,
                  status: PaymentTaskStatus.RESERVED,
                  consumptionCredit: 0,
                } as PaymentReplyDto);
              }),
              verifyResults: registrationIds.map((x) => {
                return plainToInstance(VerifyItemDto, {
                  taskId: x,
                  consumptionCredit: 0,
                  dataSourceType: DataSourceType.ARCHIVE,
                  imagingMode: ImagingMode.Stripmap,
                  numberOfLicense: 1,
                  options: [],
                } as VerifyItemDto);
              }),
            } as PaymentsDto);

            return Promise.resolve(tmp);
          },
        );

        mockSlackNotificationService.send = jest.fn((message: SlackMessage) => {
          return Promise.resolve(message.shouldNotify);
        });

        const contract = DUMMY_CONTRACTS.find(
          (c) => c.contractId === getTestContractIdForFixture(),
        );

        return {
          targetTaskingRequest: tmp.taskingRequest,
          selectedCandidate,
          orderId,
          orderCode,
          contract,
        };
      }
    });

    it(`${baseUrl}/update-status (PUT) to canceled`, async () => {
      // prepare mock of MissionPortalService.updateStatusByOrderId
      prepareTest();
      storedCitadelRelatedData.push(
        ...createdTaskingInfos.map((x) => {
          return plainToInstance(CitadelRelatedDataForTest, {
            taskingId: x.id,
            paymentId: x.paymentId,
          } as CitadelRelatedDataForTest);
        }),
      );

      const body: TaskingInfoUpdateStatusDto = {
        ids: createdTaskingInfos.map((x) => x.id),
        status: TaskingStatus.Canceled,
        statusDetail: TaskingStatusDetail.CanceledByOrderer,
      };

      const res: request.Response = await request
        .default(httpServer)
        .put(`${baseUrl}/update-status `)
        .set('Content-Type', 'application/json')
        .send(body);
      expect(res.status).toEqual(200);

      const result = plainToInstance(
        TaskingInfoUpdateStatusResultDtoDecorator,
        { items: res.body },
      );

      const found = await dataSource
        .getRepository(TaskingInfo)
        .findOneOrFail({ where: { id: result.items[0].id } });
      expect(result.items[0].updatedAt).toEqual(found.updatedAt);
      expect(result.items[0].status).toEqual(found.status);
      expect(result.items[0].statusDetail).toEqual(found.statusDetail);

      expect(
        mockMissionPortalService.updateStatusByOrderId,
      ).toHaveBeenNthCalledWith(1, [
        {
          orderId: found.scsOrderId,
          orderStatus: toScsOrderStatus(body.status),
        } as ScsUpdateStatusRequestDto,
      ]);

      expect(mockCitadelGrpcService.emitTaskResult).toHaveBeenNthCalledWith(
        1,
        storedCitadelRelatedData.map((x) => {
          return plainToInstance(EmitRequestDto, {
            registrationId: x.taskingId,
            status: fromTaskingOperationStatusToPaymentTaskStatus(
              TaskingStatus.Canceled,
            ), // FIXME
          } as EmitRequestDto);
        }),
        await generateNotificationContents(
          TaskingStatus.Canceled,
          plainToInstance(NotificationParam, {
            env: process.env.NODE_ENV,
            taskMgmtLink: taskMgmtUrl,
            items: result.items.map((x) =>
              plainToInstance(NotificationParamItem, {
                scsOrderCode: found.scsOrderCode,
                obsStart: found.observationStart,
                reason: found.statusDetail,
                aoiName: found.name,
              } as NotificationParamItem),
            ),
          } as NotificationParam),
        ),
      );

      expect(mockSlackNotificationService.send).toHaveBeenCalledTimes(1);
      expect(mockSlackNotificationService.send).toHaveBeenNthCalledWith(
        1,
        new SlackTaskingInfoStatusMessage(
          {
            name: found.name,
            status: TaskingStatus.Canceled,
            orderCode: found.scsOrderCode,
            observationStart: found.observationStart,
          },
          { channel: SlackChannel.DEFAULT },
        ),
      );
      // TaskingStatus.Canceled should be notified to Slack
      await expect(
        mockSlackNotificationService.send.mock.results[0].value,
      ).resolves.toEqual(true);

      function prepareTest() {
        mockMissionPortalService.updateStatusByOrderId = jest.fn(() => {
          return Promise.resolve({
            result: true,
            errorMessage: null,
          } as ScsCommonResponseDto);
        });
        // prepare mock of Citadel
        mockCitadelGrpcService.emitTaskResult = jest.fn(
          (
            emitRequests: EmitRequestDto[],
            notificationContents: NotificationContents,
          ) => {
            return Promise.resolve(
              emitRequests.map((x) => {
                return plainToInstance(PaymentReplyDto, {
                  registrationId: storedCitadelRelatedData.find(
                    (y) => y.taskingId === x.registrationId,
                  ).paymentId,
                  taskId: x.registrationId,
                  status: x.status,
                  consumptionCredit: 0,
                } as PaymentReplyDto);
              }),
            );
          },
        );
        mockSlackNotificationService.send = jest.fn((message: SlackMessage) => {
          return Promise.resolve(message.shouldNotify);
        });
      }
    });

    it.each([
      ['delivered', 'fixture-tasking_info-4', 'DUMMY_ANOTHER_USER'],
      ['pre-order', 'fixture-tasking_info-5', 'DUMMY_ANOTHER_USER'],
      ['processing', 'fixture-tasking_info-1', 'DUMMY_USER'],
      ['product-created', 'fixture-tasking_info-7', 'DUMMY_USER'],
      ['product-created', 'Afixture-tasking_info-31', 'DUMMY_ANOTHER_USER'], //Check latest is NoRequest
      ['product-created', 'Afixture-tasking_info-32', 'DUMMY_ANOTHER_USER'], //Check only NoRequest
    ])(
      `${baseUrl}/:id (GET): Succeeded in retrieving tasking-info with status '%s %s'`,
      async (expectedStatus, taskingInfoName, user) => {
        switch (user) {
          case 'DUMMY_USER':
            DummyAuthGuard.setDummy(DUMMY_USER, DUMMY_CONTRACTS);
            break;
          case 'DUMMY_ANOTHER_USER':
            DummyAuthGuard.setDummy(
              DUMMY_ANOTHER_USER,
              DUMMY_ANOTHER_CONTRACTS,
            );
            break;
        }
        const target = fixtureTaskingInfos.find(
          (ti) => ti.name === taskingInfoName,
        );
        const res: request.Response = await request
          .default(httpServer)
          .get(`${baseUrl}/${target.id}`)
          .set('Content-Type', 'application/json')
          .send();
        expect(res.status).toEqual(200);

        const gotData = res.body as TaskingInfo;
        expect(gotData.id).toEqual(target.id);
        expect(gotData.name).toEqual(target.name);
        expect(gotData.taskingSummary.summaryStatus).toEqual(expectedStatus);
        expect(gotData.taskingRequest).toHaveProperty('id');
        expect(gotData.taskingRequest).toHaveProperty('name');
        expect(gotData.taskingRequest).not.toHaveProperty('priority');
        expect(gotData.taskingRequest.aois[0]).toHaveProperty('id');
        expect(gotData.taskingRequest.aois[0]).toHaveProperty('name');
        expect(gotData.taskingRequest.aois[0]).toHaveProperty('center');
        expect(gotData.taskingRequest.aois[0]).toHaveProperty('altitude');
        expect(gotData.taskingRequest.aois[0]).toHaveProperty('area');
        expect(gotData.taskingSummary).toHaveProperty('summaryStatus');
        expect(gotData.taskingSummary).toHaveProperty('summaryUpdatedAt');
      },
    );

    it(`${baseUrl}/:id (GET): Error when getting TaskingInfo of organization to which user does not belong`, async () => {
      const target = fixtureTaskingInfos.filter(
        (x) => x.organizationId == TEST_ANOTHER_ORGANIZATION_ID,
      )[0];
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/${target.id}`)
        .set('Content-Type', 'application/json')
        .send();
      expect(res.status).toEqual(404);
    });

    it(`${baseUrl}/search (GET): If you search createdAt with the condition of before the next day, you can get what was registered in the above test`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.name': `$eq:tasking-info-001`,
          'filter.status': `$in:canceled`,
          sortBy: 'createdAt:ASC',
        })
        .send();
      expect(res.status).toEqual(200);

      const gotData = res.body as Paginated<TaskingInfoWithTaskingRequestDto>;
      expect(gotData.data.length).toEqual(1);
      expect(gotData.data[0].taskingRequest).toHaveProperty('id');
      expect(gotData.data[0].taskingRequest).toHaveProperty('name');
      expect(gotData.data[0].taskingRequest).not.toHaveProperty('priority');
      expect(gotData.data[0].taskingRequest.aois[0]).toHaveProperty('id');
      expect(gotData.data[0].taskingRequest.aois[0]).toHaveProperty('name');
      expect(gotData.data[0].taskingRequest.aois[0]).toHaveProperty('center');
      expect(gotData.data[0].taskingRequest.aois[0]).toHaveProperty('altitude');
      expect(gotData.data[0].taskingRequest.aois[0]).toHaveProperty('area');
      expect(gotData.data[0].taskingSummary).toHaveProperty('summaryStatus');
      expect(gotData.data[0].taskingSummary).toHaveProperty('summaryUpdatedAt');
    });

    it(`${baseUrl}/search (GET): If you search scsOrderId`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.scsOrderId': `$in:9974ea33-526e-4249-81ef-d992d7b0c32a,5a056da6-c87b-4b5d-b7cd-71c7477055be`,
        })
        .send();
      expect(res.status).toEqual(200);

      const gotData = res.body as Paginated<TaskingInfoWithTaskingRequestDto>;
      expect(gotData.data.length).toEqual(2);
    });

    it(`${baseUrl}/search (GET): No data hits for other organizations`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/search`)
        .set('Content-Type', 'application/json')
        .query({
          'filter.name': `$eq:fixture-tasking_info-3`,
          sortBy: 'createdAt:ASC',
        })
        .send();
      expect(res.status).toEqual(200);

      const gotData = res.body as Paginated<TaskingInfo>;
      expect(gotData.data.length).toEqual(0);
    });

    it(`${baseUrl} (DELETE): Successful soft deletion`, async () => {
      const target = createdTaskingInfos[0];
      const res: request.Response = await request
        .default(httpServer)
        .delete(`${baseUrl}/${target.id}`)
        .set('Content-Type', 'application/json');

      expect(res.status).toEqual(200);
      const gotData = res.body as TaskingInfo;
      expect(gotData.deletedAt).not.toBeNull();

      const check1 = await dataSource
        .getRepository(TaskingInfo)
        .findOne({ where: { id: target.id } });
      expect(check1).toBeNull();
      const check2 = await dataSource
        .getRepository(TaskingInfo)
        .findOne({ where: { id: target.id }, withDeleted: true });
      expect(check2).not.toBeNull();
      expect(check2.deletedAt).not.toBeNull();
    });

    it(`${baseUrl} (DELETE): can not be logically deleted, when different organizationId`, async () => {
      const target = fixtureTaskingInfos.filter(
        (x) => x.organizationId == TEST_ANOTHER_ORGANIZATION_ID,
      )[0];
      const res: request.Response = await request
        .default(httpServer)
        .delete(`${baseUrl}/${target.id}`)
        .set('Content-Type', 'application/json');

      expect(res.status).toEqual(404);

      const found = await dataSource.manager.findOne(TaskingInfo, {
        where: { id: target.id },
      });
      expect(found).toBeTruthy();
      expect(found.deletedAt).toBeNull();
    });
  });

  describe('irregular', () => {
    const associatedTaskingRequest: AssociatedTaskingRequest =
      new AssociatedTaskingRequest();
    let storedCitadelRelatedData: CitadelRelatedDataForTest[] =
      new Array<CitadelRelatedDataForTest>();
    const createdTaskingInfos = new Array<TaskingInfo>();

    afterEach(async () => {
      mockMissionPortalService.registrationAvailabilityCheck = jest.fn();
      mockMissionPortalService.register = jest.fn();
      mockMissionPortalService.updateStatusByOrderId = jest.fn();
      mockMissionPortalService.updateAltitude = jest.fn();
      mockCitadelGrpcService.checkQuota = jest.fn();
      mockCitadelGrpcService.reserveTask = jest.fn();
      mockCitadelGrpcService.emitTaskResult = jest.fn();
      mockSlackNotificationService.send = jest.fn();
      storedCitadelRelatedData = [];
      await dataSource
        .createQueryBuilder()
        .relation(TaskingRequest, 'aois')
        .of(associatedTaskingRequest.taskingRequest)
        .remove(associatedTaskingRequest.aois.map((x) => x.id));
    });

    afterAll(async () => {
      if (createdTaskingInfos.length > 0) {
        await dataSource.manager
          .getRepository(TaskingInfo)
          .delete(createdTaskingInfos.map((x) => x.id));
      }
    });

    it(`${baseUrl} (POST): failed registration (rollback due to failed registrationAvailabilityCheck )`, async () => {
      const selectedCandidate = await prepareTest();

      const body: TaskingInfoCreateDto = plainToInstance(TaskingInfoCreateDto, {
        name: 'tasking-info-rollback-001',
        taskingRequestId: associatedTaskingRequest.taskingRequest.id,
        selectedCandidates: [selectedCandidate],
        contractId: getTestContractIdForFixture(),
        organizationId: associatedTaskingRequest.taskingRequest.organizationId,
      });
      const res: request.Response = await request
        .default(httpServer)
        .post(baseUrl)
        .set('Content-Type', 'application/json')
        .send(body);
      expect(res.status).toEqual(500);

      const found = await dataSource
        .getRepository(TaskingInfo)
        .findOne({ where: { name: body.name } });
      expect(found).toBeNull();

      expect(
        mockMissionPortalService.registrationAvailabilityCheck,
      ).toHaveBeenNthCalledWith(1, [
        plainToInstance(ScsRegistrationAvailabilityCheckRequestDto, {
          searchIndex: 1,
          satelliteInfo: selectedCandidate.satelliteInfo,
          observationTiming: selectedCandidate.observationTiming,
        } as ScsRegistrationAvailabilityCheckRequestDto),
      ]);

      async function prepareTest() {
        associatedTaskingRequest.taskingRequest = fixtureTaskingRequests.find(
          (x) =>
            x.organizationId == TEST_ORGANIZATION_ID &&
            x.name.startsWith('fixture-tasking_request-2'),
        );
        associatedTaskingRequest.aois = [
          fixtureAois.find(
            (x) =>
              x.organizationId == TEST_ORGANIZATION_ID &&
              x.name.startsWith('fixture-aoi-common'),
          ),
        ];
        // Link aoi to tasking request
        await linkAoisToTaskingRequest(dataSource, associatedTaskingRequest);
        const selectedCandidate = plainToInstance(
          ScsCandidateForViewDto,
          structuredClone(displayCandidates[0]),
        );
        // adjust observationTiming
        selectedCandidate.observationTiming.obsStartTimeUTC = add(
          getUrgentDeadlineTime(
            new Date(),
            getDetermineDeadlineBaseDate(new Date()),
          ),
          { days: 1 },
        );
        selectedCandidate.observationTiming.obsEndTimeUTC = add(
          selectedCandidate.observationTiming.obsStartTimeUTC,
          { seconds: 10 },
        );
        selectedCandidate.taskingType = TaskingType.Regular;

        // prepare mock of MissionPortalService.registrationAvailabilityCheck with error
        mockMissionPortalService.registrationAvailabilityCheck = jest.fn(() =>
          Promise.reject(new AxiosError('test')),
        );
        return selectedCandidate;
      }
    });

    it(`${baseUrl} (POST): failed registration (rollback due to failed register)`, async () => {
      const selectedCandidate = await prepareTest();

      const body: TaskingInfoCreateDto = plainToInstance(TaskingInfoCreateDto, {
        name: 'tasking-info-rollback-002',
        taskingRequestId: associatedTaskingRequest.taskingRequest.id,
        selectedCandidates: [selectedCandidate],
        contractId: getTestContractIdForFixture(),
        organizationId: associatedTaskingRequest.taskingRequest.organizationId,
      });
      const res: request.Response = await request
        .default(httpServer)
        .post(baseUrl)
        .set('Content-Type', 'application/json')
        .send(body);
      expect(res.status).toEqual(500);

      const found = await dataSource
        .getRepository(TaskingInfo)
        .findOne({ where: { name: body.name } });
      expect(found).toBeNull();

      expect(
        mockMissionPortalService.registrationAvailabilityCheck,
      ).toHaveBeenNthCalledWith(1, [
        plainToInstance(ScsRegistrationAvailabilityCheckRequestDto, {
          searchIndex: 1,
          satelliteInfo: selectedCandidate.satelliteInfo,
          observationTiming: selectedCandidate.observationTiming,
        } as ScsRegistrationAvailabilityCheckRequestDto),
      ]);
      expect(mockCitadelGrpcService.checkQuota).toHaveBeenNthCalledWith(
        1,
        body.contractId,
        [
          {
            id: storedCitadelRelatedData[0].taskingId,
            dataSourceType: DataSourceType.NEW,
            imagingMode:
              selectedCandidate.observationTiming.orbitParams.imagingMode,
            taskingType: selectedCandidate.taskingType,
            scene: 1,
            productDetails: defaultProductDetails,
            deliveryTimeKind: DeliveryTimeKind.RUSH,
            taskPriorityKind: TaskingPriorityKind.HIGH,
          } as CheckQuotaDto,
        ],
      );

      expect(mockMissionPortalService.register).toHaveBeenNthCalledWith(1, [
        {
          title: body.name,
          email: mockMissionPortalService.getEmailForRegistraion(),
          customerOrgID:
            associatedTaskingRequest.taskingRequest.organizationId.toString(),
          basePriority: associatedTaskingRequest.taskingRequest.priority,
          centerPosition:
            selectedCandidate.observationArea.obsCenterPosition.getScsPointDto(),
          imagingMode:
            selectedCandidate.observationTiming.orbitParams.imagingMode,
          polarization: associatedTaskingRequest.taskingRequest.polarization,
          startOBCTime: selectedCandidate.observationTiming.obsStartTime,
          endOBCTime: selectedCandidate.observationTiming.obsEndTime,
          pathDirection:
            selectedCandidate.observationTiming.orbitParams.pathDirection,
          sightDirection:
            selectedCandidate.observationTiming.orbitParams.sightDirection,
          offnadirAngle:
            selectedCandidate.observationTiming.orbitParams.offNadir,
          satId: selectedCandidate.satelliteInfo.satId,
        } as ScsOrderRequestDto,
      ]);

      expect(mockSlackNotificationService.send).toHaveBeenCalledTimes(0);

      // in rollback
      expect(mockCitadelGrpcService.emitTaskResult).toHaveBeenNthCalledWith(
        1,
        storedCitadelRelatedData.map((x) => {
          return plainToInstance(EmitRequestDto, {
            registrationId: x.taskingId,
            status: fromTaskingOperationStatusToPaymentTaskStatus(
              UnrecordedTaskingStatus.RegisterFailed,
            ),
          } as EmitRequestDto);
        }),
        await generateNotificationContents(
          UnrecordedTaskingStatus.RegisterFailed,
        ),
      );

      async function prepareTest() {
        associatedTaskingRequest.taskingRequest = fixtureTaskingRequests.find(
          (x) =>
            x.organizationId == TEST_ORGANIZATION_ID &&
            x.name.startsWith('fixture-tasking_request'),
        );
        associatedTaskingRequest.aois = [
          fixtureAois.find(
            (x) =>
              x.organizationId == TEST_ORGANIZATION_ID &&
              x.name.startsWith('fixture-aoi-common'),
          ),
        ];
        // Link aoi to tasking request
        await linkAoisToTaskingRequest(dataSource, associatedTaskingRequest);
        const selectedCandidate = plainToInstance(
          ScsCandidateForViewDto,
          structuredClone(displayCandidates[0]),
        );
        // adjust observationTiming
        selectedCandidate.observationTiming.obsStartTimeUTC = add(
          getUrgentDeadlineTime(
            new Date(),
            getDetermineDeadlineBaseDate(new Date()),
          ),
          { days: 1 },
        );
        selectedCandidate.observationTiming.obsEndTimeUTC = add(
          selectedCandidate.observationTiming.obsStartTimeUTC,
          { seconds: 10 },
        );
        selectedCandidate.taskingType = TaskingType.Regular;

        // prepare mock of MissionPortalService.registrationAvailabilityCheck
        mockMissionPortalService.registrationAvailabilityCheck = jest.fn(() => {
          return Promise.resolve(true);
        });
        // prepare mock of MissionPortalService.register with error
        mockMissionPortalService.register = jest.fn(() => {
          return new Promise(() => {
            throw new AxiosError('error');
          });
        });
        // prepare mock of Citadel
        mockCitadelGrpcService.checkQuota = jest.fn(
          (contractId: number, checkList: CheckQuotaDto[]) => {
            return Promise.resolve(
              checkList.map((x, idx) => {
                const tmp = plainToInstance(CitadelRelatedDataForTest, {
                  taskingId: x.id,
                  paymentId: 999000 + idx,
                } as CitadelRelatedDataForTest);
                storedCitadelRelatedData.push(tmp);
                return plainToInstance(PaymentReplyDto, {
                  registrationId: tmp.paymentId,
                  taskId: tmp.taskingId,
                  status: PaymentTaskStatus.TEMPORAL,
                  consumptionCredit: 0,
                } as PaymentReplyDto);
              }),
            );
          },
        );
        mockCitadelGrpcService.emitTaskResult = jest.fn(
          (
            emitRequests: EmitRequestDto[],
            notificationContents: NotificationContents,
          ) => {
            return Promise.resolve(
              emitRequests.map((x) => {
                return plainToInstance(PaymentReplyDto, {
                  registrationId: storedCitadelRelatedData.find(
                    (y) => y.taskingId === x.registrationId,
                  ).paymentId,
                  taskId: x.registrationId,
                  status: PaymentTaskStatus.EXCEPTIONAL,
                  consumptionCredit: 0,
                } as PaymentReplyDto);
              }),
            );
          },
        );
        return selectedCandidate;
      }
    });

    it(`${baseUrl} (POST): failed registration (rollback due to failed updateStatusByOrderId)`, async () => {
      const selectedCandidate = await prepareTest();
      const orderId = '848b8d62-13dd-4815-a088-464d367e3c7b';
      const orderCode = '202302-00011';

      const body: TaskingInfoCreateDto = plainToInstance(TaskingInfoCreateDto, {
        name: 'tasking-info-rollback-003',
        contractId: getTestContractIdForFixture(),
        taskingRequestId: associatedTaskingRequest.taskingRequest.id,
        selectedCandidates: [selectedCandidate],
        organizationId: associatedTaskingRequest.taskingRequest.organizationId,
      });
      const res: request.Response = await request
        .default(httpServer)
        .post(baseUrl)
        .set('Content-Type', 'application/json')
        .send(body);
      expect(res.status).toEqual(500);

      const found = await dataSource
        .getRepository(TaskingInfo)
        .findOne({ where: { name: body.name } });
      expect(found).toBeNull();

      expect(
        mockMissionPortalService.registrationAvailabilityCheck,
      ).toHaveBeenNthCalledWith(1, [
        plainToInstance(ScsRegistrationAvailabilityCheckRequestDto, {
          searchIndex: 1,
          satelliteInfo: selectedCandidate.satelliteInfo,
          observationTiming: selectedCandidate.observationTiming,
        } as ScsRegistrationAvailabilityCheckRequestDto),
      ]);

      expect(mockMissionPortalService.register).toHaveBeenNthCalledWith(1, [
        {
          title: body.name,
          email: mockMissionPortalService.getEmailForRegistraion(),
          customerOrgID:
            associatedTaskingRequest.taskingRequest.organizationId.toString(),
          basePriority: associatedTaskingRequest.taskingRequest.priority,
          centerPosition:
            selectedCandidate.observationArea.obsCenterPosition.getScsPointDto(),
          imagingMode:
            selectedCandidate.observationTiming.orbitParams.imagingMode,
          polarization: associatedTaskingRequest.taskingRequest.polarization,
          startOBCTime: selectedCandidate.observationTiming.obsStartTime,
          endOBCTime: selectedCandidate.observationTiming.obsEndTime,
          pathDirection:
            selectedCandidate.observationTiming.orbitParams.pathDirection,
          sightDirection:
            selectedCandidate.observationTiming.orbitParams.sightDirection,
          offnadirAngle:
            selectedCandidate.observationTiming.orbitParams.offNadir,
          satId: selectedCandidate.satelliteInfo.satId,
        } as ScsOrderRequestDto,
      ]);
      expect(
        mockMissionPortalService.updateStatusByOrderId,
      ).toHaveBeenNthCalledWith(1, [
        {
          orderId,
          orderStatus: toScsOrderStatus(TaskingStatus.Ordered),
        } as ScsUpdateStatusRequestDto,
      ]);

      expect(
        mockMissionPortalService.updateStatusByOrderId,
      ).toHaveBeenNthCalledWith(2, [
        {
          orderId,
          orderStatus: toScsOrderStatus(TaskingStatus.Canceled),
        } as ScsUpdateStatusRequestDto,
      ]);

      expect(mockCitadelGrpcService.checkQuota).toHaveBeenNthCalledWith(
        1,
        body.contractId,
        [
          {
            id: storedCitadelRelatedData[0].taskingId,
            dataSourceType: DataSourceType.NEW,
            imagingMode:
              selectedCandidate.observationTiming.orbitParams.imagingMode,
            taskingType: selectedCandidate.taskingType,
            scene: 1,
            productDetails: defaultProductDetails,
            deliveryTimeKind: DeliveryTimeKind.RUSH,
            taskPriorityKind: TaskingPriorityKind.HIGH,
          } as CheckQuotaDto,
        ],
      );

      expect(mockCitadelGrpcService.reserveTask).toHaveBeenCalledTimes(0);

      expect(mockCitadelGrpcService.emitTaskResult).toHaveBeenNthCalledWith(
        1,
        storedCitadelRelatedData.map((x) => {
          return plainToInstance(EmitRequestDto, {
            registrationId: x.taskingId,
            status: fromTaskingOperationStatusToPaymentTaskStatus(
              UnrecordedTaskingStatus.RegisterFailed,
            ),
          } as EmitRequestDto);
        }),
        await generateNotificationContents(
          UnrecordedTaskingStatus.RegisterFailed,
        ),
      );

      expect(mockSlackNotificationService.send).toHaveBeenCalledTimes(0);

      async function prepareTest() {
        associatedTaskingRequest.taskingRequest = fixtureTaskingRequests.find(
          (x) =>
            x.organizationId == TEST_ORGANIZATION_ID &&
            x.name.startsWith('fixture-tasking_request'),
        );
        associatedTaskingRequest.aois = [
          fixtureAois.find(
            (x) =>
              x.organizationId == TEST_ORGANIZATION_ID &&
              x.name.startsWith('fixture-aoi-common'),
          ),
        ];
        // Link aoi to tasking request
        await linkAoisToTaskingRequest(dataSource, associatedTaskingRequest);
        const selectedCandidate = plainToInstance(
          ScsCandidateForViewDto,
          structuredClone(displayCandidates[0]),
        );
        // adjust observationTiming
        selectedCandidate.observationTiming.obsStartTimeUTC = add(
          getUrgentDeadlineTime(
            new Date(),
            getDetermineDeadlineBaseDate(new Date()),
          ),
          { days: 1 },
        );
        selectedCandidate.observationTiming.obsEndTimeUTC = add(
          selectedCandidate.observationTiming.obsStartTimeUTC,
          { seconds: 10 },
        );
        selectedCandidate.taskingType = TaskingType.Regular;

        // prepare mock of MissionPortalService.registrationAvailabilityCheck
        mockMissionPortalService.registrationAvailabilityCheck = jest.fn(() => {
          return Promise.resolve(true);
        });

        // prepare mock of MissionPortalService.register
        mockMissionPortalService.register = jest.fn(() => {
          return Promise.resolve([
            mockDataScsOrderResponseDto(
              orderId,
              orderCode,
              ScsOrderStatus.PreRegistration,
              plainToInstance(
                TaskingRequestInputDataForTest,
                associatedTaskingRequest.taskingRequest,
              ),
              selectedCandidate,
            ),
          ] as ScsOrderResponseDto[]);
        });

        // prepare mock of MissionPortalService.updateStatusByOrderId with error
        mockMissionPortalService.updateStatusByOrderId = jest
          .fn()
          .mockImplementationOnce(() => {
            return new Promise(() => {
              throw new AxiosError('error');
            });
          })
          .mockImplementationOnce(() => {
            return Promise.resolve({
              result: true,
              errorMessage: null,
            } as ScsCommonResponseDto);
          });
        // prepare mock of Citadel
        mockCitadelGrpcService.checkQuota = jest.fn(
          (contractId: number, checkList: CheckQuotaDto[]) => {
            return Promise.resolve(
              checkList.map((x, idx) => {
                const tmp = plainToInstance(CitadelRelatedDataForTest, {
                  taskingId: x.id,
                  paymentId: 999000 + idx,
                } as CitadelRelatedDataForTest);
                storedCitadelRelatedData.push(tmp);
                return plainToInstance(PaymentReplyDto, {
                  registrationId: tmp.paymentId,
                  taskId: tmp.taskingId,
                  status: PaymentTaskStatus.TEMPORAL,
                  consumptionCredit: 0,
                } as PaymentReplyDto);
              }),
            );
          },
        );
        mockCitadelGrpcService.reserveTask = jest.fn(
          (registrationIds: string[]) => {
            const tmp = plainToInstance(PaymentsDto, {
              totalConsumptionCredit: 0,
              remainingCredit: 0,
              results: registrationIds.map((x) => {
                return plainToInstance(PaymentReplyDto, {
                  registrationId: storedCitadelRelatedData.find(
                    (y) => y.taskingId == x,
                  ).paymentId,
                  taskId: x,
                  status: PaymentTaskStatus.RESERVED,
                  consumptionCredit: 0,
                } as PaymentReplyDto);
              }),
              verifyResults: registrationIds.map((x) => {
                return plainToInstance(VerifyItemDto, {
                  taskId: x,
                  consumptionCredit: 0,
                  dataSourceType: DataSourceType.ARCHIVE,
                  imagingMode: ImagingMode.Stripmap,
                  numberOfLicense: 1,
                  options: [],
                } as VerifyItemDto);
              }),
            } as PaymentsDto);

            return Promise.resolve(tmp);
          },
        );
        mockCitadelGrpcService.emitTaskResult = jest
          .fn()
          .mockImplementationOnce(
            (
              emitRequests: EmitRequestDto[],
              notificationContents: NotificationContents,
            ) => {
              return Promise.resolve(
                emitRequests.map((x) => {
                  return plainToInstance(PaymentReplyDto, {
                    registrationId: storedCitadelRelatedData.find(
                      (y) => y.taskingId === x.registrationId,
                    ).paymentId,
                    taskId: x.registrationId,
                    status: x.status,
                    consumptionCredit: 0,
                  } as PaymentReplyDto);
                }),
              );
            },
          );
        return selectedCandidate;
      }
    });

    it(`${baseUrl} (POST): failed registration (rollback due to failed updateStatusByOrderId ) 1`, async () => {
      const { selectedCandidate, mockSetStatusToPreOrder } =
        await prepareTest();
      const orderId = '5c15ffce-c28e-4527-97bf-ed1337713f6c';
      const orderCode = '202302-00012';

      const body: TaskingInfoCreateDto = plainToInstance(TaskingInfoCreateDto, {
        name: 'tasking-info-rollback-004',
        taskingRequestId: associatedTaskingRequest.taskingRequest.id,
        selectedCandidates: [selectedCandidate],
        contractId: getTestContractIdForFixture(),
        organizationId: associatedTaskingRequest.taskingRequest.organizationId,
      });
      const res: request.Response = await request
        .default(httpServer)
        .post(baseUrl)
        .set('Content-Type', 'application/json')
        .send(body);
      expect(res.status).toEqual(500);

      const found = await dataSource
        .getRepository(TaskingInfo)
        .findOne({ where: { name: body.name } });
      createdTaskingInfos.push(found);

      // It seems that it will be easier to investigate the cause if the taskingInfo is not deleted, so the current situation is like this.
      expect(found).not.toBeNull();
      expect(found.status).toEqual(TaskingStatus.PreCreditCheck);
      expect(mockSetStatusToPreOrder).toBeCalledTimes(1);
      expect(
        mockMissionPortalService.registrationAvailabilityCheck,
      ).toHaveBeenNthCalledWith(1, [
        plainToInstance(ScsRegistrationAvailabilityCheckRequestDto, {
          searchIndex: 1,
          satelliteInfo: selectedCandidate.satelliteInfo,
          observationTiming: selectedCandidate.observationTiming,
        } as ScsRegistrationAvailabilityCheckRequestDto),
      ]);
      expect(mockMissionPortalService.register).toHaveBeenNthCalledWith(1, [
        {
          title: body.name,
          email: mockMissionPortalService.getEmailForRegistraion(),
          customerOrgID:
            associatedTaskingRequest.taskingRequest.organizationId.toString(),
          basePriority: associatedTaskingRequest.taskingRequest.priority,
          centerPosition:
            selectedCandidate.observationArea.obsCenterPosition.getScsPointDto(),
          imagingMode:
            selectedCandidate.observationTiming.orbitParams.imagingMode,
          polarization: associatedTaskingRequest.taskingRequest.polarization,
          startOBCTime: selectedCandidate.observationTiming.obsStartTime,
          endOBCTime: selectedCandidate.observationTiming.obsEndTime,
          pathDirection:
            selectedCandidate.observationTiming.orbitParams.pathDirection,
          sightDirection:
            selectedCandidate.observationTiming.orbitParams.sightDirection,
          offnadirAngle:
            selectedCandidate.observationTiming.orbitParams.offNadir,
          satId: selectedCandidate.satelliteInfo.satId,
        } as ScsOrderRequestDto,
      ]);
      expect(
        mockMissionPortalService.updateStatusByOrderId,
      ).toHaveBeenNthCalledWith(1, [
        {
          orderId,
          orderStatus: toScsOrderStatus(TaskingStatus.Canceled),
        } as ScsUpdateStatusRequestDto,
      ]);

      expect(mockCitadelGrpcService.checkQuota).toHaveBeenNthCalledWith(
        1,
        body.contractId,
        [
          {
            id: storedCitadelRelatedData[0].taskingId,
            dataSourceType: DataSourceType.NEW,
            imagingMode:
              selectedCandidate.observationTiming.orbitParams.imagingMode,
            taskingType: TaskingType.Regular,
            scene: 1,
            productDetails: found.productDetails,
            deliveryTimeKind: DeliveryTimeKind.RUSH,
            taskPriorityKind: TaskingPriorityKind.HIGH,
          } as CheckQuotaDto,
        ],
      );
      expect(mockCitadelGrpcService.emitTaskResult).toHaveBeenNthCalledWith(
        1,
        storedCitadelRelatedData.map((x) => {
          return plainToInstance(EmitRequestDto, {
            registrationId: x.taskingId,
            status: fromTaskingOperationStatusToPaymentTaskStatus(
              UnrecordedTaskingStatus.RegisterFailed,
            ), // FIXME
          } as EmitRequestDto);
        }),
        await generateNotificationContents(
          UnrecordedTaskingStatus.RegisterFailed,
        ),
      );

      expect(mockSlackNotificationService.send).toHaveBeenCalledTimes(0);

      mockSetStatusToPreOrder.mockRestore();

      async function prepareTest() {
        associatedTaskingRequest.taskingRequest = fixtureTaskingRequests.find(
          (x) =>
            x.organizationId == TEST_ORGANIZATION_ID &&
            x.name.startsWith('fixture-tasking_request'),
        );
        associatedTaskingRequest.aois = [
          fixtureAois.find(
            (x) =>
              x.organizationId == TEST_ORGANIZATION_ID &&
              x.name.startsWith('fixture-aoi-common'),
          ),
        ];
        // Link aoi to tasking request
        await linkAoisToTaskingRequest(dataSource, associatedTaskingRequest);
        const selectedCandidate = plainToInstance(
          ScsCandidateForViewDto,
          structuredClone(displayCandidates[0]),
        );
        // adjust observationTiming
        selectedCandidate.observationTiming.obsStartTimeUTC = add(
          getUrgentDeadlineTime(
            new Date(),
            getDetermineDeadlineBaseDate(new Date()),
          ),
          { days: 1 },
        );
        selectedCandidate.observationTiming.obsEndTimeUTC = add(
          selectedCandidate.observationTiming.obsStartTimeUTC,
          { seconds: 10 },
        );
        selectedCandidate.taskingType = TaskingType.Regular;

        // prepare mock of MissionPortalService.registrationAvailabilityCheck
        mockMissionPortalService.registrationAvailabilityCheck = jest.fn(() => {
          return Promise.resolve(true);
        });
        // prepare mock of TaskingInfoUsecaseService.setStatusToPreOrder with error
        const mockSetStatusToPreOrder = jest
          .spyOn(
            TaskingInfoUsecaseService.prototype as any,
            'setStatusToPreOrder',
          )
          .mockImplementationOnce(() => {
            return new Promise(() => {
              throw new Error('may be db error');
            });
          });

        // prepare mock of MissionPortalService.register
        mockMissionPortalService.register = jest.fn(() => {
          return Promise.resolve([
            mockDataScsOrderResponseDto(
              orderId,
              orderCode,
              ScsOrderStatus.PreRegistration,
              plainToInstance(
                TaskingRequestInputDataForTest,
                associatedTaskingRequest.taskingRequest,
              ),
              selectedCandidate,
            ),
          ] as ScsOrderResponseDto[]);
        });

        // prepare mock of MissionPortalService.updateStatusByOrderId
        mockMissionPortalService.updateStatusByOrderId = jest.fn(() => {
          return new Promise(() => {
            throw new AxiosError('error');
          });
        });

        // prepare mock of Citadel
        mockCitadelGrpcService.checkQuota = jest.fn(
          (contractId: number, checkList: CheckQuotaDto[]) => {
            return Promise.resolve(
              checkList.map((x, idx) => {
                const tmp = plainToInstance(CitadelRelatedDataForTest, {
                  taskingId: x.id,
                  paymentId: 999000 + idx,
                } as CitadelRelatedDataForTest);
                storedCitadelRelatedData.push(tmp);
                return plainToInstance(PaymentReplyDto, {
                  registrationId: tmp.paymentId,
                  taskId: tmp.taskingId,
                  status: PaymentTaskStatus.TEMPORAL,
                  consumptionCredit: 0,
                } as PaymentReplyDto);
              }),
            );
          },
        );
        mockCitadelGrpcService.emitTaskResult = jest
          .fn()
          .mockImplementationOnce(
            (
              emitRequests: EmitRequestDto[],
              notificationContents: NotificationContents,
            ) => {
              return Promise.resolve(
                emitRequests.map((x) => {
                  return plainToInstance(PaymentReplyDto, {
                    registrationId: storedCitadelRelatedData.find(
                      (y) => y.taskingId === x.registrationId,
                    ).paymentId,
                    taskId: x.registrationId,
                    status: x.status,
                    consumptionCredit: 0,
                  } as PaymentReplyDto);
                }),
              );
            },
          );
        return { selectedCandidate, mockSetStatusToPreOrder };
      }
    });

    it(`${baseUrl} (POST): failed registration (rollback due to failed updateStatusByOrderId in rollback function) 2`, async () => {
      const { selectedCandidate, updateStatusByIdWithEntityManager } =
        await prepareTest();
      const orderId = '90f642de-226a-4132-948e-b2df284dd860';
      const orderCode = '202302-00013';

      const body: TaskingInfoCreateDto = plainToInstance(TaskingInfoCreateDto, {
        name: 'tasking-info-rollback-005',
        taskingRequestId: associatedTaskingRequest.taskingRequest.id,
        selectedCandidates: [selectedCandidate],
        contractId: getTestContractIdForFixture(),
        organizationId: associatedTaskingRequest.taskingRequest.organizationId,
      });
      const res: request.Response = await request
        .default(httpServer)
        .post(baseUrl)
        .set('Content-Type', 'application/json')
        .send(body);
      expect(res.status).toEqual(500);

      const found = await dataSource
        .getRepository(TaskingInfo)
        .findOne({ where: { name: body.name } });
      createdTaskingInfos.push(found);

      // It seems that it will be easier to investigate the cause if the taskingInfo is not deleted, so the current situation is like this.
      expect(found).not.toBeNull();
      expect(found.status).toEqual(TaskingStatus.PreCreditCheck);
      expect(found.scsOrderId).toBeNull(); // due to rollback
      expect(found.paymentId).toBeNull(); // due to rollback

      expect(
        mockMissionPortalService.registrationAvailabilityCheck,
      ).toHaveBeenNthCalledWith(1, [
        plainToInstance(ScsRegistrationAvailabilityCheckRequestDto, {
          searchIndex: 1,
          satelliteInfo: selectedCandidate.satelliteInfo,
          observationTiming: selectedCandidate.observationTiming,
        } as ScsRegistrationAvailabilityCheckRequestDto),
      ]);

      expect(mockMissionPortalService.register).toHaveBeenNthCalledWith(1, [
        {
          title: body.name,
          email: mockMissionPortalService.getEmailForRegistraion(),
          customerOrgID:
            associatedTaskingRequest.taskingRequest.organizationId.toString(),
          basePriority: associatedTaskingRequest.taskingRequest.priority,
          centerPosition:
            selectedCandidate.observationArea.obsCenterPosition.getScsPointDto(),
          imagingMode:
            selectedCandidate.observationTiming.orbitParams.imagingMode,
          polarization: associatedTaskingRequest.taskingRequest.polarization,
          startOBCTime: selectedCandidate.observationTiming.obsStartTime,
          endOBCTime: selectedCandidate.observationTiming.obsEndTime,
          pathDirection:
            selectedCandidate.observationTiming.orbitParams.pathDirection,
          sightDirection:
            selectedCandidate.observationTiming.orbitParams.sightDirection,
          offnadirAngle:
            selectedCandidate.observationTiming.orbitParams.offNadir,
          satId: selectedCandidate.satelliteInfo.satId,
        } as ScsOrderRequestDto,
      ]);
      expect(
        mockMissionPortalService.updateStatusByOrderId,
      ).toHaveBeenNthCalledWith(1, [
        {
          orderId,
          orderStatus: toScsOrderStatus(TaskingStatus.Ordered),
        } as ScsUpdateStatusRequestDto,
      ]);
      expect(
        mockMissionPortalService.updateStatusByOrderId,
      ).toHaveBeenNthCalledWith(2, [
        {
          orderId,
          orderStatus: toScsOrderStatus(TaskingStatus.Canceled),
        } as ScsUpdateStatusRequestDto,
      ]);

      expect(mockCitadelGrpcService.checkQuota).toHaveBeenNthCalledWith(
        1,
        body.contractId,
        [
          {
            id: storedCitadelRelatedData[0].taskingId,
            dataSourceType: DataSourceType.NEW,
            imagingMode:
              selectedCandidate.observationTiming.orbitParams.imagingMode,
            taskingType: TaskingType.Regular,
            scene: 1,
            productDetails: defaultProductDetails,
            deliveryTimeKind: DeliveryTimeKind.RUSH,
            taskPriorityKind: TaskingPriorityKind.HIGH,
          } as CheckQuotaDto,
        ],
      );

      expect(mockCitadelGrpcService.reserveTask).toHaveBeenCalledTimes(0);

      expect(mockCitadelGrpcService.emitTaskResult).toHaveBeenNthCalledWith(
        1,
        storedCitadelRelatedData.map((x) => {
          return plainToInstance(EmitRequestDto, {
            registrationId: x.taskingId,
            status: fromTaskingOperationStatusToPaymentTaskStatus(
              UnrecordedTaskingStatus.RegisterFailed,
            ), // FIXME
          } as EmitRequestDto);
        }),
        await generateNotificationContents(
          UnrecordedTaskingStatus.RegisterFailed,
        ),
      );

      expect(updateStatusByIdWithEntityManager).toBeCalledTimes(1);

      expect(mockSlackNotificationService.send).toHaveBeenCalledTimes(0);

      updateStatusByIdWithEntityManager.mockRestore();

      async function prepareTest() {
        associatedTaskingRequest.taskingRequest = fixtureTaskingRequests.find(
          (x) =>
            x.organizationId == TEST_ORGANIZATION_ID &&
            x.name.startsWith('fixture-tasking_request'),
        );
        associatedTaskingRequest.aois = [
          fixtureAois.find(
            (x) =>
              x.organizationId == TEST_ORGANIZATION_ID &&
              x.name.startsWith('fixture-aoi-common'),
          ),
        ];
        // Link aoi to tasking request
        await linkAoisToTaskingRequest(dataSource, associatedTaskingRequest);
        const selectedCandidate = plainToInstance(
          ScsCandidateForViewDto,
          structuredClone(displayCandidates[0]),
        );
        // adjust observationTiming
        selectedCandidate.observationTiming.obsStartTimeUTC = add(
          getUrgentDeadlineTime(
            new Date(),
            getDetermineDeadlineBaseDate(new Date()),
          ),
          { days: 1 },
        );
        selectedCandidate.observationTiming.obsEndTimeUTC = add(
          selectedCandidate.observationTiming.obsStartTimeUTC,
          { seconds: 10 },
        );
        selectedCandidate.taskingType = TaskingType.Urgent;
        selectedCandidate.taskingType = TaskingType.Regular;

        // prepare mock of MissionPortalService.registrationAvailabilityCheck
        mockMissionPortalService.registrationAvailabilityCheck = jest.fn(() => {
          return Promise.resolve(true);
        });
        // prepare mock of MissionPortalService.register
        mockMissionPortalService.register = jest.fn(() => {
          return Promise.resolve([
            mockDataScsOrderResponseDto(
              orderId,
              orderCode,
              ScsOrderStatus.PreRegistration,
              plainToInstance(
                TaskingRequestInputDataForTest,
                associatedTaskingRequest.taskingRequest,
              ),
              selectedCandidate,
            ),
          ] as ScsOrderResponseDto[]);
        });
        // prepare mock of MissionPortalService.updateStatusByOrderId with error
        mockMissionPortalService.updateStatusByOrderId = jest
          .fn()
          .mockImplementationOnce(() => {
            return Promise.resolve({
              result: true,
              errorMessage: null,
            } as ScsCommonResponseDto);
          })
          .mockImplementationOnce(() => {
            return new Promise(() => {
              throw new AxiosError('error');
            });
          });
        // prepare mock of TaskingInfoUsecaseService.updateStatusByIdWithEntityManager (in updateStatusById) with error
        const updateStatusByIdWithEntityManager = jest
          .spyOn(
            TaskingInfoUsecaseService.prototype as any,
            'updateStatusByIdWithEntityManager',
          )
          .mockImplementationOnce(() => {
            return new Promise(() => {
              throw new Error('may be db error');
            });
          });

        // prepare mock of Citadel
        mockCitadelGrpcService.checkQuota = jest.fn(
          (contractId: number, checkList: CheckQuotaDto[]) => {
            return Promise.resolve(
              checkList.map((x, idx) => {
                const tmp = plainToInstance(CitadelRelatedDataForTest, {
                  taskingId: x.id,
                  paymentId: 999000 + idx,
                } as CitadelRelatedDataForTest);
                storedCitadelRelatedData.push(tmp);
                return plainToInstance(PaymentReplyDto, {
                  registrationId: tmp.paymentId,
                  taskId: tmp.taskingId,
                  status: PaymentTaskStatus.TEMPORAL,
                  consumptionCredit: 0,
                } as PaymentReplyDto);
              }),
            );
          },
        );
        mockCitadelGrpcService.reserveTask = jest.fn(
          (registrationIds: string[]) => {
            const tmp = plainToInstance(PaymentsDto, {
              totalConsumptionCredit: 0,
              remainingCredit: 0,
              results: registrationIds.map((x) => {
                return plainToInstance(PaymentReplyDto, {
                  registrationId: storedCitadelRelatedData.find(
                    (y) => y.taskingId == x,
                  ).paymentId,
                  taskId: x,
                  status: PaymentTaskStatus.RESERVED,
                  consumptionCredit: 0,
                } as PaymentReplyDto);
              }),
              verifyResults: registrationIds.map((x) => {
                return plainToInstance(VerifyItemDto, {
                  taskId: x,
                  consumptionCredit: 0,
                  dataSourceType: DataSourceType.ARCHIVE,
                  imagingMode: ImagingMode.Stripmap,
                  numberOfLicense: 1,
                  options: [],
                } as VerifyItemDto);
              }),
            } as PaymentsDto);

            return Promise.resolve(tmp);
          },
        );

        mockCitadelGrpcService.emitTaskResult = jest
          .fn()
          .mockImplementationOnce(
            (
              emitRequests: EmitRequestDto[],
              notificationContents: NotificationContents,
            ) => {
              return Promise.resolve(
                emitRequests.map((x) => {
                  return plainToInstance(PaymentReplyDto, {
                    registrationId: storedCitadelRelatedData.find(
                      (y) => y.taskingId === x.registrationId,
                    ).paymentId,
                    taskId: x.registrationId,
                    status: x.status,
                    consumptionCredit: 0,
                  } as PaymentReplyDto);
                }),
              );
            },
          );
        return { selectedCandidate, updateStatusByIdWithEntityManager };
      }
    });
  });

  describe('update status', () => {
    // Restore original status
    afterAll(async () => {
      await dataSource
        .getRepository(TaskingInfo)
        .update(
          { id: testForUpdateOperation.id },
          { status: TaskingStatus.PreOrder },
        );
    });

    it(`ng ${baseUrl}/update-status (PUT) from pre-order to order-fixed`, async () => {
      // prepare mock of MissionPortalService.updateStatusByOrderId
      mockMissionPortalService.updateStatusByOrderId = jest.fn(() => {
        return Promise.resolve({
          result: true,
          errorMessage: null,
        } as ScsCommonResponseDto);
      });

      const body: TaskingInfoUpdateStatusDto = {
        ids: [testForUpdateOperation.id],
        status: TaskingStatus.OrderFixed,
        statusDetail: TaskingStatusDetail.None,
      };

      const res: request.Response = await request
        .default(httpServer)
        .put(`${baseUrl}/update-status `)
        .set('Content-Type', 'application/json')
        .send(body);
      expect(res.status).toEqual(400);
    });

    // これはいまのところない操作
    it(`ok ${baseUrl}/update-status (PUT) from pre-order to ordered`, async () => {
      // prepare mock of MissionPortalService.updateStatusByOrderId
      mockMissionPortalService.updateStatusByOrderId = jest.fn(() => {
        return Promise.resolve({
          result: true,
          errorMessage: null,
        } as ScsCommonResponseDto);
      });
      mockCitadelGrpcService.reserveTask = jest.fn(
        (registrationIds: string[]) => {
          const tmp = plainToInstance(PaymentsDto, {
            totalConsumptionCredit: 0,
            remainingCredit: 0,
            results: registrationIds.map((x) => {
              return plainToInstance(PaymentReplyDto, {
                registrationId: testForUpdateOperation.paymentId,
                taskId: x,
                status: PaymentTaskStatus.RESERVED,
                consumptionCredit: 0,
              } as PaymentReplyDto);
            }),
            verifyResults: registrationIds.map((x) => {
              return plainToInstance(VerifyItemDto, {
                taskId: x,
                consumptionCredit: 0,
                dataSourceType: DataSourceType.ARCHIVE,
                imagingMode: ImagingMode.Stripmap,
                numberOfLicense: 1,
                options: [],
              } as VerifyItemDto);
            }),
          } as PaymentsDto);

          return Promise.resolve(tmp);
        },
      );
      mockSlackNotificationService.send = jest.fn((message: SlackMessage) => {
        return Promise.resolve(message.shouldNotify);
      });

      const body: TaskingInfoUpdateStatusDto = {
        ids: [testForUpdateOperation.id],
        status: TaskingStatus.Ordered,
        statusDetail: TaskingStatusDetail.None,
      };

      const res: request.Response = await request
        .default(httpServer)
        .put(`${baseUrl}/update-status`)
        .set('Content-Type', 'application/json')
        .send(body);
      expect(res.status).toEqual(200);

      const result = plainToInstance(
        TaskingInfoUpdateStatusResultDtoDecorator,
        { items: res.body },
      );

      const found = await dataSource
        .getRepository(TaskingInfo)
        .findOneOrFail({ where: { id: result.items[0].id } });
      expect(result.items[0].updatedAt).toEqual(found.updatedAt);
      expect(result.items[0].status).toEqual(found.status);
      expect(result.items[0].statusDetail).toEqual(found.statusDetail);

      expect(mockCitadelGrpcService.reserveTask).toHaveBeenNthCalledWith(
        1,
        [testForUpdateOperation.id],
        await generateNotificationContents(
          TaskingStatus.Ordered,
          plainToInstance(NotificationParam, {
            env: process.env.NODE_ENV,
            taskMgmtLink: taskMgmtUrl,
            items: [
              plainToInstance(NotificationParamItem, {
                scsOrderCode: result.items[0].scsOrderCode,
                obsStart: result.items[0].observationStart,
                aoiName: result.items[0].name,
                satellite: result.items[0].satellite.name,
                imagingMode: result.items[0].imagingMode,
                flightDirection: result.items[0].flightDirection,
                lookingDirection: result.items[0].lookingDirection,
                offnadirAngle: result.items[0].offnadirAngle,
                taskingType: result.items[0].taskingType,
              } as NotificationParamItem),
            ],
          } as NotificationParam),
        ),
      );

      expect(mockSlackNotificationService.send).toHaveBeenCalledTimes(1);
      expect(mockSlackNotificationService.send).toHaveBeenNthCalledWith(
        1,
        new SlackTaskingInfoStatusMessage(
          {
            name: testForUpdateOperation.name,
            status: TaskingStatus.Ordered,
            orderCode: testForUpdateOperation.scsOrderCode,
            observationStart: testForUpdateOperation.observationStart,
          },
          { channel: SlackChannel.DEFAULT },
        ),
      );
      // TaskingStatus.Ordered should be notified to Slack
      await expect(
        mockSlackNotificationService.send.mock.results[0].value,
      ).resolves.toEqual(true);
    });

    it.each([TaskingStatus.OrderFixed, TaskingStatus.ObservationCompleted])(
      `ok ${baseUrl}/update-status (PUT) from %s to observation-failed`,
      async (srcStatus) => {
        await dataSource
          .getRepository(TaskingInfo)
          .update({ id: testForUpdateOperation.id }, { status: srcStatus });

        mockCitadelGrpcService.emitTaskResult = jest
          .fn()
          .mockImplementationOnce(
            (
              emitRequests: EmitRequestDto[],
              notificationContents: NotificationContents,
            ) => {
              return Promise.resolve(
                emitRequests.map((x) => {
                  return plainToInstance(PaymentReplyDto, {
                    registrationId: testForUpdateOperation.paymentId,
                    taskId: x.registrationId,
                    status: x.status,
                    consumptionCredit: 0,
                  } as PaymentReplyDto);
                }),
              );
            },
          );

        mockSlackNotificationService.send = jest.fn((message: SlackMessage) => {
          return Promise.resolve(message.shouldNotify);
        });

        const body: TaskingInfoUpdateStatusDto = {
          ids: [testForUpdateOperation.id],
          status: TaskingStatus.ObservationFailed,
          statusDetail: TaskingStatusDetail.None,
        };
        const res: request.Response = await request
          .default(httpServer)
          .put(`${baseUrl}/update-status`)
          .set('Content-Type', 'application/json')
          .send(body);
        expect(res.status).toEqual(200);
        const result = plainToInstance(
          TaskingInfoUpdateStatusResultDtoDecorator,
          { items: res.body },
        );

        expect(mockCitadelGrpcService.emitTaskResult).toHaveBeenNthCalledWith(
          1,
          [
            plainToInstance(EmitRequestDto, {
              registrationId: testForUpdateOperation.id,
              status: fromTaskingOperationStatusToPaymentTaskStatus(
                TaskingStatus.ObservationFailed,
              ), // FIXME
            } as EmitRequestDto),
          ],
          await generateNotificationContents(
            TaskingStatus.ObservationFailed,
            plainToInstance(NotificationParam, {
              env: process.env.NODE_ENV,
              taskMgmtLink: taskMgmtUrl,
              items: [
                plainToInstance(NotificationParamItem, {
                  scsOrderCode: result.items[0].scsOrderCode,
                  obsStart: result.items[0].observationStart,
                  reason: result.items[0].statusDetail,
                  aoiName: result.items[0].name,
                } as NotificationParamItem),
              ],
            } as NotificationParam),
          ),
        );

        expect(mockSlackNotificationService.send).toHaveBeenCalledTimes(1);
        expect(mockSlackNotificationService.send).toHaveBeenNthCalledWith(
          1,
          new SlackTaskingInfoStatusMessage(
            {
              name: testForUpdateOperation.name,
              status: TaskingStatus.ObservationFailed,
              orderCode: testForUpdateOperation.scsOrderCode,
              observationStart: testForUpdateOperation.observationStart,
            },
            { channel: SlackChannel.DEFAULT },
          ),
        );
        // TaskingStatus.ObservationFailed should be notified to Slack
        await expect(
          mockSlackNotificationService.send.mock.results[0].value,
        ).resolves.toEqual(true);
      },
    );
  });

  describe('update altitude', () => {
    afterAll(async () => {
      await dataSource
        .getRepository(TaskingInfo)
        .update(
          { id: testForUpdateOperation.id },
          { status: TaskingStatus.PreOrder },
        );
    });

    afterEach(async () => {
      mockMissionPortalService.registrationAvailabilityCheck = jest.fn();
      mockMissionPortalService.register = jest.fn();
      mockMissionPortalService.updateStatusByOrderId = jest.fn();
      mockMissionPortalService.updateAltitude = jest.fn();
    });

    it(`ok ${baseUrl}/update-altitude (PUT)`, async () => {
      // prepare mock of MissionPortalService.updateAltitude
      mockMissionPortalService.updateAltitude = jest.fn(() => {
        return Promise.resolve({
          result: true,
          errorMessage: null,
        } as ScsCommonResponseDto);
      });
      const body: TaskingInfoUpdateAltitudeDto = {
        id: testForUpdateOperation.id,
        altitude: 99999,
      };
      const res: request.Response = await request
        .default(httpServer)
        .put(`${baseUrl}/update-altitude`)
        .set('Content-Type', 'application/json')
        .send(body);
      expect(res.status).toEqual(200);
      const result = await dataSource
        .getRepository(TaskingInfo)
        .findOne({ where: { id: testForUpdateOperation.id } });
      expect(result.altitude).toEqual(Number.parseFloat('99999').toFixed(3));

      expect(mockMissionPortalService.updateAltitude).toHaveBeenNthCalledWith(
        1,
        result.scsOrderId,
        {
          altitude: body.altitude,
        } as ScsUpdateAltitudeDto,
      );
    });

    it(`ng ${baseUrl}/update-altitude (PUT)`, async () => {
      // prepare mock of MissionPortalService.updateAltitude
      mockMissionPortalService.updateAltitude = jest.fn(() => {
        return Promise.resolve({
          result: true,
          errorMessage: null,
        } as ScsCommonResponseDto);
      });
      const body: TaskingInfoUpdateAltitudeDto = {
        id: testForUpdateOperation.id,
        altitude: 100000,
      };
      const res: request.Response = await request
        .default(httpServer)
        .put(`${baseUrl}/update-altitude`)
        .set('Content-Type', 'application/json')
        .send(body);
      expect(res.status).toEqual(400);
      const result = await dataSource
        .getRepository(TaskingInfo)
        .findOne({ where: { id: testForUpdateOperation.id } });
      expect(result.altitude).toEqual('99999.000');
      expect(mockMissionPortalService.updateAltitude).toHaveBeenCalledTimes(0);
    });

    it(`ok ${baseUrl}/update-altitude (PUT) Not updated if there is an error in SCS`, async () => {
      // prepare mock of MissionPortalService.updateAltitude
      mockMissionPortalService.updateAltitude = jest.fn(() => {
        throw new InternalServerErrorException(
          'An error occurred in scs',
          'dummy',
        );
      });
      const body: TaskingInfoUpdateAltitudeDto = {
        id: testForUpdateOperation.id,
        altitude: 99999,
      };

      const res: request.Response = await request
        .default(httpServer)
        .put(`${baseUrl}/update-altitude`)
        .set('Content-Type', 'application/json')
        .send(body);
      expect(res.status).toEqual(500);
      const result = await dataSource
        .getRepository(TaskingInfo)
        .findOne({ where: { id: testForUpdateOperation.id } });
      expect(result.altitude).toEqual(Number.parseFloat('99999').toFixed(3));
      expect(mockMissionPortalService.updateAltitude).toHaveBeenNthCalledWith(
        1,
        result.scsOrderId,
        {
          altitude: body.altitude,
        } as ScsUpdateAltitudeDto,
      );
    });

    it(`ok ${baseUrl}/update-altitude (PUT) order-fixed cannot be changed`, async () => {
      await dataSource
        .getRepository(TaskingInfo)
        .update(
          { id: testForUpdateOperation.id },
          { status: TaskingStatus.OrderFixed },
        );
      // prepare mock of MissionPortalService.updateAltitude
      mockMissionPortalService.updateAltitude = jest.fn(() => {
        return Promise.resolve({
          result: true,
          errorMessage: null,
        } as ScsCommonResponseDto);
      });
      const body: TaskingInfoUpdateAltitudeDto = {
        id: testForUpdateOperation.id,
        altitude: 11,
      };

      const res: request.Response = await request
        .default(httpServer)
        .put(`${baseUrl}/update-altitude`)
        .set('Content-Type', 'application/json')
        .send(body);
      expect(res.status).toEqual(400);
      expect(mockMissionPortalService.updateAltitude).toHaveBeenCalledTimes(0);
    });
  });
});
