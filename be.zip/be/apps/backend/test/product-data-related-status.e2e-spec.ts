import { INestApplication } from '@nestjs/common';
import { ExpressAdapter } from '@nestjs/platform-express';
import { DataSource } from 'typeorm';
import { createAppForE2ETest } from './utils';
import * as request from 'supertest';
import { ProductDataRelatedStatus, TaskingInfo } from '@iris-lib/db/entities';
import Redis, { Cluster } from 'ioredis';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { RedisCache } from 'cache-manager-ioredis-yet';
import { loadFixtureTaskingInfo } from './fixtures';
import {
  IrisUserRole,
  IrisUserRoleTaskingValues,
  ProductFormat,
  ResolutionMode,
} from '@iris-lib/constants';
import {
  DUMMY_ANOTHER_CONTRACTS,
  DUMMY_ANOTHER_USER,
  DUMMY_CONTRACTS,
  DUMMY_USER,
  DummyAuthGuard,
} from '@iris-lib/guards';
import { instanceToInstance } from 'class-transformer';

const baseUrl = '/product-data-related-status';

describe('ProductDataRelatedStatusController', () => {
  let app: INestApplication;
  let dataSource: DataSource;
  let cacheManager: Redis | Cluster;
  let httpServer: ExpressAdapter;
  let fixtureTaskingInfos: TaskingInfo[];

  beforeAll(async () => {
    app = await createAppForE2ETest();
    await app.init();
    dataSource = app.get(DataSource);
    cacheManager = (app.get(CACHE_MANAGER) as RedisCache).store.client;
    httpServer = app.getHttpServer();
    fixtureTaskingInfos = await loadFixtureTaskingInfo(dataSource);
  });

  afterAll(async () => {
    await cacheManager.flushdb();
    await cacheManager.quit();
    await dataSource.destroy();
    await app.close();
  });

  it.each([
    ['ADMINISTRATOR', IrisUserRole.ADMINISTRATOR, /info-7$/],
    ['INTERNAL', IrisUserRole.INTERNAL, /info-7$/],
    ['COLLABORATOR', IrisUserRole.COLLABORATOR, /info-7$/],
    ['CUSTOMER', IrisUserRole.CUSTOMER, /info-7$/],
  ])('ok (%s)', async (_, userRole, targetName) => {
    const dummyUser = instanceToInstance(DUMMY_USER);
    dummyUser.roleTypes = [userRole];
    DummyAuthGuard.setDummy(dummyUser, DUMMY_CONTRACTS);

    const target = fixtureTaskingInfos.find((x) => x.name.match(targetName));
    const res: request.Response = await request
      .default(httpServer)
      .get(`${baseUrl}/${target.scsOrderCode}`)
      .set('Content-Type', 'application/json');
    expect(res.status).toEqual(200);

    const results = res.body as ProductDataRelatedStatus[];
    const expected = [
      expect.objectContaining({
        sceneNo: 1,
        productFormat: ProductFormat.SLC_SICD,
        resolutionMode: ResolutionMode.normal,
      }),
      expect.objectContaining({
        sceneNo: 1,
        productFormat: ProductFormat.SLC_CEOS,
        resolutionMode: ResolutionMode.normal,
      }),
      expect.objectContaining({
        sceneNo: 2,
        productFormat: ProductFormat.SLC_SICD,
        resolutionMode: ResolutionMode.normal,
      }),
      expect.objectContaining({
        sceneNo: 2,
        productFormat: ProductFormat.SLC_CEOS,
        resolutionMode: ResolutionMode.normal,
      }),
    ];
    if (IrisUserRoleTaskingValues.includes(userRole)) {
      expected.push(
        expect.objectContaining({
          sceneNo: 1,
          productFormat: ProductFormat.GRD_GEOTIFF,
          resolutionMode: ResolutionMode.normal,
        }),
        expect.objectContaining({
          sceneNo: 2,
          productFormat: ProductFormat.GRD_GEOTIFF,
          resolutionMode: ResolutionMode.normal,
        }),
      );
    }

    expect(results).toHaveLength(expected.length);
    expect(
      results.every((x) => x.orderCode === target.scsOrderCode),
    ).toBeTruthy();
    expect(results).toEqual(expect.arrayContaining(expected));
  });
  it.each([
    ['ADMINISTRATOR', IrisUserRole.ADMINISTRATOR, /info-31$/],
    ['INTERNAL', IrisUserRole.INTERNAL, /info-31$/],
    ['COLLABORATOR', IrisUserRole.COLLABORATOR, /info-31$/],
    ['CUSTOMER', IrisUserRole.CUSTOMER, /info-31$/],
  ])('ok (%s)', async (_, userRole, targetName) => {
    const dummyUser = instanceToInstance(DUMMY_ANOTHER_USER);
    dummyUser.roleTypes = [userRole];
    DummyAuthGuard.setDummy(dummyUser, DUMMY_ANOTHER_CONTRACTS);

    const target = fixtureTaskingInfos.find((x) => x.name.match(targetName));
    const res: request.Response = await request
      .default(httpServer)
      .get(`${baseUrl}/${target.scsOrderCode}`)
      .set('Content-Type', 'application/json');
    expect(res.status).toEqual(200);

    const results = res.body as ProductDataRelatedStatus[];
    const expected = [
      expect.objectContaining({
        sceneNo: 1,
        productFormat: ProductFormat.GRD_GEOTIFF,
        resolutionMode: ResolutionMode.normal,
      }),
    ];

    expect(results).toHaveLength(expected.length);
    expect(
      results.every((x) => x.orderCode === target.scsOrderCode),
    ).toBeTruthy();
    expect(results).toEqual(expect.arrayContaining(expected));
  });
});
