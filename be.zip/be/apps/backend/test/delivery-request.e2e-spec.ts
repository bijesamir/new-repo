import {
  DeliveryRequest,
  ProductDataVersion,
  TaskingInfo,
} from '@iris-lib/db/entities';
import { INestApplication } from '@nestjs/common';
import { ExpressAdapter } from '@nestjs/platform-express';
import { DataSource, In } from 'typeorm';
import { createAppForE2ETest } from './utils';
import {
  SlackDeliveryRequestStatusMessage,
  SlackChannel,
  SlackMessage,
  SlackNotificationService,
} from '@iris-lib/slack';
import { DeliveryRequestCreateDto } from '../src/models/dto/delivery-request/delivery-request-register.dto';
import {
  AppConstants,
  DeliveryRequestSource,
  DeliveryRequestStatus,
  DeliveryRequestStatusDetail,
  NotificationContents,
  NotificationParam,
  NotificationParamItem,
  NotificationProductParam,
  TEST_ORGANIZATION_ID,
  generateNotificationContents,
} from '@iris-lib/constants';
import * as request from 'supertest';
import { loadFixtureProductDataVersion } from './fixtures';
import { CitadelGrpcService } from '@iris-lib/citadel';
import {
  EmitRequestDto,
  PaymentReplyDto,
  ProcessingSuccessResult,
} from '@iris-lib/models/payment';
import { plainToInstance } from 'class-transformer';
import { PaymentTaskStatus } from '@iris-lib/constants/payment-task-status';
import { CitadelRelatedError } from '@iris-lib/citadel/models';
import { basename } from 'path';
import Redis, { Cluster } from 'ioredis';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { RedisCache } from 'cache-manager-ioredis-yet';

const baseUrl = '/delivery-request';

describe('DeliveryRequestController', () => {
  let app: INestApplication;
  let dataSource: DataSource;
  let cacheManager: Redis | Cluster;
  let httpServer: ExpressAdapter;

  let fixtureProductDataVersions: ProductDataVersion[];
  const createdDeliveryRequests: DeliveryRequest[] = [];

  const mockCitadelGrpcService = {
    emitTaskResult: jest.fn(),
  };
  const mockSlackNotificationService = {
    send: jest.fn(),
  };

  beforeAll(async () => {
    app = await createAppForE2ETest((tm) => {
      tm.overrideProvider(CitadelGrpcService).useValue(mockCitadelGrpcService);
      tm.overrideProvider(SlackNotificationService).useValue(
        mockSlackNotificationService,
      );
    });
    await app.init();
    dataSource = app.get(DataSource);
    cacheManager = (app.get(CACHE_MANAGER) as RedisCache).store.client;
    httpServer = app.getHttpServer();
    fixtureProductDataVersions =
      await loadFixtureProductDataVersion(dataSource);
  });

  beforeEach(() => {
    mockSlackNotificationService.send = jest.fn((message: SlackMessage) => {
      return Promise.resolve(message.shouldNotify);
    });
  });

  afterAll(async () => {
    await cacheManager.flushdb();
    await cacheManager.quit();
    await dataSource.manager
      .getRepository(DeliveryRequest)
      .delete(createdDeliveryRequests.map((x) => x.id));
    await dataSource.destroy();
    await app.close();
  });

  afterEach(async () => {
    mockCitadelGrpcService.emitTaskResult = jest.fn();
  });

  it.each([
    [
      DeliveryRequestStatus.Prepared,
      DeliveryRequestStatusDetail.None,
      DeliveryRequestSource.Observation,
    ],
    [
      DeliveryRequestStatus.Failed,
      DeliveryRequestStatusDetail.None,
      DeliveryRequestSource.Observation,
    ],
    [
      DeliveryRequestStatus.Completed,
      DeliveryRequestStatusDetail.None,
      DeliveryRequestSource.Observation,
    ],
    [
      DeliveryRequestStatus.Completed,
      DeliveryRequestStatusDetail.None,
      DeliveryRequestSource.OnlyDeliveryRequest,
    ],
    [
      DeliveryRequestStatus.Completed,
      DeliveryRequestStatusDetail.None,
      DeliveryRequestSource.ReprocessingRequest,
    ],
  ])(
    `${baseUrl} (POST): Successful registration (status: %s, statusDetail: %s, source: %s)`,
    async (targetStatus, targetStatusDetail, targetSource) => {
      const targetProductDataVersions = fixtureProductDataVersions
        .filter((pdv) => pdv.organizationId === TEST_ORGANIZATION_ID)
        .slice(1, 2); //to make test result stable
      const productDataVersionIds = targetProductDataVersions.map((x) => x.id);

      mockCitadelGrpcService.emitTaskResult = jest.fn(
        (
          emitRequests: EmitRequestDto[],
          // eslint-disable-next-line @typescript-eslint/no-unused-vars
          notificationContents: NotificationContents,
        ) => {
          return Promise.resolve(
            emitRequests.map((x) => {
              return plainToInstance(PaymentReplyDto, {
                registrationId: 1,
                taskId: x.registrationId,
                status: x.status,
                consumptionCredit: 0,
              } as PaymentReplyDto);
            }),
          );
        },
      );

      const body: DeliveryRequestCreateDto = {
        productDataVersionIds,
        status: targetStatus,
        statusDetail: targetStatusDetail,
        source: targetSource,
      };
      const res: request.Response = await request
        .default(httpServer)
        .post(baseUrl)
        .set('Content-Type', 'application/json')
        .send(body);
      expect(res.status).toEqual(201);

      const ar: DeliveryRequest[] = res.body;
      createdDeliveryRequests.push(...ar);
      const found = await dataSource.manager.find(DeliveryRequest, {
        where: { id: In(ar.map((x) => x.id)) },
        relations: {
          productDataVersion: {
            productData: {
              taskingInfo: { taskingRequest: { aois: true } },
            },
          },
        },
      });
      const results = found.reduce((p, c) => {
        p[c.productDataVersionId] = c;
        return p;
      }, {});

      const taskingInfos = await dataSource
        .getRepository(TaskingInfo)
        .createQueryBuilder('ti')
        .innerJoinAndSelect('ti.productData', 'pd')
        .innerJoinAndSelect('pd.productDataVersions', 'pdv')
        .select()
        .where('pdv.id IN (:...productDataVersionIds)', {
          productDataVersionIds,
        })
        .getMany();

      expect(found.length).toEqual(1);

      Object.values(targetProductDataVersions).forEach((pdv) => {
        expect(results[pdv.id].status).toEqual(targetStatus);
        expect(results[pdv.id].statusDetail).toEqual(targetStatusDetail);
        expect(results[pdv.id].source).toEqual(targetSource);
        expect(results[pdv.id].productDataVersionId).toEqual(pdv.id);
        expect(results[pdv.id].organizationId).toEqual(pdv.organizationId);
        expect(results[pdv.id].contractId).toEqual(pdv.contractId);
        expect(results[pdv.id].latestEditorId).not.toBeNull();
        expect(results[pdv.id].createdAt).not.toBeNull();
        expect(results[pdv.id].updatedAt).not.toBeNull();
        expect(results[pdv.id].deletedAt).toBeNull();

        switch (targetStatus) {
          case DeliveryRequestStatus.Prepared:
          case DeliveryRequestStatus.Failed:
            expect(results[pdv.id].paymentId).toBeNull();
            break;
          case DeliveryRequestStatus.Completed:
            expect(results[pdv.id].paymentId).not.toBeNull();
            break;
          default:
            throw new Error('unexpected status');
        }
      });

      // citadel
      switch (targetStatus) {
        case DeliveryRequestStatus.Prepared:
        case DeliveryRequestStatus.Failed:
          expect(mockCitadelGrpcService.emitTaskResult).not.toHaveBeenCalled();
          break;
        case DeliveryRequestStatus.Completed:
          expect(mockCitadelGrpcService.emitTaskResult).toHaveBeenCalledTimes(
            taskingInfos.length,
          );
          await Promise.all(
            taskingInfos.map(async (ti) => {
              const processingSuccessList = ti.productData.flatMap((pd) =>
                pd.productDataVersions.map((pdv) =>
                  plainToInstance(ProcessingSuccessResult, {
                    productDataVersionId: pdv.id,
                    productFormat: pdv.metadata.product.productFormat,
                    resolutionMode: pdv.metadata.product.resolutionMode,
                  }),
                ),
              );
              expect(
                mockCitadelGrpcService.emitTaskResult,
              ).toHaveBeenCalledWith(
                expect.arrayContaining([
                  expect.objectContaining({
                    registrationId: ti.id,
                    status: PaymentTaskStatus.COMPLETED,
                    processingSuccessList: expect.arrayContaining(
                      //order is not fixed
                      processingSuccessList,
                    ),
                  }),
                ]),
                expect.objectContaining(
                  await generateNotificationContents(
                    targetStatus,
                    plainToInstance(NotificationParam, {
                      env: process.env.NODE_ENV,
                      items: [
                        plainToInstance(NotificationParamItem, {
                          scsOrderCode: ti.scsOrderCode,
                          obsStart: ti.observationStart,
                          files: ti.productData.flatMap((pd) =>
                            pd.productDataVersions.map((pdv) =>
                              plainToInstance(NotificationProductParam, {
                                filename: basename(pdv.location),
                                link: `${process.env.IRIS_API_URL}/v${AppConstants.DEFAULT_VERSION}/product-data-version/${pdv.id}/download`,
                              }),
                            ),
                          ),
                          aoiName: ti.name,
                        } as NotificationParamItem),
                      ],
                    } as NotificationParam),
                  ),
                ),
              );
            }),
          );
          break;
        default:
          throw new Error('unexpected status');
      }

      // slack notification
      expect(mockSlackNotificationService.send).toHaveBeenCalledTimes(1);

      found.forEach(async (ar, idx) => {
        let shouldMention = false;

        switch (targetStatus) {
          case DeliveryRequestStatus.Prepared:
            await expect(
              mockSlackNotificationService.send.mock.results[idx].value,
            ).resolves.toEqual(false);
            break;
          case DeliveryRequestStatus.Failed:
            shouldMention = true;
          // fall-through
          case DeliveryRequestStatus.Completed:
            await expect(
              mockSlackNotificationService.send.mock.results[idx].value,
            ).resolves.toEqual(true);
            break;
          default:
            throw new Error('unexpected status');
        }

        expect(mockSlackNotificationService.send).toHaveBeenCalledWith(
          //order is not fixed
          expect.objectContaining(
            new SlackDeliveryRequestStatusMessage(
              {
                aoiName: expect.any(String), //aoi name test result unstable
                status: targetStatus,
                orderCode:
                  ar.productDataVersion.productData.taskingInfo.scsOrderCode,
                sceneNo: ar.productDataVersion.productData.sceneNo,
                fileName: basename(ar.productDataVersion.location),
                productDataVersionId: ar.productDataVersionId,
              },
              { channel: SlackChannel.DEFAULT, shouldMention },
            ),
          ),
        );
      });
    },
  );

  it(`${baseUrl} (POST): Failed registration (error in emitTaskResult)`, async () => {
    const targetProductDataVersions = fixtureProductDataVersions
      .filter(
        (pdv) =>
          pdv.organizationId === TEST_ORGANIZATION_ID &&
          !createdDeliveryRequests
            .map((ar) => ar.productDataVersionId)
            .includes(pdv.id),
      )
      .slice(1, 2);

    const productDataVersionIds = targetProductDataVersions.map((x) => x.id);
    // only DeliveryRequestStatus.Completed calls emitTaskResult
    const targetStatus = DeliveryRequestStatus.Completed;

    mockCitadelGrpcService.emitTaskResult = jest.fn(() => {
      return Promise.reject(new CitadelRelatedError('test error'));
    });

    const body: DeliveryRequestCreateDto = {
      productDataVersionIds,
      status: targetStatus,
      statusDetail: DeliveryRequestStatusDetail.None,
      source: DeliveryRequestSource.Observation,
    };
    const res: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(500);

    const found = await dataSource.getRepository(DeliveryRequest).find({
      where: {
        productDataVersionId: In(productDataVersionIds),
      },
    });

    const taskingInfos = await dataSource
      .getRepository(TaskingInfo)
      .createQueryBuilder('ti')
      .innerJoinAndSelect('ti.productData', 'pd')
      .innerJoinAndSelect('pd.productDataVersions', 'pdv')
      .select()
      .where('pdv.id IN (:...productDataVersionIds)', {
        productDataVersionIds,
      })
      .getMany();

    expect(found.length).toEqual(0);

    // citadel
    expect(mockCitadelGrpcService.emitTaskResult).toHaveBeenCalledTimes(
      taskingInfos.length,
    );
    for (const ti of taskingInfos) {
      const processingSuccessList = await ti.productData.flatMap((pd) =>
        pd.productDataVersions.map((pdv) =>
          plainToInstance(ProcessingSuccessResult, {
            productDataVersionId: pdv.id,
            productFormat: pdv.metadata.product.productFormat,
            resolutionMode: pdv.metadata.product.resolutionMode,
          }),
        ),
      );
      const param = plainToInstance(EmitRequestDto, {
        registrationId: ti.id,
        status: PaymentTaskStatus.COMPLETED,
        processingSuccessList,
      });
      expect(mockCitadelGrpcService.emitTaskResult).toHaveBeenCalledWith(
        [param],
        await generateNotificationContents(
          targetStatus,
          plainToInstance(NotificationParam, {
            env: process.env.NODE_ENV,
            items: [
              plainToInstance(NotificationParamItem, {
                scsOrderCode: ti.scsOrderCode,
                obsStart: ti.observationStart,
                files: ti.productData.flatMap((pd) =>
                  pd.productDataVersions.map((pdv) =>
                    plainToInstance(NotificationProductParam, {
                      filename: basename(pdv.location),
                      link: `${process.env.IRIS_API_URL}/v${AppConstants.DEFAULT_VERSION}/product-data-version/${pdv.id}/download`,
                    }),
                  ),
                ),
                aoiName: ti.name,
              } as NotificationParamItem),
            ],
          } as NotificationParam),
        ),
      );
    }

    // slack notification
    expect(mockSlackNotificationService.send).toHaveBeenCalledTimes(0);
  });
});
