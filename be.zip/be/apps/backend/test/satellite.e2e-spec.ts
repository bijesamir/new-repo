import { INestApplication } from '@nestjs/common';
import { SatelliteCreateDto } from '../src/models/dto/satellite/satellite-create.dto';
import { Satellite } from '@iris-lib/db/entities';
import * as request from 'supertest';
import { DataSource } from 'typeorm';

import { createAppForE2ETest } from './utils';
import { plainToClass, plainToInstance } from 'class-transformer';
import { SatelliteUpdateDto } from '../src/models/dto/satellite/satellite-update.dto';
import {
  FlightDirection,
  ImagingMode,
  IrisUserRoleAllValues,
  IrisUserRoleInternalValues,
  LookingDirection,
  TaskingType,
} from '@iris-lib/constants';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { RedisCache } from 'cache-manager-ioredis-yet';
import Redis, { Cluster } from 'ioredis';
import { ExpressAdapter } from '@nestjs/platform-express';

const baseUrl = '/satellite';

describe('SatelliteController (e2e)', () => {
  let app: INestApplication;
  let dataSource: DataSource;
  let cacheManager: Redis | Cluster;
  let httpServer: ExpressAdapter;

  let createdSatelliteId: string;

  beforeAll(async () => {
    app = await createAppForE2ETest();
    await app.init();
    dataSource = app.get(DataSource);
    cacheManager = (app.get(CACHE_MANAGER) as RedisCache).store.client;
    httpServer = app.getHttpServer();
  });

  afterAll(async () => {
    await cacheManager.flushdb();
    await cacheManager.quit();
    await dataSource.manager
      .getRepository(Satellite)
      .delete(createdSatelliteId);
    await dataSource.destroy();
    await app.close();
  });

  describe('abnormal case', () => {
    it(`${baseUrl} (GET) : If the target is not found, the response status will be 404.`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/52e94619-89c3-4889-8cb9-7a4c54c22d8a`);
      expect(res.status).toEqual(404);
    });

    it(`${baseUrl} (GET) : If the parameter check fails, the response status is 400.`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/681452f0-7aae-11ed-9c05-eb3751df404a`);
      expect(res.status).toEqual(400);
    });
  });

  describe('normal case', () => {
    describe('create', () => {
      it(`${baseUrl} (POST) : Registered when the specified JSON is posted.`, async () => {
        const body: SatelliteCreateDto = plainToInstance(SatelliteCreateDto, {
          name: 'StriX-Dummy',
          satId: 'ST9999',
          satelliteDevelopmentCode: 'dsx9999',
          isAvailable: true,
          visibleTo: IrisUserRoleAllValues,
          parameters: [
            {
              imagingMode: ImagingMode.Stripmap,
              flightDirection: [FlightDirection.Descending],
              lookingDirection: [LookingDirection.Left],
              taskingType: [TaskingType.Regular, TaskingType.Urgent],
              offnadirLowerLimit: 15,
              offnadirUpperLimit: 45,
            },
          ],
        });

        const res: request.Response = await request
          .default(httpServer)
          .post(baseUrl)
          .set('Content-Type', 'application/json')
          .send(body);
        expect(res.status).toEqual(201);

        createdSatelliteId = (res.body as Satellite).id;
        const found = await dataSource.manager.findOne(Satellite, {
          where: { id: createdSatelliteId },
        });

        expect(found.name).toEqual(body.name);
        expect(found.satId).toEqual(body.satId);
        expect(found.satelliteDevelopmentCode).toEqual(
          body.satelliteDevelopmentCode,
        );
        expect(found.visibleTo).toEqual(body.visibleTo);
        expect(found.parameters).toEqual(body.parameters);
        expect(found.createdAt).not.toBeNull();
        expect(found.updatedAt).not.toBeNull();
        expect(found.deletedAt).toBeNull();
      });
    });

    describe('update', () => {
      it(`${baseUrl} (PUT) : Updated when the specified JSON and existed Id is put.`, async () => {
        const body: SatelliteUpdateDto = {
          name: 'StriX-Dummy2',
          satId: 'ST9998',
          satelliteDevelopmentCode: 'dsx9998',
        };
        const res: request.Response = await request
          .default(httpServer)
          .put(`${baseUrl}/${createdSatelliteId}`)
          .set('Content-Type', 'application/json')
          .send(body);
        expect(res.status).toEqual(200);

        const result = plainToClass(Satellite, res.body);
        const found = await dataSource.manager.findOne(Satellite, {
          where: { id: createdSatelliteId },
        });

        expect(found.id).toEqual(result.id);
        expect(found.createdAt).toEqual(result.createdAt);
        expect(found.updatedAt).toEqual(result.updatedAt);
        expect(found.deletedAt).toBeNull();
        expect(found.parameters).toEqual(result.parameters);
        expect(found.visibleTo).toEqual(result.visibleTo);

        expect(found.name).toEqual(body.name);
        expect(found.satId).toEqual(body.satId);
        expect(found.satelliteDevelopmentCode).toEqual(
          body.satelliteDevelopmentCode,
        );
      });
    });

    describe('update', () => {
      it(`${baseUrl} (PUT) : Note that updating parameters will overwrite`, async () => {
        const body: SatelliteUpdateDto = {
          // overwrite existing
          visibleTo: IrisUserRoleInternalValues,
          parameters: [
            {
              imagingMode: ImagingMode.Stripmap,
              flightDirection: [FlightDirection.Descending],
              lookingDirection: [LookingDirection.Left],
              taskingType: [TaskingType.Regular, TaskingType.Urgent],
              offnadirLowerLimit: 25,
              offnadirUpperLimit: 30,
            },
            {
              imagingMode: ImagingMode.SlidingSpotlight,
              flightDirection: [FlightDirection.Descending],
              lookingDirection: [LookingDirection.Left],
              taskingType: [TaskingType.Regular, TaskingType.Urgent],
              offnadirLowerLimit: 15,
              offnadirUpperLimit: 45,
            },
          ],
        };
        const res: request.Response = await request
          .default(httpServer)
          .put(`${baseUrl}/${createdSatelliteId}`)
          .set('Content-Type', 'application/json')
          .send(body);
        expect(res.status).toEqual(200);

        const result = plainToClass(Satellite, res.body);
        const found = await dataSource.manager.findOne(Satellite, {
          where: { id: createdSatelliteId },
        });

        expect(found.id).toEqual(result.id);
        expect(found.name).toEqual(result.name);
        expect(found.satId).toEqual(result.satId);
        expect(found.satelliteDevelopmentCode).toEqual(
          result.satelliteDevelopmentCode,
        );
        expect(found.createdAt).toEqual(result.createdAt);
        expect(found.updatedAt).toEqual(result.updatedAt);
        expect(found.deletedAt).toBeNull();

        expect(found.visibleTo).toEqual(body.visibleTo);
        expect(found.parameters).toEqual(body.parameters);
      });
    });

    it(`${baseUrl} (GET) : can be searched.`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/${createdSatelliteId}`);
      expect(res.status).toEqual(200);
      const result = plainToClass(Satellite, res.body);
      expect(createdSatelliteId).toEqual(result.id);
      return;
    });

    it(`${baseUrl} (DELETE) : soft deleted`, async () => {
      const res: request.Response = await request
        .default(httpServer)
        .delete(`${baseUrl}/${createdSatelliteId}`);
      expect(res.status).toEqual(200);

      const found = await dataSource.manager.findOne(Satellite, {
        where: { id: createdSatelliteId },
        withDeleted: true,
      });
      expect(found.deletedAt).not.toBeNull();
      return;
    });
  });
});
