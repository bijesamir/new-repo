import { NestFactory } from '@nestjs/core';
import { DataSource } from 'typeorm';
import { allFixtures } from './fixtures';
import { TestEnvModule } from './test-env-module';

export const teardownTestData = async (ds: DataSource, mode) => {
  await ds.transaction(async (em) => {
    return await Object.entries(allFixtures)
      .filter((x) => {
        return (
          mode == 'all' ||
          mode in x[1] ||
          (mode == 'fixture' && !('seed' in x[1]))
        );
      })
      .reduce(async (p, c) => {
        await p;
        const tableMeta = em.connection.getMetadata(c[1].entity);
        await ds.query(
          `TRUNCATE TABLE ${tableMeta.tableName} RESTART IDENTITY CASCADE`,
        );
        return;
      }, Promise.resolve());
  });
};

const main = async () => {
  let [mode] = process.argv.length >= 3 ? process.argv.splice(2) : [];
  mode ||= 'all';
  console.log('cleanupTestData', mode);
  const app = await NestFactory.create(TestEnvModule, {});
  const ds = app.get(DataSource);
  await teardownTestData(ds, mode);
  ds.destroy();
  app.close();
  return;
};

if (require.main === module) {
  main();
}
