import { INestApplication } from '@nestjs/common';
import { DataSource } from 'typeorm';
import { createAppForE2ETest } from './utils';
import { AoiCreateDto } from '../src/models/dto/aoi/aoi-create.dto';
import * as request from 'supertest';
import { Aoi } from '@iris-lib/db/entities';
import { AoiUpdateDto } from '../src/models/dto/aoi/aoi-update.dto';
import { addDays } from 'date-fns';
import { Paginated } from 'nestjs-paginate';
import { AoiSearchDto } from '../src/models/dto/aoi/aoi-search.dto';
import { loadFixtureAoi } from './fixtures';
import {
  TEST_ANOTHER_ORGANIZATION_ID,
  TEST_ORGANIZATION_ID,
} from '@iris-lib/constants/test-support';
import { ExpressAdapter } from '@nestjs/platform-express';
import { AoiDeleteDto } from '../src/models/dto/aoi/aoi-delete.dto';
import { plainToInstance } from 'class-transformer';
import Redis, { Cluster } from 'ioredis';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { RedisCache } from 'cache-manager-ioredis-yet';

const baseUrl = '/aoi';

describe('AoiController (e2e)', () => {
  let app: INestApplication;
  let dataSource: DataSource;
  let cacheManager: Redis | Cluster;
  let httpServer: ExpressAdapter;

  const aoiIdList = new Array<string>();
  let fixtureAoiIdList: Aoi[];

  beforeAll(async () => {
    app = await createAppForE2ETest();
    await app.init();
    dataSource = app.get(DataSource);
    cacheManager = (app.get(CACHE_MANAGER) as RedisCache).store.client;
    httpServer = app.getHttpServer();
    fixtureAoiIdList = await loadFixtureAoi(dataSource);
  });

  afterAll(async () => {
    await cacheManager.flushdb();
    await cacheManager.quit();
    await dataSource.manager.getRepository(Aoi).delete(aoiIdList);
    await dataSource.destroy();
    await app.close();
  });

  it(`${baseUrl} (POST): Successful registration without polygons`, async () => {
    const body: AoiCreateDto = {
      name: 'aoi-1',
      center: {
        type: 'Point',
        coordinates: [138.7309, 35.3628],
      },
      altitude: 10,
      organizationId: TEST_ORGANIZATION_ID,
    };
    const res: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(201);
    const createdId = (res.body as Aoi).id;
    const found = await dataSource.manager.findOneOrFail(Aoi, {
      where: { id: createdId },
    });
    expect(found.name).toEqual(body.name);
    expect(found.center).toEqual(body.center);
    expect(Math.trunc(found.altitude)).toBe(body.altitude);
    expect(found.area).toBeNull();
    expect(found.organizationId).toEqual(body.organizationId);
    expect(found.latestEditorId).not.toBeNull();
    expect(found.createdAt).not.toBeNull();
    expect(found.updatedAt).not.toBeNull();
    expect(found.createdAt).toEqual(found.updatedAt);
    expect(found.deletedAt).toBeNull();
    aoiIdList.push(createdId);
  });

  it(`${baseUrl} (POST): Successful registration with area`, async () => {
    const body: AoiCreateDto = {
      name: 'aoi-1-with-area',
      center: {
        type: 'Point',
        coordinates: [138.7309, 35.3628],
      },
      altitude: 10,
      area: {
        coordinates: [
          [
            [139.56431812672935, 35.81470688094848],
            [139.56431812672935, 35.548685800882055],
            [139.8503864048817, 35.548685800882055],
            [139.8503864048817, 35.81470688094848],
            [139.56431812672935, 35.81470688094848],
          ],
        ],
        type: 'Polygon',
      },
      organizationId: TEST_ORGANIZATION_ID,
    };
    const res: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(201);
    const createdId = (res.body as Aoi).id;
    const found = await dataSource.manager.findOneOrFail(Aoi, {
      where: { id: createdId },
    });
    expect(found.name).toEqual(body.name);
    expect(found.center).toEqual(body.center);
    expect(Math.trunc(found.altitude)).toBe(body.altitude);
    expect(found.area).toEqual({
      ...body.area,
      ...{
        coordinates: body.area.coordinates.map((x) => {
          return x.map((y) => {
            // https://postgis.net/docs/ST_AsGeoJSON.html
            return [
              Math.round(y[0] * 10 ** 9) / 10 ** 9,
              Math.round(y[1] * 10 ** 9) / 10 ** 9,
            ];
          });
        }),
      },
    });
    expect(found.organizationId).toEqual(body.organizationId);
    expect(found.latestEditorId).not.toBeNull();
    expect(found.createdAt).not.toBeNull();
    expect(found.updatedAt).not.toBeNull();
    expect(found.createdAt).toEqual(found.updatedAt);

    expect(found.deletedAt).toBeNull();
    aoiIdList.push(createdId);
  });

  it(`${baseUrl} (PUT): Successful update of name`, async () => {
    const targetId = aoiIdList[0];
    const before = await dataSource.manager.findOneOrFail(Aoi, {
      where: { id: targetId },
    });

    const body: AoiUpdateDto = {
      name: 'aoi-2',
    };
    const res: request.Response = await request
      .default(httpServer)
      .put(`${baseUrl}/${targetId}`)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(200);

    const found = await dataSource.manager.findOneOrFail(Aoi, {
      where: { id: targetId },
    });
    expect(found.name).toEqual(body.name);
    expect(found.name).not.toEqual(before.name);
    expect(found.center).toEqual(before.center);
    expect(found.altitude).toBe(before.altitude);
    expect(found.area).toEqual(before.area);
    expect(found.organizationId).toEqual(before.organizationId);
    expect(found.latestEditorId).not.toBeNull(); // FIXME Unable to check updater changes
    expect(found.createdAt).not.toBeNull();
    expect(found.updatedAt).not.toBeNull();
    expect(found.createdAt.getTime()).toBeLessThan(found.updatedAt.getTime());
  });

  it(`${baseUrl} (PUT): Successful update of altitude`, async () => {
    const targetId = aoiIdList[0];
    const before = await dataSource.manager.findOneOrFail(Aoi, {
      where: { id: targetId },
    });

    const body: AoiUpdateDto = {
      altitude: 200,
    };
    const res: request.Response = await request
      .default(httpServer)
      .put(`${baseUrl}/${targetId}`)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(200);

    const found = await dataSource.manager.findOneOrFail(Aoi, {
      where: { id: targetId },
    });

    expect(found.name).toEqual(before.name);
    expect(Math.trunc(found.altitude)).toEqual(body.altitude);
    expect(found.altitude).not.toEqual(before.altitude);
    expect(found.center).toEqual(before.center);
    expect(found.area).toEqual(before.area);
    expect(found.organizationId).toEqual(before.organizationId);
    expect(found.latestEditorId).not.toBeNull(); // FIXME Unable to check updater changes
    expect(found.createdAt).not.toBeNull();
    expect(found.updatedAt).not.toBeNull();
    expect(found.createdAt.getTime()).toBeLessThan(found.updatedAt.getTime());
  });

  it(`${baseUrl} (PUT): An error occurs if the id format is not UUID`, async () => {
    const body: AoiUpdateDto = {
      altitude: 300,
    };
    const res: request.Response = await request
      .default(httpServer)
      .put(`${baseUrl}/not-uuid`)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(400);
  });

  it(`${baseUrl} (PUT): If you set null without intending to update, an error will occur`, async () => {
    const targetId = aoiIdList[0];

    const body: AoiUpdateDto = {
      name: null,
      altitude: 300,
    };
    const res: request.Response = await request
      .default(httpServer)
      .put(`${baseUrl}/${targetId}`)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(400);
  });

  it(`${baseUrl} (PUT): If you set empty string without intending to update, an error will occur`, async () => {
    const targetId = aoiIdList[0];

    const body: AoiUpdateDto = {
      name: '',
      altitude: 300,
    };
    const res: request.Response = await request
      .default(httpServer)
      .put(`${baseUrl}/${targetId}`)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(400);
  });

  it(`${baseUrl} (GET): Succeeded in retrieving data with the specified ID`, async () => {
    const targetId = aoiIdList[0];
    const before = await dataSource.manager.findOneOrFail(Aoi, {
      where: { id: targetId },
    });
    const res: request.Response = await request
      .default(httpServer)
      .get(`${baseUrl}/${targetId}`)
      .set('Content-Type', 'application/json')
      .send();
    expect(res.status).toEqual(200);

    const gotData = res.body as Aoi;

    expect(gotData.id).toEqual(targetId);
    expect(gotData.name).toEqual(before.name);
  });

  it(`${baseUrl} (GET): Not Found if the ID is not registered`, async () => {
    const res: request.Response = await request
      .default(httpServer)
      .get(`${baseUrl}/3147cf12-cf6c-40f5-8d22-b8a5538d9d47`)
      .set('Content-Type', 'application/json')
      .send();
    expect(res.status).toEqual(404);
  });

  it(`${baseUrl} (GET): Error if ID is not in UUID format`, async () => {
    const res: request.Response = await request
      .default(httpServer)
      .get(`${baseUrl}/not-uuid`)
      .set('Content-Type', 'application/json')
      .send();
    expect(res.status).toEqual(400);
  });

  it(`${baseUrl} (GET): Error when getting AOI of organization to which user does not belong`, async () => {
    const targetId = aoiIdList[0];
    const res: request.Response = await request
      .default(httpServer)
      .get(
        `${baseUrl}/${targetId}?organizationId=${TEST_ANOTHER_ORGANIZATION_ID}`,
      )
      .set('Content-Type', 'application/json')
      .send();
    expect(res.status).toEqual(400);
  });

  it(`${baseUrl}/search (GET): If you search createdAt with the condition of before the next day, you can get what was registered in the above test`, async () => {
    const a = addDays(new Date(), 1);

    const res: request.Response = await request
      .default(httpServer)
      .get(`${baseUrl}/search`)
      .set('Content-Type', 'application/json')
      .query({
        'filter.createdAt': `$lte:${a.toJSON()}`,
        sortBy: 'createdAt:ASC',
      })
      .send();
    expect(res.status).toEqual(200);

    const sameOrgAois = fixtureAoiIdList.filter(
      (x) => x.organizationId == TEST_ORGANIZATION_ID,
    );
    const gotData = res.body as Paginated<Aoi>;
    expect(gotData.data.length).toEqual(aoiIdList.length + sameOrgAois.length);
    expect(gotData.data.map((x) => x.id).sort()).toEqual(
      aoiIdList.concat(sameOrgAois.map((x) => x.id)).sort(),
    );
  });

  it(`${baseUrl}/search (GET): Searching for createdAt with the condition after the next day yields nothing`, async () => {
    const a = addDays(new Date(), 1);

    const res: request.Response = await request
      .default(httpServer)
      .get(`${baseUrl}/search`)
      .set('Content-Type', 'application/json')
      .query({
        'filter.createdAt': `$gte:${a.toJSON()}`,
        sortBy: 'createdAt:ASC',
      })
      .send();
    expect(res.status).toEqual(200);

    const gotData = res.body as Paginated<Aoi>;
    expect(gotData.data.length).toEqual(0);
  });

  it(`${baseUrl}/search (GET): If you search name with with-area using ilike, you will get 1 hit`, async () => {
    const res: request.Response = await request
      .default(httpServer)
      .get(`${baseUrl}/search`)
      .set('Content-Type', 'application/json')
      .query({
        'filter.name': `$ilike:with-area`,
        sortBy: 'createdAt:ASC',
      })
      .send();
    expect(res.status).toEqual(200);

    const gotData = res.body as Paginated<Aoi>;
    expect(gotData.data.length).toEqual(1);
  });

  it(`${baseUrl}/in-view (POST): You can get AOI that matches the specified range`, async () => {
    const body: AoiSearchDto = {
      area: {
        coordinates: [
          [
            [138.4890534850786, 35.58615155425427],
            [138.4890534850786, 35.04800180184674],
            [139.07584551279086, 35.04800180184674],
            [139.07584551279086, 35.58615155425427],
            [138.4890534850786, 35.58615155425427],
          ],
        ],
        type: 'Polygon',
      },
    };

    const res: request.Response = await request
      .default(httpServer)
      .post(`${baseUrl}/in-view`)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(200);
    const gotData = res.body as [Aoi];

    expect(gotData.length).toEqual(aoiIdList.length);
  });

  it(`${baseUrl} (DELETE): can be logically deleted`, async () => {
    const targetId = aoiIdList[0];

    const body: AoiDeleteDto = plainToInstance(AoiDeleteDto, {
      ids: [targetId],
    });
    const res: request.Response = await request
      .default(httpServer)
      .delete(`${baseUrl}/`)
      .send(body)
      .set('Content-Type', 'application/json');

    expect(res.status).toEqual(200);

    const gotData = res.body as Aoi[];

    expect(gotData[0].deletedAt).not.toBeNull();

    const notFound = await dataSource.manager.exists(Aoi, {
      where: { id: targetId },
    });
    expect(notFound).toBeFalsy();

    const found = await dataSource.manager.exists(Aoi, {
      where: { id: targetId },
      withDeleted: true,
    });
    expect(found).toBeTruthy();
  });

  it(`${baseUrl} (DELETE): can not be logically deleted, when different organizationId`, async () => {
    const targetId = fixtureAoiIdList.filter(
      (x) => x.organizationId == TEST_ANOTHER_ORGANIZATION_ID,
    )[0].id;

    const body: AoiDeleteDto = plainToInstance(AoiDeleteDto, {
      ids: [targetId],
    });
    const res: request.Response = await request
      .default(httpServer)
      .delete(`${baseUrl}/`)
      .send(body)
      .set('Content-Type', 'application/json');

    expect(res.status).toEqual(404);

    const found = await dataSource.manager.findOne(Aoi, {
      where: { id: targetId },
    });
    expect(found).toBeTruthy();
    expect(found.deletedAt).toBeNull();
  });

  it(`${baseUrl} (DELETE): ng (ids is not set)`, async () => {
    const res: request.Response = await request
      .default(httpServer)
      .delete(`${baseUrl}/`)
      .set('Content-Type', 'application/json');

    expect(res.status).toEqual(400);
  });

  it(`${baseUrl} (DELETE): ng (ids is empty)`, async () => {
    const body: AoiDeleteDto = plainToInstance(AoiDeleteDto, {
      ids: [],
    });

    const res: request.Response = await request
      .default(httpServer)
      .delete(`${baseUrl}/`)
      .send(body)
      .set('Content-Type', 'application/json');

    expect(res.status).toEqual(400);
  });
});
