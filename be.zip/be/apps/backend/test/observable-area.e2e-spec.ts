import { INestApplication } from '@nestjs/common';
import * as request from 'supertest';
import { DataSource } from 'typeorm';

import { createAppForE2ETest } from './utils';
import { ObservableAreaSearchDto } from '../src/models/dto/observable-area/observable-area-search.dto';
import { Type, plainToInstance } from 'class-transformer';
import * as df from 'date-fns';
import { ObservableArea } from '@iris-lib/db/entities';
import { IsArray } from 'class-validator';
import Redis, { Cluster } from 'ioredis';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { RedisCache } from 'cache-manager-ioredis-yet';
import { ExpressAdapter } from '@nestjs/platform-express';

const baseUrl = '/observable-area';

class ObservableAreaSearchResponse {
  @IsArray()
  @Type(() => ObservableArea)
  items: ObservableArea[];
}

describe('ObservableAreaController (e2e)', () => {
  let app: INestApplication;
  let dataSource: DataSource;
  let cacheManager: Redis | Cluster;
  let httpServer: ExpressAdapter;

  beforeAll(async () => {
    app = await createAppForE2ETest();
    dataSource = app.get(DataSource);
    await app.init();
    cacheManager = (app.get(CACHE_MANAGER) as RedisCache).store.client;
    httpServer = app.getHttpServer();
  });

  afterAll(async () => {
    await cacheManager.flushdb();
    await cacheManager.quit();
    await dataSource.destroy();
    await app.close();
  });

  it(`${baseUrl}/search (POST)`, async () => {
    const satIds = ['ST0003'];
    const body: ObservableAreaSearchDto = plainToInstance(
      ObservableAreaSearchDto,
      {
        satIds,
        startAt: df.parse('20230328_150000', 'yyyyMMdd_HHmmss', new Date()),
        endAt: df.parse('20230329_150000', 'yyyyMMdd_HHmmss', new Date()),
        bounds: {
          type: 'Polygon',
          coordinates: [
            [
              [-100.250215, -66.611957],
              [-121.401844, -64.557515],
              [-119.190092, -62.959596],
              [-110.432081, -64.884794],
              [-100.250215, -66.611957],
            ],
          ],
        },
      },
    );
    const res: request.Response = await request
      .default(httpServer)
      .post(`${baseUrl}/search`)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(200);

    const result = plainToInstance(ObservableAreaSearchResponse, {
      items: res.body,
    });
    expect(result.items.length).toBeGreaterThan(0);
    expect(result.items.every((x) => satIds.includes(x.satId))).toBeTruthy();
  });

  it(`${baseUrl}/search (POST) Error when selecting unavailable satellite`, async () => {
    const satIds = ['ST0001'];
    const body: ObservableAreaSearchDto = plainToInstance(
      ObservableAreaSearchDto,
      {
        satIds,
        startAt: df.parse('20230328_150000', 'yyyyMMdd_HHmmss', new Date()),
        endAt: df.parse('20230329_150000', 'yyyyMMdd_HHmmss', new Date()),
        bounds: {
          type: 'Polygon',
          coordinates: [
            [
              [-105.794171, -67.59254, 0],
              [-94.539307, -68.57315, 0],
              [-93.883764, -66.71727, 0],
              [-104.351972, -65.799645, 0],
              [-105.794171, -67.59254, 0],
            ],
          ],
        },
      },
    );

    const res: request.Response = await request
      .default(httpServer)
      .post(`${baseUrl}/search`)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(400);
  });

  it(`${baseUrl}/search (POST) Error when selecting non-visible satellite`, async () => {
    const satIds = ['ST0002', 'ST0003'];
    const body: ObservableAreaSearchDto = plainToInstance(
      ObservableAreaSearchDto,
      {
        satIds,
        startAt: df.parse('20230328_150000', 'yyyyMMdd_HHmmss', new Date()),
        endAt: df.parse('20230329_150000', 'yyyyMMdd_HHmmss', new Date()),
        bounds: {
          type: 'Polygon',
          coordinates: [
            [
              [-105.794171, -67.59254, 0],
              [-94.539307, -68.57315, 0],
              [-93.883764, -66.71727, 0],
              [-104.351972, -65.799645, 0],
              [-105.794171, -67.59254, 0],
            ],
          ],
        },
      },
    );

    const res: request.Response = await request
      .default(httpServer)
      .post(`${baseUrl}/search`)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(400);
  });
});
