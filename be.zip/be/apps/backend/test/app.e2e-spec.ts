import { INestApplication } from '@nestjs/common';

import { createAppForE2ETest } from './utils';
import * as request from 'supertest';
import { ExpressAdapter } from '@nestjs/platform-express';
import { DataSource } from 'typeorm';
import Redis, { Cluster } from 'ioredis';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { RedisCache } from 'cache-manager-ioredis-yet';

describe('AppController (e2e)', () => {
  let app: INestApplication;
  let cacheManager: Redis | Cluster;
  let httpServer: ExpressAdapter;

  beforeAll(async () => {
    app = await createAppForE2ETest();
    await app.init();
    cacheManager = (app.get(CACHE_MANAGER) as RedisCache).store.client;
    httpServer = app.getHttpServer();
  });

  afterAll(async () => {
    await cacheManager.flushdb();
    await cacheManager.quit();
    const ds = app.get(DataSource);
    await ds.destroy();
    await app.close();
  });

  it('/ (GET)', async () => {
    const res = await request.default(httpServer).get('/');
    expect(res.status).toEqual(200);
    expect(res.text).toEqual('ok');
  });
});
