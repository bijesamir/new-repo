import { INestApplication } from '@nestjs/common';
import { ExpressAdapter } from '@nestjs/platform-express';
import { DataSource } from 'typeorm';
import { createAppForE2ETest } from './utils';
import * as request from 'supertest';
import Redis, { Cluster } from 'ioredis';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { RedisCache } from 'cache-manager-ioredis-yet';
import {
  FeatureCollectionDto,
  Item,
} from '../src/models/dto/stac/feature-collection.dto';
import {
  AppConstants,
  FlightDirection,
  ImagingMode,
  LookingDirection,
  StacConstellation,
  StacInstrument,
  StacLicense,
  StacProvider,
} from '@iris-lib/constants';
import { loadFixtureProductDataWithSceneInfo } from './fixtures';
import { ProductData, SceneInfo } from '@iris-lib/db/entities';
import { teardownTestData } from './global-teardown';
import { setUpTestData } from './global-setup';

const baseUrl = '/catalog';

describe('CatalogController', () => {
  let app: INestApplication;
  let dataSource: DataSource;
  let cacheManager: Redis | Cluster;
  let httpServer: ExpressAdapter;
  let fixtureProductData: ProductData[];

  beforeAll(async () => {
    app = await createAppForE2ETest();
    await app.init();
    dataSource = app.get(DataSource);
    cacheManager = (app.get(CACHE_MANAGER) as RedisCache).store.client;
    httpServer = app.getHttpServer();
    await teardownTestData(dataSource, 'all');
    await setUpTestData(dataSource, 'basic');

    fixtureProductData = await loadFixtureProductDataWithSceneInfo(dataSource);
  });

  afterAll(async () => {
    await teardownTestData(dataSource, 'basic');
    await setUpTestData(dataSource, 'all');

    await cacheManager.flushdb();
    await cacheManager.quit();
    await dataSource.destroy();
    await app.close();
  });

  const featureChecker = () => (feat: Item) => {
    expect(feat.type).toEqual('Feature');
    expect(feat.stac_version).toEqual('1.0.0');
    expect(feat.bbox).toHaveLength(4);
    expect(feat.bbox).toEqual(expect.arrayContaining([expect.any(Number)]));
    expect(feat.geometry).toEqual(
      expect.objectContaining({
        type: 'Polygon',
        coordinates: expect.any(Array),
      }),
    );
    expect(new Date(feat.properties.datetime)).toBeInstanceOf(Date);
    expect(new Date(feat.properties.start_datetime as string)).toBeInstanceOf(
      Date,
    );
    expect(new Date(feat.properties.end_datetime as string)).toBeInstanceOf(
      Date,
    );
    expect(new Date(feat.properties.created as string)).toBeInstanceOf(Date);
    expect(new Date(feat.properties.updated as string)).toBeInstanceOf(Date);
    expect(feat.properties).toEqual(
      expect.objectContaining({
        title: expect.any(String),
        license: StacLicense.Proprietary,
        providers: StacProvider.synspective,
        platform: expect.any(String),
        instruments: StacInstrument.strixsar,
        constellation: StacConstellation.Strix,
        'syns:scene_info_id': expect.any(String),
        'syns:scene_no': expect.any(Number),
        'syns:tasking_info_id': expect.any(String),
        'syns:imaging_mode': expect.any(Number),
        'syns:flight_direction': expect.any(Number),
        'syns:looking_direction': expect.any(Number),
        'syns:imaging_mode_param': expect.any(String),
        'syns:flight_direction_param': expect.any(String),
        'syns:looking_direction_param': expect.any(String),
        'syns:offnadir_angle': expect.any(Number),
      }),
    );
    expect(feat.collection).toEqual('StriX');
    expect(feat.links).toHaveLength(2);
    expect(feat.links).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          rel: 'root',
          href: process.env.IRIS_API_URL,
        }),
        expect.objectContaining({
          rel: 'thumbnail',
          href: expect.any(String),
        }),
      ]),
    );
    Object.values(feat.assets).forEach((asset) => {
      expect(asset).toEqual(
        expect.objectContaining({
          title: expect.any(String),
          href: expect.any(String),
        }),
      );
    });
  };

  describe.each([['GET'], ['POST']])(`Search`, (method) => {
    it(`${baseUrl}/search (${method}): all`, async () => {
      const targetSceneInfos = fixtureProductData.map((p) => p.sceneInfo);

      let res: request.Response;
      switch (method) {
        case 'GET':
          res = await request
            .default(httpServer)
            .get(`${baseUrl}/search`)
            .query({})
            .set('Content-Type', 'application/json')
            .send();
          break;
        case 'POST':
          res = await request
            .default(httpServer)
            .post(`${baseUrl}/search`)
            .set('Content-Type', 'application/json')
            .send();
          break;
      }
      expect(res.status).toEqual(200);

      const result = res.body as FeatureCollectionDto;
      expect(result.type).toEqual('FeatureCollection');
      expect(result.context).toEqual(
        expect.objectContaining({
          matched: targetSceneInfos.length,
          returned: targetSceneInfos.length,
          limit: 10,
        }),
      );
      expect(result.links).toHaveLength(1);
      expect(result.links).toEqual(
        expect.arrayContaining([
          { rel: 'root', href: process.env.IRIS_API_URL },
        ]),
      );

      expect(result.features).toHaveLength(targetSceneInfos.length);
      result.features.forEach((f, idx) => {
        expect(f.id).toEqual(targetSceneInfos[idx].itemId);
        expect(f.properties['syns:scene_info_id']).toEqual(
          targetSceneInfos[idx].id,
        );
      });
      result.features.forEach(featureChecker());
    });

    it(`${baseUrl}/search (${method}): sortby id ASC`, async () => {
      const targetSceneInfos = fixtureProductData
        .map((p) => p.sceneInfo)
        .sort((sia, sib) => (sib.itemId > sia.itemId ? -1 : 1));
      let res: request.Response;
      switch (method) {
        case 'GET':
          res = await request
            .default(httpServer)
            .get(`${baseUrl}/search`)
            .query({ sortby: 'id' })
            .set('Content-Type', 'application/json')
            .send();
          break;
        case 'POST':
          const body = {
            sortby: [
              {
                field: 'id',
                direction: 'asc',
              },
            ],
          };
          res = await request
            .default(httpServer)
            .post(`${baseUrl}/search`)
            .set('Content-Type', 'application/json')
            .send(body);
          break;
      }
      expect(res.status).toEqual(200);

      const result = res.body as FeatureCollectionDto;
      expect(result.type).toEqual('FeatureCollection');
      expect(result.context).toEqual(
        expect.objectContaining({
          matched: targetSceneInfos.length,
          returned: targetSceneInfos.length,
          limit: 10,
        }),
      );
      expect(result.links).toHaveLength(1);
      expect(result.links).toEqual(
        expect.arrayContaining([
          { rel: 'root', href: process.env.IRIS_API_URL },
        ]),
      );

      expect(result.features).toHaveLength(targetSceneInfos.length);
      result.features.forEach((f, idx) => {
        expect(f.id).toEqual(targetSceneInfos[idx].itemId);
        expect(f.properties['syns:scene_info_id']).toEqual(
          targetSceneInfos[idx].id,
        );
      });
      result.features.forEach(featureChecker());
    });

    it(`${baseUrl}/search (${method}): sortby datetime DESC, updated ASC`, async () => {
      const targetSceneInfos = fixtureProductData.map((p) => p.sceneInfo);
      // second & third items are swapped
      [targetSceneInfos[1], targetSceneInfos[2]] = [
        targetSceneInfos[2],
        targetSceneInfos[1],
      ];

      let res: request.Response;
      switch (method) {
        case 'GET':
          res = await request
            .default(httpServer)
            .get(`${baseUrl}/search`)
            .query({
              // "%2B" is url-decoded to "+"
              sortby: decodeURIComponent('-datetime,%2Bupdated'),
            })
            .set('Content-Type', 'application/json')
            .send();
          break;
        case 'POST':
          const body = {
            sortby: [
              {
                field: 'datetime',
                direction: 'desc',
              },
              {
                field: 'updated',
                direction: 'asc',
              },
            ],
          };
          res = await request
            .default(httpServer)
            .post(`${baseUrl}/search`)
            .set('Content-Type', 'application/json')
            .send(body);
          break;
      }
      expect(res.status).toEqual(200);

      const result = res.body as FeatureCollectionDto;
      expect(result.type).toEqual('FeatureCollection');
      expect(result.context).toEqual(
        expect.objectContaining({
          matched: targetSceneInfos.length,
          returned: targetSceneInfos.length,
          limit: 10,
        }),
      );
      expect(result.links).toHaveLength(1);
      expect(result.links).toEqual(
        expect.arrayContaining([
          { rel: 'root', href: process.env.IRIS_API_URL },
        ]),
      );

      expect(result.features).toHaveLength(targetSceneInfos.length);
      result.features.forEach((f, idx) => {
        expect(f.id).toEqual(targetSceneInfos[idx].itemId);
        expect(f.properties['syns:scene_info_id']).toEqual(
          targetSceneInfos[idx].id,
        );
      });
      result.features.forEach(featureChecker());
    });

    it(`${baseUrl}/search (${method}): limit (page 1)`, async () => {
      const targetSceneInfos = fixtureProductData
        .map((p) => p.sceneInfo)
        .slice(0, 2);

      let res: request.Response;
      switch (method) {
        case 'GET':
          res = await request
            .default(httpServer)
            .get(`${baseUrl}/search`)
            .query({
              limit: 2,
              page: 1,
            })
            .set('Content-Type', 'application/json')
            .send();
          break;
        case 'POST':
          const body = {
            limit: 2,
            page: 1,
          };
          res = await request
            .default(httpServer)
            .post(`${baseUrl}/search`)
            .set('Content-Type', 'application/json')
            .send(body);
          break;
      }
      expect(res.status).toEqual(200);

      const expectedLinks: object[] = [
        { rel: 'root', href: process.env.IRIS_API_URL },
      ];
      switch (method) {
        case 'GET':
          expectedLinks.push({
            rel: 'next',
            href: `${process.env.IRIS_API_URL}/v${AppConstants.DEFAULT_VERSION}/catalog/search?page=2&limit=2`,
          });
          break;
        case 'POST':
          expectedLinks.push({
            rel: 'next',
            href: `${process.env.IRIS_API_URL}/v${AppConstants.DEFAULT_VERSION}/catalog/search`,
            method: 'POST',
            body: {
              page: 2,
              limit: 2,
            },
            merge: true,
          });
          break;
      }
      const result = res.body as FeatureCollectionDto;
      expect(result.type).toEqual('FeatureCollection');
      expect(result.context).toEqual(
        expect.objectContaining({
          matched: 3,
          returned: targetSceneInfos.length,
          limit: 2,
        }),
      );
      expect(result.links).toHaveLength(2);
      expect(result.links).toEqual(expect.arrayContaining(expectedLinks));

      expect(result.features).toHaveLength(targetSceneInfos.length);
      result.features.forEach((f, idx) => {
        expect(f.id).toEqual(targetSceneInfos[idx].itemId);
        expect(f.properties['syns:scene_info_id']).toEqual(
          targetSceneInfos[idx].id,
        );
      });
      result.features.forEach(featureChecker());
    });

    it(`${baseUrl}/search (${method}): limit (page 2)`, async () => {
      const targetSceneInfos = fixtureProductData
        .map((p) => p.sceneInfo)
        .slice(2);

      let res: request.Response;
      switch (method) {
        case 'GET':
          res = await request
            .default(httpServer)
            .get(`${baseUrl}/search`)
            .query({
              limit: 2,
              page: 2,
            })
            .set('Content-Type', 'application/json')
            .send();
          break;
        case 'POST':
          const body = {
            limit: 2,
            page: 2,
          };
          res = await request
            .default(httpServer)
            .post(`${baseUrl}/search`)
            .set('Content-Type', 'application/json')
            .send(body);
          break;
      }
      expect(res.status).toEqual(200);

      const expectedLinks: object[] = [
        { rel: 'root', href: process.env.IRIS_API_URL },
      ];
      switch (method) {
        case 'GET':
          expectedLinks.push({
            rel: 'prev',
            href: `${process.env.IRIS_API_URL}/v${AppConstants.DEFAULT_VERSION}/catalog/search?page=1&limit=2`,
          });
          break;
        case 'POST':
          expectedLinks.push({
            rel: 'prev',
            href: `${process.env.IRIS_API_URL}/v${AppConstants.DEFAULT_VERSION}/catalog/search`,
            method: 'POST',
            body: {
              page: 1,
              limit: 2,
            },
            merge: true,
          });
          break;
      }
      const result = res.body as FeatureCollectionDto;
      expect(result.type).toEqual('FeatureCollection');
      expect(result.context).toEqual(
        expect.objectContaining({
          matched: 3,
          returned: targetSceneInfos.length,
          limit: 2,
        }),
      );
      expect(result.links).toHaveLength(2);
      expect(result.links).toEqual(expect.arrayContaining(expectedLinks));

      expect(result.features).toHaveLength(targetSceneInfos.length);
      result.features.forEach((f, idx) => {
        expect(f.id).toEqual(targetSceneInfos[idx].itemId);
        expect(f.properties['syns:scene_info_id']).toEqual(
          targetSceneInfos[idx].id,
        );
      });
      result.features.forEach(featureChecker());
    });

    it(`${baseUrl}/search (${method}): filter by bbox`, async () => {
      const targetSceneInfos = fixtureProductData
        .map((p) => p.sceneInfo)
        .slice(0, 1);

      const bbox = '-66.8,-27.5,-66.7,-27';

      let res: request.Response;
      switch (method) {
        case 'GET':
          res = await request
            .default(httpServer)
            .get(`${baseUrl}/search`)
            .query({ bbox })
            .set('Content-Type', 'application/json')
            .send();
          break;
        case 'POST':
          const body = {
            bbox: bbox.split(',').map((v) => +v),
          };
          res = await request
            .default(httpServer)
            .post(`${baseUrl}/search`)
            .set('Content-Type', 'application/json')
            .send(body);
          break;
      }
      expect(res.status).toEqual(200);

      const result = res.body as FeatureCollectionDto;
      expect(result.type).toEqual('FeatureCollection');
      expect(result.context).toEqual(
        expect.objectContaining({
          matched: targetSceneInfos.length,
          returned: targetSceneInfos.length,
          limit: 10,
        }),
      );
      expect(result.links).toHaveLength(1);
      expect(result.links).toEqual(
        expect.arrayContaining([
          { rel: 'root', href: process.env.IRIS_API_URL },
        ]),
      );

      expect(result.features).toHaveLength(targetSceneInfos.length);
      result.features.forEach((f, idx) => {
        expect(f.id).toEqual(targetSceneInfos[idx].itemId);
        expect(f.properties['syns:scene_info_id']).toEqual(
          targetSceneInfos[idx].id,
        );
      });
      result.features.forEach(featureChecker());
    });

    it(`${baseUrl}/search (${method}): filter by ids`, async () => {
      const targetSceneInfos = fixtureProductData
        .map((p) => p.sceneInfo)
        .slice(0, 2);
      const ids = targetSceneInfos.map((si) => si.itemId);

      let res: request.Response;
      switch (method) {
        case 'GET':
          res = await request
            .default(httpServer)
            .get(`${baseUrl}/search`)
            .query({ ids: ids.join(',') })
            .set('Content-Type', 'application/json')
            .send();
          break;
        case 'POST':
          const body = { ids };
          res = await request
            .default(httpServer)
            .post(`${baseUrl}/search`)
            .set('Content-Type', 'application/json')
            .send(body);
          break;
      }
      expect(res.status).toEqual(200);

      const result = res.body as FeatureCollectionDto;
      expect(result.type).toEqual('FeatureCollection');
      expect(result.context).toEqual(
        expect.objectContaining({
          matched: targetSceneInfos.length,
          returned: targetSceneInfos.length,
          limit: 10,
        }),
      );
      expect(result.links).toHaveLength(1);
      expect(result.links).toEqual(
        expect.arrayContaining([
          { rel: 'root', href: process.env.IRIS_API_URL },
        ]),
      );

      expect(result.features).toHaveLength(targetSceneInfos.length);
      result.features.forEach((f, idx) => {
        expect(f.id).toEqual(targetSceneInfos[idx].itemId);
        expect(f.properties['syns:scene_info_id']).toEqual(
          targetSceneInfos[idx].id,
        );
      });
      result.features.forEach(featureChecker());
    });

    it(`${baseUrl}/search (${method}): filter by collections`, async () => {
      const targetSceneInfos = fixtureProductData.map((p) => p.sceneInfo);
      const collections = ['StriX'];

      let res: request.Response;
      switch (method) {
        case 'GET':
          res = await request
            .default(httpServer)
            .get(`${baseUrl}/search`)
            .query({ collections: collections.join(',') })
            .set('Content-Type', 'application/json')
            .send();
          break;
        case 'POST':
          const body = { collections };
          res = await request
            .default(httpServer)
            .post(`${baseUrl}/search`)
            .set('Content-Type', 'application/json')
            .send(body);
          break;
      }
      expect(res.status).toEqual(200);

      const result = res.body as FeatureCollectionDto;
      expect(result.type).toEqual('FeatureCollection');
      expect(result.context).toEqual(
        expect.objectContaining({
          matched: targetSceneInfos.length,
          returned: targetSceneInfos.length,
          limit: 10,
        }),
      );
      expect(result.links).toHaveLength(1);
      expect(result.links).toEqual(
        expect.arrayContaining([
          { rel: 'root', href: process.env.IRIS_API_URL },
        ]),
      );

      expect(result.features).toHaveLength(targetSceneInfos.length);
      result.features.forEach((f, idx) => {
        expect(f.id).toEqual(targetSceneInfos[idx].itemId);
        expect(f.properties['syns:scene_info_id']).toEqual(
          targetSceneInfos[idx].id,
        );
      });
      result.features.forEach(featureChecker());
    });

    it.each([
      ['exact', '2023-02-01T01:01:01.000Z', 1],
      [
        'closed interval',
        '2023-01-01T00:00:00.000Z/2023-01-01T23:59:59.999Z',
        2,
      ],
      ['open interval [1]', '2023-02-01T00:00:00.000Z/..', 1],
      ['open interval [2]', '../2023-01-01T23:59:59.999Z', 2],
    ])(
      `${baseUrl}/search (${method}): filter by datetime (%s)`,
      async (_, datetime, groupNo) => {
        let targetSceneInfos: SceneInfo[];
        switch (groupNo) {
          case 1:
            targetSceneInfos = fixtureProductData
              .map((p) => p.sceneInfo)
              .slice(0, 1);
            break;
          case 2:
            targetSceneInfos = fixtureProductData
              .map((p) => p.sceneInfo)
              .slice(1);
            break;
        }

        let res: request.Response;
        switch (method) {
          case 'GET':
            res = await request
              .default(httpServer)
              .get(`${baseUrl}/search`)
              .query({ datetime })
              .set('Content-Type', 'application/json')
              .send();
            break;
          case 'POST':
            const body = { datetime };
            res = await request
              .default(httpServer)
              .post(`${baseUrl}/search`)
              .set('Content-Type', 'application/json')
              .send(body);
            break;
        }
        expect(res.status).toEqual(200);

        const result = res.body as FeatureCollectionDto;
        expect(result.type).toEqual('FeatureCollection');
        expect(result.context).toEqual(
          expect.objectContaining({
            matched: targetSceneInfos.length,
            returned: targetSceneInfos.length,
            limit: 10,
          }),
        );
        expect(result.links).toHaveLength(1);
        expect(result.links).toEqual(
          expect.arrayContaining([
            { rel: 'root', href: process.env.IRIS_API_URL },
          ]),
        );

        expect(result.features).toHaveLength(targetSceneInfos.length);
        result.features.forEach((f, idx) => {
          expect(f.id).toEqual(targetSceneInfos[idx].itemId);
          expect(f.properties['syns:scene_info_id']).toEqual(
            targetSceneInfos[idx].id,
          );
        });
        result.features.forEach(featureChecker());
      },
    );

    it(`${baseUrl}/search (${method}): filter by intersects`, async () => {
      const targetSceneInfos = fixtureProductData
        .map((p) => p.sceneInfo)
        .slice(0, 1);
      const intersects = {
        type: 'Polygon',
        coordinates: [
          [
            [-66.7, -27.3],
            [-66.76, -27.44],
            [-66.55, -27.4],
            [-66.58, -27.26],
            [-66.7, -27.3],
          ],
        ],
      };
      let res: request.Response;
      switch (method) {
        case 'GET':
          res = await request
            .default(httpServer)
            .get(`${baseUrl}/search`)
            .query({ intersects: JSON.stringify(intersects) })
            .set('Content-Type', 'application/json')
            .send();
          break;
        case 'POST':
          const body = {
            intersects,
          };
          res = await request
            .default(httpServer)
            .post(`${baseUrl}/search`)
            .set('Content-Type', 'application/json')
            .send(body);
          break;
      }
      expect(res.status).toEqual(200);

      const result = res.body as FeatureCollectionDto;
      expect(result.type).toEqual('FeatureCollection');
      expect(result.context).toEqual(
        expect.objectContaining({
          matched: targetSceneInfos.length,
          returned: targetSceneInfos.length,
          limit: 10,
        }),
      );
      expect(result.links).toHaveLength(1);
      expect(result.links).toEqual(
        expect.arrayContaining([
          { rel: 'root', href: process.env.IRIS_API_URL },
        ]),
      );

      expect(result.features).toHaveLength(targetSceneInfos.length);
      result.features.forEach((f, idx) => {
        expect(f.id).toEqual(targetSceneInfos[idx].itemId);
        expect(f.properties['syns:scene_info_id']).toEqual(
          targetSceneInfos[idx].id,
        );
      });
      result.features.forEach(featureChecker());
    });

    it.each([
      [
        'datetime',
        { gt: '2023-01-01T00:00:00.000Z', lt: '2023-01-01T23:59:59.999Z' },
      ],
      [
        'start_datetime',
        { gt: '2023-12-01T00:00:00.000Z', lt: '2023-12-31T23:59:59.999Z' },
      ],
      [
        'end_datetime',
        { gt: '2023-12-01T00:00:00.000Z', lt: '2023-12-31T23:59:59.999Z' },
      ],
      [
        'created',
        { gte: '2023-04-01T00:00:00.000Z', lte: '2023-04-03T23:59:59.999Z' },
      ],
      [
        'updated',
        { gte: '2023-04-04T00:00:00.000Z', lte: '2023-04-05T23:59:59.999Z' },
      ],
      ['id', { startsWith: 'StriX-1' }],
      ['title', { startsWith: 'StriX-1' }],
      ['platform', { endsWith: 'X-1' }],
      // skip 'syns:scene_info_id' because ids are not fixed
      ['syns:scene_no', { in: [2] }],
      ['syns:imaging_mode', { eq: ImagingMode.Stripmap }],
      ['syns:flight_direction', { eq: FlightDirection.Descending }],
      ['syns:looking_direction', { neq: LookingDirection.Left }],
      ['syns:offnadir_angle', { gte: 43, lte: 43.1 }],
    ])(`${baseUrl}/search (${method}): query by %s`, async (key, filter) => {
      const targetSceneInfos = fixtureProductData
        .map((p) => p.sceneInfo)
        .slice(1);

      const query = {
        [key]: filter,
      };

      let res: request.Response;
      switch (method) {
        case 'GET':
          res = await request
            .default(httpServer)
            .get(`${baseUrl}/search`)
            .query({ query: JSON.stringify(query) })
            .set('Content-Type', 'application/json')
            .send();
          break;
        case 'POST':
          const body = { query };
          res = await request
            .default(httpServer)
            .post(`${baseUrl}/search`)
            .set('Content-Type', 'application/json')
            .send(body);
          break;
      }
      expect(res.status).toEqual(200);

      const result = res.body as FeatureCollectionDto;
      expect(result.type).toEqual('FeatureCollection');
      expect(result.context).toEqual(
        expect.objectContaining({
          matched: targetSceneInfos.length,
          returned: targetSceneInfos.length,
          limit: 10,
        }),
      );
      expect(result.links).toHaveLength(1);
      expect(result.links).toEqual(
        expect.arrayContaining([
          { rel: 'root', href: process.env.IRIS_API_URL },
        ]),
      );

      expect(result.features).toHaveLength(targetSceneInfos.length);
      result.features.forEach((f, idx) => {
        expect(f.id).toEqual(targetSceneInfos[idx].itemId);
        expect(f.properties['syns:scene_info_id']).toEqual(
          targetSceneInfos[idx].id,
        );
      });
      result.features.forEach(featureChecker());
    });

    it(`${baseUrl}/search (${method}): query by combo`, async () => {
      const targetSceneInfos = fixtureProductData
        .map((p) => p.sceneInfo)
        .slice(2);

      const query = {
        'syns:imaging_mode': {
          eq: ImagingMode.Stripmap,
        },
        start_datetime: {
          in: ['2023-12-01T01:01:00.000Z'],
        },
      };

      let res: request.Response;
      switch (method) {
        case 'GET':
          res = await request
            .default(httpServer)
            .get(`${baseUrl}/search`)
            .query({ query: JSON.stringify(query) })
            .set('Content-Type', 'application/json')
            .send();
          break;
        case 'POST':
          const body = { query };
          res = await request
            .default(httpServer)
            .post(`${baseUrl}/search`)
            .set('Content-Type', 'application/json')
            .send(body);
          break;
      }
      expect(res.status).toEqual(200);

      const result = res.body as FeatureCollectionDto;
      expect(result.type).toEqual('FeatureCollection');
      expect(result.context).toEqual(
        expect.objectContaining({
          matched: targetSceneInfos.length,
          returned: targetSceneInfos.length,
          limit: 10,
        }),
      );
      expect(result.links).toHaveLength(1);
      expect(result.links).toEqual(
        expect.arrayContaining([
          { rel: 'root', href: process.env.IRIS_API_URL },
        ]),
      );

      expect(result.features).toHaveLength(targetSceneInfos.length);
      result.features.forEach((f, idx) => {
        expect(f.id).toEqual(targetSceneInfos[idx].itemId);
        expect(f.properties['syns:scene_info_id']).toEqual(
          targetSceneInfos[idx].id,
        );
      });
      result.features.forEach(featureChecker());
    });
  });
});
