import { INestApplication } from '@nestjs/common';
import { ExpressAdapter } from '@nestjs/platform-express';
import { DataSource } from 'typeorm';
import { createAppForE2ETest } from './utils';
import { ProcessingStatus } from '@iris-lib/constants';
import * as request from 'supertest';
import { ReprocessingRequest } from '@iris-lib/db/entities';
import { loadFixtureReprocessingRequest } from './fixtures';

import Redis, { Cluster } from 'ioredis';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { RedisCache } from 'cache-manager-ioredis-yet';
import { ReprocessingRequestUpdateStatusDto } from '../src/models/dto/reprocessing-request/reprocessing-reques-update-status.dto';
import { Paginated } from 'nestjs-paginate';

const baseUrl = '/reprocessing';

describe('ReprocessingRequestController', () => {
  let app: INestApplication;
  let dataSource: DataSource;
  let cacheManager: Redis | Cluster;
  let httpServer: ExpressAdapter;

  let fixture: ReprocessingRequest[];
  let testForUpdateOperation: ReprocessingRequest;

  beforeAll(async () => {
    app = await createAppForE2ETest();
    await app.init();
    dataSource = app.get(DataSource);
    cacheManager = (app.get(CACHE_MANAGER) as RedisCache).store.client;
    httpServer = app.getHttpServer();
    fixture = await loadFixtureReprocessingRequest(dataSource);
    testForUpdateOperation = fixture.find((pdr) => {
      return pdr.status === ProcessingStatus.New;
    });
  });

  beforeEach(() => {});

  afterAll(async () => {
    await cacheManager.flushdb();
    await cacheManager.quit();
    await dataSource.destroy();
    await app.close();
  });

  afterEach(async () => {
    await dataSource.getRepository(ReprocessingRequest).update(
      { id: testForUpdateOperation.id },
      {
        updatedAt: testForUpdateOperation.updatedAt,
        status: ProcessingStatus.New,
      },
    );
  });

  it(`${baseUrl} (GET): all`, async () => {
    const res: request.Response = await request
      .default(httpServer)
      .get(`${baseUrl}`)
      .set('Content-Type', 'application/json')
      .query({})
      .send();

    expect(res.status).toEqual(200);

    const result = res.body as Paginated<ReprocessingRequest>;
    expect(result.data).toHaveLength(16);
  });

  it(`${baseUrl} (GET): sortBy updatedAt ASC`, async () => {
    const res: request.Response = await request
      .default(httpServer)
      .get(`${baseUrl}`)
      .set('Content-Type', 'application/json')
      .query({
        sortBy: 'updatedAt:ASC',
      })
      .send();

    expect(res.status).toEqual(200);

    const result = res.body as Paginated<ReprocessingRequest>;
    expect(result.data).toHaveLength(16);
    expect(result.data[1].archivePurchaseRequests).toHaveLength(2);
  });

  it.each([
    // Comment out this bellow test because bellow commented line is not stable
    ['productData.taskingInfo.imagingMode:DESC', 200, /^e5000051.*/],
    //['productData.taskingInfo.imagingMode:ASC', 200, /^e5000052.*/],
    ['productData.taskingInfo.scsOrderCode:DESC', 200, /^e5000044.*/],
    ['productData.taskingInfo.scsOrderCode:ASC', 200, /^e5000051.*/],
    //['productData.taskingInfo.flightDirection:DESC', 200, /^e5000052.*/],
    ['productData.taskingInfo.flightDirection:ASC', 200, /^e5000044.*/],
    ['productData.taskingInfo.lookingDirection:DESC', 200, /^e5000044.*/],
    //['productData.taskingInfo.lookingDirection:ASC', 200, /^e5000052.*/],
    ['updatedAt:DESC', 200, /^e5000052.*/],
    ['updatedAt:ASC', 200, /^e5000042.*/],
  ])(`${baseUrl}/search (GET) sortBy %s`, async (key, expStatus, expId) => {
    const query = { sortBy: key };
    const res: request.Response = await request
      .default(httpServer)
      .get(`${baseUrl}`)
      .set('Content-Type', 'application/json')
      .query(query)
      .send();
    expect(res.status).toEqual(expStatus);
    const result = res.body as Paginated<ReprocessingRequest>;
    expect(result.data[0].productData.id).toMatch(expId);
  });

  it(`${baseUrl} (GET): limit (page 1)`, async () => {
    const res: request.Response = await request
      .default(httpServer)
      .get(`${baseUrl}`)
      .set('Content-Type', 'application/json')
      .query({
        limit: 3,
        page: 1,
      })
      .send();

    expect(res.status).toEqual(200);

    const result = res.body as Paginated<ReprocessingRequest>;
    expect(result.data).toHaveLength(3);
  });

  it(`${baseUrl} (GET): limit (page 2)`, async () => {
    const res: request.Response = await request
      .default(httpServer)
      .get(`${baseUrl}`)
      .set('Content-Type', 'application/json')
      .query({
        limit: 3,
        page: 2,
      })
      .send();

    expect(res.status).toEqual(200);

    const result = res.body as Paginated<ReprocessingRequest>;
    expect(result.data).toHaveLength(3);
  });
  it(`ok ${baseUrl}/update-status (PUT) from new to failed`, async () => {
    const body: ReprocessingRequestUpdateStatusDto = {
      ids: [testForUpdateOperation.id],
      status: ProcessingStatus.Failed,
    };
    const res: request.Response = await request
      .default(httpServer)
      .put(`${baseUrl}/update-status`)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(200);

    const result = await dataSource.getRepository(ReprocessingRequest).findOne({
      where: { id: testForUpdateOperation.id },
    });
    expect(result.status).toEqual(ProcessingStatus.Failed);
  });

  it(`ok ${baseUrl}/update-status (PUT) from new to completed`, async () => {
    const body: ReprocessingRequestUpdateStatusDto = {
      ids: [testForUpdateOperation.id],
      status: ProcessingStatus.Completed,
    };
    const res: request.Response = await request
      .default(httpServer)
      .put(`${baseUrl}/update-status`)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(200);

    const result = await dataSource.getRepository(ReprocessingRequest).findOne({
      where: { id: testForUpdateOperation.id },
    });
    expect(result.status).toEqual(ProcessingStatus.Completed);
  });

  it(`ng ${baseUrl}/update-status`, async () => {
    const body: ReprocessingRequestUpdateStatusDto = {
      ids: [testForUpdateOperation.id],
      status: 'unknown',
    };

    const res: request.Response = await request
      .default(httpServer)
      .put(`${baseUrl}/update-status `)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(400);
  });
});
