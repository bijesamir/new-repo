import {
  ContractType,
  TEST_ANOTHER_ORGANIZATION_ID,
  TEST_ORGANIZATION_ID,
} from '@iris-lib/constants';
import { ProductData, ProductDataVersion } from '@iris-lib/db/entities';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { INestApplication } from '@nestjs/common';
import { ExpressAdapter } from '@nestjs/platform-express';
import { RedisCache } from 'cache-manager-ioredis-yet';
import Redis, { Cluster } from 'ioredis';
import { Readable } from 'stream';
import * as request from 'supertest';
import { DataSource } from 'typeorm';
import {
  DUMMY_ANOTHER_CONTRACTS,
  DUMMY_ANOTHER_USER,
  DUMMY_CONTRACTS,
  DUMMY_USER,
  DummyAuthGuard,
} from '@iris-lib/guards';
import { GcsServiceService } from '../src/infra/gcs-service/gcs-service.service';
import { ProductDataVersionDto } from '../src/models/dto/product-data-version/product-data-version.dto';
import { ProductDataUsecaseService } from '../src/usecases/product-data/product-data-usecase.service';
import {
  loadFixtureProductDataVersion,
  loadFixtureProductSceneData,
} from './fixtures';
import { createAppForE2ETest } from './utils';
import { GcPubsubServiceService } from '../src/infra/gc-pubsub-service/gc-pubsub-service.service';
import { TEST_FAKE_TIME } from './fixtures/tasking-info';

const baseUrl = '/product-data-version';

describe('ProductDataVersionController', () => {
  let app: INestApplication;
  let dataSource: DataSource;
  let cacheManager: Redis | Cluster;
  let httpServer: ExpressAdapter;
  let productDataUsecaseService: ProductDataUsecaseService;
  let fixtureProductDataVersions: ProductDataVersion[];
  let fixtureProductSceneData: ProductData[];

  const mockGcsService = {
    generateV4ReadSignedUrl: jest.fn(),
    createReadStream: jest.fn((_bucket: string, name: string) => {
      const readable = new Readable();
      readable.push(`write: ${name}`);
      readable.push(null);

      return readable;
    }),
    checkFileExists: jest.fn(() => {
      return [true];
    }),
  };
  const mockGcPubsubService = {
    publishDownloadProductDataEvent: jest.fn(() => {
      return;
    }),
    emitDownloadProductDataEvent: jest.fn(() => {
      return;
    }),
  };

  beforeAll(async () => {
    jest.useFakeTimers({
      advanceTimers: true,
      now: TEST_FAKE_TIME,
    });

    app = await createAppForE2ETest((tm) => {
      tm.overrideProvider(GcsServiceService).useValue(mockGcsService);
      tm.overrideProvider(GcPubsubServiceService).useValue(mockGcPubsubService);
    });
    await app.init();
    dataSource = app.get(DataSource);
    cacheManager = (app.get(CACHE_MANAGER) as RedisCache).store.client;
    httpServer = app.getHttpServer();
    productDataUsecaseService = app.get(ProductDataUsecaseService);
    fixtureProductSceneData = await loadFixtureProductSceneData(dataSource);
    fixtureProductDataVersions =
      await loadFixtureProductDataVersion(dataSource);
  });

  afterAll(async () => {
    await cacheManager.flushdb();
    await cacheManager.quit();
    await dataSource.destroy();
    await app.close();
    jest.useRealTimers();
  });

  describe(`Get`, () => {
    it.each([
      [200, 'tasking only', /^e5000021/, 0, 'AnotherUser'],
      [200, 'tasking', /^e5000052/, 1, 'AnotherUser'],
      [200, 'tasking&archive', /^e5000031/, 0, 'User'],

      //TBD: current behavior we didn't check  expired check for view
      [200, 'tasking expired', /^e5000051/, 0, 'AnotherUser'],

      //TBD: current spec we are not supporting archive ordered product data view
      [404, 'archive', /^e5000051/, 0, 'User'],
      [404, 'archive', /^e5000052/, 0, 'User'],
      [404, 'archive', /^e5000031/, 0, 'AnotherUser'],
      [404, 'archive', /^e5000032/, 0, 'AnotherUser'],

      // expected 404 case
      [404, 'not owner', /^e5000047/, 0, 'User'],
      [404, 'archive expired', /^e5000023/, 0, 'User'],
    ])(
      `${baseUrl}/:id (GET) %d %s %s %s %s`,
      async (expectCode, _, targetPD, targetPDV, user) => {
        mockGcsService.generateV4ReadSignedUrl = jest.fn((bucket, location) => {
          return Promise.resolve([location]);
        });
        mockGcsService.checkFileExists = jest.fn(() => {
          return [true];
        });
        const target = fixtureProductSceneData.find((pd) =>
          pd.id.match(targetPD),
        );

        if (user === 'User') {
          DummyAuthGuard.setDummy(DUMMY_USER, DUMMY_CONTRACTS);
        } else if (user === 'AnotherUser') {
          DummyAuthGuard.setDummy(DUMMY_ANOTHER_USER, DUMMY_ANOTHER_CONTRACTS);
        }
        const res: request.Response = await request
          .default(httpServer)
          .get(`${baseUrl}/${target.productDataVersions[targetPDV].id}`)
          .send();
        expect(res.status).toEqual(expectCode);
        if (expectCode === 200) {
          const result = res.body as ProductDataVersion;

          expect(result.id).toEqual(target.productDataVersions[targetPDV].id);
          expect(result.productData.id).toEqual(target.id);
        }
      },
    );
  });

  describe(`Download`, () => {
    it.each([
      [
        302,
        'tasking only',
        /^e5000021/,
        0,
        'AnotherUser',
        ContractType.Tasking,
      ],
      [302, 'tasking', /^e5000052/, 1, 'AnotherUser', ContractType.Tasking],
      [302, 'archive', /^e5000051/, 0, 'User', ContractType.Archive],
      [302, 'archive', /^e5000052/, 0, 'User', ContractType.Archive],
      [302, 'archive', /^e5000031/, 0, 'AnotherUser', ContractType.Archive],
      [302, 'archive', /^e5000032/, 0, 'AnotherUser', ContractType.Archive],
      [302, 'tasking&archive', /^e5000031/, 0, 'User', ContractType.Tasking],
      [404, 'not owner', /^e5000047/, 0, 'User', ContractType.Tasking],
      [
        404,
        'tasking expired',
        /^e5000051/,
        0,
        'AnotherUser',
        ContractType.Tasking,
      ],
      [404, 'archive expired', /^e5000023/, 0, 'User', ContractType.Tasking],
    ])(
      `${baseUrl}/:id/download (GET) %d %s %s %s %s`,
      async (
        expectCode,
        _,
        targetPD,
        targetPDV,
        user,
        expectedContractType,
      ) => {
        mockGcsService.generateV4ReadSignedUrl = jest.fn((bucket, location) => {
          return Promise.resolve([location]);
        });
        mockGcsService.checkFileExists = jest.fn(() => {
          return [true];
        });
        mockGcPubsubService.publishDownloadProductDataEvent = jest.fn(() => {
          return;
        });
        mockGcPubsubService.emitDownloadProductDataEvent = jest.fn(() => {
          return;
        });
        const target = fixtureProductSceneData.find((pd) =>
          pd.id.match(targetPD),
        );

        let expectedUserId: string;
        switch (user) {
          case 'User':
            DummyAuthGuard.setDummy(DUMMY_USER, DUMMY_CONTRACTS);
            expectedUserId = String(DUMMY_USER.userId);
            break;
          case 'AnotherUser':
            DummyAuthGuard.setDummy(
              DUMMY_ANOTHER_USER,
              DUMMY_ANOTHER_CONTRACTS,
            );
            expectedUserId = String(DUMMY_ANOTHER_USER.userId);
            break;
        }
        const res: request.Response = await request
          .default(httpServer)
          .get(
            `${baseUrl}/${target.productDataVersions[targetPDV].id}/download`,
          )
          .send();
        expect(res.status).toEqual(expectCode);

        if (expectCode === 302) {
          expect(res.header.location).toMatch(
            target.productDataVersions[targetPDV].location,
          );

          expect(
            mockGcPubsubService.emitDownloadProductDataEvent,
          ).toHaveBeenCalledTimes(1);

          switch (expectedContractType) {
            case ContractType.Tasking:
              expect(
                mockGcPubsubService.emitDownloadProductDataEvent,
              ).toHaveBeenCalledWith(
                expect.objectContaining({
                  contractType: expectedContractType,
                  userId: expectedUserId,
                }),
              );
              expect(
                mockGcPubsubService.emitDownloadProductDataEvent,
              ).toHaveBeenCalledWith(
                expect.not.objectContaining({
                  archivePurchaseRequestRequestId: expect.anything(),
                }),
              );
              break;
            case ContractType.Archive:
              expect(
                mockGcPubsubService.emitDownloadProductDataEvent,
              ).toHaveBeenCalledWith(
                expect.objectContaining({
                  contractType: expectedContractType,
                  userId: expectedUserId,
                  archivePurchaseRequestRequestId: expect.anything(),
                }),
              );
              break;
          }
        } else {
          expect(
            mockGcPubsubService.emitDownloadProductDataEvent,
          ).toHaveBeenCalledTimes(0);
        }
      },
    );
  });

  describe('Quicklook', () => {
    it.each([
      ['GRD_GEOTIFF', '1aebd2bd-efdd-4d48-aeb9-0ebd04305581', 'image/jpeg'],
      ['SLC_SICD', '2fe11efa-8906-47e1-bdd7-c6774719e48f', 'image/jpeg'],
      ['SLC_CEOS', '42b89352-7420-4f02-b153-e9df7660d7bd', 'image/png'],
      ['ORT_GEOTIFF', '119d91f5-5c85-44bf-8196-bc26011e1b9f', 'image/jpeg'],
    ])(
      `${baseUrl}/:id/quicklook (GET): %s`,
      async (_, productDataVersionId, expectedContentType) => {
        const target = fixtureProductDataVersions.find((pdv) => {
          return pdv.id === productDataVersionId;
        });

        const res: request.Response = await request
          .default(httpServer)
          .get(`${baseUrl}/${target.id}/quicklook`)
          .send();
        expect(res.status).toEqual(200);
        expect(res.header['content-type']).toEqual(expectedContentType);
      },
    );

    it(`${baseUrl}/:id/quicklook (GET): can get quicklook, when different organizationId`, async () => {
      const target = fixtureProductDataVersions.filter(
        (x) => x.organizationId == TEST_ANOTHER_ORGANIZATION_ID,
      )[0];

      const res: request.Response = await request
        .default(httpServer)
        .get(`${baseUrl}/${target.id}/quicklook`)
        .send();

      expect(res.status).toEqual(404);
    });
  });

  describe('Delete', () => {
    afterEach(async () => {
      await dataSource
        .getRepository(ProductDataVersion)
        .save(fixtureProductDataVersions);
    });

    it.each([
      ['not latest', false],
      ['latest', true],
    ])(
      `${baseUrl}/:id (DELETE): successful soft deletion (%s product-data-version)`,
      async (_, isLatest) => {
        // ProductData '0603e8a8-c8eb-4da0-838a-43d407dab2df' has 2 ProductDataVersions:
        //   (1) not latest: '044ddb41-8c14-4b2f-b53c-d7a072106636'
        //   (2) latest:     '1aebd2bd-efdd-4d48-aeb9-0ebd04305581'
        const allTargets = fixtureProductDataVersions.filter(
          (x) => x.productDatumId === '0603e8a8-c8eb-4da0-838a-43d407dab2df',
        );
        const [deletedTarget, remainingTarget] = isLatest
          ? allTargets
          : allTargets.reverse();

        const res: request.Response = await request
          .default(httpServer)
          .delete(`${baseUrl}/${deletedTarget.id}`)
          .send();
        const result = res.body as ProductDataVersionDto;

        expect(res.status).toEqual(200);
        expect(result.deletedAt).not.toBeNull();

        const checkProductDataVersion1 = await dataSource
          .getRepository(ProductDataVersion)
          .findOne({ where: { id: deletedTarget.id } });
        expect(checkProductDataVersion1).toBeNull();

        const checkProductDataVersion2 = await dataSource
          .getRepository(ProductDataVersion)
          .findOne({ where: { id: deletedTarget.id }, withDeleted: true });
        expect(checkProductDataVersion2).not.toBeNull();
        expect(checkProductDataVersion2.deletedAt).not.toBeNull();

        const checkProductData = await productDataUsecaseService
          .getProductDataQuery([TEST_ORGANIZATION_ID], 'true')
          .where({
            id: deletedTarget.productDatumId,
          })
          .getOne();
        expect(checkProductData.productDataVersions).toHaveLength(1);
        expect(checkProductData.productDataVersions[0].deletedAt).toBeNull();
        expect(checkProductData.productDataVersions[0].id).toEqual(
          remainingTarget.id,
        );
      },
    );

    it(`${baseUrl}/:id (DELETE): successful soft deletion (delete last)`, async () => {
      // ProductData '161a6d67-4eba-4bbc-84b6-a0f13ce2a37d' has 1 ProductDataVersion:
      //   (1) '2fe11efa-8906-47e1-bdd7-c6774719e48f'
      const target = fixtureProductDataVersions.filter(
        (x) => x.productDatumId === '161a6d67-4eba-4bbc-84b6-a0f13ce2a37d',
      )[0];

      const res: request.Response = await request
        .default(httpServer)
        .delete(`${baseUrl}/${target.id}`)
        .send();
      const result = res.body as ProductDataVersionDto;

      expect(res.status).toEqual(200);
      expect(result.deletedAt).not.toBeNull();

      const checkProductDataVersion1 = await dataSource
        .getRepository(ProductDataVersion)
        .findOne({ where: { id: target.id } });
      expect(checkProductDataVersion1).toBeNull();

      const checkProductDataVersion2 = await dataSource
        .getRepository(ProductDataVersion)
        .findOne({ where: { id: target.id }, withDeleted: true });
      expect(checkProductDataVersion2).not.toBeNull();
      expect(checkProductDataVersion2.deletedAt).not.toBeNull();

      const checkProductData1 = await productDataUsecaseService
        .getProductDataQuery([TEST_ORGANIZATION_ID], 'true')
        .where({
          id: target.productDatumId,
        })
        .getOne();
      expect(checkProductData1).toBeNull();

      const checkProductData2 = await dataSource
        .getRepository(ProductData)
        .findOne({
          where: { id: target.productDatumId },
          relations: { productDataVersions: true },
          withDeleted: true,
        });
      expect(checkProductData2).toBeDefined();
      expect(checkProductData2.productDataVersions).toHaveLength(1);
      expect(checkProductData2.productDataVersions[0].deletedAt).not.toBeNull();
    });
  });
});
