/* eslint-disable @typescript-eslint/no-unused-vars */
import { INestApplication } from '@nestjs/common';
import { DataSource, In } from 'typeorm';
import { displayCandidates, loadFixtureAoi } from './fixtures';
import {
  TaskingInfoListDtoForTest,
  TaskingRequestInputDataForTest,
  createAppForE2ETest,
  mockDataScsOrderResponseDto,
} from './utils';
import { Aoi, TaskingInfo, TaskingRequest } from '@iris-lib/db/entities';
import { MissionPortalService } from '../src/infra/mission-portal/mission-portal.service';
import {
  TEST_CONTRACT_ID,
  TEST_ORGANIZATION_ID,
} from '@iris-lib/constants/test-support';
import { TaskingBundleCreateBaseDto } from '../src/models/dto/tasking-bundle/tasking-bundle-create.dto';

import * as request from 'supertest';

import { plainToInstance } from 'class-transformer';
import { randomUUID } from 'crypto';
import { add, format } from 'date-fns';
import {
  ImagingMode,
  LookingDirection,
  ProductFormat,
  PolarizationType,
  ScsOrderStatus,
  FlightDirection,
  TaskingType,
  getDetermineDeadlineBaseDate,
  getUrgentDeadlineTime,
  toScsOrderStatus,
  TaskingStatus,
  generateNotificationContents,
  ResolutionMode,
  NotificationParam,
  NotificationParamItem,
} from '@iris-lib/constants';
import {
  CheckQuotaDto,
  IrisContractPackage,
  PaymentReplyDto,
  PaymentsDto,
  VerifyItemDto,
} from '@iris-lib/models/payment';
import { PaymentTaskStatus } from '@iris-lib/constants/payment-task-status';

import { ScsCandidateForViewDto } from '../src/models/dto/mission-portal/scs-candidate.dto';
import {
  ScsOrderRequestDto,
  ScsUrgentOrderRequestDto,
} from '../src/models/dto/mission-portal/scs-order.dto';
import { DataSourceType } from '@iris-lib/constants/data-source-type';
import { CitadelGrpcService } from '@iris-lib/citadel';
import { ExpressAdapter } from '@nestjs/platform-express';
import { AxiosError } from 'axios';
import { ScsRegistrationAvailabilityCheckRequestDto } from '../src/models/dto/mission-portal/scs-registration-availability-check.dto';
import {
  ScsCommonResponseDto,
  ScsUpdateStatusRequestDto,
} from '../src/models/dto/mission-portal/scs-update-status.dto';
import { DeliveryTimeKind } from '@iris-lib/constants/delivery-time-kind';
import { TaskingPriorityKind } from '@iris-lib/constants/tasking-priority-kind';
import {
  SlackChannel,
  SlackMessage,
  SlackNotificationService,
  SlackTaskingInfoStatusMessage,
} from '@iris-lib/slack';
import Redis, { Cluster } from 'ioredis';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { RedisCache } from 'cache-manager-ioredis-yet';
import { DUMMY_CONTRACTS } from '@iris-lib/guards';

const baseUrl = '/tasking-bundle';

class CitadelRelatedDataForTest {
  taskingId: string;
  paymentId: number;
}

class ScsRelatedDataForTest {
  orderId: string;
  orderCode: string;
}

describe('TaskingBundleController', () => {
  let app: INestApplication;
  let dataSource: DataSource;
  let cacheManager: Redis | Cluster;
  let httpServer: ExpressAdapter;

  let fixtureAois: Aoi[];

  const createdTaskingInfos = new Array<TaskingInfo>();

  const mockMissionPortalService = {
    registrationAvailabilityCheck: jest.fn(),
    register: jest.fn(),
    registerUrgentOrder: jest.fn(),
    updateStatusByOrderId: jest.fn(),
    getEmailForRegistraion: jest.fn(() => 'test@test.com'),
  };

  const mockCitadelGrpcService = {
    checkQuota: jest.fn(),
    reserveTask: jest.fn(),
    emitTaskResult: jest.fn(),
  };

  const mockSlackNotificationService = {
    send: jest.fn(),
  };

  const storedCitadelRelatedData: CitadelRelatedDataForTest[] =
    new Array<CitadelRelatedDataForTest>();

  const taskMgmtUrl = `${process.env.IRIS_WEBPAGE_URL ?? 'NONE'}/tasks`;

  beforeAll(async () => {
    app = await createAppForE2ETest((tm) => {
      tm.overrideProvider(MissionPortalService).useValue(
        mockMissionPortalService,
      );
      tm.overrideProvider(SlackNotificationService).useValue(
        mockSlackNotificationService,
      );
      tm.overrideProvider(CitadelGrpcService).useValue(mockCitadelGrpcService);
    });
    await app.init();
    dataSource = app.get(DataSource);
    cacheManager = (app.get(CACHE_MANAGER) as RedisCache).store.client;
    httpServer = app.getHttpServer();
    fixtureAois = await loadFixtureAoi(dataSource);
  });

  afterAll(async () => {
    await createdTaskingInfos.reduce(async (p, c) => {
      await p;
      const tr = await dataSource.manager
        .getRepository(TaskingRequest)
        .findOne({ where: { id: c.taskingRequestId } });
      if (tr) {
        const aois = await dataSource
          .createQueryBuilder()
          .relation(TaskingRequest, 'aois')
          .of(tr)
          .loadMany();
        await dataSource
          .createQueryBuilder()
          .relation(TaskingRequest, 'aois')
          .of(tr)
          .remove(aois.map((x) => x.id));
      }
    }, Promise.resolve());
    await dataSource.manager
      .getRepository(TaskingRequest)
      .delete(createdTaskingInfos.map((x) => x.taskingRequestId));
    await dataSource.manager
      .getRepository(TaskingInfo)
      .delete(createdTaskingInfos.map((x) => x.id));
    await dataSource.destroy();
    await cacheManager.flushdb();
    await cacheManager.quit();
    await app.close();
  });

  afterEach(async () => {
    mockMissionPortalService.registrationAvailabilityCheck = jest.fn();
    mockMissionPortalService.register = jest.fn();
    mockMissionPortalService.registerUrgentOrder = jest.fn();
    mockMissionPortalService.updateStatusByOrderId = jest.fn();
    mockCitadelGrpcService.checkQuota = jest.fn();
    mockCitadelGrpcService.reserveTask = jest.fn();
    mockCitadelGrpcService.emitTaskResult = jest.fn();
    mockSlackNotificationService.send = jest.fn();
    storedCitadelRelatedData.splice(0);
  });

  it(`${baseUrl} (POST): Successful registration`, async () => {
    const {
      selectedCandidates,
      taskingRequestParam,
      usedAoiIds,
      orderParam,
      contract,
    }: {
      selectedCandidates: ScsCandidateForViewDto[];
      taskingRequestParam: TaskingRequestInputDataForTest;
      usedAoiIds: string[];
      orderParam: ScsRelatedDataForTest[];
      contract: IrisContractPackage;
    } = await prepareTest();

    const body: TaskingBundleCreateBaseDto = {
      name: 'e2e-test-tasking-bundle-create-001',
      selectedCandidates,
      ...taskingRequestParam,
    };
    const res: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(201);

    const result = plainToInstance(TaskingInfoListDtoForTest, {
      items: res.body,
    });
    createdTaskingInfos.push(...result.items);

    expect(result.items.length).toEqual(selectedCandidates.length);

    const aois = await dataSource
      .createQueryBuilder()
      .relation(TaskingRequest, 'aois')
      .of({ id: result.items[0].taskingRequestId })
      .loadMany();
    expect(aois.length).toEqual(usedAoiIds.length);

    const ti = await dataSource
      .getRepository(TaskingInfo)
      .find({ where: { id: In(result.items.map((x) => x.id)) } });
    expect(ti.length).toEqual(selectedCandidates.length);
    expect(
      ti.every((x) => orderParam.find((y) => y.orderId == x.scsOrderId)),
    ).toBeTruthy();
    expect(
      ti.every((x) => orderParam.find((y) => y.orderCode == x.scsOrderCode)),
    ).toBeTruthy();
    expect(
      ti.every((x) => x.scenes == taskingRequestParam.scenes),
    ).toBeTruthy();
    expect(
      ti.every((x) => x.catalogDelayKind == contract.catalogDelayKind),
    ).toBeTruthy();

    expect(
      mockMissionPortalService.registrationAvailabilityCheck,
    ).toHaveBeenNthCalledWith(
      1,
      selectedCandidates.map((x, idx) => {
        return plainToInstance(ScsRegistrationAvailabilityCheckRequestDto, {
          searchIndex: idx + 1,
          satelliteInfo: x.satelliteInfo,
          observationTiming: x.observationTiming,
        } as ScsRegistrationAvailabilityCheckRequestDto);
      }),
    );
    expect(mockMissionPortalService.register).toHaveBeenNthCalledWith(
      1,
      selectedCandidates.map((x) => {
        return {
          title: body.name,
          email: mockMissionPortalService.getEmailForRegistraion(),
          customerOrgID: taskingRequestParam.organizationId.toString(),
          basePriority: taskingRequestParam.priority,
          centerPosition: x.observationArea.obsCenterPosition.getScsPointDto(),
          imagingMode: x.observationTiming.orbitParams.imagingMode,
          polarization: taskingRequestParam.polarization,
          startOBCTime: x.observationTiming.obsStartTime,
          endOBCTime: x.observationTiming.obsEndTime,
          pathDirection: x.observationTiming.orbitParams.pathDirection,
          sightDirection: x.observationTiming.orbitParams.sightDirection,
          offnadirAngle: x.observationTiming.orbitParams.offNadir,
          satId: x.satelliteInfo.satId,
        } as ScsOrderRequestDto;
      }),
    );
    expect(
      mockMissionPortalService.updateStatusByOrderId,
    ).toHaveBeenNthCalledWith(
      1,
      orderParam.map((x) => {
        return {
          orderId: x.orderId,
          orderStatus: toScsOrderStatus(TaskingStatus.Ordered),
        } as ScsUpdateStatusRequestDto;
      }),
    );

    expect(mockCitadelGrpcService.checkQuota).toHaveBeenNthCalledWith(
      1,
      taskingRequestParam.contractId,
      storedCitadelRelatedData.map((x) => {
        const found = ti.find((y) => y.id == x.taskingId);
        return {
          id: x.taskingId,
          dataSourceType: DataSourceType.NEW,
          imagingMode: found.imagingMode,
          taskingType: TaskingType.Regular,
          scene: found.scenes,
          productDetails: found.productDetails,
          deliveryTimeKind: DeliveryTimeKind.RUSH,
          taskPriorityKind: TaskingPriorityKind.HIGH,
        } as CheckQuotaDto;
      }),
    );
    expect(mockCitadelGrpcService.reserveTask).toHaveBeenNthCalledWith(
      1,
      storedCitadelRelatedData.map((x) => x.taskingId),
      await generateNotificationContents(
        TaskingStatus.Ordered,
        plainToInstance(NotificationParam, {
          env: process.env.NODE_ENV,
          taskMgmtLink: taskMgmtUrl,
          items: result.items.map((x) =>
            plainToInstance(NotificationParamItem, {
              scsOrderCode: x.scsOrderCode,
              obsStart: x.observationStart,
              aoiName: x.name,
              satellite: x.satellite.name,
              imagingMode: x.imagingMode,
              flightDirection: x.flightDirection,
              lookingDirection: x.lookingDirection,
              offnadirAngle: x.offnadirAngle,
              taskingType: x.taskingType,
            } as NotificationParamItem),
          ),
        } as NotificationParam),
      ),
    );

    expect(mockSlackNotificationService.send).toHaveBeenCalledTimes(ti.length);
    ti.forEach(async (t, i) => {
      expect(mockSlackNotificationService.send).toHaveBeenNthCalledWith(
        i + 1,
        new SlackTaskingInfoStatusMessage(
          {
            name: t.name,
            status: TaskingStatus.Ordered,
            orderCode: t.scsOrderCode,
            observationStart: t.observationStart,
          },
          { channel: SlackChannel.DEFAULT },
        ),
      );
      // TaskingStatus.Ordered should be notified to Slack
      await expect(
        mockSlackNotificationService.send.mock.results[i].value,
      ).resolves.toEqual(true);
    });

    async function prepareTest() {
      const usedAoiIds = fixtureAois
        .filter(
          (x) =>
            x.organizationId == TEST_ORGANIZATION_ID &&
            // temporary: until aoiIds are also stored in SCS/DPS,
            // x.name.startsWith('fixture-aoi-common'),
            x.name.startsWith('fixture-aoi-common-1'),
        )
        .map((x) => x.id);

      const selectedCandidates = displayCandidates.slice(0, 1).map((x, idx) => {
        const tmp = plainToInstance(ScsCandidateForViewDto, structuredClone(x));
        tmp.observationTiming.obsStartTimeUTC = add(
          getUrgentDeadlineTime(
            new Date(),
            getDetermineDeadlineBaseDate(new Date()),
          ),
          { days: 1, seconds: 10 * (idx + 1) },
        );
        tmp.observationTiming.obsEndTimeUTC = add(
          tmp.observationTiming.obsStartTimeUTC,
          { seconds: 10 * (idx + 2) },
        );
        tmp.taskingType = TaskingType.Regular;
        return tmp;
      });

      const taskingRequestParam: TaskingRequestInputDataForTest = {
        priority: 123456,
        imagingMode: ImagingMode.SlidingSpotlight,
        lookingDirection: LookingDirection.Both,
        flightDirection: FlightDirection.Both,
        offnadirAngleMin: 15,
        offnadirAngleMax: 45,
        productDetails: [
          {
            productFormat: ProductFormat.GRD_GEOTIFF,
            resolutionMode: ResolutionMode.normal,
          },
        ],
        organizationId: TEST_ORGANIZATION_ID,
        contractId: TEST_CONTRACT_ID,
        aoiIds: usedAoiIds,
        polarization: PolarizationType.VV,
        scenes: 7,
      };

      const orderParam = selectedCandidates.map((x, idx) => {
        return plainToInstance(ScsRelatedDataForTest, {
          orderId: randomUUID(),
          orderCode:
            format(new Date(), 'yyyyMM') +
            '-' +
            String(idx + 1).padStart(5, '0'),
        });
      });

      const contract = DUMMY_CONTRACTS.find(
        (c) => c.contractId === TEST_CONTRACT_ID,
      );

      mockMissionPortalService.registrationAvailabilityCheck = jest.fn(() => {
        return Promise.resolve(true);
      });
      mockMissionPortalService.register = jest.fn(() => {
        return Promise.resolve(
          selectedCandidates.map((x, idx) => {
            return mockDataScsOrderResponseDto(
              orderParam[idx].orderId,
              orderParam[idx].orderCode,
              ScsOrderStatus.PreRegistration,
              taskingRequestParam,
              x,
            );
          }),
        );
      });
      mockMissionPortalService.updateStatusByOrderId = jest.fn(() => {
        return Promise.resolve({
          result: true,
          errorMessage: null,
        } as ScsCommonResponseDto);
      });

      // prepare mock of Citadel
      mockCitadelGrpcService.checkQuota = jest.fn(
        (contractId: number, checkList: CheckQuotaDto[]) => {
          return Promise.resolve(
            checkList.map((x, idx) => {
              const tmp = plainToInstance(CitadelRelatedDataForTest, {
                taskingId: x.id,
                paymentId: 999000 + idx,
              } as CitadelRelatedDataForTest);
              storedCitadelRelatedData.push(tmp);
              return plainToInstance(PaymentReplyDto, {
                registrationId: tmp.paymentId,
                taskId: tmp.taskingId,
                status: PaymentTaskStatus.TEMPORAL,
                consumptionCredit: 0,
              } as PaymentReplyDto);
            }),
          );
        },
      );
      mockCitadelGrpcService.reserveTask = jest.fn(
        (registrationIds: string[]) => {
          const tmp = plainToInstance(PaymentsDto, {
            totalConsumptionCredit: 0,
            remainingCredit: 0,
            results: registrationIds.map((x) => {
              return plainToInstance(PaymentReplyDto, {
                registrationId: storedCitadelRelatedData.find(
                  (y) => y.taskingId == x,
                ).paymentId,
                taskId: x,
                status: PaymentTaskStatus.RESERVED,
                consumptionCredit: 0,
              } as PaymentReplyDto);
            }),
            verifyResults: registrationIds.map((x) => {
              return plainToInstance(VerifyItemDto, {
                taskId: x,
                consumptionCredit: 0,
                dataSourceType: DataSourceType.ARCHIVE,
                imagingMode: ImagingMode.Stripmap,
                numberOfLicense: 1,
                options: [],
              } as VerifyItemDto);
            }),
          } as PaymentsDto);

          return Promise.resolve(tmp);
        },
      );
      mockSlackNotificationService.send = jest.fn((message: SlackMessage) => {
        return Promise.resolve(message.shouldNotify);
      });
      return {
        selectedCandidates,
        taskingRequestParam,
        usedAoiIds,
        orderParam,
        contract,
      };
    }
  });

  it(`${baseUrl} (POST): failed registration (rollback due to failed registrationAvailabilityCheck)`, async () => {
    const {
      selectedCandidates,
      taskingRequestParam,
    }: {
      selectedCandidates: ScsCandidateForViewDto[];
      taskingRequestParam: TaskingRequestInputDataForTest;
    } = await prepareTest();
    const body: TaskingBundleCreateBaseDto = {
      name: 'e2e-test-tasking-bundle-create-002',
      selectedCandidates,
      ...taskingRequestParam,
    };
    const res: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(500);

    const tr = await dataSource
      .getRepository(TaskingInfo)
      .findOne({ where: { name: body.name } });
    // Deleted by rollback processing
    expect(tr).toBeNull();

    const ti = await dataSource
      .getRepository(TaskingRequest)
      .findOne({ where: { name: body.name } });
    // Deleted by rollback processing
    expect(ti).toBeNull();

    expect(
      mockMissionPortalService.registrationAvailabilityCheck,
    ).toHaveBeenNthCalledWith(
      1,
      selectedCandidates.map((x, idx) => {
        return plainToInstance(ScsRegistrationAvailabilityCheckRequestDto, {
          searchIndex: idx + 1,
          satelliteInfo: x.satelliteInfo,
          observationTiming: x.observationTiming,
        } as ScsRegistrationAvailabilityCheckRequestDto);
      }),
    );
    expect(mockMissionPortalService.register).toHaveBeenCalledTimes(0);

    expect(mockCitadelGrpcService.checkQuota).toHaveBeenCalledTimes(0);
    expect(mockCitadelGrpcService.emitTaskResult).toHaveBeenCalledTimes(0);

    expect(mockSlackNotificationService.send).toHaveBeenCalledTimes(0);

    async function prepareTest() {
      const usedAoiIds = fixtureAois
        .filter(
          (x) =>
            x.organizationId == TEST_ORGANIZATION_ID &&
            // temporary: until aoiIds are also stored in SCS/DPS,
            // x.name.startsWith('fixture-aoi-common'),
            x.name.startsWith('fixture-aoi-common-1'),
        )
        .map((x) => x.id);

      const selectedCandidates = displayCandidates.slice(0, 1).map((x, idx) => {
        const tmp = plainToInstance(ScsCandidateForViewDto, structuredClone(x));
        tmp.observationTiming.obsStartTimeUTC = add(
          getUrgentDeadlineTime(
            new Date(),
            getDetermineDeadlineBaseDate(new Date()),
          ),
          { days: 1, seconds: 10 * (idx + 1) },
        );
        tmp.observationTiming.obsEndTimeUTC = add(
          tmp.observationTiming.obsStartTimeUTC,
          { seconds: 10 * (idx + 2) },
        );
        tmp.taskingType = TaskingType.Regular;
        return tmp;
      });

      const taskingRequestParam: TaskingRequestInputDataForTest = {
        priority: 123456,
        imagingMode: ImagingMode.SlidingSpotlight,
        lookingDirection: LookingDirection.Both,
        flightDirection: FlightDirection.Both,
        offnadirAngleMin: 15,
        offnadirAngleMax: 45,
        productDetails: [
          {
            productFormat: ProductFormat.GRD_GEOTIFF,
            resolutionMode: ResolutionMode.normal,
          },
        ],
        organizationId: TEST_ORGANIZATION_ID,
        contractId: TEST_CONTRACT_ID,
        aoiIds: usedAoiIds,
        polarization: PolarizationType.VV,
        scenes: 1,
      };
      mockMissionPortalService.registrationAvailabilityCheck = jest.fn(() =>
        Promise.reject(new AxiosError('test')),
      );

      return { selectedCandidates, taskingRequestParam };
    }
  });

  it(`${baseUrl} (POST): failed registration (includes non-visible satellite)`, async () => {
    const {
      selectedCandidates,
      taskingRequestParam,
    }: {
      selectedCandidates: ScsCandidateForViewDto[];
      taskingRequestParam: TaskingRequestInputDataForTest;
    } = await prepareTest();
    const body: TaskingBundleCreateBaseDto = {
      name: 'e2e-test-tasking-bundle-create-002',
      selectedCandidates,
      ...taskingRequestParam,
    };
    const res: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(400);
    expect(res.body.message[0].name).toEqual('satId');

    async function prepareTest() {
      const usedAoiIds = fixtureAois
        .filter(
          (x) =>
            x.organizationId == TEST_ORGANIZATION_ID &&
            // temporary: until aoiIds are also stored in SCS/DPS,
            // x.name.startsWith('fixture-aoi-common'),
            x.name.startsWith('fixture-aoi-common-1'),
        )
        .map((x) => x.id);

      // ST0002 is not visible to IrisUserRole.ADMINISTRATOR
      const selectedCandidates = displayCandidates.slice(0, 2).map((x, idx) => {
        const tmp = plainToInstance(ScsCandidateForViewDto, structuredClone(x));
        tmp.observationTiming.obsStartTimeUTC = add(
          getUrgentDeadlineTime(
            new Date(),
            getDetermineDeadlineBaseDate(new Date()),
          ),
          { days: 1, seconds: 10 * (idx + 1) },
        );
        tmp.observationTiming.obsEndTimeUTC = add(
          tmp.observationTiming.obsStartTimeUTC,
          { seconds: 10 * (idx + 2) },
        );
        tmp.taskingType = TaskingType.Regular;
        return tmp;
      });

      const taskingRequestParam: TaskingRequestInputDataForTest = {
        priority: 123456,
        imagingMode: ImagingMode.SlidingSpotlight,
        lookingDirection: LookingDirection.Both,
        flightDirection: FlightDirection.Both,
        offnadirAngleMin: 15,
        offnadirAngleMax: 45,
        productDetails: [
          {
            productFormat: ProductFormat.GRD_GEOTIFF,
            resolutionMode: ResolutionMode.normal,
          },
        ],
        organizationId: TEST_ORGANIZATION_ID,
        contractId: TEST_CONTRACT_ID,
        aoiIds: usedAoiIds,
        polarization: PolarizationType.VV,
        scenes: 1,
      };

      return { selectedCandidates, taskingRequestParam };
    }
  });

  it(`${baseUrl}/urgent (POST): Successful registration`, async () => {
    const {
      selectedCandidates,
      taskingRequestParam,
      usedAoiIds,
      orderParam,
      contract,
    }: {
      selectedCandidates: ScsCandidateForViewDto[];
      taskingRequestParam: TaskingRequestInputDataForTest;
      usedAoiIds: string[];
      orderParam: ScsRelatedDataForTest[];
      contract: IrisContractPackage;
    } = await prepareTest();

    const body: TaskingBundleCreateBaseDto = {
      name: 'e2e-test-tasking-bundle-createUrgent-001',
      selectedCandidates,
      ...taskingRequestParam,
    };
    const res: request.Response = await request
      .default(httpServer)
      .post(baseUrl + '/urgent')
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(201);

    const result = plainToInstance(TaskingInfoListDtoForTest, {
      items: res.body,
    });
    createdTaskingInfos.push(...result.items);

    expect(result.items.length).toEqual(selectedCandidates.length);

    const aois = await dataSource
      .createQueryBuilder()
      .relation(TaskingRequest, 'aois')
      .of({ id: result.items[0].taskingRequestId })
      .loadMany();
    expect(aois.length).toEqual(usedAoiIds.length);

    const ti = await dataSource
      .getRepository(TaskingInfo)
      .find({ where: { id: In(result.items.map((x) => x.id)) } });
    expect(ti.length).toEqual(selectedCandidates.length);
    expect(
      ti.every((x) => orderParam.find((y) => y.orderId == x.scsOrderId)),
    ).toBeTruthy();
    expect(
      ti.every((x) => orderParam.find((y) => y.orderCode == x.scsOrderCode)),
    ).toBeTruthy();
    expect(
      ti.every((x) => x.scenes == taskingRequestParam.scenes),
    ).toBeTruthy();
    expect(
      ti.every((x) => x.catalogDelayKind == contract.catalogDelayKind),
    ).toBeTruthy();

    expect(
      mockMissionPortalService.registerUrgentOrder,
    ).toHaveBeenNthCalledWith(
      1,
      selectedCandidates.map((x) => {
        return {
          title: body.name,
          email: mockMissionPortalService.getEmailForRegistraion(),
          customerOrgID: taskingRequestParam.organizationId.toString(),
          basePriority: taskingRequestParam.priority,
          centerPosition: x.observationArea.obsCenterPosition.getScsPointDto(),
          imagingMode: x.observationTiming.orbitParams.imagingMode,
          polarization: taskingRequestParam.polarization,
          startOBCTime: x.observationTiming.obsStartTime,
          endOBCTime: x.observationTiming.obsEndTime,
          pathDirection: x.observationTiming.orbitParams.pathDirection,
          sightDirection: x.observationTiming.orbitParams.sightDirection,
          offnadirAngle: x.observationTiming.orbitParams.offNadir,
          satId: x.satelliteInfo.satId,
          requestPlanType: 1,
        } as ScsUrgentOrderRequestDto;
      }),
    );

    expect(mockCitadelGrpcService.checkQuota).toHaveBeenNthCalledWith(
      1,
      taskingRequestParam.contractId,
      storedCitadelRelatedData.map((x) => {
        const found = ti.find((y) => y.id == x.taskingId);
        return {
          id: x.taskingId,
          dataSourceType: DataSourceType.NEW,
          imagingMode: found.imagingMode,
          taskingType: TaskingType.Urgent,
          scene: found.scenes,
          productDetails: found.productDetails,
          deliveryTimeKind: DeliveryTimeKind.RUSH,
          taskPriorityKind: TaskingPriorityKind.HIGH,
        } as CheckQuotaDto;
      }),
    );

    expect(mockSlackNotificationService.send).toHaveBeenCalledTimes(ti.length);
    ti.forEach(async (t, i) => {
      expect(mockSlackNotificationService.send).toHaveBeenNthCalledWith(
        i + 1,
        new SlackTaskingInfoStatusMessage(
          {
            name: t.name,
            status: TaskingStatus.Ordered,
            orderCode: t.scsOrderCode,
            observationStart: t.observationStart,
          },
          { channel: SlackChannel.URGENTTASKING, shouldMention: true },
        ),
      );
      await expect(
        mockSlackNotificationService.send.mock.results[i].value,
      ).resolves.toEqual(true);
    });

    async function prepareTest() {
      const usedAoiIds = fixtureAois
        .filter(
          (x) =>
            x.organizationId == TEST_ORGANIZATION_ID &&
            // temporary: until aoiIds are also stored in SCS/DPS,
            // x.name.startsWith('fixture-aoi-common'),
            x.name.startsWith('fixture-aoi-common-1'),
        )
        .map((x) => x.id);

      const selectedCandidates = displayCandidates.slice(0, 1).map((x, idx) => {
        const tmp = plainToInstance(ScsCandidateForViewDto, structuredClone(x));
        tmp.observationTiming.obsStartTimeUTC = add(
          getUrgentDeadlineTime(
            new Date(),
            getDetermineDeadlineBaseDate(new Date()),
          ),
          { days: 0, seconds: -1000 + 10 * (idx + 1) },
        );
        tmp.observationTiming.obsEndTimeUTC = add(
          tmp.observationTiming.obsStartTimeUTC,
          { seconds: 10 * (idx + 2) },
        );
        tmp.taskingType = TaskingType.Urgent;
        return tmp;
      });

      const taskingRequestParam: TaskingRequestInputDataForTest = {
        priority: 123456,
        imagingMode: ImagingMode.SlidingSpotlight,
        lookingDirection: LookingDirection.Both,
        flightDirection: FlightDirection.Both,
        offnadirAngleMin: 15,
        offnadirAngleMax: 45,
        productDetails: [
          {
            productFormat: ProductFormat.GRD_GEOTIFF,
            resolutionMode: ResolutionMode.normal,
          },
        ],
        organizationId: TEST_ORGANIZATION_ID,
        contractId: TEST_CONTRACT_ID,
        aoiIds: usedAoiIds,
        polarization: PolarizationType.VV,
        scenes: 7,
      };

      const orderParam = selectedCandidates.map((x, idx) => {
        return plainToInstance(ScsRelatedDataForTest, {
          orderId: randomUUID(),
          orderCode:
            format(new Date(), 'yyyyMM') +
            '-' +
            String(idx + 1).padStart(5, '0'),
        });
      });

      const contract = DUMMY_CONTRACTS.find(
        (c) => c.contractId === TEST_CONTRACT_ID,
      );

      mockMissionPortalService.registrationAvailabilityCheck = jest.fn(() => {
        return Promise.resolve(true);
      });
      mockMissionPortalService.registerUrgentOrder = jest.fn(() => {
        return Promise.resolve(
          selectedCandidates.map((x, idx) => {
            return mockDataScsOrderResponseDto(
              orderParam[idx].orderId,
              orderParam[idx].orderCode,
              ScsOrderStatus.PreRegistration,
              taskingRequestParam,
              x,
            );
          }),
        );
      });

      // prepare mock of Citadel
      mockCitadelGrpcService.checkQuota = jest.fn(
        (contractId: number, checkList: CheckQuotaDto[]) => {
          return Promise.resolve(
            checkList.map((x, idx) => {
              const tmp = plainToInstance(CitadelRelatedDataForTest, {
                taskingId: x.id,
                paymentId: 999000 + idx,
              } as CitadelRelatedDataForTest);
              storedCitadelRelatedData.push(tmp);
              return plainToInstance(PaymentReplyDto, {
                registrationId: tmp.paymentId,
                taskId: tmp.taskingId,
                status: PaymentTaskStatus.TEMPORAL,
                consumptionCredit: 0,
              } as PaymentReplyDto);
            }),
          );
        },
      );
      mockCitadelGrpcService.reserveTask = jest.fn(
        (registrationIds: string[]) => {
          const tmp = plainToInstance(PaymentsDto, {
            totalConsumptionCredit: 0,
            remainingCredit: 0,
            results: registrationIds.map((x) => {
              return plainToInstance(PaymentReplyDto, {
                registrationId: storedCitadelRelatedData.find(
                  (y) => y.taskingId == x,
                ).paymentId,
                taskId: x,
                status: PaymentTaskStatus.RESERVED,
                consumptionCredit: 0,
              } as PaymentReplyDto);
            }),
            verifyResults: registrationIds.map((x) => {
              return plainToInstance(VerifyItemDto, {
                taskId: x,
                consumptionCredit: 0,
                dataSourceType: DataSourceType.ARCHIVE,
                imagingMode: ImagingMode.Stripmap,
                numberOfLicense: 1,
                options: [],
              } as VerifyItemDto);
            }),
          } as PaymentsDto);

          return Promise.resolve(tmp);
        },
      );

      mockSlackNotificationService.send = jest.fn((message: SlackMessage) => {
        return Promise.resolve(message.shouldNotify);
      });
      return {
        selectedCandidates,
        taskingRequestParam,
        usedAoiIds,
        orderParam,
        contract,
      };
    }
  });

  it(`${baseUrl}/urgent (POST): failed registration (rollback due to failed quotaCheck)`, async () => {
    const {
      selectedCandidates,
      taskingRequestParam,
    }: {
      selectedCandidates: ScsCandidateForViewDto[];
      taskingRequestParam: TaskingRequestInputDataForTest;
    } = await prepareTest();
    const body: TaskingBundleCreateBaseDto = {
      name: 'e2e-test-urgent-tasking-bundle-create-002',
      selectedCandidates,
      ...taskingRequestParam,
    };
    const res: request.Response = await request
      .default(httpServer)
      .post(baseUrl + '/urgent')
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(500);

    const ti = await dataSource
      .getRepository(TaskingInfo)
      .findOne({ where: { name: body.name } });
    // Deleted by rollback processing
    expect(ti).toBeNull();

    const tr = await dataSource
      .getRepository(TaskingRequest)
      .findOne({ where: { name: body.name } });
    // Deleted by rollback processing
    expect(tr).toBeNull();

    expect(mockMissionPortalService.registerUrgentOrder).toHaveBeenCalledTimes(
      0,
    );

    expect(mockCitadelGrpcService.checkQuota).toHaveBeenNthCalledWith(
      1,
      taskingRequestParam.contractId,
      selectedCandidates.map((x) => {
        return {
          id: expect.any(String), // The id is created in the function, but it was deleted after test. So, use any value
          dataSourceType: DataSourceType.NEW,
          imagingMode: x.observationTiming.orbitParams.imagingMode,
          taskingType: x.taskingType,
          scene: taskingRequestParam.scenes,
          productDetails: taskingRequestParam.productDetails,
          deliveryTimeKind: DeliveryTimeKind.RUSH,
          taskPriorityKind: TaskingPriorityKind.HIGH,
        } as CheckQuotaDto;
      }),
    );
    expect(mockCitadelGrpcService.reserveTask).toHaveBeenCalledTimes(0);
    expect(mockCitadelGrpcService.emitTaskResult).toHaveBeenCalledTimes(0);

    expect(mockSlackNotificationService.send).toHaveBeenCalledTimes(0);

    async function prepareTest() {
      const usedAoiIds = fixtureAois
        .filter(
          (x) =>
            x.organizationId == TEST_ORGANIZATION_ID &&
            // temporary: until aoiIds are also stored in SCS/DPS,
            // x.name.startsWith('fixture-aoi-common'),
            x.name.startsWith('fixture-aoi-common-1'),
        )
        .map((x) => x.id);

      const selectedCandidates = displayCandidates.slice(0, 1).map((x, idx) => {
        const tmp = plainToInstance(ScsCandidateForViewDto, structuredClone(x));
        tmp.observationTiming.obsStartTimeUTC = add(
          getUrgentDeadlineTime(
            new Date(),
            getDetermineDeadlineBaseDate(new Date()),
          ),
          { days: 0, seconds: -1000 + 10 * (idx + 1) },
        );
        tmp.observationTiming.obsEndTimeUTC = add(
          tmp.observationTiming.obsStartTimeUTC,
          { seconds: 10 * (idx + 2) },
        );
        tmp.taskingType = TaskingType.Urgent;
        return tmp;
      });

      const taskingRequestParam: TaskingRequestInputDataForTest = {
        priority: 123456,
        imagingMode: ImagingMode.SlidingSpotlight,
        lookingDirection: LookingDirection.Both,
        flightDirection: FlightDirection.Both,
        offnadirAngleMin: 15,
        offnadirAngleMax: 45,
        productDetails: [
          {
            productFormat: ProductFormat.GRD_GEOTIFF,
            resolutionMode: ResolutionMode.normal,
          },
        ],
        organizationId: TEST_ORGANIZATION_ID,
        contractId: TEST_CONTRACT_ID,
        aoiIds: usedAoiIds,
        polarization: PolarizationType.VV,
        scenes: 1,
      };
      mockCitadelGrpcService.checkQuota = jest.fn(() =>
        Promise.reject(new AxiosError('test')),
      );

      return { selectedCandidates, taskingRequestParam };
    }
  });

  it(`${baseUrl}/urgent (POST): failed registration (includes non-visible satellite)`, async () => {
    const {
      selectedCandidates,
      taskingRequestParam,
    }: {
      selectedCandidates: ScsCandidateForViewDto[];
      taskingRequestParam: TaskingRequestInputDataForTest;
    } = await prepareTest();
    const body: TaskingBundleCreateBaseDto = {
      name: 'e2e-test-urgent-tasking-bundle-create-002',
      selectedCandidates,
      ...taskingRequestParam,
    };
    const res: request.Response = await request
      .default(httpServer)
      .post(baseUrl + '/urgent')
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(400);
    expect(res.body.message[0].name).toEqual('satId');

    async function prepareTest() {
      const usedAoiIds = fixtureAois
        .filter(
          (x) =>
            x.organizationId == TEST_ORGANIZATION_ID &&
            // temporary: until aoiIds are also stored in SCS/DPS,
            // x.name.startsWith('fixture-aoi-common'),
            x.name.startsWith('fixture-aoi-common-1'),
        )
        .map((x) => x.id);

      // ST0002 is not visible to IrisUserRole.ADMINISTRATOR
      const selectedCandidates = displayCandidates.slice(0, 2).map((x, idx) => {
        const tmp = plainToInstance(ScsCandidateForViewDto, structuredClone(x));
        tmp.observationTiming.obsStartTimeUTC = add(
          getUrgentDeadlineTime(
            new Date(),
            getDetermineDeadlineBaseDate(new Date()),
          ),
          { days: 0, seconds: -1000 + 10 * (idx + 1) },
        );
        tmp.observationTiming.obsEndTimeUTC = add(
          tmp.observationTiming.obsStartTimeUTC,
          { seconds: 10 * (idx + 2) },
        );
        tmp.taskingType = TaskingType.Urgent;
        return tmp;
      });

      const taskingRequestParam: TaskingRequestInputDataForTest = {
        priority: 123456,
        imagingMode: ImagingMode.SlidingSpotlight,
        lookingDirection: LookingDirection.Both,
        flightDirection: FlightDirection.Both,
        offnadirAngleMin: 15,
        offnadirAngleMax: 45,
        productDetails: [
          {
            productFormat: ProductFormat.GRD_GEOTIFF,
            resolutionMode: ResolutionMode.normal,
          },
        ],
        organizationId: TEST_ORGANIZATION_ID,
        contractId: TEST_CONTRACT_ID,
        aoiIds: usedAoiIds,
        polarization: PolarizationType.VV,
        scenes: 1,
      };

      return { selectedCandidates, taskingRequestParam };
    }
  });
});
