import { DbConfigService } from '@iris-lib/db';
import { DbConfigModule } from '@iris-lib/db/db-config.module';
import { Module } from '@nestjs/common';
import { TypeOrmModule, TypeOrmModuleOptions } from '@nestjs/typeorm';

@Module({
  imports: [
    DbConfigModule,
    TypeOrmModule.forRootAsync({
      inject: ['DbConfig'],
      useFactory: async (configService: DbConfigService) => {
        return configService.get('db') as TypeOrmModuleOptions;
      },
    }),
  ],
})
export class TestEnvModule {}
