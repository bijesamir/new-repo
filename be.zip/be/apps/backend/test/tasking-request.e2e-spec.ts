import { INestApplication } from '@nestjs/common';
import { DataSource, In } from 'typeorm';
import { createAppForE2ETest } from './utils';
import { loadFixtureAoi, loadFixtureTaskingRequest } from './fixtures';
import { TaskingRequestCreateBaseDto } from '../src/models/dto/tasking-request/tasking-request-create.dto';
import {
  TEST_ORGANIZATION_ID,
  TEST_CONTRACT_ID,
  TEST_ANOTHER_ORGANIZATION_ID,
} from '@iris-lib/constants/test-support';
import { Aoi, TaskingRequest } from '@iris-lib/db/entities';
import * as request from 'supertest';

import { plainToInstance } from 'class-transformer';
import { addDays } from 'date-fns';
import { Paginated } from 'nestjs-paginate';
import {
  ImagingMode,
  LookingDirection,
  FlightDirection,
  ProductFormat,
  PolarizationType,
  ResolutionMode,
} from '@iris-lib/constants';
import Redis, { Cluster } from 'ioredis';
import { RedisCache } from 'cache-manager-ioredis-yet';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { ExpressAdapter } from '@nestjs/platform-express';

const baseUrl = '/tasking-request';

describe('TaskingRequestController', () => {
  let app: INestApplication;
  let dataSource: DataSource;
  let cacheManager: Redis | Cluster;
  let httpServer: ExpressAdapter;

  let fixtureAois: Aoi[];
  let fixtureTaskingRequests: TaskingRequest[];

  const usedAoiIds = new Array<string>();
  const taskingRequests = new Array<TaskingRequest>();

  beforeAll(async () => {
    app = await createAppForE2ETest();
    await app.init();
    dataSource = app.get(DataSource);
    httpServer = app.getHttpServer();
    cacheManager = (app.get(CACHE_MANAGER) as RedisCache).store.client;
    fixtureAois = await loadFixtureAoi(dataSource);
    fixtureTaskingRequests = await loadFixtureTaskingRequest(dataSource, '%');
  });

  afterAll(async () => {
    await taskingRequests.reduce(async (p, c) => {
      await p;

      return await dataSource
        .createQueryBuilder()
        .relation(TaskingRequest, 'aois')
        .of(c)
        .remove(c.aois.map((x) => x.id));
    }, Promise.resolve());
    await dataSource.manager
      .getRepository(TaskingRequest)
      .delete(taskingRequests.map((x) => x.id));
    await dataSource.destroy();
    await cacheManager.flushdb();
    await cacheManager.quit();
    await app.close();
  });

  it(`${baseUrl} (POST): Successful registration`, async () => {
    const usedAoiId = fixtureAois
      .filter(
        (x) =>
          x.organizationId == TEST_ORGANIZATION_ID &&
          // temporary: until aoiIds are also stored in SCS/DPS,
          // x.name.startsWith('fixture-aoi-common'),
          x.name.startsWith('fixture-aoi-common-1'),
      )
      .map((x) => x.id);

    usedAoiIds.push(...usedAoiId);
    const body: TaskingRequestCreateBaseDto = {
      priority: 123456,
      imagingMode: ImagingMode.SlidingSpotlight,
      lookingDirection: LookingDirection.Both,
      flightDirection: FlightDirection.Both,
      offnadirAngleMin: 15,
      offnadirAngleMax: 45,
      productDetails: [
        {
          productFormat: ProductFormat.GRD_GEOTIFF,
          resolutionMode: ResolutionMode.normal,
        },
      ],
      organizationId: TEST_ORGANIZATION_ID,
      contractId: TEST_CONTRACT_ID,
      aoiIds: usedAoiIds,
      polarization: PolarizationType.VV,
      scenes: 7,
    };
    const res: request.Response = await request
      .default(httpServer)
      .post(baseUrl)
      .set('Content-Type', 'application/json')
      .send(body);
    expect(res.status).toEqual(201);
    const result = plainToInstance(TaskingRequest, res.body);
    taskingRequests.push(result);

    expect(result.id).not.toBeNull();
    expect(result.no).not.toBeNull();
    expect(result.priority).toEqual(body.priority);
    expect(result.imagingMode).toEqual(body.imagingMode);
    expect(result.lookingDirection).toEqual(body.lookingDirection);
    expect(result.flightDirection).toEqual(body.flightDirection);
    expect(result.offnadirAngleMin).toEqual(body.offnadirAngleMin);
    expect(result.offnadirAngleMax).toEqual(body.offnadirAngleMax);
    expect(result.productDetails).toEqual(body.productDetails);
    expect(result.organizationId).toEqual(body.organizationId);
    expect(result.contractId).toEqual(body.contractId);
    expect(result.scenes).toEqual(body.scenes);
    expect(
      result.aois.every((x) => usedAoiIds.find((y) => y == x.id)),
    ).toBeTruthy();
  });

  it(`${baseUrl} (GET): Succeeded in retrieving data with the specified ID`, async () => {
    const target = taskingRequests[0];
    const before = await dataSource.manager.findOneOrFail(TaskingRequest, {
      where: { id: target.id },
    });
    const res: request.Response = await request
      .default(httpServer)
      .get(`${baseUrl}/${target.id}`)
      .set('Content-Type', 'application/json')
      .send();
    expect(res.status).toEqual(200);

    const gotData = res.body as TaskingRequest;

    expect(gotData.id).toEqual(target.id);
    expect(gotData.name).toEqual(before.name);
  });

  it(`${baseUrl} (GET): Error when getting TaskingRequest of organization to which user does not belong`, async () => {
    const target = fixtureTaskingRequests.find(
      (x) => x.organizationId == TEST_ANOTHER_ORGANIZATION_ID,
    );
    const res: request.Response = await request
      .default(httpServer)
      .get(`${baseUrl}/${target.id}`)
      .set('Content-Type', 'application/json')
      .send();
    expect(res.status).toEqual(404);
  });
  it(`${baseUrl} (GET): Error when getting AOI of organization to which user does not belong`, async () => {
    const target = taskingRequests[0];
    const res: request.Response = await request
      .default(httpServer)
      .get(
        `${baseUrl}/${target.id}?organizationId=${TEST_ANOTHER_ORGANIZATION_ID}`,
      )
      .set('Content-Type', 'application/json')
      .send();
    expect(res.status).toEqual(400);
  });

  it(`${baseUrl}/search (GET): If you search createdAt with the condition of before the next day, you can get what was registered in the above test`, async () => {
    const a = addDays(new Date(), 1);

    const res: request.Response = await request
      .default(httpServer)
      .get(`${baseUrl}/search`)
      .set('Content-Type', 'application/json')
      .query({
        'filter.createdAt': `$lte:${a.toJSON()}`,
        sortBy: 'createdAt:ASC',
      })
      .send();
    expect(res.status).toEqual(200);

    const sameOrgList = fixtureTaskingRequests.filter(
      (x) => x.organizationId == TEST_ORGANIZATION_ID,
    );
    const gotData = res.body as Paginated<TaskingRequest>;
    expect(gotData.data.length).toEqual(
      taskingRequests.length + sameOrgList.length,
    );
    expect(gotData.data.map((x) => x.id).sort()).toEqual(
      taskingRequests
        .map((x) => x.id)
        .concat(sameOrgList.map((x) => x.id))
        .sort(),
    );
  });

  it(`${baseUrl} (DELETE): Successful soft deletion`, async () => {
    const target = taskingRequests[0];
    const res: request.Response = await request
      .default(httpServer)
      .delete(`${baseUrl}/${target.id}`)
      .set('Content-Type', 'application/json');

    expect(res.status).toEqual(200);
    const gotData = res.body as TaskingRequest;

    expect(gotData.deletedAt).not.toBeNull();

    const softDeletedFalse = await dataSource.getRepository(Aoi).find({
      where: { id: In(target.aois.map((x) => x.id)) },
      relations: {
        taskingRequests: true,
      },
    });
    softDeletedFalse.reduce((p, c) => {
      expect(c.taskingRequests.length).toEqual(0);
      return p;
    }, Promise.resolve());
    const softDeletedTrue = await dataSource.getRepository(Aoi).find({
      where: { id: In(target.aois.map((x) => x.id)) },
      relations: {
        taskingRequests: true,
      },
      withDeleted: true,
    });
    softDeletedTrue.reduce((p, c) => {
      expect(c.taskingRequests.length).toEqual(1);
      return p;
    }, Promise.resolve());
  });

  it(`${baseUrl} (DELETE): can not be logically deleted, when different organizationId`, async () => {
    const target = fixtureTaskingRequests.filter(
      (x) => x.organizationId == TEST_ANOTHER_ORGANIZATION_ID,
    )[0];
    const res: request.Response = await request
      .default(httpServer)
      .delete(`${baseUrl}/${target.id}`)
      .set('Content-Type', 'application/json');

    expect(res.status).toEqual(404);

    const found = await dataSource.manager.findOne(TaskingRequest, {
      where: { id: target.id },
    });
    expect(found).toBeTruthy();
    expect(found.deletedAt).toBeNull();
  });
});
