import { NestFactory } from '@nestjs/core';
import { DataSource, EntityManager, EntityTarget } from 'typeorm';
import { validateOrReject } from 'class-validator';
import { useContainer as useValidatorContainer } from 'class-validator';
import { allFixtures } from './fixtures';
import { TestEnvModule } from './test-env-module';

export const setUpTestData = async (ds: DataSource, mode: string) => {
  await Object.entries(allFixtures)
    .filter((x) => {
      return (
        mode == 'all' ||
        mode in x[1] ||
        (mode == 'fixture' && !('seed' in x[1]))
      );
    })
    //.filter((x) => !('custom' in x[1]))
    .reduce(async (p, c) => {
      await p;
      if ('m' in c[1]) {
        await c[1].m(ds, c[1].data);
      } else {
        await setupTestDataImpl(
          ds.createEntityManager(),
          c[1].entity,
          c[1].data,
        );
      }

      return;
    }, Promise.resolve());
};

const setupTestDataImpl = async <Entity>(
  em: EntityManager,
  entityClass: EntityTarget<Entity>,
  fixtures: Entity[],
): Promise<Entity[]> => {
  const testData = await fixtures.reduce(async (p, c) => {
    const rtn = await p;
    await validateOrReject(c as any);
    const tmp = em.create(entityClass, c);
    rtn.push(tmp);
    return rtn;
  }, Promise.resolve(new Array<any>()));
  await em.insert(entityClass, testData);
  return testData;
};

const main = async () => {
  let [mode] = process.argv.length >= 3 ? process.argv.splice(2) : [];
  mode ||= 'all';
  console.log('prepareTestData', mode);
  const app = await NestFactory.create(TestEnvModule, {});
  useValidatorContainer(app.select(TestEnvModule), { fallbackOnErrors: true });
  const ds = app.get(DataSource);
  await setUpTestData(ds, mode);
  await ds.destroy();
  await app.close();
  return;
};

if (require.main === module) {
  main();
}
