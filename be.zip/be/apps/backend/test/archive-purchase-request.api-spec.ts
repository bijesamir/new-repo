import request from 'supertest';
import { plainToInstance } from 'class-transformer';
import { OrderDto } from '../src/models/dto/order/order.dto';
import { DownloadableStatus, OrderStatus } from '@iris-lib/constants';
import { BaseFeeDataType } from '@syns-platform/citadel-grpc-js';

describe('order apis', () => {
  const reviewUrl = '/orders/review';
  const orderUrl = '/orders';
  const cid = process.env.API_TEST_CONTRACT_ARCHIVE_NEW_SR;
  const cid2 = process.env.API_TEST_CONTRACT_ARCHIVE_NEW_L2;
  const cid5 = process.env.API_TEST_CONTRACT_ARCHIVE_NEW_L5;
  const cid6 = process.env.API_TEST_CONTRACT_ARCHIVE_NEW_L6;
  const cid10 = process.env.API_TEST_CONTRACT_ARCHIVE_NEW_L10;
  const cid11 = process.env.API_TEST_CONTRACT_ARCHIVE_NEW_L11;
  const cidAN = process.env.API_TEST_CONTRACT_ARCHIVE_NEW;
  const cidA = process.env.API_TEST_CONTRACT_ARCHIVE_ONLY;
  const cidASR = process.env.API_TEST_CONTRACT_ARCHIVE_ONLY_SR;
  //const cidN_SL = process.env.API_TEST_CONTRACT_NEW_SL_ONLY;
  const cidLC = process.env.API_TEST_CONTRACT_LESS_CONSUMPTION;
  const cidNo = process.env.API_TEST_CONTRACT_NOT_ARCHIVE;

  const itemSM_A = process.env.API_TEST_ITEM_SM_A;
  const itemSL_A = process.env.API_TEST_ITEM_SL_A;
  const itemSM_N = process.env.API_TEST_ITEM_SM_N;
  const itemInv = 'StriX-99_INVALID_SX';

  let token = null;

  beforeAll(async () => {
    const response = await request(process.env.CITADEL_HTTP_URL)
      .post('/v1/identity/credentials')
      .set('Content-Type', 'application/json')
      .send({
        email: process.env.API_TEST_EMAIL,
        password: process.env.API_TEST_PASS,
      });
    token = response.body.IdentityToken;
  });

  const multiItems1 = [
    {
      itemId: itemSM_N,
      productDetails: [
        {
          productFormat: 1,
          resolutionMode: 1,
        },
        {
          productFormat: 2,
          resolutionMode: 1,
        },
        {
          productFormat: 1,
          resolutionMode: 2,
        },
      ],
    },
    {
      itemId: itemSM_A,
      productDetails: [
        {
          productFormat: 1,
          resolutionMode: 1,
        },
        {
          productFormat: 2,
          resolutionMode: 1,
        },
        {
          productFormat: 1,
          resolutionMode: 2,
        },
      ],
    },
  ];
  const multiItems2 = [
    {
      itemId: itemSL_A,
      productDetails: [
        {
          productFormat: 1,
          resolutionMode: 1,
        },
      ],
    },
    {
      itemId: itemSM_A,
      productDetails: [
        {
          productFormat: 1,
          resolutionMode: 2,
        },
      ],
    },
  ];

  //this test case should be done before review,
  // because will check review response include previouslyOrdered flag: true.
  it.each([
    [cid, multiItems1, 350000, 250000, 600000],
    [cid10, multiItems1, 425000, 275000, 700000],
    [cid, multiItems2, 75000, 250000, 325000],
    [cid2, multiItems2, 90000, 260000, 350000],
  ])(
    `multi item check  %s %s %d %d :%d`,
    async (
      contractId,
      items,
      exp0,
      exp1,
      expTotal,
      expVerify = /ok/,
      expError = /.*/,
    ) => {
      let response = await request(process.env.IRIS_API_URL)
        .post(reviewUrl)
        .set('Content-Type', 'application/json')
        .set('Cookie', `iat=${token}`)
        .send({
          contractId,
          items,
        });
      if (response.status !== 200 && response.status !== 201) {
        console.log('Error details:', response.body);
        expect(response.body.message).toMatch(expError);
      } else {
        expect(response.body).toMatchObject({
          totalConsumptionCredit: expTotal,
          remainingCredit: expect.any(Number),
          verifyStatus: expect.stringMatching(expVerify),
          verifyResults: expect.arrayContaining([
            expect.objectContaining({
              taskId: expect.any(String),
              consumptionCredit: exp0,
            }),
            expect.objectContaining({
              taskId: expect.any(String),
              consumptionCredit: exp1,
            }),
          ]),
        });
      }
      expect(response.status).toBe(200);

      response = await request(process.env.IRIS_API_URL)
        .post(orderUrl)
        .set('Content-Type', 'application/json')
        .set('Cookie', `iat=${token}`)
        .send({
          contractId,
          items,
        });

      if (response.status !== 200 && response.status !== 201) {
        console.log('Error details:', response.body);
        expect(response.body.message).toMatch(expError);
      } else {
        const orderDto = plainToInstance(OrderDto, response.body);
        expect(orderDto).toMatchObject({
          id: expect.any(String),
          requestId: expect.any(String),
          orderedUserId: expect.any(String),
          status: OrderStatus.New,
          organizationId: expect.any(Number),
          contractId: expect.any(Number),
          createdAt: expect.any(Date),
          downloadExpired: expect.any(Date),
          downloadableStatus: DownloadableStatus.NotReady,
          payment: expect.objectContaining({
            totalConsumptionCredit: expTotal,
            remainingCredit: expect.any(Number),
            results: expect.arrayContaining([
              expect.objectContaining({
                taskId: expect.any(String),
                registrationId: expect.any(Number),
                consumptionCredit: exp0,
              }),
              expect.objectContaining({
                taskId: expect.any(String),
                registrationId: expect.any(Number),
                consumptionCredit: exp1,
              }),
            ]),
          }),
        });
      }
      expect(response.status).toBe(201);
    },
  );

  it.each([
    [cid, itemSM_N, 1, 1, 150000, BaseFeeDataType.NEWACQUISITION],
    [cid2, itemSM_N, 1, 1, 180000, BaseFeeDataType.NEWACQUISITION],
    [cid5, itemSM_N, 1, 1, 180000, BaseFeeDataType.NEWACQUISITION],
    [cid6, itemSM_N, 1, 1, 225000, BaseFeeDataType.NEWACQUISITION],
    [cid10, itemSM_N, 1, 1, 225000, BaseFeeDataType.NEWACQUISITION],
    [cid11, itemSM_N, 1, 1, 450000, BaseFeeDataType.NEWACQUISITION],
    [cid, itemSM_A, 1, 1, 50000, BaseFeeDataType.ARCHIVE],
    [cid2, itemSM_A, 1, 1, 60000, BaseFeeDataType.ARCHIVE],
    [cid5, itemSM_A, 1, 1, 60000, BaseFeeDataType.ARCHIVE],
    [cid6, itemSM_A, 1, 1, 75000, BaseFeeDataType.ARCHIVE],
    [cid10, itemSM_A, 1, 1, 75000, BaseFeeDataType.ARCHIVE],
    [cid11, itemSM_A, 1, 1, 150000, BaseFeeDataType.ARCHIVE],
    [cid, itemSL_A, 1, 1, 75000, BaseFeeDataType.ARCHIVE],
    [cid2, itemSL_A, 1, 1, 90000, BaseFeeDataType.ARCHIVE],
    [cid5, itemSL_A, 1, 1, 90000, BaseFeeDataType.ARCHIVE],
    [cid6, itemSL_A, 1, 1, 112500, BaseFeeDataType.ARCHIVE],
    [cid10, itemSL_A, 1, 1, 112500, BaseFeeDataType.ARCHIVE],
    [cid11, itemSL_A, 1, 1, 225000, BaseFeeDataType.ARCHIVE],
    [cidA, itemSM_N, 1, 1, 150000, BaseFeeDataType.NEWACQUISITION],
    [cid, itemSM_N, 1, 2, 350000, BaseFeeDataType.NEWACQUISITION],
    [cid2, itemSM_N, 1, 2, 380000, BaseFeeDataType.NEWACQUISITION],
    [cid5, itemSM_N, 1, 2, 380000, BaseFeeDataType.NEWACQUISITION],
    [cid6, itemSM_N, 1, 2, 425000, BaseFeeDataType.NEWACQUISITION],
    [cid10, itemSM_N, 1, 2, 425000, BaseFeeDataType.NEWACQUISITION],
    [cid11, itemSM_N, 1, 2, 650000, BaseFeeDataType.NEWACQUISITION],
    [cidAN, itemSM_N, 1, 2, 350000, BaseFeeDataType.NEWACQUISITION],
    [cidASR, itemSM_N, 1, 2, 350000, BaseFeeDataType.NEWACQUISITION],
    [cid, itemSM_A, 1, 2, 250000, BaseFeeDataType.ARCHIVE],
    [cidA, itemSM_A, 1, 2, 250000, BaseFeeDataType.ARCHIVE],
    [cid2, itemSM_A, 1, 2, 260000, BaseFeeDataType.ARCHIVE],
    [cid5, itemSM_A, 1, 2, 260000, BaseFeeDataType.ARCHIVE],
    [cid6, itemSM_A, 1, 2, 275000, BaseFeeDataType.ARCHIVE],
    [cid10, itemSM_A, 1, 2, 275000, BaseFeeDataType.ARCHIVE],
    [cid11, itemSM_A, 1, 2, 350000, BaseFeeDataType.ARCHIVE],
    [cid, itemSL_A, 1, 2, 275000, BaseFeeDataType.ARCHIVE],
    [cidASR, itemSL_A, 1, 2, 275000, BaseFeeDataType.ARCHIVE],
    [cidA, itemSL_A, 1, 2, 275000, BaseFeeDataType.ARCHIVE],
    [cid2, itemSL_A, 1, 2, 290000, BaseFeeDataType.ARCHIVE],
    [cid5, itemSL_A, 1, 2, 290000, BaseFeeDataType.ARCHIVE],
    [cid6, itemSL_A, 1, 2, 312500, BaseFeeDataType.ARCHIVE],
    [cid10, itemSL_A, 1, 2, 312500, BaseFeeDataType.ARCHIVE],
    [cid11, itemSL_A, 1, 2, 425000, BaseFeeDataType.ARCHIVE],
    [cidLC, itemSM_A, 1, 1, 50000, BaseFeeDataType.ARCHIVE, /insufficient$/],
    [cid, itemInv, 1, 1, 0, -1, '', 400],
    [cidNo, itemSM_A, 1, 1, 0, -1, /h/, 400],
  ])(
    `${reviewUrl}(POST) %s %s %d %d %d %d %s:%d`,
    async (
      contractId,
      itemId,
      productFormat,
      resolutionMode,
      expTotal,
      expDataType = BaseFeeDataType.ARCHIVE,
      expVerify = /ok/,
      expStatus = 200,
    ) => {
      const response = await request(process.env.IRIS_API_URL)
        .post(reviewUrl)
        .set('Content-Type', 'application/json')
        .set('Cookie', `iat=${token}`)
        .send({
          contractId,
          items: [
            {
              itemId,
              productDetails: [
                {
                  productFormat,
                  resolutionMode,
                },
              ],
            },
          ],
        });
      if (response.status !== 200 && response.status !== 201) {
        console.log('Error details:', response.body);
      } else {
        expect(response.body).toMatchObject({
          totalConsumptionCredit: expTotal,
          remainingCredit: expect.any(Number),
          verifyStatus: expect.stringMatching(expVerify),
          verifyResults: expect.arrayContaining([
            expect.objectContaining({
              taskId: expect.any(String),
              consumptionCredit: expect.any(Number),
              dataSourceType: expDataType,
              imagingMode: expect.any(Number),
              numberOfLicense: expect.any(Number),
              options: expect.any(Array),
              itemId: itemId,
              previouslyOrdered: true,
            }),
          ]),
        });
      }
      expect(response.status).toBe(expStatus);
    },
  );

  it.each([
    [cid, itemSM_N, 1, 1, 150000],
    [cid2, itemSM_N, 1, 1, 180000],
    [cid5, itemSM_N, 1, 1, 180000],
    [cid6, itemSM_N, 1, 1, 225000],
    [cid10, itemSM_N, 1, 1, 225000],
    [cid11, itemSM_N, 1, 1, 450000],
    [cid, itemSM_A, 1, 1, 50000],
    [cid2, itemSM_A, 1, 1, 60000],
    [cid5, itemSM_A, 1, 1, 60000],
    [cid6, itemSM_A, 1, 1, 75000],
    [cid10, itemSM_A, 1, 1, 75000],
    [cid11, itemSM_A, 1, 1, 150000],
    [cid, itemSL_A, 1, 1, 75000],
    [cid2, itemSL_A, 1, 1, 90000],
    [cid5, itemSL_A, 1, 1, 90000],
    [cid6, itemSL_A, 1, 1, 112500],
    [cid10, itemSL_A, 1, 1, 112500],
    [cid11, itemSL_A, 1, 1, 225000],
    [cidA, itemSM_N, 1, 1, 150000],
    [cid, itemSM_N, 1, 2, 350000],
    [cid2, itemSM_N, 1, 2, 380000],
    [cid5, itemSM_N, 1, 2, 380000],
    [cid6, itemSM_N, 1, 2, 425000],
    [cid10, itemSM_N, 1, 2, 425000],
    [cid11, itemSM_N, 1, 2, 650000],
    [cidAN, itemSM_N, 1, 2, 350000],
    [cidASR, itemSM_N, 1, 2, 350000],
    [cid, itemSM_A, 1, 2, 250000],
    [cidA, itemSM_A, 1, 2, 250000],
    [cid2, itemSM_A, 1, 2, 260000],
    [cid5, itemSM_A, 1, 2, 260000],
    [cid6, itemSM_A, 1, 2, 275000],
    [cid10, itemSM_A, 1, 2, 275000],
    [cid11, itemSM_A, 1, 2, 350000],
    [cid, itemSL_A, 1, 2, 275000],
    [cidASR, itemSL_A, 1, 2, 275000],
    [cidA, itemSL_A, 1, 2, 275000],
    [cid2, itemSL_A, 1, 2, 290000],
    [cid5, itemSL_A, 1, 2, 290000],
    [cid6, itemSL_A, 1, 2, 312500],
    [cid10, itemSL_A, 1, 2, 312500],
    [cid11, itemSL_A, 1, 2, 425000],
    [cidLC, itemSM_A, 1, 1, 0, 400],
    [cid, itemInv, 1, 1, 0, 400],
    [cidNo, itemSM_A, 1, 1, 0, 400],
  ])(
    `${orderUrl}  %s %s %d %d :%d`,
    async (
      contractId,
      itemId,
      productFormat,
      resolutionMode,
      expTotal,
      expStatus = 201,
    ) => {
      const response = await request(process.env.IRIS_API_URL)
        .post(orderUrl)
        .set('Content-Type', 'application/json')
        .set('Cookie', `iat=${token}`)
        .send({
          contractId,
          items: [
            {
              itemId,
              productDetails: [
                {
                  productFormat,
                  resolutionMode,
                },
              ],
            },
          ],
        });

      if (response.status !== 200 && response.status !== 201) {
        console.log('Error details:', response.body);
      } else {
        const orderDto = plainToInstance(OrderDto, response.body);
        expect(orderDto).toMatchObject({
          id: expect.any(String),
          requestId: expect.any(String),
          orderedUserId: expect.any(String),
          status: OrderStatus.New,
          organizationId: expect.any(Number),
          contractId: expect.any(Number),
          createdAt: expect.any(Date),
          downloadExpired: expect.any(Date),
          downloadableStatus: DownloadableStatus.NotReady,
          payment: expect.objectContaining({
            totalConsumptionCredit: expTotal,
            remainingCredit: expect.any(Number),
            results: expect.arrayContaining([
              expect.objectContaining({
                taskId: expect.any(String),
                registrationId: expect.any(Number),
                consumptionCredit: expect.any(Number),
              }),
            ]),
            /* TODO: verifyResults is not returned
          verifyResults: expect.arrayContaining([
            expect.objectContaining({
              taskId: expect.any(String),
              consumptionCredit: expect.any(Number),
              dataSourceType: expect.any(Number),
              imagingMode: expect.any(Number),
              numberOfLicense: expect.any(Number),
              options: expect.any(Array),
            }),
          ]),
          */
          }),
        });
      }
      expect(response.status).toBe(expStatus);
    },
  );
});
