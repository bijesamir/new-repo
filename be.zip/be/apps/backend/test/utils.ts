import { TypeOrmModule, TypeOrmModuleOptions } from '@nestjs/typeorm';
import { LoggerModule } from '@iris-lib/logger';
import { DataSource } from 'typeorm';

import { AppConfigModule } from '../src/config/app-config.module';
import { Logger, ModuleMetadata } from '@nestjs/common';
import { ValidatorsModule } from '../src/validators/validators.module';
import { CacheManageModule } from '../src/infra/cache-manage/cache-manage.module';
import { createId } from '@paralleldrive/cuid2';
import { IsArray } from 'class-validator';
import { ScsOrderStatus } from '@iris-lib/constants';
import { ScsCandidateDto } from '../src/models/dto/mission-portal/scs-candidate.dto';
import { TaskingInfo, TaskingRequest } from '@iris-lib/db/entities';
import { Type } from 'class-transformer';
import { PickType } from '@nestjs/swagger';
import { Test, TestingModuleBuilder } from '@nestjs/testing';
import { AppModule } from '../src/app.module';
import { decorateApp } from '../src/boostrap-support';
import { IrisAuthGuard } from '../src/guards/iris-auth.guard';
import { DbConfigModule } from '@iris-lib/db/db-config.module';
import { DbConfigService } from '@iris-lib/db';
import { DummyAuthGuard } from '@iris-lib/guards';
import { IrisRequestContext } from '@iris-lib/middlewares';
import { IrisUserDto } from '@iris-lib/models';
import { IrisContractPackage } from '@iris-lib/models/payment';

export function testModuleBase(): ModuleMetadata {
  return {
    imports: [
      AppConfigModule,
      DbConfigModule,
      LoggerModule,
      TypeOrmModule.forRootAsync({
        inject: ['DbConfig'],
        useFactory: async (configService: DbConfigService) => {
          return configService.get('db') as TypeOrmModuleOptions;
        },
      }),
      CacheManageModule,
      ValidatorsModule,
    ],
    providers: [],
    controllers: [],
  };
}

export type MockType<T> = {
  // eslint-disable-next-line @typescript-eslint/ban-types
  [P in keyof T]?: jest.Mock<{}>;
};

export const dataSourceMockFactory: () => MockType<DataSource> = jest.fn(
  () => ({
    createQueryRunner: jest.fn().mockImplementation(() => ({
      connect: jest.fn(),
      startTransaction: jest.fn(),
      release: jest.fn(),
      rollbackTransaction: jest.fn(),
      manager: {
        insert: jest.fn(),
        update: jest.fn(),
        delete: jest.fn(),
        softRemove: jest.fn(),
      },
    })),
  }),
);

export const mockRepo = {
  metadata: {
    connection: {
      options: { type: '' },
    },
    columns: [{ propertyName: 'id', isPrimary: true }],
    relations: [],
  },
};

export const testModuleDataSourceMockBase = (): ModuleMetadata => {
  return {
    imports: [AppConfigModule, LoggerModule],
    providers: [
      {
        provide: DataSource,
        useFactory: dataSourceMockFactory,
      },
    ],
    controllers: [],
    exports: [],
  };
};

export const createAppForE2ETest = async (
  overrideFunction?: (m: TestingModuleBuilder) => void,
) => {
  const m = Test.createTestingModule({
    imports: [AppModule], // I think this is the simplest and best.
  })
    .overrideProvider(IrisAuthGuard)
    .useClass(DummyAuthGuard);
  if (overrideFunction) {
    overrideFunction(m);
  }

  const tm = await m.compile();
  tm.useLogger(new Logger());
  return await decorateApp(
    tm.createNestApplication({ forceCloseConnections: true }),
  );
};

export const mockIrisRequestContext_get = (
  dummy_user: IrisUserDto,
  dummy_contracts: IrisContractPackage[],
): jest.Mock =>
  jest.fn().mockReturnValue({
    req: {
      requestId: createId(),
      currentUser: dummy_user,
      currentContracts: dummy_contracts,
    } as IrisRequestContext,
    res: {},
  });

export class TaskingInfoListDtoForTest {
  @IsArray()
  @Type(() => TaskingInfo)
  items: TaskingInfo[];
}

export class TaskingRequestInputDataForTest extends PickType(TaskingRequest, [
  'priority',
  'imagingMode',
  'lookingDirection',
  'flightDirection',
  'offnadirAngleMin',
  'offnadirAngleMax',
  'productDetails',
  'organizationId',
  'contractId',
  'polarization',
  'scenes',
]) {
  aoiIds: string[];
}

export const mockDataScsOrderResponseDto = (
  orderId: string,
  code: string,
  status: ScsOrderStatus,
  takingRequest: TaskingRequestInputDataForTest,
  scsCandidateDto: ScsCandidateDto,
) => {
  return {
    orderId: orderId,
    orderCode: code,
    aoiId: null,
    customerOrgID: takingRequest.organizationId.toString(),
    orderStatus: status,
    basePriority: takingRequest.priority,
    currentPriority: takingRequest.priority, // TODO Not understanding the difference between base and current
    centerPosition:
      scsCandidateDto.observationArea.obsCenterPosition.getScsPointDto(),
    imagingMode: scsCandidateDto.observationTiming.orbitParams.imagingMode,
    polarization: scsCandidateDto.observationTiming.orbitParams.polarization,
    startOBCTime: scsCandidateDto.observationTiming.obsStartTime,
    endOBCTime: scsCandidateDto.observationTiming.obsEndTime,
    pathDirection: scsCandidateDto.observationTiming.orbitParams.pathDirection,
    sightDirection:
      scsCandidateDto.observationTiming.orbitParams.sightDirection,
    offnadirAngle: scsCandidateDto.observationTiming.orbitParams.offNadir,
    satId: scsCandidateDto.satelliteInfo.satId,
  };
};
